package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.ui.MainAdminApp
import com.example.ui.theme.ADAdminTheme

/**
 * Root Activity for AD Tournament Admin application.
 * Boots edge-to-edge Compose rendering with the Navy & Gold esports theme
 * and authoritative Super Admin session state observation.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ADAdminTheme {
                MainAdminApp()
            }
        }
    }
}

