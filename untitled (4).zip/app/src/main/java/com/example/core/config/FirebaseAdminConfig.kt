package com.example.core.config

/**
 * Authoritative Firebase backend configuration metadata for AD TOURNAMENT.
 * Shared with the authoritative backend and User App.
 */
object FirebaseAdminConfig {
    const val FIREBASE_PROJECT_NAME = "ADTURNAMENT"
    const val FIREBASE_PROJECT_ID = "adturnamet"
    const val RTDB_REGION = "asia-southeast1"
    const val RTDB_BASE_URL = "https://adturnamet-default-rtdb.asia-southeast1.firebasedatabase.app"
    
    // Established Realtime Database Nodes
    const val NODE_USERS = "users"
    const val NODE_MATCHES = "matches"
    const val NODE_DEPOSITS = "deposits"
    const val NODE_USER_DEPOSITS = "userDeposits"
    const val NODE_WALLETS = "wallets"
    const val NODE_TRANSACTIONS = "transactions"
    const val NODE_USER_TRANSACTIONS = "userTransactions"
    const val NODE_WITHDRAWALS = "withdrawals"
    const val NODE_RESULTS = "results"
    const val NODE_AUDIT_LOGS = "auditLogs"
    const val NODE_MATCH_PLAYERS = "matchPlayers"
    const val NODE_APP_SETTINGS = "appSettings"
    
    // Strict Single Super Admin Enforcement
    const val SUPER_ADMIN_ROLE_NAME = "Super Admin"
    const val IS_SINGLE_SUPER_ADMIN_ENFORCED = true
    const val FALLBACK_SUPER_ADMIN_UID = "GuIxwtI4hLQIoKOOt3V2XKnFhiB2"
    const val NODE_ADMINS = "admins"
    
    // Security flags for the foundation stage
    const val CLIENT_MUTATIONS_LOCKED = true
    const val BACKEND_AUTHORITATIVE_ENFORCED = true
}
