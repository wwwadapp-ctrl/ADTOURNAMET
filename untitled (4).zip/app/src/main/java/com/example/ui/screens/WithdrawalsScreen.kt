package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.navigation.AdminSection
import com.example.ui.components.SectionHeader
import com.example.ui.components.SectionShellHeroCard
import com.example.ui.components.SecurityLockNotice
import com.example.ui.components.StructuralQueueCard

@Composable
fun WithdrawalsScreen(
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        SectionHeader(
            title = AdminSection.WITHDRAWALS.title,
            subtitle = AdminSection.WITHDRAWALS.subtitle,
            icon = AdminSection.WITHDRAWALS.icon
        )

        SectionShellHeroCard(
            section = AdminSection.WITHDRAWALS,
            statusText = "DISBURSEMENT AUDIT QUEUE"
        )

        SecurityLockNotice(
            title = "Strict Two-Way Withdrawal Reconciliation",
            description = "Withdrawal approvals lock player winning balances and trigger authoritative disbursement audits. Normal client apps have zero access to approve disbursements."
        )

        StructuralQueueCard(
            title = "Pending Payout Requests",
            items = listOf(
                "Req #W-9021 • ৳1,500 (bKash 017XXXXXXXX)" to "Awaiting Super Admin",
                "Req #W-9022 • ৳800 (Nagad 018XXXXXXXX)" to "Awaiting Super Admin",
                "Req #W-9023 • ৳2,000 (Rocket 019XXXXXXXX)" to "Under Review"
            ),
            badgeLabel = "SUPER ADMIN REVIEW"
        )

        Spacer(modifier = Modifier.height(20.dp))
    }
}
