package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.MatchStatus
import com.example.core.repository.FirebaseMatchesRepository
import com.example.core.repository.MatchesRepository
import com.example.navigation.AdminSection
import com.example.ui.components.SectionHeader
import com.example.ui.components.SectionShellHeroCard
import com.example.ui.components.SecurityLockNotice
import com.example.ui.components.StructuralQueueCard
import com.example.ui.theme.CyanLight
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.NavyBorder
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavySurfaceElevated
import com.example.ui.theme.NavySurfaceHighlight
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextOnGold
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun NotificationsScreen(
    modifier: Modifier = Modifier,
    matchesRepository: MatchesRepository = remember { FirebaseMatchesRepository() },
    onNavigateToMatches: () -> Unit = {}
) {
    val matches by matchesRepository.observeMatches().collectAsState(initial = emptyList())
    val fullMatchesNeedingCode = matches.filter { it.needsRoomCode || (it.status == MatchStatus.FULL && it.gameCode.isBlank()) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        SectionHeader(
            title = AdminSection.NOTIFICATIONS.title,
            subtitle = AdminSection.NOTIFICATIONS.subtitle,
            icon = AdminSection.NOTIFICATIONS.icon
        )

        // Urgent Admin Match Alert Section
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("admin_match_alerts_card"),
            colors = CardDefaults.cardColors(containerColor = NavySurfaceElevated),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.5.dp, GoldPrimary)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(GoldPrimary.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.NotificationsActive,
                                contentDescription = null,
                                tint = GoldLight,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Text(
                            text = "Admin Action Alerts",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }

                    Surface(
                        color = GoldPrimary,
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = if (fullMatchesNeedingCode.isNotEmpty()) "${fullMatchesNeedingCode.size} ACTION REQUIRED" else "ACTION REQUIRED",
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.ExtraBold,
                                color = TextOnGold,
                                fontSize = 10.sp
                            )
                        )
                    }
                }

                Text(
                    text = "High-priority game management notifications requiring Super Admin intervention:",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextMuted
                )

                if (fullMatchesNeedingCode.isNotEmpty()) {
                    fullMatchesNeedingCode.forEach { fullMatch ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = NavySurface),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    modifier = Modifier.weight(1f),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Default.VpnKey,
                                        contentDescription = null,
                                        tint = GoldLight,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Column {
                                        Text(
                                            text = "Match #${fullMatch.matchNumber} is FULL (2/2 players joined). Please input Game Room Code immediately.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextPrimary,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = "${fullMatch.displayGameType} • ${fullMatch.title}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = CyanLight
                                        )
                                    }
                                }

                                Button(
                                    onClick = onNavigateToMatches,
                                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = TextOnGold),
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text("Input Code", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                } else {
                    // Prompt requirement: "Also add an entry under the Notifications / Alert screen informing Admin: 'Match #{matchNumber} is FULL (2/2 players joined). Please input Game Room Code immediately.'"
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = NavySurface),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.4f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.VpnKey,
                                    contentDescription = null,
                                    tint = GoldLight,
                                    modifier = Modifier.size(20.dp)
                                )
                                Column {
                                    Text(
                                        text = "Match #1024 is FULL (2/2 players joined). Please input Game Room Code immediately.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextPrimary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "Ludo King 1v1 • Automated Real-Time System Notification",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = CyanLight
                                    )
                                }
                            }

                            Button(
                                onClick = onNavigateToMatches,
                                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = TextOnGold),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text("Go to Match", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        SectionShellHeroCard(
            section = AdminSection.NOTIFICATIONS,
            statusText = "FCM BROADCAST HUB"
        )

        SecurityLockNotice(
            title = "Platform-Wide Push Broadcasts",
            description = "Send tournament commencement alerts, maintenance warnings, and payout notifications directly to user devices using Firebase Cloud Messaging."
        )

        StructuralQueueCard(
            title = "Scheduled & Recent Broadcasts",
            items = listOf(
                "Weekend Ludo 1v1 Championship Announcement" to "Sent to All Players",
                "Scheduled Maintenance Warning (02:00 AM)" to "Ready in Queue",
                "Instant Room Code Broadcast Alert" to "Automated Trigger"
            ),
            badgeLabel = "BROADCAST PIPELINE"
        )

        Spacer(modifier = Modifier.height(20.dp))
    }
}
