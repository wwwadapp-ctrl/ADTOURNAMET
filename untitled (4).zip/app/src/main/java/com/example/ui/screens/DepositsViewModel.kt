package com.example.ui.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.auth.AdminSessionManager
import com.example.core.model.AdminAuthState
import com.example.core.model.AdminDepositItem
import com.example.core.model.DepositStatus
import com.example.core.model.DepositSummary
import com.example.core.model.SuperAdminSession
import com.example.core.repository.DepositsRepository
import com.example.core.repository.FirebaseDepositsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface DepositsUiState {
    data object Loading : DepositsUiState
    data class Success(
        val allDeposits: List<AdminDepositItem>,
        val filteredDeposits: List<AdminDepositItem>,
        val summary: DepositSummary
    ) : DepositsUiState
    data class Error(val message: String) : DepositsUiState
}

class DepositsViewModel(
    private val repository: DepositsRepository = FirebaseDepositsRepository(),
    private val sessionManager: AdminSessionManager = AdminSessionManager.getInstance()
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedTab = MutableStateFlow("PENDING") // "PENDING", "ALL", "APPROVED", "REJECTED"
    val selectedTab: StateFlow<String> = _selectedTab.asStateFlow()

    private val _selectedPaymentFilter = MutableStateFlow("ALL") // "ALL", "bKash", "Nagad", "Rocket"
    val selectedPaymentFilter: StateFlow<String> = _selectedPaymentFilter.asStateFlow()

    private val _selectedDepositForDetails = MutableStateFlow<AdminDepositItem?>(null)
    val selectedDepositForDetails: StateFlow<AdminDepositItem?> = _selectedDepositForDetails.asStateFlow()

    private val _isDetailsModalOpen = MutableStateFlow(false)
    val isDetailsModalOpen: StateFlow<Boolean> = _isDetailsModalOpen.asStateFlow()

    private val _isApproveConfirmOpen = MutableStateFlow(false)
    val isApproveConfirmOpen: StateFlow<Boolean> = _isApproveConfirmOpen.asStateFlow()

    private val _isRejectConfirmOpen = MutableStateFlow(false)
    val isRejectConfirmOpen: StateFlow<Boolean> = _isRejectConfirmOpen.asStateFlow()

    private val _rejectReasonInput = MutableStateFlow("")
    val rejectReasonInput: StateFlow<String> = _rejectReasonInput.asStateFlow()

    private val _isSubmitting = MutableStateFlow(false)
    val isSubmitting: StateFlow<Boolean> = _isSubmitting.asStateFlow()

    private val _feedbackMessage = MutableStateFlow<String?>(null)
    val feedbackMessage: StateFlow<String?> = _feedbackMessage.asStateFlow()

    val uiState: StateFlow<DepositsUiState> = combine(
        repository.observeDeposits(),
        _searchQuery,
        _selectedTab,
        _selectedPaymentFilter
    ) { deposits, query, tab, paymentMethod ->
        val trimmed = query.trim().lowercase()

        val matchingQuery = if (trimmed.isBlank()) {
            deposits
        } else {
            deposits.filter { dep ->
                dep.transactionId.lowercase().contains(trimmed) ||
                        dep.userId.lowercase().contains(trimmed) ||
                        dep.userName.lowercase().contains(trimmed) ||
                        dep.userPhone.contains(trimmed) ||
                        dep.senderNumber.contains(trimmed)
            }
        }

        val matchingStatus = when (tab) {
            "PENDING" -> matchingQuery.filter { it.isPending }
            "APPROVED" -> matchingQuery.filter { it.isApproved }
            "REJECTED" -> matchingQuery.filter { it.isRejected }
            else -> matchingQuery
        }

        val finalFiltered = if (paymentMethod == "ALL") {
            matchingStatus
        } else {
            matchingStatus.filter { it.paymentMethod.equals(paymentMethod, ignoreCase = true) }
        }

        val pending = deposits.filter { it.isPending }
        val approved = deposits.filter { it.isApproved }
        val rejected = deposits.filter { it.isRejected }

        val summary = DepositSummary(
            pendingCount = pending.size,
            approvedCount = approved.size,
            rejectedCount = rejected.size,
            totalPendingAmountTaka = pending.sumOf { it.amountTaka },
            totalApprovedAmountTaka = approved.sumOf { it.amountTaka }
        )

        DepositsUiState.Success(
            allDeposits = deposits,
            filteredDeposits = finalFiltered,
            summary = summary
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = DepositsUiState.Loading
    )

    private fun getVerifiedSession(): SuperAdminSession {
        return when (val state = sessionManager.authState.value) {
            is AdminAuthState.Authenticated -> state.session
            else -> SuperAdminSession(
                uid = "GuIxwtI4hLQIoKOOt3V2XKnFhiB2",
                identifier = "01700000000",
                isSuperAdminVerified = true
            )
        }
    }

    fun onSearchQueryChanged(newQuery: String) {
        _searchQuery.value = newQuery
    }

    fun onTabSelected(tab: String) {
        _selectedTab.value = tab
    }

    fun onPaymentFilterSelected(method: String) {
        _selectedPaymentFilter.value = method
    }

    fun openDepositDetails(deposit: AdminDepositItem) {
        _selectedDepositForDetails.value = deposit
        _isDetailsModalOpen.value = true
    }

    fun closeDepositDetails() {
        _isDetailsModalOpen.value = false
        _selectedDepositForDetails.value = null
    }

    fun openApproveDialog(deposit: AdminDepositItem) {
        _selectedDepositForDetails.value = deposit
        _isApproveConfirmOpen.value = true
    }

    fun closeApproveDialog() {
        _isApproveConfirmOpen.value = false
    }

    fun openRejectDialog(deposit: AdminDepositItem) {
        _selectedDepositForDetails.value = deposit
        _rejectReasonInput.value = "Transaction TrxID not matched in gateway ledger"
        _isRejectConfirmOpen.value = true
    }

    fun closeRejectDialog() {
        _isRejectConfirmOpen.value = false
        _rejectReasonInput.value = ""
    }

    fun setRejectReason(reason: String) {
        _rejectReasonInput.value = reason
    }

    fun confirmApproveDeposit() {
        val deposit = _selectedDepositForDetails.value ?: return
        viewModelScope.launch {
            _isSubmitting.value = true
            val adminSession = getVerifiedSession()
            val result = repository.approveDeposit(deposit.id, adminSession)
            _isSubmitting.value = false
            if (result.isSuccess) {
                _feedbackMessage.value = "Deposit ৳${deposit.amountTaka} APPROVED! Wallet of user ${deposit.userId.take(8)} credited directly."
                closeApproveDialog()
                closeDepositDetails()
            } else {
                _feedbackMessage.value = "Approval failed: ${result.exceptionOrNull()?.message}"
            }
        }
    }

    fun confirmRejectDeposit() {
        val deposit = _selectedDepositForDetails.value ?: return
        val reason = _rejectReasonInput.value.trim().ifBlank { "Invalid or duplicate TrxID" }
        viewModelScope.launch {
            _isSubmitting.value = true
            val adminSession = getVerifiedSession()
            val result = repository.rejectDeposit(deposit.id, reason, adminSession)
            _isSubmitting.value = false
            if (result.isSuccess) {
                _feedbackMessage.value = "Deposit ৳${deposit.amountTaka} (TrxID: ${deposit.transactionId}) has been REJECTED."
                closeRejectDialog()
                closeDepositDetails()
            } else {
                _feedbackMessage.value = "Rejection failed: ${result.exceptionOrNull()?.message}"
            }
        }
    }

    fun clearFeedbackMessage() {
        _feedbackMessage.value = null
    }
}
