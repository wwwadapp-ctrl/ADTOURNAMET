package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.core.config.FirebaseAdminConfig
import com.example.core.model.PaymentNumberItem
import com.example.navigation.AdminSection
import com.example.ui.components.SectionHeader
import com.example.ui.components.SectionShellHeroCard
import com.example.ui.components.SecurityLockNotice
import com.example.ui.components.StructuralQueueCard
import com.example.ui.theme.CyanLight
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.NavyBorder
import com.example.ui.theme.NavyBorderLight
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyDeepest
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavySurfaceElevated
import com.example.ui.theme.NavySurfaceHighlight
import com.example.ui.theme.StatusLive
import com.example.ui.theme.StatusPending
import com.example.ui.theme.StatusRejected
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextOnGold
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Provider Identity Brand Accents
private val BkashBrandPink = Color(0xFFE2136E)
private val NagadBrandOrange = Color(0xFFF7941D)
private val RocketBrandPurple = Color(0xFF8C3494)

@Composable
fun SettingsScreen(
    modifier: Modifier = Modifier,
    viewModel: SettingsViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val isAddEditModalOpen by viewModel.isAddEditModalOpen.collectAsState()
    val editingItem by viewModel.editingItem.collectAsState()
    val isDeleteConfirmOpen by viewModel.isDeleteConfirmOpen.collectAsState()
    val deletingItem by viewModel.deletingItem.collectAsState()

    val inputMethod by viewModel.inputMethod.collectAsState()
    val inputType by viewModel.inputType.collectAsState()
    val inputNumber by viewModel.inputNumber.collectAsState()
    val inputInstructions by viewModel.inputInstructions.collectAsState()
    val inputIsActive by viewModel.inputIsActive.collectAsState()
    val isSubmitting by viewModel.isSubmitting.collectAsState()

    val depositBannerImageUrl by viewModel.depositBannerImageUrl.collectAsState()
    val howToDepositVideoUrl by viewModel.howToDepositVideoUrl.collectAsState()
    val matchJoinBannerImageUrl by viewModel.matchJoinBannerImageUrl.collectAsState()
    val howToJoinVideoUrl by viewModel.howToJoinVideoUrl.collectAsState()
    val resultSubmitBannerImageUrl by viewModel.resultSubmitBannerImageUrl.collectAsState()
    val howToSubmitResultVideoUrl by viewModel.howToSubmitResultVideoUrl.collectAsState()
    val rulesBannerImageUrl by viewModel.rulesBannerImageUrl.collectAsState()
    val tournamentRulesVideoUrl by viewModel.tournamentRulesVideoUrl.collectAsState()
    val customBannerImageUrl by viewModel.customBannerImageUrl.collectAsState()
    val isSavingTutorialSettings by viewModel.isSavingTutorialSettings.collectAsState()

    val snackbarMessage by viewModel.snackbarMessage.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current

    LaunchedEffect(snackbarMessage) {
        snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbarMessage()
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            SectionHeader(
                title = AdminSection.SETTINGS.title,
                subtitle = "bKash / Nagad Gateways & App Configuration",
                icon = AdminSection.SETTINGS.icon
            )

            SectionShellHeroCard(
                section = AdminSection.SETTINGS,
                statusText = "BROADCASTING TO USER APP"
            )

            when (val state = uiState) {
                is SettingsUiState.Loading -> {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = GoldPrimary)
                    }
                }
                is SettingsUiState.Error -> {
                    Text(
                        text = "Error loading settings: ${state.message}",
                        color = StatusRejected,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                is SettingsUiState.Success -> {
                    // Top Live Broadcast Banner for User App
                    ActivePaymentBroadCastBanner(
                        activeBkash = state.activeBkash,
                        activeNagad = state.activeNagad
                    )

                    // 4 Dynamic Guide Banners (Image + Video) Settings (Broadcast to Home Screen)
                    TutorialVideosAndBannerSettingsCard(
                        depositBannerImageUrl = depositBannerImageUrl,
                        onDepositBannerImageChange = { viewModel.setDepositBannerImageUrl(it) },
                        howToDepositVideoUrl = howToDepositVideoUrl,
                        onHowToDepositChange = { viewModel.setHowToDepositVideoUrl(it) },
                        matchJoinBannerImageUrl = matchJoinBannerImageUrl,
                        onMatchJoinBannerImageChange = { viewModel.setMatchJoinBannerImageUrl(it) },
                        howToJoinVideoUrl = howToJoinVideoUrl,
                        onHowToJoinChange = { viewModel.setHowToJoinVideoUrl(it) },
                        resultSubmitBannerImageUrl = resultSubmitBannerImageUrl,
                        onResultSubmitBannerImageChange = { viewModel.setResultSubmitBannerImageUrl(it) },
                        howToSubmitResultVideoUrl = howToSubmitResultVideoUrl,
                        onHowToSubmitResultChange = { viewModel.setHowToSubmitResultVideoUrl(it) },
                        rulesBannerImageUrl = rulesBannerImageUrl,
                        onRulesBannerImageChange = { viewModel.setRulesBannerImageUrl(it) },
                        tournamentRulesVideoUrl = tournamentRulesVideoUrl,
                        onTournamentRulesChange = { viewModel.setTournamentRulesVideoUrl(it) },
                        customBannerImageUrl = customBannerImageUrl,
                        onCustomBannerImageChange = { viewModel.setCustomBannerImageUrl(it) },
                        isSaving = isSavingTutorialSettings,
                        onSave = { viewModel.saveTutorialAndBannerSettings() },
                        onClear = { viewModel.clearTutorialAndBannerSettings() }
                    )

                    // Payment Numbers Management Section Header with Add Button
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Official Payment Numbers",
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Dynamic bKash & Nagad numbers synced via /appSettings",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }

                        Button(
                            onClick = { viewModel.openAddDialog() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = GoldPrimary,
                                contentColor = TextOnGold
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("add_payment_number_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Add Number",
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Add Number",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }

                    // List of configured payment numbers
                    if (state.paymentNumbers.isEmpty()) {
                        EmptyPaymentNumbersCard(onAddClick = { viewModel.openAddDialog() })
                    } else {
                        state.paymentNumbers.forEach { item ->
                            PaymentNumberCard(
                                item = item,
                                onEdit = { viewModel.openEditDialog(item) },
                                onDelete = { viewModel.openDeleteDialog(item) },
                                onToggleActive = { viewModel.togglePaymentActive(item) },
                                onCopy = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("Payment Number", item.number))
                                }
                            )
                        }
                    }
                }
            }

            // System Security & RTDB Architecture (Persisted)
            SecurityLockNotice(
                title = "Authoritative /appSettings & Audit Governance",
                description = "All modifications to payment numbers immediately broadcast to User Apps and record an immutable Super Admin entry under /auditLogs."
            )

            StructuralQueueCard(
                title = "Connected Infrastructure",
                items = listOf(
                    "Firebase Project ID" to FirebaseAdminConfig.FIREBASE_PROJECT_ID,
                    "RTDB Instance URL" to FirebaseAdminConfig.RTDB_BASE_URL.take(35) + "...",
                    "Database Region" to FirebaseAdminConfig.RTDB_REGION,
                    "Broadcast Node" to "/${FirebaseAdminConfig.NODE_APP_SETTINGS}",
                    "Audit Logs Node" to "/${FirebaseAdminConfig.NODE_AUDIT_LOGS}",
                    "Super Admin UID" to FirebaseAdminConfig.FALLBACK_SUPER_ADMIN_UID.take(12) + "..."
                ),
                badgeLabel = "SYSTEM ARCHITECTURE"
            )

            Spacer(modifier = Modifier.height(30.dp))
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(16.dp)
        )
    }

    // Add / Edit Payment Number Dialog
    if (isAddEditModalOpen) {
        AddEditPaymentNumberDialog(
            isEditing = editingItem != null,
            method = inputMethod,
            type = inputType,
            number = inputNumber,
            instructions = inputInstructions,
            isActive = inputIsActive,
            isSubmitting = isSubmitting,
            onMethodChange = { viewModel.setInputMethod(it) },
            onTypeChange = { viewModel.setInputType(it) },
            onNumberChange = { viewModel.setInputNumber(it) },
            onInstructionsChange = { viewModel.setInputInstructions(it) },
            onIsActiveChange = { viewModel.setInputIsActive(it) },
            onDismiss = { viewModel.closeDialog() },
            onConfirm = { viewModel.savePaymentNumber() }
        )
    }

    // Delete Confirmation Dialog
    if (isDeleteConfirmOpen && deletingItem != null) {
        DeletePaymentNumberConfirmDialog(
            item = deletingItem!!,
            isSubmitting = isSubmitting,
            onDismiss = { viewModel.closeDeleteDialog() },
            onConfirm = { viewModel.confirmDelete() }
        )
    }
}

@Composable
private fun ActivePaymentBroadCastBanner(
    activeBkash: PaymentNumberItem?,
    activeNagad: PaymentNumberItem?
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = NavySurfaceHighlight),
        border = BorderStroke(1.dp, NavyBorder)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(StatusLive, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "LIVE USER APP BROADCAST",
                        style = MaterialTheme.typography.labelSmall,
                        color = StatusLive,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }

                Text(
                    text = "Node: /appSettings",
                    style = MaterialTheme.typography.bodySmall,
                    color = CyanLight,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // bKash active slot
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(NavySurface, RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "bKash",
                                style = MaterialTheme.typography.labelMedium,
                                color = BkashBrandPink,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = activeBkash?.type ?: "None",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted,
                                fontSize = 10.sp
                            )
                        }
                        Text(
                            text = activeBkash?.number ?: "Not configured",
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (activeBkash != null) TextPrimary else TextMuted,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // Nagad active slot
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(NavySurface, RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Nagad",
                                style = MaterialTheme.typography.labelMedium,
                                color = NagadBrandOrange,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = activeNagad?.type ?: "None",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted,
                                fontSize = 10.sp
                            )
                        }
                        Text(
                            text = activeNagad?.number ?: "Not configured",
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (activeNagad != null) TextPrimary else TextMuted,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PaymentNumberCard(
    item: PaymentNumberItem,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onToggleActive: () -> Unit,
    onCopy: () -> Unit
) {
    val brandColor = when (item.method.lowercase()) {
        "bkash" -> BkashBrandPink
        "nagad" -> NagadBrandOrange
        else -> RocketBrandPurple
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = NavySurfaceElevated),
        border = BorderStroke(
            width = 1.dp,
            color = if (item.isActive) NavyBorderLight else NavyBorder
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header Row: Method Badge + Account Type + Status Chip
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Method pill
                    Surface(
                        color = brandColor.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(6.dp),
                        border = BorderStroke(1.dp, brandColor.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = item.method,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                            style = MaterialTheme.typography.labelSmall,
                            color = brandColor,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Type pill
                    Surface(
                        color = NavySurfaceHighlight,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = item.type,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                // Active / Inactive Badge
                Surface(
                    color = if (item.isActive) StatusLive.copy(alpha = 0.15f) else TextMuted.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(
                        1.dp,
                        if (item.isActive) StatusLive.copy(alpha = 0.4f) else TextMuted.copy(alpha = 0.3f)
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .background(
                                    if (item.isActive) StatusLive else TextMuted,
                                    CircleShape
                                )
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = if (item.isActive) "ACTIVE" else "INACTIVE",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (item.isActive) StatusLive else TextMuted,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Middle Row: Phone Number + Copy Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Phone,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = item.number,
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }

                IconButton(
                    onClick = onCopy,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy number",
                        tint = CyanLight,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            // Instructions if any
            if (item.instructions.isNotBlank()) {
                Text(
                    text = item.instructions,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }

            // Footer Actions Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (item.updatedAt > 0) {
                        "Updated: ${SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(item.updatedAt))}"
                    } else {
                        "Authoritative RTDB Record"
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = TextMuted,
                    fontSize = 10.sp
                )

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    // Toggle status
                    OutlinedButton(
                        onClick = onToggleActive,
                        shape = RoundedCornerShape(6.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = if (item.isActive) StatusPending else StatusLive
                        ),
                        border = BorderStroke(1.dp, NavyBorder),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Text(
                            text = if (item.isActive) "Deactivate" else "Activate",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    // Edit
                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit number",
                            tint = GoldLight,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    // Delete
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete number",
                            tint = StatusRejected,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyPaymentNumbersCard(onAddClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = NavySurfaceElevated),
        border = BorderStroke(1.dp, NavyBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Payment,
                contentDescription = null,
                tint = GoldPrimary,
                modifier = Modifier.size(36.dp)
            )
            Text(
                text = "No Payment Numbers Configured",
                style = MaterialTheme.typography.titleSmall,
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Add official bKash or Nagad numbers for dynamic User App deposits.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
            Button(
                onClick = onAddClick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = GoldPrimary,
                    contentColor = TextOnGold
                ),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Add Payment Number", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun AddEditPaymentNumberDialog(
    isEditing: Boolean,
    method: String,
    type: String,
    number: String,
    instructions: String,
    isActive: Boolean,
    isSubmitting: Boolean,
    onMethodChange: (String) -> Unit,
    onTypeChange: (String) -> Unit,
    onNumberChange: (String) -> Unit,
    onInstructionsChange: (String) -> Unit,
    onIsActiveChange: (Boolean) -> Unit,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    Dialog(onDismissRequest = { if (!isSubmitting) onDismiss() }) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = NavyDark),
            border = BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.6f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Payment,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = if (isEditing) "Edit Payment Number" else "Add Official Payment Number",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = "This number will immediately appear in the User App under dynamic deposit methods.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )

                // Provider Selector (bKash, Nagad, Rocket)
                Text(
                    text = "Payment Provider",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextPrimary,
                    fontWeight = FontWeight.SemiBold
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("bKash", "Nagad", "Rocket").forEach { prov ->
                        val isSelected = method.equals(prov, true)
                        val color = when (prov.lowercase()) {
                            "bkash" -> BkashBrandPink
                            "nagad" -> NagadBrandOrange
                            else -> RocketBrandPurple
                        }
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onMethodChange(prov) },
                            color = if (isSelected) color.copy(alpha = 0.25f) else NavySurface,
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(
                                1.5.dp,
                                if (isSelected) color else NavyBorder
                            )
                        ) {
                            Box(
                                modifier = Modifier.padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = prov,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (isSelected) color else TextSecondary,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }
                }

                // Account Type Selector (Personal, Agent, Merchant)
                Text(
                    text = "Account Type",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextPrimary,
                    fontWeight = FontWeight.SemiBold
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Personal", "Agent", "Merchant").forEach { accType ->
                        val isSelected = type.equals(accType, true)
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onTypeChange(accType) },
                            color = if (isSelected) GoldPrimary.copy(alpha = 0.2f) else NavySurface,
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(
                                1.5.dp,
                                if (isSelected) GoldPrimary else NavyBorder
                            )
                        ) {
                            Box(
                                modifier = Modifier.padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = accType,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isSelected) GoldLight else TextSecondary,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }
                }

                // Phone Number Input
                Text(
                    text = "Official Mobile Number",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextPrimary,
                    fontWeight = FontWeight.SemiBold
                )
                OutlinedTextField(
                    value = number,
                    onValueChange = onNumberChange,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("payment_number_input"),
                    placeholder = { Text("017XXXXXXXX", color = TextMuted) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = NavyBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = NavySurface,
                        unfocusedContainerColor = NavySurface
                    )
                )

                // Instructions Input
                Text(
                    text = "Deposit Instructions (Optional)",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextPrimary,
                    fontWeight = FontWeight.SemiBold
                )
                OutlinedTextField(
                    value = instructions,
                    onValueChange = onInstructionsChange,
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("e.g. Send Money (Personal) with User UID note", color = TextMuted) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyanSecondary,
                        unfocusedBorderColor = NavyBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = NavySurface,
                        unfocusedContainerColor = NavySurface
                    )
                )

                // Active Status Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Active on User App",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Players will be able to see and copy this number",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }

                    Switch(
                        checked = isActive,
                        onCheckedChange = onIsActiveChange,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = TextOnGold,
                            checkedTrackColor = GoldPrimary,
                            uncheckedThumbColor = TextSecondary,
                            uncheckedTrackColor = NavySurfaceHighlight
                        )
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = onDismiss,
                        enabled = !isSubmitting
                    ) {
                        Text("Cancel", color = TextSecondary)
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = onConfirm,
                        enabled = !isSubmitting && number.trim().length >= 11,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = GoldPrimary,
                            contentColor = TextOnGold
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("save_payment_number_submit")
                    ) {
                        if (isSubmitting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                color = TextOnGold,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text(
                                text = if (isEditing) "Save Changes" else "Save to /appSettings",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DeletePaymentNumberConfirmDialog(
    item: PaymentNumberItem,
    isSubmitting: Boolean,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    Dialog(onDismissRequest = { if (!isSubmitting) onDismiss() }) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = NavyDark),
            border = BorderStroke(1.dp, StatusRejected.copy(alpha = 0.6f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = StatusRejected,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = "Remove Payment Number?",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = "Are you sure you want to remove ${item.method} (${item.type}) number ${item.number}? This will immediately update /appSettings and remove it from player deposit screens.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = onDismiss,
                        enabled = !isSubmitting
                    ) {
                        Text("Cancel", color = TextSecondary)
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = onConfirm,
                        enabled = !isSubmitting,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = StatusRejected,
                            contentColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        if (isSubmitting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                color = TextPrimary,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text("Confirm Delete", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

/**
 * Dedicated Card for managing User App Home 4 Dynamic Guide Banners (Image + Video).
 * Groups 4 guides: Deposit, Match Join, Result Submit, and Tournament Rules.
 * Synchronizes with /appSettings node in Firebase Realtime Database.
 */
@Composable
private fun TutorialVideosAndBannerSettingsCard(
    depositBannerImageUrl: String,
    onDepositBannerImageChange: (String) -> Unit,
    howToDepositVideoUrl: String,
    onHowToDepositChange: (String) -> Unit,
    matchJoinBannerImageUrl: String,
    onMatchJoinBannerImageChange: (String) -> Unit,
    howToJoinVideoUrl: String,
    onHowToJoinChange: (String) -> Unit,
    resultSubmitBannerImageUrl: String,
    onResultSubmitBannerImageChange: (String) -> Unit,
    howToSubmitResultVideoUrl: String,
    onHowToSubmitResultChange: (String) -> Unit,
    rulesBannerImageUrl: String,
    onRulesBannerImageChange: (String) -> Unit,
    tournamentRulesVideoUrl: String,
    onTournamentRulesChange: (String) -> Unit,
    customBannerImageUrl: String,
    onCustomBannerImageChange: (String) -> Unit,
    isSaving: Boolean,
    onSave: () -> Unit,
    onClear: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("tutorial_videos_and_banner_settings_card"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = NavySurface),
        border = BorderStroke(1.dp, NavyBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(GoldPrimary.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayCircle,
                            contentDescription = null,
                            tint = GoldPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Column {
                        Text(
                            text = "Tutorial Videos & Banner Settings",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "4 dynamic guide banners (Image + Video) synced via /appSettings",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }

                val hasAnySet = depositBannerImageUrl.isNotBlank() ||
                    howToDepositVideoUrl.isNotBlank() ||
                    matchJoinBannerImageUrl.isNotBlank() ||
                    howToJoinVideoUrl.isNotBlank() ||
                    resultSubmitBannerImageUrl.isNotBlank() ||
                    howToSubmitResultVideoUrl.isNotBlank() ||
                    rulesBannerImageUrl.isNotBlank() ||
                    tournamentRulesVideoUrl.isNotBlank() ||
                    customBannerImageUrl.isNotBlank()

                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = if (hasAnySet) StatusLive.copy(alpha = 0.15f) else NavySurfaceElevated,
                    border = BorderStroke(
                        1.dp,
                        if (hasAnySet) StatusLive.copy(alpha = 0.35f) else NavyBorder
                    )
                ) {
                    Text(
                        text = if (hasAnySet) "CONFIGURED" else "NOT SET",
                        color = if (hasAnySet) StatusLive else TextMuted,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            // Section 1: Deposit Guide (Image + Video)
            GuideBannerSection(
                title = "1. Deposit Guide",
                subtitle = "bKash / Nagad wallet deposit instructions",
                icon = Icons.Default.Payment,
                accentColor = CyanLight,
                imageUrl = depositBannerImageUrl,
                onImageUrlChange = onDepositBannerImageChange,
                imageTag = "input_deposit_banner_image_url",
                imagePlaceholder = "https://.../deposit_banner.png (Banner graphic)",
                videoUrl = howToDepositVideoUrl,
                onVideoUrlChange = onHowToDepositChange,
                videoTag = "input_deposit_video_url",
                videoPlaceholder = "https://youtu.be/... (Deposit tutorial video)"
            )

            // Section 2: Match Join Guide (Image + Video)
            GuideBannerSection(
                title = "2. Match Join Guide",
                subtitle = "Room code, custom room entry, & match lobby tutorial",
                icon = Icons.Default.SmartDisplay,
                accentColor = GoldPrimary,
                imageUrl = matchJoinBannerImageUrl,
                onImageUrlChange = onMatchJoinBannerImageChange,
                imageTag = "input_match_join_banner_image_url",
                imagePlaceholder = "https://.../join_banner.png (Banner graphic)",
                videoUrl = howToJoinVideoUrl,
                onVideoUrlChange = onHowToJoinChange,
                videoTag = "input_match_join_video_url",
                videoPlaceholder = "https://youtu.be/... (How to join & play video)"
            )

            // Section 3: Result Submit Guide (Image + Video)
            GuideBannerSection(
                title = "3. Result Submit Guide",
                subtitle = "Match screenshot and proof upload walkthrough",
                icon = Icons.Default.CheckCircle,
                accentColor = StatusLive,
                imageUrl = resultSubmitBannerImageUrl,
                onImageUrlChange = onResultSubmitBannerImageChange,
                imageTag = "input_result_submit_banner_image_url",
                imagePlaceholder = "https://.../result_banner.png (Banner graphic)",
                videoUrl = howToSubmitResultVideoUrl,
                onVideoUrlChange = onHowToSubmitResultChange,
                videoTag = "input_result_submit_video_url",
                videoPlaceholder = "https://youtu.be/... (Screenshot proof video)"
            )

            // Section 4: Tournament Rules (Image + Video)
            GuideBannerSection(
                title = "4. Tournament Rules",
                subtitle = "Rules, fair play regulations, and penalties policy",
                icon = Icons.Default.Info,
                accentColor = GoldLight,
                imageUrl = rulesBannerImageUrl,
                onImageUrlChange = onRulesBannerImageChange,
                imageTag = "input_rules_banner_image_url",
                imagePlaceholder = "https://.../rules_banner.png (Banner graphic)",
                videoUrl = tournamentRulesVideoUrl,
                onVideoUrlChange = onTournamentRulesChange,
                videoTag = "input_rules_video_url",
                videoPlaceholder = "https://youtu.be/... (Tournament rules video)"
            )

            // Optional Top Hero Slider Banner Graphic
            OutlinedTextField(
                value = customBannerImageUrl,
                onValueChange = onCustomBannerImageChange,
                label = { Text("Optional Custom Top Hero Slider Banner URL") },
                placeholder = { Text("https://.../hero_slider.png (Top carousel graphic)", color = TextMuted) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Image,
                        contentDescription = null,
                        tint = CyanSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_custom_banner_image_url"),
                singleLine = true,
                shape = RoundedCornerShape(8.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GoldPrimary,
                    unfocusedBorderColor = NavyBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedLabelColor = GoldPrimary,
                    unfocusedLabelColor = TextSecondary,
                    cursorColor = GoldPrimary
                )
            )

            // Actions: Clear / Reset & Save Settings
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onClear,
                    enabled = !isSaving,
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("clear_tutorial_settings_button"),
                    border = BorderStroke(1.dp, NavyBorderLight),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = TextSecondary
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.RestartAlt,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Clear / Reset",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                }

                Button(
                    onClick = onSave,
                    enabled = !isSaving,
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("save_tutorial_settings_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = GoldPrimary,
                        contentColor = TextOnGold,
                        disabledContainerColor = NavySurfaceHighlight
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    if (isSaving) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            color = TextOnGold,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Saving...",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Save,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Save Settings",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}

/**
 * Reusable expandable/grouped card section for each guide banner (Image URL & Video URL).
 */
@Composable
private fun GuideBannerSection(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color,
    imageUrl: String,
    onImageUrlChange: (String) -> Unit,
    imageTag: String,
    imagePlaceholder: String,
    videoUrl: String,
    onVideoUrlChange: (String) -> Unit,
    videoTag: String,
    videoPlaceholder: String
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        color = NavySurfaceElevated,
        border = BorderStroke(1.dp, NavyBorderLight)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Group Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(18.dp)
                    )
                    Column {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                val hasData = imageUrl.isNotBlank() || videoUrl.isNotBlank()
                if (hasData) {
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = accentColor.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = "SET",
                            color = accentColor,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                        )
                    }
                }
            }

            // Image URL field
            OutlinedTextField(
                value = imageUrl,
                onValueChange = onImageUrlChange,
                label = { Text("Banner Image URL") },
                placeholder = { Text(imagePlaceholder, color = TextMuted) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Image,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(18.dp)
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag(imageTag),
                singleLine = true,
                shape = RoundedCornerShape(8.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = accentColor,
                    unfocusedBorderColor = NavyBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedLabelColor = accentColor,
                    unfocusedLabelColor = TextSecondary,
                    cursorColor = accentColor
                )
            )

            // Video URL field
            OutlinedTextField(
                value = videoUrl,
                onValueChange = onVideoUrlChange,
                label = { Text("Tutorial Video URL") },
                placeholder = { Text(videoPlaceholder, color = TextMuted) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.PlayCircle,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag(videoTag),
                singleLine = true,
                shape = RoundedCornerShape(8.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GoldPrimary,
                    unfocusedBorderColor = NavyBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedLabelColor = GoldPrimary,
                    unfocusedLabelColor = TextSecondary,
                    cursorColor = GoldPrimary
                )
            )
        }
    }
}
