package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.core.config.FirebaseAdminConfig
import com.example.core.model.AdminDepositItem
import com.example.core.model.DepositStatus
import com.example.core.model.DepositSummary
import com.example.navigation.AdminSection
import com.example.ui.components.SectionHeader
import com.example.ui.components.SectionShellHeroCard
import com.example.ui.components.SecurityLockNotice
import com.example.ui.components.StructuralQueueCard
import com.example.ui.theme.CyanLight
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.NavyBorder
import com.example.ui.theme.NavyBorderLight
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyDeepest
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavySurfaceElevated
import com.example.ui.theme.NavySurfaceHighlight
import com.example.ui.theme.StatusLive
import com.example.ui.theme.StatusPending
import com.example.ui.theme.StatusRejected
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextOnGold
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Provider Brand Accents
private val BkashBrandPink = Color(0xFFE2136E)
private val NagadBrandOrange = Color(0xFFF7941D)
private val RocketBrandPurple = Color(0xFF8C3494)

@Composable
fun DepositsScreen(
    modifier: Modifier = Modifier,
    viewModel: DepositsViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedTab by viewModel.selectedTab.collectAsState()
    val selectedPaymentFilter by viewModel.selectedPaymentFilter.collectAsState()

    val selectedDepositForDetails by viewModel.selectedDepositForDetails.collectAsState()
    val isDetailsModalOpen by viewModel.isDetailsModalOpen.collectAsState()
    val isApproveConfirmOpen by viewModel.isApproveConfirmOpen.collectAsState()
    val isRejectConfirmOpen by viewModel.isRejectConfirmOpen.collectAsState()
    val rejectReasonInput by viewModel.rejectReasonInput.collectAsState()
    val isSubmitting by viewModel.isSubmitting.collectAsState()
    val feedbackMessage by viewModel.feedbackMessage.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current

    LaunchedEffect(feedbackMessage) {
        feedbackMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearFeedbackMessage()
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            SectionHeader(
                title = AdminSection.DEPOSITS.title,
                subtitle = "Manual TrxID Verification & Direct Wallet Credit Flow",
                icon = AdminSection.DEPOSITS.icon
            )

            SectionShellHeroCard(
                section = AdminSection.DEPOSITS,
                statusText = "AUTHORITATIVE DIRECT WALLET CREDIT"
            )

            when (val state = uiState) {
                is DepositsUiState.Loading -> {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = GoldPrimary)
                    }
                }
                is DepositsUiState.Error -> {
                    Text(
                        text = "Error loading deposits: ${state.message}",
                        color = StatusRejected,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                is DepositsUiState.Success -> {
                    // Summary Metrics Row
                    DepositsSummaryBanner(summary = state.summary)

                    // Search input
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { viewModel.onSearchQueryChanged(it) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("deposits_search_input"),
                        placeholder = { Text("Search by TrxID, User ID, phone, or name...", color = TextMuted) },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "Search",
                                tint = CyanLight
                            )
                        },
                        trailingIcon = {
                            if (searchQuery.isNotBlank()) {
                                IconButton(onClick = { viewModel.onSearchQueryChanged("") }) {
                                    Icon(
                                        imageVector = Icons.Default.Clear,
                                        contentDescription = "Clear search",
                                        tint = TextSecondary
                                    )
                                }
                            }
                        },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = NavyBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedContainerColor = NavySurfaceElevated,
                            unfocusedContainerColor = NavySurfaceElevated
                        ),
                        shape = RoundedCornerShape(10.dp)
                    )

                    // Filter Status Tabs
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = selectedTab == "PENDING",
                            onClick = { viewModel.onTabSelected("PENDING") },
                            label = { Text("Pending (${state.summary.pendingCount})") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = StatusPending.copy(alpha = 0.25f),
                                selectedLabelColor = StatusPending,
                                containerColor = NavySurface,
                                labelColor = TextSecondary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = selectedTab == "PENDING",
                                borderColor = if (selectedTab == "PENDING") StatusPending else NavyBorder
                            )
                        )

                        FilterChip(
                            selected = selectedTab == "ALL",
                            onClick = { viewModel.onTabSelected("ALL") },
                            label = { Text("All (${state.allDeposits.size})") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = GoldPrimary,
                                selectedLabelColor = TextOnGold,
                                containerColor = NavySurface,
                                labelColor = TextSecondary
                            )
                        )

                        FilterChip(
                            selected = selectedTab == "APPROVED",
                            onClick = { viewModel.onTabSelected("APPROVED") },
                            label = { Text("Approved (${state.summary.approvedCount})") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = StatusLive.copy(alpha = 0.2f),
                                selectedLabelColor = StatusLive,
                                containerColor = NavySurface,
                                labelColor = TextSecondary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = selectedTab == "APPROVED",
                                borderColor = if (selectedTab == "APPROVED") StatusLive else NavyBorder
                            )
                        )

                        FilterChip(
                            selected = selectedTab == "REJECTED",
                            onClick = { viewModel.onTabSelected("REJECTED") },
                            label = { Text("Rejected (${state.summary.rejectedCount})") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = StatusRejected.copy(alpha = 0.2f),
                                selectedLabelColor = StatusRejected,
                                containerColor = NavySurface,
                                labelColor = TextSecondary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = selectedTab == "REJECTED",
                                borderColor = if (selectedTab == "REJECTED") StatusRejected else NavyBorder
                            )
                        )
                    }

                    // Payment Provider Quick Filter Chips (bKash, Nagad, Rocket)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("ALL" to "All Gateways", "bKash" to "bKash", "Nagad" to "Nagad", "Rocket" to "Rocket").forEach { (method, label) ->
                            val isSelected = selectedPaymentFilter == method
                            FilterChip(
                                selected = isSelected,
                                onClick = { viewModel.onPaymentFilterSelected(method) },
                                label = { Text(label, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = NavySurfaceHighlight,
                                    selectedLabelColor = GoldLight,
                                    containerColor = NavySurface,
                                    labelColor = TextMuted
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = isSelected,
                                    borderColor = if (isSelected) GoldPrimary else NavyBorder
                                )
                            )
                        }
                    }

                    // Deposit Cards
                    if (state.filteredDeposits.isEmpty()) {
                        EmptyDepositsCard(
                            tab = selectedTab,
                            query = searchQuery,
                            onClear = { viewModel.onSearchQueryChanged("") }
                        )
                    } else {
                        state.filteredDeposits.forEach { deposit ->
                            DepositItemCard(
                                deposit = deposit,
                                onClick = { viewModel.openDepositDetails(deposit) },
                                onApprove = { viewModel.openApproveDialog(deposit) },
                                onReject = { viewModel.openRejectDialog(deposit) },
                                onCopyTrxId = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("TrxID", deposit.transactionId))
                                }
                            )
                        }
                    }
                }
            }

            SecurityLockNotice(
                title = "Direct Realtime Wallet Credit Architecture",
                description = "Upon Super Admin approval, the player's wallet (/wallets/{userId}) is credited directly without external Cloud Functions, writing mirrored records to /userDeposits, /transactions, and /auditLogs."
            )

            StructuralQueueCard(
                title = "Deposit Flow Nodes",
                items = listOf(
                    "Deposit Ingestion" to "/${FirebaseAdminConfig.NODE_DEPOSITS}",
                    "User Mirrored Queue" to "/${FirebaseAdminConfig.NODE_USER_DEPOSITS}",
                    "Direct Wallet Balance" to "/${FirebaseAdminConfig.NODE_WALLETS}/{userId}",
                    "Ledger Transactions" to "/${FirebaseAdminConfig.NODE_TRANSACTIONS}",
                    "Audit Logs" to "/${FirebaseAdminConfig.NODE_AUDIT_LOGS}"
                ),
                badgeLabel = "REALTIME PIPELINE"
            )

            Spacer(modifier = Modifier.height(30.dp))
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(16.dp)
        )
    }

    // Deposit Details Dialog
    if (isDetailsModalOpen && selectedDepositForDetails != null) {
        DepositDetailsDialog(
            deposit = selectedDepositForDetails!!,
            isSubmitting = isSubmitting,
            onDismiss = { viewModel.closeDepositDetails() },
            onApprove = { viewModel.openApproveDialog(selectedDepositForDetails!!) },
            onReject = { viewModel.openRejectDialog(selectedDepositForDetails!!) },
            onCopy = { text, label ->
                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
            }
        )
    }

    // Approve Confirmation Dialog
    if (isApproveConfirmOpen && selectedDepositForDetails != null) {
        ApproveDepositConfirmDialog(
            deposit = selectedDepositForDetails!!,
            isSubmitting = isSubmitting,
            onDismiss = { viewModel.closeApproveDialog() },
            onConfirm = { viewModel.confirmApproveDeposit() }
        )
    }

    // Reject Confirmation Dialog
    if (isRejectConfirmOpen && selectedDepositForDetails != null) {
        RejectDepositConfirmDialog(
            deposit = selectedDepositForDetails!!,
            reason = rejectReasonInput,
            isSubmitting = isSubmitting,
            onReasonChange = { viewModel.setRejectReason(it) },
            onDismiss = { viewModel.closeRejectDialog() },
            onConfirm = { viewModel.confirmRejectDeposit() }
        )
    }
}

@Composable
private fun DepositsSummaryBanner(summary: DepositSummary) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Pending Queue Card
        Card(
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(containerColor = NavySurfaceElevated),
            border = BorderStroke(1.dp, if (summary.pendingCount > 0) StatusPending.copy(alpha = 0.6f) else NavyBorder)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(StatusPending, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "PENDING",
                        style = MaterialTheme.typography.labelSmall,
                        color = StatusPending,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${summary.pendingCount}",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "৳${summary.totalPendingAmountTaka} in review",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }
        }

        // Approved Card
        Card(
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(containerColor = NavySurfaceElevated),
            border = BorderStroke(1.dp, StatusLive.copy(alpha = 0.4f))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "APPROVED",
                    style = MaterialTheme.typography.labelSmall,
                    color = StatusLive,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${summary.approvedCount}",
                    style = MaterialTheme.typography.titleLarge,
                    color = StatusLive,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "৳${summary.totalApprovedAmountTaka} credited",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }
        }

        // Rejected Card
        Card(
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(containerColor = NavySurfaceElevated),
            border = BorderStroke(1.dp, if (summary.rejectedCount > 0) StatusRejected.copy(alpha = 0.5f) else NavyBorder)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "REJECTED",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (summary.rejectedCount > 0) StatusRejected else TextMuted,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${summary.rejectedCount}",
                    style = MaterialTheme.typography.titleLarge,
                    color = if (summary.rejectedCount > 0) StatusRejected else TextSecondary,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Mismatches",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextMuted,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
private fun DepositItemCard(
    deposit: AdminDepositItem,
    onClick: () -> Unit,
    onApprove: () -> Unit,
    onReject: () -> Unit,
    onCopyTrxId: () -> Unit
) {
    val brandColor = when (deposit.paymentMethod.lowercase()) {
        "bkash" -> BkashBrandPink
        "nagad" -> NagadBrandOrange
        else -> RocketBrandPurple
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("deposit_card_${deposit.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = NavySurfaceElevated),
        border = BorderStroke(
            width = 1.dp,
            color = when {
                deposit.isPending -> StatusPending.copy(alpha = 0.5f)
                deposit.isApproved -> StatusLive.copy(alpha = 0.4f)
                else -> StatusRejected.copy(alpha = 0.3f)
            }
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header Row: Gateway Brand Pill + Amount + Status Chip
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Gateway Pill
                    Surface(
                        color = brandColor.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(6.dp),
                        border = BorderStroke(1.dp, brandColor.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = deposit.paymentMethod,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                            style = MaterialTheme.typography.labelSmall,
                            color = brandColor,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Text(
                        text = deposit.formattedAmount,
                        style = MaterialTheme.typography.titleMedium,
                        color = GoldLight,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Status Badge
                Surface(
                    color = when {
                        deposit.isPending -> StatusPending.copy(alpha = 0.15f)
                        deposit.isApproved -> StatusLive.copy(alpha = 0.15f)
                        else -> StatusRejected.copy(alpha = 0.15f)
                    },
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(
                        1.dp,
                        when {
                            deposit.isPending -> StatusPending.copy(alpha = 0.6f)
                            deposit.isApproved -> StatusLive.copy(alpha = 0.5f)
                            else -> StatusRejected.copy(alpha = 0.5f)
                        }
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .background(
                                    when {
                                        deposit.isPending -> StatusPending
                                        deposit.isApproved -> StatusLive
                                        else -> StatusRejected
                                    },
                                    CircleShape
                                )
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = deposit.status.name,
                            style = MaterialTheme.typography.labelSmall,
                            color = when {
                                deposit.isPending -> StatusPending
                                deposit.isApproved -> StatusLive
                                else -> StatusRejected
                            },
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Transaction ID Highlight Box
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(NavySurface, RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "TRANSACTION TrxID",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = deposit.transactionId.ifBlank { "N/A" },
                        style = MaterialTheme.typography.bodyMedium,
                        color = CyanLight,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }

                IconButton(
                    onClick = onCopyTrxId,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy TrxID",
                        tint = CyanLight,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            // User info & sender number
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "${deposit.userName.ifBlank { "Player" }} (${deposit.senderNumber.ifBlank { deposit.userPhone }})",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "UID: ${deposit.userId.take(12)}...",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Text(
                    text = if (deposit.createdAt > 0) {
                        SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(deposit.createdAt))
                    } else "Recent",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextMuted,
                    fontSize = 10.sp
                )
            }

            // Rejection reason if rejected
            if (deposit.isRejected && !deposit.rejectionReason.isNullOrBlank()) {
                Text(
                    text = "Reason: ${deposit.rejectionReason}",
                    style = MaterialTheme.typography.bodySmall,
                    color = StatusRejected,
                    fontSize = 11.sp
                )
            }

            // Action Buttons for PENDING deposits
            if (deposit.isPending) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onReject,
                        modifier = Modifier
                            .weight(1f)
                            .height(36.dp)
                            .testTag("reject_deposit_btn_${deposit.id}"),
                        shape = RoundedCornerShape(6.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = StatusRejected
                        ),
                        border = BorderStroke(1.dp, StatusRejected.copy(alpha = 0.5f))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Reject", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = onApprove,
                        modifier = Modifier
                            .weight(1.5f)
                            .height(36.dp)
                            .testTag("approve_deposit_btn_${deposit.id}"),
                        shape = RoundedCornerShape(6.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = StatusLive,
                            contentColor = TextOnGold
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Approve Deposit", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            } else if (deposit.isApproved) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = StatusLive,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "Wallet Credited • Processed by Super Admin",
                        style = MaterialTheme.typography.labelSmall,
                        color = StatusLive,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptyDepositsCard(
    tab: String,
    query: String,
    onClear: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = NavySurfaceElevated),
        border = BorderStroke(1.dp, NavyBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Default.AccountBalanceWallet,
                contentDescription = null,
                tint = TextMuted,
                modifier = Modifier.size(36.dp)
            )
            Text(
                text = if (query.isNotBlank()) "No deposits matching '$query'" else "No $tab deposits found",
                style = MaterialTheme.typography.titleSmall,
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Incoming player bKash and Nagad deposits appear here automatically.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
            if (query.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Button(
                    onClick = onClear,
                    colors = ButtonDefaults.buttonColors(containerColor = NavySurfaceHighlight),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Clear Search Query", color = TextPrimary)
                }
            }
        }
    }
}

@Composable
private fun DepositDetailsDialog(
    deposit: AdminDepositItem,
    isSubmitting: Boolean,
    onDismiss: () -> Unit,
    onApprove: () -> Unit,
    onReject: () -> Unit,
    onCopy: (String, String) -> Unit
) {
    Dialog(onDismissRequest = { if (!isSubmitting) onDismiss() }) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = NavyDark),
            border = BorderStroke(1.5.dp, GoldPrimary.copy(alpha = 0.6f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Payment,
                            contentDescription = null,
                            tint = GoldPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = "Deposit Verification Dossier",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                // Amount Highlight Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = NavySurfaceHighlight)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("CREDIT AMOUNT", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 10.sp)
                            Text(deposit.formattedAmount, style = MaterialTheme.typography.headlineMedium, color = GoldLight, fontWeight = FontWeight.Bold)
                        }

                        Surface(
                            color = when {
                                deposit.isPending -> StatusPending.copy(alpha = 0.2f)
                                deposit.isApproved -> StatusLive.copy(alpha = 0.2f)
                                else -> StatusRejected.copy(alpha = 0.2f)
                            },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = deposit.status.name,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                style = MaterialTheme.typography.labelMedium,
                                color = when {
                                    deposit.isPending -> StatusPending
                                    deposit.isApproved -> StatusLive
                                    else -> StatusRejected
                                },
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Transaction & Player Ledger
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = NavySurface),
                    border = BorderStroke(1.dp, NavyBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // TrxID
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Transaction TrxID", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                Text(deposit.transactionId, style = MaterialTheme.typography.bodyMedium, color = CyanLight, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            }
                            IconButton(onClick = { onCopy(deposit.transactionId, "TrxID") }, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "Copy TrxID", tint = CyanLight, modifier = Modifier.size(16.dp))
                            }
                        }

                        // Method & Sender
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("Payment Gateway", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                Text(deposit.paymentMethod, style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Sender Mobile", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                Text(deposit.senderNumber.ifBlank { deposit.userPhone }, style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontFamily = FontFamily.Monospace)
                            }
                        }

                        // Player Name & UID
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("Player Name", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                Text(deposit.userName.ifBlank { "Registered Player" }, style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Target User UID", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                Text(deposit.userId, style = MaterialTheme.typography.bodySmall, color = CyanLight, fontFamily = FontFamily.Monospace)
                            }
                        }

                        if (deposit.receiverNumber.isNotBlank()) {
                            Text("Sent to Official Number: ${deposit.receiverNumber}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }

                        if (deposit.isRejected && !deposit.rejectionReason.isNullOrBlank()) {
                            Text("Rejection Reason: ${deposit.rejectionReason}", style = MaterialTheme.typography.bodySmall, color = StatusRejected)
                        }
                    }
                }

                // Action buttons if pending
                if (deposit.isPending) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = onReject,
                            enabled = !isSubmitting,
                            modifier = Modifier
                                .weight(1f)
                                .height(42.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusRejected),
                            border = BorderStroke(1.dp, StatusRejected.copy(alpha = 0.6f))
                        ) {
                            Text("Reject", fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = onApprove,
                            enabled = !isSubmitting,
                            modifier = Modifier
                                .weight(1.6f)
                                .height(42.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = StatusLive, contentColor = TextOnGold)
                        ) {
                            Text("Approve & Credit Wallet", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Close Dossier", color = TextSecondary)
                }
            }
        }
    }
}

@Composable
private fun ApproveDepositConfirmDialog(
    deposit: AdminDepositItem,
    isSubmitting: Boolean,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    Dialog(onDismissRequest = { if (!isSubmitting) onDismiss() }) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = NavyDark),
            border = BorderStroke(1.5.dp, StatusLive)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = StatusLive,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = "Approve & Credit Wallet?",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = "This action will immediately increment User ${deposit.userName.ifBlank { deposit.userId.take(8) }}'s balance by ${deposit.formattedAmount} in /wallets/${deposit.userId}, update /userDeposits to APPROVED, and write a completed transaction record.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )

                // Summary
                Surface(
                    color = NavySurface,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("TrxID: ${deposit.transactionId}", style = MaterialTheme.typography.bodySmall, color = CyanLight, fontFamily = FontFamily.Monospace)
                        Text("Gateway: ${deposit.paymentMethod}", style = MaterialTheme.typography.bodySmall, color = TextPrimary)
                        Text("Credit: ${deposit.formattedAmount}", style = MaterialTheme.typography.bodySmall, color = GoldLight, fontWeight = FontWeight.Bold)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = onDismiss,
                        enabled = !isSubmitting
                    ) {
                        Text("Cancel", color = TextSecondary)
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = onConfirm,
                        enabled = !isSubmitting,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = StatusLive,
                            contentColor = TextOnGold
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("confirm_approve_submit")
                    ) {
                        if (isSubmitting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                color = TextOnGold,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text("Confirm & Credit", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RejectDepositConfirmDialog(
    deposit: AdminDepositItem,
    reason: String,
    isSubmitting: Boolean,
    onReasonChange: (String) -> Unit,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    Dialog(onDismissRequest = { if (!isSubmitting) onDismiss() }) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = NavyDark),
            border = BorderStroke(1.5.dp, StatusRejected)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = StatusRejected,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = "Reject Deposit Request?",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = "Rejecting deposit for ${deposit.formattedAmount} (TrxID: ${deposit.transactionId}). The player will receive this reason in their transaction history.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )

                Text(
                    text = "Reason for Rejection",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextPrimary,
                    fontWeight = FontWeight.SemiBold
                )

                OutlinedTextField(
                    value = reason,
                    onValueChange = onReasonChange,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("reject_reason_input"),
                    placeholder = { Text("e.g. TrxID not found in gateway statement", color = TextMuted) },
                    singleLine = false,
                    maxLines = 3,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = StatusRejected,
                        unfocusedBorderColor = NavyBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = NavySurface,
                        unfocusedContainerColor = NavySurface
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = onDismiss,
                        enabled = !isSubmitting
                    ) {
                        Text("Cancel", color = TextSecondary)
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = onConfirm,
                        enabled = !isSubmitting,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = StatusRejected,
                            contentColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("confirm_reject_submit")
                    ) {
                        if (isSubmitting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                color = TextPrimary,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text("Confirm Rejection", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
