package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.core.auth.AdminSessionManager
import com.example.core.model.AdminAuthState
import com.example.navigation.AdminSection
import com.example.ui.auth.LoginScreen
import com.example.ui.auth.LoginViewModel
import com.example.ui.components.AdminBottomBar
import com.example.ui.components.AdminDrawerContent
import com.example.ui.components.AdminTopBar
import com.example.ui.screens.AuditLogsScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.DepositsScreen
import com.example.ui.screens.MatchesScreen
import com.example.ui.screens.NotificationsScreen
import com.example.ui.screens.ResultsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.UsersScreen
import com.example.ui.screens.WithdrawalsScreen
import com.example.ui.theme.NavyDeepest
import kotlinx.coroutines.launch

@Composable
fun MainAdminApp(
    sessionManager: AdminSessionManager = AdminSessionManager.getInstance(),
    navController: NavHostController = rememberNavController(),
    loginViewModel: LoginViewModel = viewModel()
) {
    val authState by sessionManager.authState.collectAsState()
    val scope = rememberCoroutineScope()

    when (authState) {
        is AdminAuthState.Unauthenticated,
        is AdminAuthState.AccessDenied,
        is AdminAuthState.Loading -> {
            LoginScreen(
                viewModel = loginViewModel,
                onLoginSuccess = {
                    // Handled automatically via authState Flow
                }
            )
        }
        is AdminAuthState.Authenticated -> {
            AuthenticatedAdminScaffold(
                navController = navController,
                onLogout = {
                    scope.launch {
                        sessionManager.logout()
                    }
                }
            )
        }
    }
}

@Composable
fun AuthenticatedAdminScaffold(
    navController: NavHostController,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    val currentSection = AdminSection.fromRoute(currentRoute)

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            AdminDrawerContent(
                currentSection = currentSection,
                onSectionSelected = { section ->
                    if (currentSection != section) {
                        navController.navigate(section.route) {
                            popUpTo(AdminSection.DASHBOARD.route) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                },
                onCloseDrawer = {
                    scope.launch { drawerState.close() }
                },
                onLogout = onLogout
            )
        }
    ) {
        Scaffold(
            modifier = modifier.fillMaxSize(),
            topBar = {
                AdminTopBar(
                    onMenuClick = {
                        scope.launch {
                            if (drawerState.isClosed) drawerState.open() else drawerState.close()
                        }
                    },
                    onNotificationClick = {
                        navController.navigate(AdminSection.NOTIFICATIONS.route) {
                            launchSingleTop = true
                        }
                    },
                    onLogoutClick = onLogout
                )
            },
            bottomBar = {
                AdminBottomBar(
                    currentSection = currentSection,
                    onSectionSelected = { section ->
                        if (currentSection != section) {
                            navController.navigate(section.route) {
                                popUpTo(AdminSection.DASHBOARD.route) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    },
                    onMenuClick = {
                        scope.launch {
                            if (drawerState.isClosed) drawerState.open() else drawerState.close()
                        }
                    }
                )
            },
            containerColor = NavyDeepest
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(NavyDeepest)
                    .padding(paddingValues)
            ) {
                NavHost(
                    navController = navController,
                    startDestination = AdminSection.DASHBOARD.route,
                    modifier = Modifier.fillMaxSize()
                ) {
                    composable(AdminSection.DASHBOARD.route) {
                        DashboardScreen(
                            onNavigateToSection = { targetSection ->
                                navController.navigate(targetSection.route) {
                                    popUpTo(AdminSection.DASHBOARD.route) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        )
                    }
                    composable(AdminSection.MATCHES.route) {
                        MatchesScreen()
                    }
                    composable(AdminSection.RESULTS.route) {
                        ResultsScreen()
                    }
                    composable(AdminSection.DEPOSITS.route) {
                        DepositsScreen()
                    }
                    composable(AdminSection.WITHDRAWALS.route) {
                        WithdrawalsScreen()
                    }
                    composable(AdminSection.USERS.route) {
                        UsersScreen()
                    }
                    composable(AdminSection.NOTIFICATIONS.route) {
                        NotificationsScreen(
                            onNavigateToMatches = {
                                navController.navigate(AdminSection.MATCHES.route) {
                                    popUpTo(AdminSection.DASHBOARD.route) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        )
                    }
                    composable(AdminSection.AUDIT_LOGS.route) {
                        AuditLogsScreen()
                    }
                    composable(AdminSection.SETTINGS.route) {
                        SettingsScreen()
                    }
                }
            }
        }
    }
}
