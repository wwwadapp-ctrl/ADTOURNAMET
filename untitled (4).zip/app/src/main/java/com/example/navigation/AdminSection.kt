package com.example.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.HistoryEdu
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PeopleAlt
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.ui.graphics.vector.ImageVector

enum class AdminCategory(val label: String) {
    OVERVIEW("Overview"),
    TOURNAMENT_OPS("Tournament Ops"),
    FINANCIAL_OVERSIGHT("Financial Oversight"),
    GOVERNANCE("Governance & Security")
}

enum class AdminSection(
    val route: String,
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val category: AdminCategory
) {
    DASHBOARD(
        route = "dashboard",
        title = "Dashboard",
        subtitle = "System overview & operational telemetry",
        icon = Icons.Default.Dashboard,
        category = AdminCategory.OVERVIEW
    ),
    MATCHES(
        route = "matches",
        title = "Matches",
        subtitle = "Tournament brackets, fixtures & room coordination",
        icon = Icons.Default.SportsEsports,
        category = AdminCategory.TOURNAMENT_OPS
    ),
    RESULTS(
        route = "results",
        title = "Results",
        subtitle = "Match scores, screenshot proof & verification",
        icon = Icons.Default.EmojiEvents,
        category = AdminCategory.TOURNAMENT_OPS
    ),
    DEPOSITS(
        route = "deposits",
        title = "Deposits",
        subtitle = "Player deposit reconciliation & gateway ledger",
        icon = Icons.Default.AccountBalanceWallet,
        category = AdminCategory.FINANCIAL_OVERSIGHT
    ),
    WITHDRAWALS(
        route = "withdrawals",
        title = "Withdrawals",
        subtitle = "Payout requests & Super Admin disbursement queue",
        icon = Icons.Default.Payments,
        category = AdminCategory.FINANCIAL_OVERSIGHT
    ),
    USERS(
        route = "users",
        title = "Users",
        subtitle = "Player roster, account status & ban enforcement",
        icon = Icons.Default.PeopleAlt,
        category = AdminCategory.GOVERNANCE
    ),
    NOTIFICATIONS(
        route = "notifications",
        title = "Notifications",
        subtitle = "Global announcements & in-game push bulletins",
        icon = Icons.Default.Notifications,
        category = AdminCategory.GOVERNANCE
    ),
    AUDIT_LOGS(
        route = "audit_logs",
        title = "Audit Logs",
        subtitle = "Immutable security logs & system events",
        icon = Icons.Default.HistoryEdu,
        category = AdminCategory.GOVERNANCE
    ),
    SETTINGS(
        route = "settings",
        title = "Settings",
        subtitle = "Firebase connection, region & admin parameters",
        icon = Icons.Default.Settings,
        category = AdminCategory.GOVERNANCE
    );

    companion object {
        fun fromRoute(route: String?): AdminSection {
            return entries.firstOrNull { it.route == route } ?: DASHBOARD
        }
    }
}
