package com.example

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import com.example.core.error.Resource
import com.example.data.repository.FirebaseNotificationRepository
import com.example.data.repository.LocalDataStore
import com.example.domain.model.NotificationEntity
import com.example.ui.home.HomeScreen
import com.example.ui.home.HomeViewModel
import com.example.ui.notifications.NotificationsScreen
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.util.concurrent.CopyOnWriteArrayList

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk = [36])
class NotificationCenterTest {

  @Rule
  @JvmField
  val composeTestRule = createComposeRule()

  private val notificationRepository = FirebaseNotificationRepository()

  @Before
  fun setup() {
    LocalDataStore.localUserNotifications.clear()
  }

  @Test
  fun homeNotificationButton_triggersCallback() {
    var notificationClicked = false

    composeTestRule.setContent {
      HomeScreen(
        viewModel = HomeViewModel(
          matchRepository = com.example.data.repository.FirebaseMatchRepository(),
          currentUserId = "test_user_1",
        ),
        currentUser = null,
        wallet = null,
        onMatchClick = {},
        onWalletClick = {},
        onDepositClick = {},
        onNotificationClick = { notificationClicked = true },
        onProfileClick = {},
        onRulesClick = {},
        onSupportClick = {},
        onAdminClick = {},
      )
    }

    composeTestRule.onNodeWithTag("home_notification_button").assertIsDisplayed()
    composeTestRule.onNodeWithTag("home_notification_button").performClick()
    assertTrue(notificationClicked)
  }

  @Test
  fun notificationsScreen_showsEmptyState_whenNoNotifications() {
    composeTestRule.setContent {
      NotificationsScreen(
        userId = "user_with_no_notifs",
        onNavigateBack = {},
        notificationRepository = notificationRepository,
      )
    }

    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("notifications_screen").assertIsDisplayed()
    composeTestRule.onNodeWithTag("notifications_empty_state").assertIsDisplayed()
    composeTestRule.onNodeWithText("কোনো নতুন নোটিফিকেশন নেই").assertIsDisplayed()
  }

  @Test
  fun notificationsScreen_doesNotShowOtherUsersNotifications() {
    // Add notification for user_B
    LocalDataStore.localUserNotifications["user_B"] = CopyOnWriteArrayList(
      listOf(
        NotificationEntity(
          notificationId = "notif_user_b",
          userId = "user_B",
          title = "Secret Alert For User B",
          body = "This must not be visible to user A",
          createdAt = System.currentTimeMillis(),
        )
      )
    )

    // View notifications for user_A
    composeTestRule.setContent {
      NotificationsScreen(
        userId = "user_A",
        onNavigateBack = {},
        notificationRepository = notificationRepository,
      )
    }

    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("notifications_empty_state").assertIsDisplayed()
    composeTestRule.onNodeWithText("কোনো নতুন নোটিফিকেশন নেই").assertIsDisplayed()
  }

  @Test
  fun notificationsScreen_showsUserNotifications_andMarksAsReadOnClick() {
    val targetUser = "user_real_winner"
    val notifId = "notif_winner_1"
    LocalDataStore.localUserNotifications[targetUser] = CopyOnWriteArrayList(
      listOf(
        NotificationEntity(
          notificationId = notifId,
          userId = targetUser,
          title = "Prize Credited! 🏆",
          body = "Congratulations! You won ৳ 90.",
          isRead = false,
          createdAt = System.currentTimeMillis(),
        )
      )
    )

    composeTestRule.setContent {
      NotificationsScreen(
        userId = targetUser,
        onNavigateBack = {},
        notificationRepository = notificationRepository,
      )
    }

    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("notification_item_$notifId").assertIsDisplayed()
    composeTestRule.onNodeWithText("Prize Credited! 🏆").assertIsDisplayed()
    composeTestRule.onNodeWithText("NEW").assertIsDisplayed()

    // Click on the notification to mark it as read
    composeTestRule.onNodeWithTag("notification_item_$notifId").performClick()
    composeTestRule.waitForIdle()

    // Verify local storage isRead changed to true
    val updatedNotif = LocalDataStore.localUserNotifications[targetUser]?.firstOrNull { it.notificationId == notifId }
    assertTrue(updatedNotif?.isRead == true)
  }

  @Test
  fun test1_notificationListIsSourceOfTruth() = runBlocking {
    val userId = "user_source_of_truth"
    val notif = NotificationEntity(
      notificationId = "truth_notif_1",
      userId = userId,
      title = "Room Code Alert",
      body = "Room Code: 12345",
      isRead = false,
      createdAt = System.currentTimeMillis(),
    )
    val createRes = notificationRepository.createNotification(notif)
    assertTrue(createRes is Resource.Success)

    val flowRes = notificationRepository.getNotifications(userId, 50).first()
    assertTrue(flowRes is Resource.Success)
    val list = (flowRes as Resource.Success<List<NotificationEntity>>).data
    assertEquals(1, list.size)
    assertEquals("truth_notif_1", list[0].notificationId)
    assertEquals("Room Code Alert", list[0].title)
  }

  @Test
  fun test2_unreadCountRemainsCorrectAcrossNavigationFlow() = runBlocking {
    val userId = "user_nav_flow"
    val notif1 = NotificationEntity(
      notificationId = "nav_notif_1",
      userId = userId,
      title = "Match Starting",
      body = "Join room now",
      isRead = false,
      createdAt = 1000L,
    )
    val notif2 = NotificationEntity(
      notificationId = "nav_notif_2",
      userId = userId,
      title = "Result Updated",
      body = "You scored 5 kills",
      isRead = false,
      createdAt = 2000L,
    )
    notificationRepository.createNotification(notif1)
    notificationRepository.createNotification(notif2)

    // Initial state on Home: 2 unread
    val initialRes = notificationRepository.getNotifications(userId, 50).first()
    val initialNotifications = (initialRes as Resource.Success<List<NotificationEntity>>).data
    var unreadCount = initialNotifications.count { !it.isRead }
    assertEquals(2, unreadCount)

    // User navigates to Notification Center and marks one notification as read
    notificationRepository.markAsRead("nav_notif_1")

    // Upon navigating back to Home, unread count is preserved as 1 without reset
    val afterRes = notificationRepository.getNotifications(userId, 50).first()
    val afterNavNotifications = (afterRes as Resource.Success<List<NotificationEntity>>).data
    unreadCount = afterNavNotifications.count { !it.isRead }
    assertEquals(1, unreadCount)
  }

  @Test
  fun test3_markingNotificationReadUpdatesUnreadCount() = runBlocking {
    val userId = "user_mark_read"
    val notif = NotificationEntity(
      notificationId = "read_notif_1",
      userId = userId,
      title = "Deposit Confirmed",
      body = "50 BDT added",
      isRead = false,
      createdAt = System.currentTimeMillis(),
    )
    notificationRepository.createNotification(notif)

    val beforeRes = notificationRepository.getNotifications(userId, 50).first()
    val before = (beforeRes as Resource.Success<List<NotificationEntity>>).data
    assertEquals(1, before.count { !it.isRead })

    val markRes = notificationRepository.markAsRead("read_notif_1")
    assertTrue(markRes is Resource.Success)

    val afterRes = notificationRepository.getNotifications(userId, 50).first()
    val after = (afterRes as Resource.Success<List<NotificationEntity>>).data
    assertEquals(0, after.count { !it.isRead })
    assertTrue(after[0].isRead)
  }

  @Test
  fun test4_markAllAsReadUpdatesUnreadCount() = runBlocking {
    val userId = "user_mark_all_read"
    notificationRepository.createNotification(
      NotificationEntity(notificationId = "all_1", userId = userId, title = "A", body = "A", isRead = false)
    )
    notificationRepository.createNotification(
      NotificationEntity(notificationId = "all_2", userId = userId, title = "B", body = "B", isRead = false)
    )

    val beforeRes = notificationRepository.getNotifications(userId, 50).first()
    val before = (beforeRes as Resource.Success<List<NotificationEntity>>).data
    assertEquals(2, before.count { !it.isRead })

    val markAllRes = notificationRepository.markAllAsRead(userId)
    assertTrue(markAllRes is Resource.Success)

    val afterRes = notificationRepository.getNotifications(userId, 50).first()
    val after = (afterRes as Resource.Success<List<NotificationEntity>>).data
    assertEquals(0, after.count { !it.isRead })
    assertTrue(after.all { it.isRead })
  }

  @Test
  fun test5_notificationPersistsAfterRepositoryRecreation() = runBlocking {
    val userId = "user_repo_recreate"
    val repo1 = FirebaseNotificationRepository()
    val notif = NotificationEntity(
      notificationId = "persist_notif_1",
      userId = userId,
      title = "Persistent Notif",
      body = "Should survive repo recreation",
      isRead = false,
      createdAt = System.currentTimeMillis(),
    )
    repo1.createNotification(notif)

    // Recreate repository instance
    val repo2 = FirebaseNotificationRepository()
    val fetchedRes = repo2.getNotifications(userId, 50).first()
    val fetched = (fetchedRes as Resource.Success<List<NotificationEntity>>).data
    assertEquals(1, fetched.size)
    assertEquals("persist_notif_1", fetched[0].notificationId)
    assertEquals("Persistent Notif", fetched[0].title)
  }

  @Test
  fun test6_duplicateNotificationIdDoesNotCreateDuplicateRecords() = runBlocking {
    val userId = "user_duplicate_test"
    val notifId = "duplicate_test_id"
    val notifInitial = NotificationEntity(
      notificationId = notifId,
      userId = userId,
      title = "Initial Title",
      body = "Initial Body",
      isRead = false,
      createdAt = 1000L,
    )
    val notifUpdated = NotificationEntity(
      notificationId = notifId,
      userId = userId,
      title = "Updated Title",
      body = "Updated Body",
      isRead = false,
      createdAt = 2000L,
    )

    // Submit duplicate notification ID
    notificationRepository.createNotification(notifInitial)
    notificationRepository.createNotification(notifUpdated)

    val listRes = notificationRepository.getNotifications(userId, 50).first()
    val list = (listRes as Resource.Success<List<NotificationEntity>>).data
    assertEquals(1, list.size)
    assertEquals(notifId, list[0].notificationId)
    assertEquals("Updated Title", list[0].title)
    assertEquals("Updated Body", list[0].body)
  }

  @Test
  fun test7_notificationTapDirectlyShowsContentMessage_andMarksAsRead() {
    val targetUser = "user_tap_dialog"
    val notifId = "tap_notif_777"
    val notifTitle = "Room Code Alert"
    val notifBody = "Room Code: RC-888999. Join immediately!"

    LocalDataStore.localUserNotifications[targetUser] = CopyOnWriteArrayList(
      listOf(
        NotificationEntity(
          notificationId = notifId,
          userId = targetUser,
          title = notifTitle,
          body = notifBody,
          isRead = false,
          createdAt = System.currentTimeMillis(),
        )
      )
    )

    composeTestRule.setContent {
      NotificationsScreen(
        userId = targetUser,
        onNavigateBack = {},
        notificationRepository = notificationRepository,
      )
    }

    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("notification_item_$notifId").assertIsDisplayed()

    // Tap the notification
    composeTestRule.onNodeWithTag("notification_item_$notifId").performClick()
    composeTestRule.waitForIdle()

    // Notification marked as read
    val updatedNotif = LocalDataStore.localUserNotifications[targetUser]?.firstOrNull { it.notificationId == notifId }
    assertTrue(updatedNotif?.isRead == true)

    // Direct content dialog is shown with exact title and body
    composeTestRule.onNodeWithTag("notification_detail_dialog").assertIsDisplayed()
    composeTestRule.onNodeWithText(notifTitle).assertIsDisplayed()
    composeTestRule.onNodeWithText(notifBody).assertIsDisplayed()

    // Click confirm/dismiss
    composeTestRule.onNodeWithTag("notification_dialog_close_button").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("notification_detail_dialog").assertDoesNotExist()
  }
}
