package com.example.data.sample

import com.example.domain.model.*

/**
 * Phase 1 Sample Data Foundation
 * Provides realistic game entities for Ludo & Carrom 1v1 match coordination,
 * wallet financial breakdown, and transaction history according to Phase 1 specifications.
 */
object SampleData {
  val sampleUser = UserEntity(
    userId = "AD-USER-9481",
    displayName = "Rohit Sharma",
    phoneNumber = "9876543210",
    avatarUrl = "",
    role = "PLAYER",
    isBlocked = false,
    totalMatches = 38,
    wins = 26,
    losses = 12,
    totalWinnings = 1850.0,
    walletBalance = 240.0,
    createdAt = 1715000000000L,
    lastActiveAt = System.currentTimeMillis(),
  )

  val sampleWallet = WalletEntity(
    uid = "AD-USER-9481",
    availableBalance = 24000L, // 240.00 BDT in minor units
    pendingBalance = 5000L, // 50.00 BDT held in active match
    totalDeposited = 50000L, // 500.00 BDT
    totalWithdrawn = 15000L, // 150.00 BDT
    totalWinnings = 18000L, // 180.00 BDT
    updatedAt = System.currentTimeMillis(),
  )

  val sampleMatches = listOf(
    MatchEntity(
      matchId = "match_101",
      matchNumber = "#M-101",
      title = "Ludo Classic 1v1 Speed Battle",
      gameType = GameType.LUDO.name,
      entryFee = 50.0,
      entryFeeMinorUnits = 5000L,
      prizePool = 90.0,
      prizeMinorUnits = 9000L,
      status = MatchStatus.AVAILABLE.name,
      gameCode = "",
      isCodeVisible = false,
      scheduledTime = System.currentTimeMillis() + 15 * 60 * 1000L,
      scheduledAt = System.currentTimeMillis() + 15 * 60 * 1000L,
      maxPlayers = 2,
      joinedPlayersCount = 1,
      createdAt = System.currentTimeMillis() - 30 * 60 * 1000L,
      updatedAt = System.currentTimeMillis() - 30 * 60 * 1000L,
    ),
    MatchEntity(
      matchId = "match_102",
      matchNumber = "#M-102",
      title = "Carrom Point Pro 1v1 Arena",
      gameType = GameType.CARROM.name,
      entryFee = 100.0,
      entryFeeMinorUnits = 10000L,
      prizePool = 180.0,
      prizeMinorUnits = 18000L,
      status = MatchStatus.AVAILABLE.name,
      gameCode = "",
      isCodeVisible = false,
      scheduledTime = System.currentTimeMillis() + 25 * 60 * 1000L,
      scheduledAt = System.currentTimeMillis() + 25 * 60 * 1000L,
      maxPlayers = 2,
      joinedPlayersCount = 1,
      createdAt = System.currentTimeMillis() - 20 * 60 * 1000L,
      updatedAt = System.currentTimeMillis() - 20 * 60 * 1000L,
    ),
    MatchEntity(
      matchId = "match_103",
      matchNumber = "#M-103",
      title = "Ludo Master 1v1 High Stakes",
      gameType = GameType.LUDO.name,
      entryFee = 50.0,
      entryFeeMinorUnits = 5000L,
      prizePool = 90.0,
      prizeMinorUnits = 9000L,
      status = MatchStatus.RUNNING.name,
      gameCode = "LD-883921",
      isCodeVisible = true, // Player is joined!
      scheduledTime = System.currentTimeMillis() - 5 * 60 * 1000L,
      scheduledAt = System.currentTimeMillis() - 5 * 60 * 1000L,
      maxPlayers = 2,
      joinedPlayersCount = 2,
      createdAt = System.currentTimeMillis() - 40 * 60 * 1000L,
      updatedAt = System.currentTimeMillis() - 40 * 60 * 1000L,
    ),
    MatchEntity(
      matchId = "match_104",
      matchNumber = "#M-104",
      title = "Carrom Board 1v1 Duel",
      gameType = GameType.CARROM.name,
      entryFee = 25.0,
      entryFeeMinorUnits = 2500L,
      prizePool = 45.0,
      prizeMinorUnits = 4500L,
      status = MatchStatus.FULL.name,
      gameCode = "",
      isCodeVisible = false,
      scheduledTime = System.currentTimeMillis() + 45 * 60 * 1000L,
      scheduledAt = System.currentTimeMillis() + 45 * 60 * 1000L,
      maxPlayers = 2,
      joinedPlayersCount = 2,
      createdAt = System.currentTimeMillis() - 15 * 60 * 1000L,
      updatedAt = System.currentTimeMillis() - 15 * 60 * 1000L,
    ),
    MatchEntity(
      matchId = "match_105",
      matchNumber = "#M-105",
      title = "Ludo Quick Match 1v1",
      gameType = GameType.LUDO.name,
      entryFee = 20.0,
      entryFeeMinorUnits = 2000L,
      prizePool = 36.0,
      prizeMinorUnits = 3600L,
      status = MatchStatus.AVAILABLE.name,
      gameCode = "",
      isCodeVisible = false,
      scheduledTime = System.currentTimeMillis() + 60 * 60 * 1000L,
      scheduledAt = System.currentTimeMillis() + 60 * 60 * 1000L,
      maxPlayers = 2,
      joinedPlayersCount = 0,
      createdAt = System.currentTimeMillis() - 10 * 60 * 1000L,
      updatedAt = System.currentTimeMillis() - 10 * 60 * 1000L,
    ),
    MatchEntity(
      matchId = "match_106",
      matchNumber = "#M-106",
      title = "Carrom Grand Championship",
      gameType = GameType.CARROM.name,
      entryFee = 200.0,
      entryFeeMinorUnits = 20000L,
      prizePool = 360.0,
      prizeMinorUnits = 36000L,
      status = MatchStatus.AVAILABLE.name,
      gameCode = "",
      isCodeVisible = false,
      scheduledTime = System.currentTimeMillis() + 120 * 60 * 1000L,
      scheduledAt = System.currentTimeMillis() + 120 * 60 * 1000L,
      maxPlayers = 2,
      joinedPlayersCount = 1,
      createdAt = System.currentTimeMillis() - 5 * 60 * 1000L,
      updatedAt = System.currentTimeMillis() - 5 * 60 * 1000L,
    ),
  )

  val sampleDeposits = listOf(
    DepositEntity(
      depositId = "DEP-1001",
      uid = "AD-USER-9481",
      amount = 20000L, // 200.00 BDT
      method = "BKASH",
      senderNumber = "01712345678",
      trxId = "9J8K7L6M",
      screenshotUrl = "",
      status = DepositStatus.APPROVED.name,
      createdAt = System.currentTimeMillis() - 24 * 3600 * 1000L,
      processedAt = System.currentTimeMillis() - 23 * 3600 * 1000L,
      adminUid = "ADMIN-01",
    )
  )

  val sampleWithdrawals = listOf(
    WithdrawalEntity(
      withdrawalId = "WTH-2001",
      uid = "AD-USER-9481",
      amount = 15000L, // 150.00 BDT
      method = "BKASH",
      recipientNumber = "01712345678",
      status = WithdrawalStatus.APPROVED.name,
      createdAt = System.currentTimeMillis() - 48 * 3600 * 1000L,
      processedAt = System.currentTimeMillis() - 47 * 3600 * 1000L,
      adminUid = "ADMIN-01",
    )
  )

  val sampleTransactions = listOf(
    TransactionEntity(
      transactionId = "TXN-90218",
      uid = "AD-USER-9481",
      amount = 9000L, // +90.00 BDT
      type = TransactionType.MATCH_PRIZE.name,
      status = TransactionStatus.COMPLETED.name,
      beforeBalance = 15000L,
      afterBalance = 24000L,
      referenceId = "#M-098",
      source = "MATCH_REWARD",
      description = "Prize pool credit for Ludo 1v1 #M-098 victory",
      createdAt = System.currentTimeMillis() - 2 * 3600 * 1000L,
      processedAt = System.currentTimeMillis() - 2 * 3600 * 1000L,
    ),
    TransactionEntity(
      transactionId = "TXN-90192",
      uid = "AD-USER-9481",
      amount = 5000L, // 50.00 BDT
      type = TransactionType.MATCH_ENTRY.name,
      status = TransactionStatus.COMPLETED.name,
      beforeBalance = 20000L,
      afterBalance = 15000L,
      referenceId = "#M-098",
      source = "CONTEST_JOIN",
      description = "Entry fee deduction for Ludo 1v1 #M-098",
      createdAt = System.currentTimeMillis() - 3 * 3600 * 1000L,
      processedAt = System.currentTimeMillis() - 3 * 3600 * 1000L,
    ),
    TransactionEntity(
      transactionId = "TXN-89943",
      uid = "AD-USER-9481",
      amount = 20000L, // +200.00 BDT
      type = TransactionType.DEPOSIT.name,
      status = TransactionStatus.COMPLETED.name,
      beforeBalance = 0L,
      afterBalance = 20000L,
      referenceId = "UPI-REF-8849120",
      source = "BKASH_DEPOSIT",
      description = "Wallet deposit via bKash (Admin verified)",
      createdAt = System.currentTimeMillis() - 24 * 3600 * 1000L,
      processedAt = System.currentTimeMillis() - 24 * 3600 * 1000L,
    ),
    TransactionEntity(
      transactionId = "TXN-88210",
      uid = "AD-USER-9481",
      amount = 15000L, // 150.00 BDT
      type = TransactionType.WITHDRAW.name,
      status = TransactionStatus.COMPLETED.name,
      beforeBalance = 35000L,
      afterBalance = 20000L,
      referenceId = "PAYOUT-55102",
      source = "BKASH_PAYOUT",
      description = "Winnings withdrawal to 01712345678",
      createdAt = System.currentTimeMillis() - 48 * 3600 * 1000L,
      processedAt = System.currentTimeMillis() - 48 * 3600 * 1000L,
    ),
  )

  val sampleHistoryMatches = listOf(
    MatchEntity(
      matchId = "match_098",
      matchNumber = "#M-098",
      title = "Ludo Classic 1v1 Speed Battle",
      gameType = GameType.LUDO.name,
      entryFee = 50.0,
      prizePool = 90.0,
      status = MatchStatus.COMPLETED.name,
      gameCode = "LD-771923",
      isCodeVisible = true,
      scheduledTime = System.currentTimeMillis() - 3 * 3600 * 1000L,
      maxPlayers = 2,
      joinedPlayersCount = 2,
      winnerUserId = "AD-USER-9481", // Rohit won!
      createdAt = System.currentTimeMillis() - 4 * 3600 * 1000L,
    ),
    MatchEntity(
      matchId = "match_095",
      matchNumber = "#M-095",
      title = "Carrom Point Pro 1v1 Arena",
      gameType = GameType.CARROM.name,
      entryFee = 100.0,
      prizePool = 180.0,
      status = MatchStatus.COMPLETED.name,
      gameCode = "CR-119284",
      isCodeVisible = true,
      scheduledTime = System.currentTimeMillis() - 26 * 3600 * 1000L,
      maxPlayers = 2,
      joinedPlayersCount = 2,
      winnerUserId = "AD-USER-1102", // Opponent won
      createdAt = System.currentTimeMillis() - 27 * 3600 * 1000L,
    ),
    MatchEntity(
      matchId = "match_090",
      matchNumber = "#M-090",
      title = "Ludo Master 1v1 High Stakes",
      gameType = GameType.LUDO.name,
      entryFee = 100.0,
      prizePool = 180.0,
      status = MatchStatus.COMPLETED.name,
      gameCode = "LD-663819",
      isCodeVisible = true,
      scheduledTime = System.currentTimeMillis() - 52 * 3600 * 1000L,
      maxPlayers = 2,
      joinedPlayersCount = 2,
      winnerUserId = "AD-USER-9481", // Rohit won!
      createdAt = System.currentTimeMillis() - 53 * 3600 * 1000L,
    ),
  )

  val sampleNotifications = listOf(
    NotificationEntity(
      notificationId = "notif_1",
      userId = "AD-USER-9481",
      title = "Room Code Added for Match #M-103",
      body = "Super Admin added room code: LD-883921. Open Ludo King and enter the room code to play.",
      targetScreen = "home",
      isRead = false,
      createdAt = System.currentTimeMillis() - 10 * 60 * 1000L,
    ),
    NotificationEntity(
      notificationId = "notif_2",
      userId = "AD-USER-9481",
      title = "Prize Credited ₹90",
      body = "Congratulations! You won Match #M-098. Prize ₹90 has been credited to your winning balance.",
      targetScreen = "wallet",
      isRead = false,
      createdAt = System.currentTimeMillis() - 2 * 3600 * 1000L,
    ),
    NotificationEntity(
      notificationId = "notif_3",
      userId = "AD-USER-9481",
      title = "Deposit Confirmed ₹200",
      body = "Your deposit of ₹200 via UPI has been verified and added to your wallet balance.",
      targetScreen = "wallet",
      isRead = true,
      createdAt = System.currentTimeMillis() - 24 * 3600 * 1000L,
    ),
  )

  fun getSamplePlayersForMatch(matchId: String): List<MatchPlayerEntity> {
    return when (matchId) {
      "match_103" -> listOf(
        MatchPlayerEntity("mp_1", "match_103", "AD-USER-9481", "Rohit Sharma", PlayerSlot.PLAYER_1.name, System.currentTimeMillis() - 35 * 60 * 1000L, true),
        MatchPlayerEntity("mp_2", "match_103", "AD-USER-4421", "Vikram Singh", PlayerSlot.PLAYER_2.name, System.currentTimeMillis() - 25 * 60 * 1000L, true),
      )
      "match_101" -> listOf(
        MatchPlayerEntity("mp_3", "match_101", "AD-USER-7712", "Amit Verma", PlayerSlot.PLAYER_1.name, System.currentTimeMillis() - 10 * 60 * 1000L, true),
      )
      "match_102" -> listOf(
        MatchPlayerEntity("mp_4", "match_102", "AD-USER-3391", "Karan Johar", PlayerSlot.PLAYER_1.name, System.currentTimeMillis() - 8 * 60 * 1000L, true),
      )
      "match_104" -> listOf(
        MatchPlayerEntity("mp_5", "match_104", "AD-USER-2211", "Deepak Rao", PlayerSlot.PLAYER_1.name, System.currentTimeMillis() - 14 * 60 * 1000L, true),
        MatchPlayerEntity("mp_6", "match_104", "AD-USER-9988", "Suresh Raina", PlayerSlot.PLAYER_2.name, System.currentTimeMillis() - 12 * 60 * 1000L, true),
      )
      else -> emptyList()
    }
  }
}
