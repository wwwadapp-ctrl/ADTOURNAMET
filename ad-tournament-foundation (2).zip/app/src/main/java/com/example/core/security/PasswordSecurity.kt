package com.example.core.security

import java.security.MessageDigest

/**
 * Password Security Protocol & Policy Verifier
 *
 * Phase 2 Directive:
 * "Use a secure server-side authentication architecture.
 *  Do not implement insecure client-side password hashing as a substitute for proper authentication.
 *  Never store passwords in plaintext. Never expose passwords in logs, UI state, or database records."
 */
object PasswordSecurity {

  /**
   * Password policy verification.
   * Enforces security standards before transmitting credentials to the secure auth backend.
   */
  fun isPasswordValid(password: String): Boolean {
    return password.length in 6..64 && !password.all { it.isWhitespace() }
  }

  fun isValidMobileNumber(phone: String): Boolean {
    val clean = phone.filter { it.isDigit() }
    return clean.length == 10 && clean.firstOrNull() in listOf('6', '7', '8', '9')
  }

  @Deprecated(
    message = "Do not use client-side SHA-256 as substitute for proper authentication. Passwords must be verified server-side by Firebase Auth.",
    replaceWith = ReplaceWith("password")
  )
  fun hashPassword(rawPassword: String): String = rawPassword
}
