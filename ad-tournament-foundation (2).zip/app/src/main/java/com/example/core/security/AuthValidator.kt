package com.example.core.security

/**
 * Result of authentication input validation.
 */
data class ValidationResult(
  val isValid: Boolean,
  val errorMessage: String? = null,
)

/**
 * Comprehensive client and server-side validation rules for authentication.
 * Ensures inputs strictly conform to AD Tournament security requirements:
 * - Clean mobile number (10 digits, valid prefixes)
 * - Secure password policy (min 6 characters, max 64, not whitespace)
 * - Proper name format (2-50 characters, letters/spaces only)
 * - 6-digit numeric OTP code
 */
object AuthValidator {

  /**
   * Validates a 10-digit mobile number.
   * Standard Indian mobile numbers begin with 6, 7, 8, or 9.
   */
  fun validateMobileNumber(phone: String): ValidationResult {
    val clean = phone.filter { it.isDigit() }
    return when {
      clean.isEmpty() -> ValidationResult(false, "Mobile number cannot be empty")
      clean.length != 10 -> ValidationResult(false, "Mobile number must be exactly 10 digits")
      clean.first() !in listOf('6', '7', '8', '9') -> ValidationResult(false, "Mobile number must start with 6, 7, 8, or 9")
      else -> ValidationResult(true)
    }
  }

  /**
   * Validates password strength and length.
   * Requirement: minimum 6 characters, maximum 64 characters, not purely whitespace.
   */
  fun validatePassword(password: String): ValidationResult {
    return when {
      password.isEmpty() -> ValidationResult(false, "Password cannot be empty")
      password.length < 6 -> ValidationResult(false, "Password must be at least 6 characters")
      password.length > 64 -> ValidationResult(false, "Password must not exceed 64 characters")
      password.all { it.isWhitespace() } -> ValidationResult(false, "Password cannot consist only of whitespace")
      else -> ValidationResult(true)
    }
  }

  /**
   * Validates user full name.
   * Requirement: 2 to 50 characters, letters and spaces only.
   */
  fun validateFullName(name: String): ValidationResult {
    val trimmed = name.trim()
    return when {
      trimmed.isEmpty() -> ValidationResult(false, "Full name cannot be empty")
      trimmed.length < 2 -> ValidationResult(false, "Full name must be at least 2 characters")
      trimmed.length > 50 -> ValidationResult(false, "Full name cannot exceed 50 characters")
      !trimmed.all { it.isLetter() || it.isWhitespace() || it == '.' || it == '-' } ->
        ValidationResult(false, "Full name can only contain letters, spaces, dots, or hyphens")
      else -> ValidationResult(true)
    }
  }

  /**
   * Validates confirm password matches initial password.
   */
  fun validateConfirmPassword(password: String, confirm: String): ValidationResult {
    return when {
      confirm.isEmpty() -> ValidationResult(false, "Please confirm your password")
      password != confirm -> ValidationResult(false, "Passwords do not match")
      else -> ValidationResult(true)
    }
  }

  /**
   * Validates a 6-digit OTP code.
   */
  fun validateOtp(otp: String): ValidationResult {
    val clean = otp.filter { it.isDigit() }
    return when {
      clean.isEmpty() -> ValidationResult(false, "Please enter the 6-digit OTP")
      clean.length != 6 -> ValidationResult(false, "OTP must be exactly 6 digits")
      else -> ValidationResult(true)
    }
  }
}
