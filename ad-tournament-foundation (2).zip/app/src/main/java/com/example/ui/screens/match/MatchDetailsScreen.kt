package com.example.ui.screens.match

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.error.Resource
import com.example.domain.model.*
import com.example.domain.repository.MatchRepository
import com.example.domain.repository.WalletRepository
import com.example.ui.components.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MatchDetailsScreen(
  matchId: String,
  userId: String,
  onNavigateBack: () -> Unit,
  onNavigateToWallet: () -> Unit,
  matchRepository: MatchRepository,
  walletRepository: WalletRepository,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()
  val matchResource by matchRepository.getMatchById(matchId).collectAsState(initial = Resource.Loading)
  val playersResource by matchRepository.getMatchPlayers(matchId).collectAsState(initial = Resource.Loading)
  val walletResource by walletRepository.getWallet(userId).collectAsState(initial = Resource.Loading)

  var showJoinConfirmDialog by remember { mutableStateOf(false) }
  var isJoining by remember { mutableStateOf(false) }
  var joinErrorMessage by remember { mutableStateOf<String?>(null) }
  var showJoinSuccessDialog by remember { mutableStateOf(false) }
  var hasLocalJoined by remember { mutableStateOf(false) }
  var showCodeCopiedMessage by remember { mutableStateOf(false) }
  var showRulesDialog by remember { mutableStateOf(false) }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Column {
            Text(
              text = "Match Details",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = Color.White,
            )
            val matchNumber = (matchResource as? Resource.Success)?.data?.matchNumber
            if (!matchNumber.isNullOrBlank()) {
              Text(
                text = matchNumber,
                style = MaterialTheme.typography.labelSmall,
                color = Gold400,
              )
            }
          }
        },
        navigationIcon = {
          IconButton(
            onClick = onNavigateBack,
            modifier = Modifier.testTag("match_details_back_button"),
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "Back",
              tint = Color.White,
            )
          }
        },
        actions = {
          IconButton(onClick = { showRulesDialog = true }) {
            Icon(
              imageVector = Icons.Default.HelpOutline,
              contentDescription = "Match Rules",
              tint = Slate400,
            )
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = NavySurface,
        ),
      )
    },
    containerColor = NavyDark,
    modifier = modifier.fillMaxSize(),
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding),
    ) {
      when (val resource = matchResource) {
        is Resource.Loading, is Resource.Idle -> {
          LoadingState(message = "Loading match details...")
        }
        is Resource.Error -> {
          ErrorState(
            message = resource.error.userMessage,
            onRetry = onNavigateBack,
            retryButtonText = "Go Back",
          )
        }
        is Resource.Success -> {
          val match = resource.data
          if (match == null) {
            EmptyState(
              title = "Match Not Found",
              description = "The requested tournament match does not exist or has been removed.",
              actionButtonText = "Back to Matches",
              onActionClick = onNavigateBack,
            )
          } else {
            val players = (playersResource as? Resource.Success)?.data ?: emptyList()
            val userWallet = (walletResource as? Resource.Success)?.data

            // Check if current user is one of the joined players
            val isUserJoined = hasLocalJoined || players.any { it.effectiveUid == userId || it.userId == userId } || (match.status == MatchStatus.RUNNING.name && match.isCodeVisible)
            val effectiveJoinedCount = if (hasLocalJoined && players.none { it.effectiveUid == userId || it.userId == userId }) {
              (match.joinedPlayersCount + 1).coerceAtMost(match.maxPlayers)
            } else {
              match.joinedPlayersCount
            }

            val entryFeeMinor = match.effectiveEntryFeeMinorUnits
            val userAvailableMinor = userWallet?.availableBalance ?: 0L
            val hasSufficientBalance = userAvailableMinor >= entryFeeMinor

            MatchDetailsContent(
              match = match,
              players = players,
              userId = userId,
              isUserJoined = isUserJoined,
              effectiveJoinedCount = effectiveJoinedCount,
              userWallet = userWallet,
              onJoinClick = { showJoinConfirmDialog = true },
              onNavigateToWallet = onNavigateToWallet,
              onCopyRoomCode = { code ->
                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clip = ClipData.newPlainText("Game Room Code", code)
                clipboard.setPrimaryClip(clip)
                Toast.makeText(context, "Room Code copied: $code", Toast.LENGTH_SHORT).show()
                showCodeCopiedMessage = true
              },
            )

            // Real Join Confirmation Dialog
            if (showJoinConfirmDialog) {
              val formattedMatchTime = remember(match.scheduledTime) {
                if (match.scheduledTime > 0) {
                  SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(match.scheduledTime))
                } else {
                  "Ready to Start"
                }
              }

              AlertDialog(
                onDismissRequest = {
                  if (!isJoining) showJoinConfirmDialog = false
                },
                shape = RoundedCornerShape(16.dp),
                containerColor = Slate900,
                title = {
                  Text(
                    text = "Confirm Match Join",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = Slate50,
                  )
                },
                text = {
                  Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                      text = "${match.matchNumber} • ${match.title}",
                      style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                      color = Color.White,
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                      text = "Game: ${if (match.gameType.equals("LUDO", ignoreCase = true)) "Ludo 1v1 Battle" else "Carrom 1v1 Battle"}",
                      style = MaterialTheme.typography.bodySmall,
                      color = Slate300,
                    )
                    Text(
                      text = "Schedule: $formattedMatchTime",
                      style = MaterialTheme.typography.bodySmall,
                      color = Slate400,
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Financial summary card
                    Surface(
                      color = Slate950,
                      shape = RoundedCornerShape(10.dp),
                      border = BorderStroke(1.dp, Slate800),
                      modifier = Modifier.fillMaxWidth(),
                    ) {
                      Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                          modifier = Modifier.fillMaxWidth(),
                          horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                          Text(text = "Entry Fee:", style = MaterialTheme.typography.bodySmall, color = Slate400)
                          Text(
                            text = "৳${"%.0f".format(entryFeeMinor / 100.0)}",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                            color = Gold400,
                          )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                          modifier = Modifier.fillMaxWidth(),
                          horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                          Text(text = "Prize Pool:", style = MaterialTheme.typography.bodySmall, color = Slate400)
                          Text(
                            text = "৳${"%.0f".format(match.effectivePrizeMinorUnits / 100.0)}",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                            color = Cyan400,
                          )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        HorizontalDivider(color = Slate800, thickness = 1.dp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                          modifier = Modifier.fillMaxWidth(),
                          horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                          Text(text = "Your Available Balance:", style = MaterialTheme.typography.bodySmall, color = Slate400)
                          Text(
                            text = "৳${"%.2f".format(userAvailableMinor / 100.0)}",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                            color = if (hasSufficientBalance) Emerald400 else Rose400,
                          )
                        }
                      }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    if (!hasSufficientBalance) {
                      Surface(
                        color = Rose900.copy(alpha = 0.25f),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, Rose600.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth(),
                      ) {
                        Row(
                          modifier = Modifier.padding(10.dp),
                          verticalAlignment = Alignment.CenterVertically,
                        ) {
                          Icon(Icons.Default.Warning, contentDescription = null, tint = Rose400, modifier = Modifier.size(16.dp))
                          Spacer(modifier = Modifier.width(8.dp))
                          Text(
                            text = "Insufficient balance. You need ৳${"%.0f".format(entryFeeMinor / 100.0)} to enter. Please deposit funds first.",
                            style = MaterialTheme.typography.labelSmall,
                            color = Rose400,
                          )
                        }
                      }
                    } else {
                      Surface(
                        color = Indigo900.copy(alpha = 0.25f),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, Indigo600.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth(),
                      ) {
                        Row(
                          modifier = Modifier.padding(10.dp),
                          verticalAlignment = Alignment.CenterVertically,
                        ) {
                          Icon(Icons.Default.Info, contentDescription = null, tint = Cyan400, modifier = Modifier.size(16.dp))
                          Spacer(modifier = Modifier.width(8.dp))
                          Text(
                            text = "Entry fee of ৳${"%.0f".format(entryFeeMinor / 100.0)} will be deducted from your wallet balance upon joining.",
                            style = MaterialTheme.typography.labelSmall,
                            color = Cyan300,
                          )
                        }
                      }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Product Rules Reminder
                    Text(
                      text = "• 1v1 Battle (Max 2 players).\n• Cannot leave or cancel after joining.\n• Room code will be posted by Super Admin before match time.",
                      style = MaterialTheme.typography.bodySmall,
                      color = Slate400,
                    )
                  }
                },
                confirmButton = {
                  if (!hasSufficientBalance) {
                    TournamentButton(
                      text = "DEPOSIT TO WALLET",
                      onClick = {
                        showJoinConfirmDialog = false
                        onNavigateToWallet()
                      },
                      variant = TournamentButtonVariant.PRIMARY,
                      modifier = Modifier.fillMaxWidth(),
                      testTag = "deposit_to_wallet_from_join_dialog",
                    )
                  } else {
                    TournamentButton(
                      text = if (isJoining) "JOINING..." else "CONFIRM & DEDUCT ৳${"%.0f".format(entryFeeMinor / 100.0)}",
                      onClick = {
                        isJoining = true
                        coroutineScope.launch {
                          val result = matchRepository.joinMatch(userId, match.matchId)
                          isJoining = false
                          showJoinConfirmDialog = false
                          when (result) {
                            is Resource.Success -> {
                              hasLocalJoined = true
                              showJoinSuccessDialog = true
                            }
                            is Resource.Error -> {
                              joinErrorMessage = result.error.userMessage
                            }
                            else -> {}
                          }
                        }
                      },
                      enabled = !isJoining,
                      modifier = Modifier.fillMaxWidth(),
                      testTag = "confirm_join_match_dialog",
                    )
                  }
                },
                dismissButton = {
                  TournamentButton(
                    text = "CANCEL",
                    onClick = { showJoinConfirmDialog = false },
                    variant = TournamentButtonVariant.OUTLINED,
                    enabled = !isJoining,
                    modifier = Modifier.fillMaxWidth(),
                  )
                },
              )
            }

            // Success feedback dialog
            if (showJoinSuccessDialog) {
              AlertDialog(
                onDismissRequest = { showJoinSuccessDialog = false },
                shape = RoundedCornerShape(16.dp),
                containerColor = Slate900,
                title = {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Emerald400, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                      text = "Registration Successful!",
                      style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                      color = Slate50,
                    )
                  }
                },
                text = {
                  Column {
                    Text(
                      text = "You have joined match ${match.matchNumber} successfully!",
                      style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                      color = Color.White,
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                      text = "Entry fee of ৳${"%.0f".format(entryFeeMinor / 100.0)} was deducted from your wallet.\n\nPlease check the GAME ROOM CODE section above. When the Super Admin posts the room code, copy it to enter the game.",
                      style = MaterialTheme.typography.bodySmall,
                      color = Slate300,
                    )
                  }
                },
                confirmButton = {
                  TournamentButton(
                    text = "GOT IT",
                    onClick = { showJoinSuccessDialog = false },
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "join_success_dialog_dismiss",
                  )
                },
              )
            }

            // Error feedback dialog
            if (joinErrorMessage != null) {
              val isBalanceError = joinErrorMessage?.contains("balance", ignoreCase = true) == true ||
                  joinErrorMessage?.contains("insufficient", ignoreCase = true) == true
              AlertDialog(
                onDismissRequest = { joinErrorMessage = null },
                shape = RoundedCornerShape(16.dp),
                containerColor = Slate900,
                title = {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Error, contentDescription = null, tint = Rose400, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                      text = "Join Match Failed",
                      style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                      color = Slate50,
                    )
                  }
                },
                text = {
                  Text(
                    text = joinErrorMessage ?: "An error occurred while joining the match.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Slate300,
                  )
                },
                confirmButton = {
                  if (isBalanceError) {
                    TournamentButton(
                      text = "DEPOSIT FUNDS",
                      onClick = {
                        joinErrorMessage = null
                        onNavigateToWallet()
                      },
                      modifier = Modifier.fillMaxWidth(),
                    )
                  } else {
                    TournamentButton(
                      text = "CLOSE",
                      onClick = { joinErrorMessage = null },
                      modifier = Modifier.fillMaxWidth(),
                    )
                  }
                },
              )
            }

            // Rules & Fair Play Dialog
            if (showRulesDialog) {
              AlertDialog(
                onDismissRequest = { showRulesDialog = false },
                shape = RoundedCornerShape(16.dp),
                containerColor = Slate900,
                title = {
                  Text(
                    text = "1v1 Tournament Rules",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = Slate50,
                  )
                },
                text = {
                  Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                      text = "1. Max 2 Players:\nThis is a strict 1v1 match. Exactly 2 players compete.\n\n" +
                          "2. No Cancellations:\nOnce you join, you cannot leave or cancel.\n\n" +
                          "3. Room Code Access:\nOnly joined players can see the room code once generated.\n\n" +
                          "4. Proof Submission:\nWinner must take a clear victory screenshot displaying the room code and submit within 15 minutes of completion.\n\n" +
                          "5. Fair Play:\nAny match leaving, hacking, or fake screenshot submission results in an immediate account ban.",
                      style = MaterialTheme.typography.bodySmall,
                      color = Slate300,
                    )
                  }
                },
                confirmButton = {
                  TournamentButton(
                    text = "GOT IT",
                    onClick = { showRulesDialog = false },
                    modifier = Modifier.fillMaxWidth(),
                  )
                },
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun MatchDetailsContent(
  match: MatchEntity,
  players: List<MatchPlayerEntity>,
  userId: String,
  isUserJoined: Boolean,
  effectiveJoinedCount: Int,
  userWallet: WalletEntity?,
  onJoinClick: () -> Unit,
  onNavigateToWallet: () -> Unit,
  onCopyRoomCode: (String) -> Unit,
) {
  val isLudo = match.gameType.equals("LUDO", ignoreCase = true)
  val isRunning = match.status.equals(MatchStatus.RUNNING.name, ignoreCase = true)
  val isCompleted = match.status.equals(MatchStatus.COMPLETED.name, ignoreCase = true)
  val isCancelled = match.status.equals(MatchStatus.CANCELLED.name, ignoreCase = true)
  val isFull = effectiveJoinedCount >= match.maxPlayers || match.status.equals(MatchStatus.FULL.name, ignoreCase = true)
  val isTimePassed = match.scheduledTime > 0 && System.currentTimeMillis() > match.scheduledTime && !isRunning && !isUserJoined
  val canJoin = !isUserJoined && !isFull && !isRunning && !isCompleted && !isCancelled && !isTimePassed && match.status.equals(MatchStatus.AVAILABLE.name, ignoreCase = true)

  val entryFeeMinor = match.effectiveEntryFeeMinorUnits
  val userBalanceMinor = userWallet?.availableBalance ?: 0L
  val hasSufficientBalance = userBalanceMinor >= entryFeeMinor

  val scrollState = rememberScrollState()

  Column(
    modifier = Modifier
      .fillMaxSize()
      .verticalScroll(scrollState)
      .padding(16.dp),
  ) {
    // 1. Hero Game Banner Card
    Surface(
      color = NavyCard,
      shape = RoundedCornerShape(16.dp),
      border = BorderStroke(1.dp, if (isRunning) Indigo600 else NavyCardBorder),
      modifier = Modifier.fillMaxWidth(),
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        // Game Header Row
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
              color = if (isLudo) Indigo600.copy(alpha = 0.25f) else Cyan600.copy(alpha = 0.25f),
              shape = RoundedCornerShape(8.dp),
              border = BorderStroke(1.dp, if (isLudo) Indigo600 else Cyan400),
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Icon(
                  imageVector = if (isLudo) Icons.Default.Casino else Icons.Default.Album,
                  contentDescription = null,
                  tint = if (isLudo) Gold400 else Cyan400,
                  modifier = Modifier.size(16.dp),
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = if (isLudo) "LUDO 1v1" else "CARROM 1v1",
                  style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                  color = Color.White,
                )
              }
            }
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = match.matchNumber,
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = Slate300,
            )
          }

          MatchStatusBadge(
            status = if (isRunning) MatchStatus.RUNNING.name else match.status,
            joinedPlayersCount = effectiveJoinedCount,
            maxPlayers = match.maxPlayers,
            isJoined = isUserJoined,
          )
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text(
          text = match.title.ifBlank { "${if (isLudo) "Ludo" else "Carrom"} 1v1 Tournament" },
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
          color = Color.White,
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Scheduled Date & Time
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.Schedule, contentDescription = null, tint = Gold400, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(8.dp))
          val formattedTime = remember(match.scheduledTime) {
            if (match.scheduledTime > 0) {
              SimpleDateFormat("EEEE, dd MMM • hh:mm a", Locale.getDefault()).format(Date(match.scheduledTime))
            } else {
              "Upcoming / Ready to Start"
            }
          }
          Text(
            text = formattedTime,
            style = MaterialTheme.typography.bodyMedium,
            color = Slate300,
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // 2. Financial Breakdown Card (Entry Fee vs Prize Pool)
    Surface(
      color = Slate900,
      shape = RoundedCornerShape(16.dp),
      border = BorderStroke(1.dp, Slate800),
      modifier = Modifier.fillMaxWidth(),
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Text(
          text = "PRIZE & ENTRY SPECIFICATIONS",
          style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
          color = Slate400,
        )
        Spacer(modifier = Modifier.height(12.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column {
            Text(text = "Entry Fee", style = MaterialTheme.typography.bodySmall, color = Slate400)
            Spacer(modifier = Modifier.height(2.dp))
            Text(
              text = "৳${"%.0f".format(match.effectiveEntryFeeMinorUnits / 100.0)}",
              style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
              color = Color.White,
            )
          }

          Box(
            modifier = Modifier
              .size(40.dp)
              .clip(CircleShape)
              .background(Indigo600.copy(alpha = 0.3f)),
            contentAlignment = Alignment.Center,
          ) {
            Text(
              text = "VS",
              style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Black),
              color = Cyan400,
            )
          }

          Column(horizontalAlignment = Alignment.End) {
            Text(text = "Winner Prize", style = MaterialTheme.typography.bodySmall, color = Slate400)
            Spacer(modifier = Modifier.height(2.dp))
            Text(
              text = "৳${"%.0f".format(match.effectivePrizeMinorUnits / 100.0)}",
              style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Black),
              color = Gold400,
            )
          }
        }

        Spacer(modifier = Modifier.height(12.dp))
        HorizontalDivider(color = Slate800, thickness = 1.dp)
        Spacer(modifier = Modifier.height(10.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = "Payout Rule",
            style = MaterialTheme.typography.bodySmall,
            color = Slate400,
          )
          Text(
            text = "100% Winner Takes All",
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
            color = Emerald400,
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // 3. Room Code Card (Confidentiality & Access Control)
    Surface(
      color = if (isUserJoined) Indigo950.copy(alpha = 0.5f) else Slate900,
      shape = RoundedCornerShape(16.dp),
      border = BorderStroke(1.dp, if (isUserJoined) Indigo600 else Slate800),
      modifier = Modifier.fillMaxWidth(),
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = if (isUserJoined) Icons.Default.VpnKey else Icons.Default.Lock,
              contentDescription = null,
              tint = if (isUserJoined) Gold400 else Slate400,
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "GAME ROOM CODE",
              style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
              color = if (isUserJoined) Gold400 else Slate400,
            )
          }
          if (isUserJoined && match.gameCode.isNotBlank()) {
            Surface(
              color = Emerald900.copy(alpha = 0.4f),
              shape = RoundedCornerShape(6.dp),
            ) {
              Text(
                text = "READY",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = Emerald400,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        when {
          // Case A: User is NOT joined
          !isUserJoined -> {
            Text(
              text = "Room code is confidential. Only registered players can see the room code once generated by the Super Admin.",
              style = MaterialTheme.typography.bodySmall,
              color = Slate400,
            )
          }

          // Case B: User IS joined, but room code not yet added by Super Admin
          match.gameCode.isBlank() -> {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Slate850)
                .padding(12.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              CircularProgressIndicator(
                modifier = Modifier.size(18.dp),
                color = Gold400,
                strokeWidth = 2.dp,
              )
              Spacer(modifier = Modifier.width(12.dp))
              Text(
                text = "Super Admin is generating the room code. It will appear here before match time.",
                style = MaterialTheme.typography.bodySmall,
                color = Slate300,
              )
            }
          }

          // Case C: User IS joined, and room code is added
          else -> {
            Surface(
              color = Slate950,
              shape = RoundedCornerShape(10.dp),
              border = BorderStroke(1.dp, Gold500.copy(alpha = 0.4f)),
              modifier = Modifier.fillMaxWidth(),
            ) {
              Row(
                modifier = Modifier.padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Column {
                  Text(text = "ROOM CODE", style = MaterialTheme.typography.labelSmall, color = Slate400)
                  Text(
                    text = match.gameCode,
                    style = MaterialTheme.typography.headlineMedium.copy(
                      fontWeight = FontWeight.Black,
                      letterSpacing = 3.sp,
                    ),
                    color = Color.White,
                  )
                }
                TournamentButton(
                  text = "COPY CODE",
                  onClick = { onCopyRoomCode(match.gameCode) },
                  variant = TournamentButtonVariant.PRIMARY,
                  modifier = Modifier.height(38.dp),
                  testTag = "copy_room_code_btn",
                )
              }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(
              text = "Instructions: Open ${if (isLudo) "Ludo King" else "Carrom Disc Pool"}, choose 'Play With Friends', enter this Room Code to join the match.",
              style = MaterialTheme.typography.bodySmall,
              color = Slate300,
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // 4. Players Roster (Max 2 Players Rule)
    Surface(
      color = NavyCard,
      shape = RoundedCornerShape(16.dp),
      border = BorderStroke(1.dp, NavyCardBorder),
      modifier = Modifier.fillMaxWidth(),
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = "PLAYERS ROSTER",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
            color = Slate400,
          )
          Text(
            text = "$effectiveJoinedCount / ${match.maxPlayers} Max Players",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = if (isFull) Rose400 else Cyan400,
          )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Slot 1: Player 1
        PlayerSlotRow(
          slotNumber = 1,
          playerName = if (players.isNotEmpty()) players[0].username.ifBlank { "Player 1" } else if (effectiveJoinedCount >= 1) "Registered Player" else null,
          isCurrentUser = players.getOrNull(0)?.userId == userId || (effectiveJoinedCount >= 1 && isUserJoined && players.isEmpty()),
          isReady = true,
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Slot 2: Player 2
        PlayerSlotRow(
          slotNumber = 2,
          playerName = if (players.size >= 2) {
            players[1].username.ifBlank { "Player 2" }
          } else if (effectiveJoinedCount >= 2) {
            if (isUserJoined) "You (Joined)" else "Opponent Joined"
          } else {
            null
          },
          isCurrentUser = players.getOrNull(1)?.userId == userId || (effectiveJoinedCount >= 2 && isUserJoined && players.size < 2),
          isReady = effectiveJoinedCount >= 2,
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Product Rule Note
        Text(
          text = "Rule: Exactly 2 players. Once filled, match locks as FULL. A player cannot leave after joining.",
          style = MaterialTheme.typography.labelSmall,
          color = Slate400,
        )
      }
    }

    Spacer(modifier = Modifier.height(24.dp))

    // 5. Join CTA Action Bar
    when {
      isCompleted -> {
        TournamentButton(
          text = "MATCH COMPLETED",
          onClick = {},
          enabled = false,
          modifier = Modifier.fillMaxWidth(),
        )
      }
      isCancelled -> {
        TournamentButton(
          text = "MATCH CANCELLED",
          onClick = {},
          enabled = false,
          modifier = Modifier.fillMaxWidth(),
        )
      }
      isUserJoined -> {
        Surface(
          color = Emerald900.copy(alpha = 0.3f),
          shape = RoundedCornerShape(12.dp),
          border = BorderStroke(1.dp, Emerald600),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Emerald400, modifier = Modifier.size(20.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "You are registered for this match!",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = Emerald400,
              )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = if (match.gameCode.isNotBlank()) "Room code is ready above. Enter the game and play." else "Waiting for Super Admin to post the room code.",
              style = MaterialTheme.typography.bodySmall,
              color = Slate300,
              textAlign = TextAlign.Center,
            )
          }
        }
      }
      isRunning -> {
        TournamentButton(
          text = "MATCH IS IN PROGRESS",
          onClick = {},
          enabled = false,
          modifier = Modifier.fillMaxWidth(),
        )
      }
      isFull -> {
        TournamentButton(
          text = "MATCH FULL (2/2 PLAYERS)",
          onClick = {},
          enabled = false,
          modifier = Modifier.fillMaxWidth(),
        )
      }
      isTimePassed -> {
        TournamentButton(
          text = "MATCH EXPIRED",
          onClick = {},
          enabled = false,
          modifier = Modifier.fillMaxWidth(),
        )
      }
      canJoin -> {
        if (!hasSufficientBalance) {
          Surface(
            color = Amber900.copy(alpha = 0.2f),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, Amber600.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = Amber400, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = "Insufficient Balance (৳${"%.2f".format(userBalanceMinor / 100.0)})",
                  style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                  color = Amber400,
                )
              }
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "Entry fee is ৳${"%.0f".format(entryFeeMinor / 100.0)}. Deposit funds into your wallet to join this tournament match.",
                style = MaterialTheme.typography.bodySmall,
                color = Slate300,
              )
              Spacer(modifier = Modifier.height(10.dp))
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                TournamentButton(
                  text = "DEPOSIT TO WALLET",
                  onClick = onNavigateToWallet,
                  modifier = Modifier.weight(1f),
                  testTag = "deposit_to_wallet_cta",
                )
                TournamentButton(
                  text = "DETAILS",
                  onClick = onJoinClick,
                  variant = TournamentButtonVariant.OUTLINED,
                  modifier = Modifier.weight(0.7f),
                )
              }
            }
          }
        } else {
          TournamentButton(
            text = "JOIN MATCH — ৳${"%.0f".format(entryFeeMinor / 100.0)}",
            onClick = onJoinClick,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("match_details_join_cta"),
          )
        }
      }
      else -> {
        TournamentButton(
          text = "UNAVAILABLE",
          onClick = {},
          enabled = false,
          modifier = Modifier.fillMaxWidth(),
        )
      }
    }

    Spacer(modifier = Modifier.height(20.dp))
  }
}

@Composable
private fun PlayerSlotRow(
  slotNumber: Int,
  playerName: String?,
  isCurrentUser: Boolean,
  isReady: Boolean,
) {
  val isSlotFilled = !playerName.isNullOrBlank()

  Surface(
    color = if (isSlotFilled) Slate850 else Slate900.copy(alpha = 0.5f),
    shape = RoundedCornerShape(10.dp),
    border = BorderStroke(
      1.dp,
      if (isCurrentUser) Gold500 else if (isSlotFilled) Slate700 else Slate800,
    ),
    modifier = Modifier.fillMaxWidth(),
  ) {
    Row(
      modifier = Modifier.padding(12.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .size(32.dp)
            .clip(CircleShape)
            .background(if (isSlotFilled) Indigo600.copy(alpha = 0.3f) else Slate800),
          contentAlignment = Alignment.Center,
        ) {
          Text(
            text = "P$slotNumber",
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
            color = if (isSlotFilled) Cyan400 else Slate500,
          )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
          Text(
            text = if (isSlotFilled) {
              if (isCurrentUser) "$playerName (You)" else playerName ?: ""
            } else {
              "Waiting for opponent..."
            },
            style = MaterialTheme.typography.bodyMedium.copy(
              fontWeight = if (isSlotFilled) FontWeight.Bold else FontWeight.Normal,
            ),
            color = if (isSlotFilled) Color.White else Slate500,
          )
          Text(
            text = if (isSlotFilled) "Joined Slot $slotNumber" else "Open Slot (1v1)",
            style = MaterialTheme.typography.labelSmall,
            color = if (isSlotFilled) Emerald400 else Slate500,
          )
        }
      }

      if (isSlotFilled) {
        Surface(
          color = Emerald600.copy(alpha = 0.2f),
          shape = RoundedCornerShape(6.dp),
        ) {
          Text(
            text = "READY",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = Emerald400,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
          )
        }
      } else {
        Surface(
          color = Amber600.copy(alpha = 0.15f),
          shape = RoundedCornerShape(6.dp),
        ) {
          Text(
            text = "EMPTY",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = Amber400,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
          )
        }
      }
    }
  }
}
