package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(
  val route: String,
  val title: String,
  val icon: ImageVector,
) {
  // AUTHENTICATION & ONBOARDING FLOW
  data object Splash : Screen("splash", "Splash", Icons.Default.SportsEsports)
  data object Login : Screen("login", "Login", Icons.Default.Login)
  data object Register : Screen("register", "Register", Icons.Default.PersonAdd)
  data object ForgotPassword : Screen("forgot_password", "Forgot Password", Icons.Default.LockReset)
  data object NewPassword : Screen("new_password", "New Password", Icons.Default.Password)

  // 5 PRIMARY USER DESTINATIONS (Phase 2 Spec)
  // 1. Home, 2. Wallet, 3. Matches, 4. Notifications, 5. Profile
  data object Home : Screen("home", "Home", Icons.Default.Home)
  data object Wallet : Screen("wallet", "Wallet", Icons.Default.AccountBalanceWallet)
  data object Matches : Screen("matches", "Matches", Icons.Default.SportsEsports)
  data object Notifications : Screen("notifications", "Notifications", Icons.Default.Notifications)
  data object Profile : Screen("profile", "Profile", Icons.Default.Person)

  // MATCH DETAILS DESTINATION
  data object MatchDetails : Screen("match/{matchId}", "Match Details", Icons.Default.SportsEsports) {
    fun createRoute(matchId: String): String = "match/$matchId"
  }

  // SECONDARY / UTILITY SCREENS
  data object History : Screen("history", "History", Icons.AutoMirrored.Filled.List)
  data object Support : Screen("support", "Support", Icons.Default.HeadsetMic)

  companion object {
    /**
     * 5 primary bottom navigation items ordered strictly per Phase 2 spec:
     * 1. Home -> 2. Wallet -> 3. Matches -> 4. Notifications -> 5. Profile
     */
    val primaryNavigation: List<Screen>
      get() = listOf(
        Home,
        Wallet,
        Matches,
        Notifications,
        Profile,
      )
  }
}

