package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// AD TOURNAMENT - Tournament Palette
val DeepNavyBg = Color(0xFF0A0E1A)
val NavyDark = Color(0xFF0A0E1A)
val NavySurface = Color(0xFF0F172A)
val NavyCard = Color(0xFF151D30)
val NavyCardBorder = Color(0xFF22304A)

val Slate950 = Color(0xFF0A0E1A)
val Slate900 = Color(0xFF0F172A)
val Slate850 = Color(0xFF151D30)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate500 = Color(0xFF64748B)
val Slate400 = Color(0xFF94A3B8)
val Slate300 = Color(0xFFCBD5E1)
val Slate200 = Color(0xFFE2E8F0)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)

// Tournament Brand Accents: Electric Amber & Champion Gold
val Gold400 = Color(0xFFFBBF24)
val Gold500 = Color(0xFFF59E0B)
val Amber400 = Color(0xFFFBBF24)
val Amber500 = Color(0xFFF59E0B)
val Amber600 = Color(0xFFD97706)
val Amber700 = Color(0xFFB45309)
val Amber900 = Color(0xFF78350F)

// Gaming Indigo & Purple Gradients
val Indigo950 = Color(0xFF0F0E2A)
val Indigo900 = Color(0xFF1E1B4B)
val Indigo600 = Color(0xFF4F46E5)
val Indigo500 = Color(0xFF6366F1)
val Indigo400 = Color(0xFF818CF8)
val Purple600 = Color(0xFF7C3AED)
val Purple500 = Color(0xFF8B5CF6)
val Purple400 = Color(0xFFA78BFA)
val Blue600 = Color(0xFF2563EB)
val Blue500 = Color(0xFF3B82F6)

// Vibrant Gaming Accents
val Cyan300 = Color(0xFF67E8F9)
val Cyan400 = Color(0xFF22D3EE)
val Cyan500 = Color(0xFF06B6D4)
val Cyan600 = Color(0xFF0891B2)
val Emerald400 = Color(0xFF34D399)
val Emerald500 = Color(0xFF10B981)
val Emerald600 = Color(0xFF059669)
val Emerald900 = Color(0xFF064E3B)
val Rose400 = Color(0xFFFB7185)
val Rose500 = Color(0xFFF43F5E)
val Rose600 = Color(0xFFE11D48)
val Rose900 = Color(0xFF4C0519)

// Surface Overlays & Glows
val CardBorder = Color(0xFF22304A)
val GoldGlow = Color(0x33F59E0B)
val CyanGlow = Color(0x3306B6D4)
val PurpleGlow = Color(0x338B5CF6)

