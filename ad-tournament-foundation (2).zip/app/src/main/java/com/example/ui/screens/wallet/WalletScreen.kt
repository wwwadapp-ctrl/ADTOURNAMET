package com.example.ui.screens.wallet

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.error.Resource
import kotlinx.coroutines.launch
import com.example.domain.model.TransactionEntity
import com.example.domain.model.TransactionStatus
import com.example.domain.model.TransactionType
import com.example.domain.model.WalletEntity
import com.example.domain.repository.WalletRepository
import com.example.ui.components.TournamentButton
import com.example.ui.components.TournamentButtonVariant
import com.example.ui.components.TournamentCard
import com.example.ui.components.TournamentTextField
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun WalletScreen(
  userId: String,
  walletRepository: WalletRepository,
  modifier: Modifier = Modifier,
) {
  var selectedFilter by remember { mutableStateOf("ALL") }
  var showDepositDialog by remember { mutableStateOf(false) }
  var showWithdrawDialog by remember { mutableStateOf(false) }
  var bannerMessage by remember { mutableStateOf<String?>(null) }
  var isSubmitting by remember { mutableStateOf(false) }
  val coroutineScope = rememberCoroutineScope()

  // Observe Wallet
  val walletResource by walletRepository.getWallet(userId).collectAsState(initial = null)
  val wallet = (walletResource as? Resource.Success)?.data

  // Observe Transactions
  val transactionsResource by walletRepository.getTransactions(userId, 50).collectAsState(initial = null)
  val transactions = (transactionsResource as? Resource.Success)?.data ?: emptyList()

  val filteredTransactions = remember(transactions, selectedFilter) {
    when (selectedFilter) {
      "DEPOSITS" -> transactions.filter { it.type == TransactionType.DEPOSIT.name }
      "WITHDRAWALS" -> transactions.filter { it.type == TransactionType.WITHDRAW.name || it.type == TransactionType.WITHDRAWAL.name || it.type == TransactionType.WITHDRAW_HOLD.name }
      "FEES" -> transactions.filter { it.type == TransactionType.MATCH_ENTRY.name || it.type == TransactionType.MATCH_ENTRY_FEE.name }
      "PRIZES" -> transactions.filter { it.type == TransactionType.MATCH_PRIZE.name || it.type == TransactionType.MATCH_PRIZE_CREDIT.name }
      else -> transactions
    }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(DeepNavyBg)
      .testTag("wallet_screen"),
  ) {
    // 1. TOP TITLE BAR
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 20.dp, vertical = 16.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Icon(
        imageVector = Icons.Default.AccountBalanceWallet,
        contentDescription = null,
        tint = Gold400,
        modifier = Modifier.size(24.dp),
      )
      Spacer(modifier = Modifier.width(10.dp))
      Text(
        text = "PLAYER WALLET",
        style = MaterialTheme.typography.titleLarge.copy(
          fontWeight = FontWeight.Black,
          letterSpacing = 1.sp,
        ),
        color = Color.White,
      )
    }

    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 16.dp),
      contentPadding = PaddingValues(bottom = 24.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      // 2. FINANCIAL BALANCE BREAKDOWN
      item {
        WalletBalanceBreakdownCard(
          wallet = wallet,
          onDepositClick = { showDepositDialog = true },
          onWithdrawClick = { showWithdrawDialog = true },
        )
      }

      // BANNER MESSAGE
      item {
        AnimatedVisibility(visible = bannerMessage != null) {
          Surface(
            color = Cyan500.copy(alpha = 0.15f),
            border = BorderStroke(1.dp, Cyan400),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Row(
              modifier = Modifier.padding(12.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(Icons.Default.Info, contentDescription = null, tint = Cyan400, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = bannerMessage ?: "",
                style = MaterialTheme.typography.bodySmall,
                color = Color.White,
                modifier = Modifier.weight(1f),
              )
              IconButton(onClick = { bannerMessage = null }, modifier = Modifier.size(24.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = Slate400, modifier = Modifier.size(16.dp))
              }
            }
          }
        }
      }

      // 3. SECURITY / LEDGER INTEGRITY NOTICE
      item {
        SecurityLedgerNotice()
      }

      // 4. TRANSACTION HISTORY SECTION HEADER & FILTERS
      item {
        Column {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(
              text = "TRANSACTION LEDGER",
              style = MaterialTheme.typography.titleSmall.copy(
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
              ),
              color = Gold400,
            )
            Text(
              text = "${filteredTransactions.size} Records",
              style = MaterialTheme.typography.labelSmall,
              color = Slate400,
            )
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Filter Chips
          LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val filterOptions = listOf(
              "ALL" to "All",
              "PRIZES" to "Winnings",
              "DEPOSITS" to "Deposits",
              "FEES" to "Entry Fees",
              "WITHDRAWALS" to "Payouts",
            )
            items(filterOptions) { (key, label) ->
              val isSelected = selectedFilter == key
              Surface(
                shape = RoundedCornerShape(16.dp),
                color = if (isSelected) Gold500 else Slate900,
                border = BorderStroke(1.dp, if (isSelected) Gold400 else CardBorder),
                modifier = Modifier
                  .clickable { selectedFilter = key }
                  .testTag("wallet_filter_$key"),
              ) {
                Text(
                  text = label,
                  style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                  ),
                  color = if (isSelected) Slate950 else Color.White,
                  modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                )
              }
            }
          }
        }
      }

      // 5. TRANSACTION LIST ITEMS
      if (filteredTransactions.isEmpty()) {
        item {
          EmptyTransactionsCard()
        }
      } else {
        items(filteredTransactions, key = { it.transactionId }) { txn ->
          TransactionItemRow(txn = txn)
        }
      }
    }
  }

  // DIALOG: DEPOSIT CASH
  if (showDepositDialog) {
    DepositCashDialog(
      onDismiss = { showDepositDialog = false },
      onSubmitDeposit = { amount, method, senderNumber, txnRef ->
        showDepositDialog = false
        val minorUnits = (amount.toDoubleOrNull()?.let { it * 100 } ?: 0.0).toLong()
        coroutineScope.launch {
          isSubmitting = true
          val result = walletRepository.submitDepositRequest(
            userId = userId,
            amountMinorUnits = minorUnits,
            method = method,
            senderNumber = senderNumber,
            trxId = txnRef,
            screenshotUrl = "",
          )
          isSubmitting = false
          when (result) {
            is Resource.Success -> {
              bannerMessage = "Deposit request for ৳$amount (TrxID: $txnRef) submitted. Super Admin will verify and credit your wallet."
            }
            is Resource.Error -> {
              bannerMessage = "Failed to submit deposit: ${result.error.userMessage}"
            }
            is Resource.Loading, is Resource.Idle -> {}
          }
        }
      },
    )
  }

  // DIALOG: WITHDRAW WINNINGS
  if (showWithdrawDialog) {
    WithdrawWinningsDialog(
      withdrawableBalance = wallet?.winningBalance ?: 0.0,
      onDismiss = { showWithdrawDialog = false },
      onSubmitWithdraw = { amount, method, recipientNumber ->
        showWithdrawDialog = false
        val minorUnits = (amount.toDoubleOrNull()?.let { it * 100 } ?: 0.0).toLong()
        coroutineScope.launch {
          isSubmitting = true
          val result = walletRepository.submitWithdrawalRequest(
            userId = userId,
            amountMinorUnits = minorUnits,
            method = method,
            recipientNumber = recipientNumber,
          )
          isSubmitting = false
          when (result) {
            is Resource.Success -> {
              bannerMessage = "Withdrawal request for ৳$amount to $recipientNumber submitted. Payout will be processed after Super Admin approval."
            }
            is Resource.Error -> {
              bannerMessage = "Failed to submit withdrawal: ${result.error.userMessage}"
            }
            is Resource.Loading, is Resource.Idle -> {}
          }
        }
      },
    )
  }
}

// ==========================================
// SUB-COMPONENTS
// ==========================================

@Composable
private fun WalletBalanceBreakdownCard(
  wallet: WalletEntity?,
  onDepositClick: () -> Unit,
  onWithdrawClick: () -> Unit,
) {
  val playableBalance = wallet?.balance ?: 0.0
  val winningBalance = wallet?.winningBalance ?: 0.0
  val lockedBalance = wallet?.lockedBalance ?: 0.0
  val totalBalance = playableBalance + lockedBalance

  TournamentCard(
    modifier = Modifier.fillMaxWidth(),
    backgroundColor = NavyCard,
    borderColor = NavyCardBorder,
  ) {
    // Total Balance Header
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Column {
        Text(
          text = "TOTAL WALLET BALANCE",
          style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.sp),
          color = Slate400,
        )
        Text(
          text = "৳${"%.2f".format(totalBalance)}",
          style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Black),
          color = Color.White,
        )
      }
      Surface(
        color = Emerald600.copy(alpha = 0.2f),
        shape = RoundedCornerShape(12.dp),
      ) {
        Text(
          text = "VERIFIED",
          style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
          color = Emerald500,
          modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
        )
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Tri-Balance Breakdown Row
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(12.dp))
        .background(Slate900)
        .padding(12.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      // 1. Playable
      Column {
        Text(text = "Playable", style = MaterialTheme.typography.labelSmall, color = Slate400)
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = "৳${"%.0f".format(playableBalance)}",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          color = Gold400,
        )
      }

      // Divider
      Box(
        modifier = Modifier
          .width(1.dp)
          .height(36.dp)
          .background(CardBorder)
      )

      // 2. Winning (Withdrawable)
      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = "Withdrawable", style = MaterialTheme.typography.labelSmall, color = Slate400)
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = "৳${"%.0f".format(winningBalance)}",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          color = Emerald500,
        )
      }

      // Divider
      Box(
        modifier = Modifier
          .width(1.dp)
          .height(36.dp)
          .background(CardBorder)
      )

      // 3. Held / Locked
      Column(horizontalAlignment = Alignment.End) {
        Text(text = "Held In Match", style = MaterialTheme.typography.labelSmall, color = Slate400)
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = "৳${"%.0f".format(lockedBalance)}",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          color = Cyan400,
        )
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Action CTAs: Deposit & Withdraw
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      TournamentButton(
        text = "DEPOSIT MONEY",
        onClick = onDepositClick,
        leadingIcon = {
          Icon(Icons.Default.AddCircle, contentDescription = null, tint = Slate950, modifier = Modifier.size(18.dp))
        },
        modifier = Modifier.weight(1f),
        testTag = "wallet_deposit_button",
      )

      TournamentButton(
        text = "WITHDRAW",
        onClick = onWithdrawClick,
        variant = TournamentButtonVariant.OUTLINED,
        leadingIcon = {
          Icon(Icons.Default.NorthEast, contentDescription = null, tint = Gold500, modifier = Modifier.size(18.dp))
        },
        modifier = Modifier.weight(1f),
        testTag = "wallet_withdraw_button",
      )
    }
  }
}

@Composable
private fun SecurityLedgerNotice() {
  Surface(
    color = Slate900,
    shape = RoundedCornerShape(10.dp),
    border = BorderStroke(1.dp, CardBorder),
    modifier = Modifier.fillMaxWidth(),
  ) {
    Row(
      modifier = Modifier.padding(12.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Icon(
        imageVector = Icons.Default.Gavel,
        contentDescription = null,
        tint = Gold400,
        modifier = Modifier.size(20.dp),
      )
      Spacer(modifier = Modifier.width(10.dp))
      Text(
        text = "Read-Only Wallet Architecture: Balances cannot be manipulated by the client. All credits and payouts are audited and processed on the server ledger.",
        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
        color = Slate400,
      )
    }
  }
}

@Composable
private fun TransactionItemRow(txn: TransactionEntity) {
  val isCredit = txn.amount > 0
  val formattedDate = remember(txn.createdAt) {
    SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(txn.createdAt))
  }

  TournamentCard(
    modifier = Modifier.fillMaxWidth(),
    backgroundColor = NavyCard,
    borderColor = CardBorder,
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        // Icon
        Box(
          modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(if (isCredit) Emerald600.copy(alpha = 0.2f) else Rose600.copy(alpha = 0.2f)),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            imageVector = if (isCredit) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
            contentDescription = null,
            tint = if (isCredit) Emerald500 else Rose500,
            modifier = Modifier.size(18.dp),
          )
        }

        Spacer(modifier = Modifier.width(10.dp))

        Column {
          Text(
            text = txn.description.ifBlank { txn.type.replace("_", " ") },
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
            color = Color.White,
          )
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = "$formattedDate • Ref: ${txn.referenceId}",
            style = MaterialTheme.typography.labelSmall,
            color = Slate400,
          )
        }
      }

      Column(horizontalAlignment = Alignment.End) {
        Text(
          text = if (isCredit) "+৳${"%.2f".format(txn.amountInCurrency)}" else "-৳${"%.2f".format(kotlin.math.abs(txn.amountInCurrency))}",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
          color = if (isCredit) Emerald500 else Rose500,
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = "Balance: ৳${"%.2f".format(txn.afterBalanceInCurrency)}",
          style = MaterialTheme.typography.labelSmall,
          color = Slate500,
        )
      }
    }
  }
}

@Composable
private fun EmptyTransactionsCard() {
  Box(
    modifier = Modifier
      .fillMaxWidth()
      .padding(32.dp),
    contentAlignment = Alignment.Center,
  ) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
      Icon(Icons.Default.ReceiptLong, contentDescription = null, tint = Slate600, modifier = Modifier.size(40.dp))
      Spacer(modifier = Modifier.height(8.dp))
      Text("No transactions found in this category", color = Slate400, style = MaterialTheme.typography.bodyMedium)
    }
  }
}

// ==========================================
// MODAL DIALOGS
// ==========================================

@Composable
fun DepositCashDialog(
  onDismiss: () -> Unit,
  onSubmitDeposit: (amount: String, method: String, senderNumber: String, txnRef: String) -> Unit,
) {
  var amount by remember { mutableStateOf("100") }
  var utrReference by remember { mutableStateOf("") }
  var senderNumber by remember { mutableStateOf("") }
  var selectedMethod by remember { mutableStateOf("BKASH") }
  var errorMessage by remember { mutableStateOf<String?>(null) }

  val paymentMethods = listOf("BKASH" to "bKash", "NAGAD" to "Nagad")

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.AddCircle, contentDescription = null, tint = Gold400)
        Spacer(modifier = Modifier.width(8.dp))
        Text("Deposit Money", color = Color.White)
      }
    },
    text = {
      Column {
        Text(
          text = "Select payment method and enter transaction details",
          style = MaterialTheme.typography.bodySmall,
          color = Slate400,
        )
        Spacer(modifier = Modifier.height(12.dp))

        // Payment Method Selector
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          paymentMethods.forEach { (code, label) ->
            val isSelected = selectedMethod == code
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = if (isSelected) Gold500 else Slate900,
              border = BorderStroke(1.dp, if (isSelected) Gold400 else CardBorder),
              modifier = Modifier
                .weight(1f)
                .clickable { selectedMethod = code },
            ) {
              Text(
                text = label,
                style = MaterialTheme.typography.labelMedium.copy(
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                ),
                color = if (isSelected) Slate950 else Color.White,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(vertical = 8.dp),
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Preset Amount Buttons
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          listOf("50", "100", "200", "500").forEach { preset ->
            val isSelected = amount == preset
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = if (isSelected) Gold500 else Slate900,
              border = BorderStroke(1.dp, if (isSelected) Gold400 else CardBorder),
              modifier = Modifier
                .weight(1f)
                .clickable { amount = preset },
            ) {
              Text(
                text = "৳$preset",
                style = MaterialTheme.typography.labelMedium.copy(
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                ),
                color = if (isSelected) Slate950 else Color.White,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(vertical = 8.dp),
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Official Merchant Number banner
        Surface(
          color = Indigo900.copy(alpha = 0.5f),
          shape = RoundedCornerShape(8.dp),
          border = BorderStroke(1.dp, Indigo500),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.padding(10.dp)) {
            Text("OFFICIAL $selectedMethod NUMBER (SEND MONEY):", style = MaterialTheme.typography.labelSmall, color = Slate400)
            Text("01700-000000", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = Gold400)
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Sender phone number
        TournamentTextField(
          value = senderNumber,
          onValueChange = {
            senderNumber = it
            errorMessage = null
          },
          label = "Sender Mobile Number (11 digits)",
          placeholder = "e.g. 01712345678",
          leadingIcon = Icons.Default.Phone,
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
          testTag = "deposit_sender_input",
          modifier = Modifier.fillMaxWidth(),
        )

        Spacer(modifier = Modifier.height(8.dp))

        // TrxID / Reference number input
        TournamentTextField(
          value = utrReference,
          onValueChange = {
            utrReference = it
            errorMessage = null
          },
          label = "Transaction ID (TrxID)",
          placeholder = "e.g. 9J8K7L6M",
          leadingIcon = Icons.Default.Tag,
          testTag = "deposit_utr_input",
          modifier = Modifier.fillMaxWidth(),
        )

        AnimatedVisibility(visible = errorMessage != null) {
          Text(
            text = errorMessage ?: "",
            style = MaterialTheme.typography.bodySmall,
            color = Rose500,
            modifier = Modifier.padding(top = 6.dp),
          )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
          text = "Security Foundation: All deposit requests are audited by the Super Admin before wallet balance is credited.",
          style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
          color = Slate400,
        )
      }
    },
    confirmButton = {
      TournamentButton(
        text = "SUBMIT DEPOSIT REQUEST",
        onClick = {
          val amt = amount.toDoubleOrNull() ?: 0.0
          if (amt < 50.0) {
            errorMessage = "Minimum deposit amount is ৳50"
            return@TournamentButton
          }
          if (senderNumber.length < 11) {
            errorMessage = "Please enter valid 11-digit mobile number"
            return@TournamentButton
          }
          if (utrReference.isBlank() || utrReference.length < 4) {
            errorMessage = "Please enter valid Transaction ID (TrxID)"
            return@TournamentButton
          }
          onSubmitDeposit(amount, selectedMethod, senderNumber, utrReference.trim())
        },
        enabled = amount.isNotBlank(),
        testTag = "submit_deposit_confirm_button",
      )
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel", color = Slate400)
      }
    },
    containerColor = NavyCard,
  )
}

@Composable
fun WithdrawWinningsDialog(
  withdrawableBalance: Double,
  onDismiss: () -> Unit,
  onSubmitWithdraw: (amount: String, method: String, recipientNumber: String) -> Unit,
) {
  var amount by remember { mutableStateOf("") }
  var recipientNumber by remember { mutableStateOf("") }
  var selectedMethod by remember { mutableStateOf("BKASH") }
  var errorMessage by remember { mutableStateOf<String?>(null) }

  val paymentMethods = listOf("BKASH" to "bKash", "NAGAD" to "Nagad")

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.NorthEast, contentDescription = null, tint = Emerald500)
        Spacer(modifier = Modifier.width(8.dp))
        Text("Withdraw Winnings", color = Color.White)
      }
    },
    text = {
      Column {
        Text(
          text = "Eligible Withdrawable Balance: ৳${"%.2f".format(withdrawableBalance)}",
          style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
          color = Emerald500,
        )
        Text(
          text = "Minimum withdrawal amount: ৳100",
          style = MaterialTheme.typography.bodySmall,
          color = Slate400,
        )
        Spacer(modifier = Modifier.height(12.dp))

        // Payment Method Selector
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          paymentMethods.forEach { (code, label) ->
            val isSelected = selectedMethod == code
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = if (isSelected) Gold500 else Slate900,
              border = BorderStroke(1.dp, if (isSelected) Gold400 else CardBorder),
              modifier = Modifier
                .weight(1f)
                .clickable { selectedMethod = code },
            ) {
              Text(
                text = label,
                style = MaterialTheme.typography.labelMedium.copy(
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                ),
                color = if (isSelected) Slate950 else Color.White,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(vertical = 8.dp),
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Amount input
        TournamentTextField(
          value = amount,
          onValueChange = {
            amount = it
            errorMessage = null
          },
          label = "Withdrawal Amount (৳)",
          placeholder = "Min 100",
          leadingIcon = Icons.Default.AccountBalanceWallet,
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          testTag = "withdraw_amount_input",
          modifier = Modifier.fillMaxWidth(),
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Recipient Phone Number
        TournamentTextField(
          value = recipientNumber,
          onValueChange = {
            recipientNumber = it
            errorMessage = null
          },
          label = "$selectedMethod Account Number (11 digits)",
          placeholder = "e.g. 01712345678",
          leadingIcon = Icons.Default.Phone,
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
          testTag = "withdraw_account_input",
          modifier = Modifier.fillMaxWidth(),
        )

        AnimatedVisibility(visible = errorMessage != null) {
          Text(
            text = errorMessage ?: "",
            style = MaterialTheme.typography.bodySmall,
            color = Rose500,
            modifier = Modifier.padding(top = 8.dp),
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text(
          text = "Note: Payout requests are verified by the Super Admin to guarantee fair play and prevent unauthorized deductions.",
          style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
          color = Slate400,
        )
      }
    },
    confirmButton = {
      TournamentButton(
        text = "SUBMIT WITHDRAWAL",
        onClick = {
          val amt = amount.toDoubleOrNull() ?: 0.0
          if (amt < 100.0) {
            errorMessage = "Minimum withdrawal amount is ৳100"
            return@TournamentButton
          }
          if (amt > withdrawableBalance) {
            errorMessage = "Cannot withdraw more than withdrawable balance (৳${"%.0f".format(withdrawableBalance)})"
            return@TournamentButton
          }
          if (recipientNumber.length < 11) {
            errorMessage = "Please enter a valid 11-digit mobile account number"
            return@TournamentButton
          }
          onSubmitWithdraw(amount, selectedMethod, recipientNumber)
        },
        enabled = amount.isNotBlank() && recipientNumber.isNotBlank(),
        testTag = "submit_withdraw_confirm_button",
      )
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel", color = Slate400)
      }
    },
    containerColor = NavyCard,
  )
}
