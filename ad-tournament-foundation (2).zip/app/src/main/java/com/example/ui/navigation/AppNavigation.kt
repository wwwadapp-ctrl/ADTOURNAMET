package com.example.ui.navigation

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.core.di.AppContainer
import com.example.core.network.NetworkStatus
import com.example.ui.components.NetworkStatusBar
import com.example.ui.screens.auth.*
import com.example.ui.screens.history.HistoryScreen
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.match.MatchDetailsScreen
import com.example.ui.screens.matches.MatchesScreen
import com.example.ui.screens.notifications.NotificationsScreen
import com.example.ui.screens.profile.ProfileScreen
import com.example.ui.screens.support.SupportScreen
import com.example.ui.screens.wallet.WalletScreen
import com.example.ui.theme.*

@Composable
fun AdTournamentApp(
  networkStatus: NetworkStatus,
  appContainer: AppContainer,
  navController: NavHostController = rememberNavController(),
) {
  val navBackStackEntry by navController.currentBackStackEntryAsState()
  val currentRoute = navBackStackEntry?.destination?.route ?: Screen.Splash.route

  // Bottom navigation visibility: visible only on main application destinations
  val authRoutes = setOf(
    Screen.Splash.route,
    Screen.Login.route,
    Screen.Register.route,
    Screen.ForgotPassword.route,
  )
  val isBottomBarVisible = currentRoute !in authRoutes

  // Current logged in user ID
  val currentUser by appContainer.authRepository.getCurrentUser().collectAsState(initial = null)
  val currentUserId = currentUser?.userId ?: "AD-USER-9481"

  Scaffold(
    modifier = Modifier
      .fillMaxSize()
      .testTag("ad_tournament_scaffold"),
    containerColor = DeepNavyBg,
    topBar = {
      // Network status indicator displayed globally when connectivity changes
      NetworkStatusBar(networkStatus = networkStatus)
    },
    bottomBar = {
      if (isBottomBarVisible) {
        TournamentBottomNavigationBar(
          currentRoute = currentRoute,
          onNavigate = { screen ->
            navController.navigate(screen.route) {
              popUpTo(Screen.Home.route) {
                saveState = true
              }
              launchSingleTop = true
              restoreState = true
            }
          },
        )
      }
    },
  ) { innerPadding ->
    NavHost(
      navController = navController,
      startDestination = Screen.Splash.route,
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding),
    ) {
      // 1. SPLASH SCREEN
      composable(Screen.Splash.route) {
        SplashScreen(
          onNavigateToHome = {
            navController.navigate(Screen.Home.route) {
              popUpTo(Screen.Splash.route) { inclusive = true }
            }
          },
          onNavigateToLogin = {
            navController.navigate(Screen.Login.route) {
              popUpTo(Screen.Splash.route) { inclusive = true }
            }
          },
          authRepository = appContainer.authRepository,
        )
      }

      // 2. LOGIN SCREEN
      composable(Screen.Login.route) {
        LoginScreen(
          onLoginSuccess = {
            navController.navigate(Screen.Home.route) {
              popUpTo(Screen.Login.route) { inclusive = true }
            }
          },
          onNavigateToRegister = {
            navController.navigate(Screen.Register.route)
          },
          onNavigateToForgotPassword = {
            navController.navigate(Screen.ForgotPassword.route)
          },
          authRepository = appContainer.authRepository,
        )
      }

      // 3. REGISTRATION SCREEN
      composable(Screen.Register.route) {
        RegistrationScreen(
          onRegisterSuccess = {
            navController.navigate(Screen.Home.route) {
              popUpTo(Screen.Register.route) { inclusive = true }
            }
          },
          onNavigateToLogin = {
            navController.popBackStack()
          },
          authRepository = appContainer.authRepository,
        )
      }

      // 4. FORGOT PASSWORD SCREEN
      composable(Screen.ForgotPassword.route) {
        ForgotPasswordScreen(
          onResetSuccess = {
            navController.navigate(Screen.Login.route) {
              popUpTo(Screen.ForgotPassword.route) { inclusive = true }
            }
          },
          onNavigateToLogin = {
            navController.popBackStack()
          },
          authRepository = appContainer.authRepository,
        )
      }

      // 4b. NEW PASSWORD SCREEN (Direct Route)
      composable(Screen.NewPassword.route) {
        NewPasswordScreen(
          phoneNumber = "",
          onResetSuccess = {
            navController.navigate(Screen.Login.route) {
              popUpTo(Screen.NewPassword.route) { inclusive = true }
            }
          },
          onNavigateToLogin = {
            navController.popBackStack()
          },
          authRepository = appContainer.authRepository,
        )
      }

      // 5. HOME SCREEN
      composable(Screen.Home.route) {
        HomeScreen(
          userId = currentUserId,
          onNavigateToWallet = {
            navController.navigate(Screen.Wallet.route) {
              popUpTo(Screen.Home.route) { saveState = true }
              launchSingleTop = true
            }
          },
          onNavigateToNotifications = {
            navController.navigate(Screen.Notifications.route)
          },
          onNavigateToHistory = {
            navController.navigate(Screen.Matches.route) {
              popUpTo(Screen.Home.route) { saveState = true }
              launchSingleTop = true
            }
          },
          onNavigateToMatchDetails = { matchId ->
            navController.navigate(Screen.MatchDetails.createRoute(matchId))
          },
          matchRepository = appContainer.matchRepository,
          walletRepository = appContainer.walletRepository,
        )
      }

      // 6. WALLET SCREEN
      composable(Screen.Wallet.route) {
        WalletScreen(
          userId = currentUserId,
          walletRepository = appContainer.walletRepository,
        )
      }

      // 7. MATCHES SCREEN (Phase 2 Dedicated Hub)
      composable(Screen.Matches.route) {
        MatchesScreen(
          userId = currentUserId,
          onNavigateToMatchDetails = { matchId ->
            navController.navigate(Screen.MatchDetails.createRoute(matchId))
          },
          matchRepository = appContainer.matchRepository,
        )
      }

      // 8. MATCH DETAILS SCREEN (Phase 2 Core Screen)
      composable(Screen.MatchDetails.route) { backStackEntry ->
        val matchId = backStackEntry.arguments?.getString("matchId") ?: ""
        MatchDetailsScreen(
          matchId = matchId,
          userId = currentUserId,
          onNavigateBack = { navController.popBackStack() },
          onNavigateToWallet = {
            navController.navigate(Screen.Wallet.route) {
              popUpTo(Screen.Home.route) { saveState = true }
              launchSingleTop = true
            }
          },
          matchRepository = appContainer.matchRepository,
          walletRepository = appContainer.walletRepository,
        )
      }

      // 9. NOTIFICATIONS SCREEN (Primary Bottom Tab in Phase 2)
      composable(Screen.Notifications.route) {
        NotificationsScreen(
          userId = currentUserId,
          onNavigateBack = { navController.popBackStack() },
          notificationRepository = appContainer.notificationRepository,
        )
      }

      // 10. PROFILE SCREEN
      composable(Screen.Profile.route) {
        ProfileScreen(
          onSignOut = {
            navController.navigate(Screen.Login.route) {
              popUpTo(0) { inclusive = true }
            }
          },
          authRepository = appContainer.authRepository,
        )
      }

      // 11. LEGACY HISTORY SCREEN (Accessible if navigated directly)
      composable(Screen.History.route) {
        HistoryScreen(
          userId = currentUserId,
          matchRepository = appContainer.matchRepository,
        )
      }

      // 12. SUPPORT SCREEN (Direct Route)
      composable(Screen.Support.route) {
        SupportScreen()
      }
    }
  }
}

/**
 * 5-item Primary User Bottom Navigation (Phase 2 Spec):
 * 1. Home -> 2. Wallet -> 3. Matches -> 4. Notifications -> 5. Profile
 * All five destinations behave consistently as standard bottom-navigation destinations.
 */
@Composable
private fun TournamentBottomNavigationBar(
  currentRoute: String,
  onNavigate: (Screen) -> Unit,
) {
  Surface(
    color = NavySurface,
    border = BorderStroke(1.dp, NavyCardBorder),
    modifier = Modifier
      .fillMaxWidth()
      .testTag("tournament_bottom_nav"),
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .navigationBarsPadding()
        .padding(vertical = 8.dp),
      horizontalArrangement = Arrangement.SpaceEvenly,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Screen.primaryNavigation.forEach { screen ->
        val isSelected = currentRoute == screen.route

        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.Center,
          modifier = Modifier
            .weight(1f)
            .clickable { onNavigate(screen) }
            .padding(vertical = 4.dp)
            .testTag("bottom_nav_${screen.route}"),
        ) {
          Icon(
            imageVector = screen.icon,
            contentDescription = screen.title,
            tint = if (isSelected) Gold400 else Slate400,
            modifier = Modifier.size(24.dp),
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = screen.title,
            style = MaterialTheme.typography.labelSmall.copy(
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
              fontSize = 11.sp,
            ),
            color = if (isSelected) Gold400 else Slate400,
          )
        }
      }
    }
  }
}
