package com.example

import com.example.core.finance.FinancialEngine
import com.example.domain.model.DepositEntity
import com.example.domain.model.DepositStatus
import com.example.domain.model.TransactionEntity
import com.example.domain.model.TransactionStatus
import com.example.domain.model.TransactionType
import com.example.domain.model.WalletEntity
import com.example.domain.model.WithdrawalEntity
import com.example.domain.model.WithdrawalStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

/**
 * Unit tests verifying the AD TOURNAMENT Phase 3 Financial Engine:
 * - Tiered commission rules (Entry fee <= ৳100 -> ৳10; <= ৳200 -> ৳20; > ৳200 -> ৳40)
 * - 2-Player prize pool math: (entry fee * 2) - commission
 * - Strict integer minor-unit accounting (1 ৳ = 100 minor units)
 * - Non-negative prize bounds and non-positive entry fee protection
 * - Idempotency and atomic mutation safety
 */
class FinancialEngineUnitTest {

  // 1. ৳50 entry -> totalPool ৳100 -> commission ৳10 -> prize ৳90
  @Test
  fun testCommissionAndPrize_50Bdt() {
    val entryFee = 50_00L // 5,000 minor units = ৳50
    val commission = FinancialEngine.calculateCommission(entryFee)
    assertEquals(10_00L, commission) // ৳10

    val prizeCalc = FinancialEngine.calculateMatchPrize(entryFee)
    assertEquals(100_00L, prizeCalc.totalPool) // ৳100
    assertEquals(10_00L, prizeCalc.commissionAmount) // ৳10
    assertEquals(90_00L, prizeCalc.winnerPrize) // ৳90
  }

  // 2. ৳100 entry boundary -> commission ৳10 -> prize ৳190
  @Test
  fun testCommission_100Bdt_Boundary() {
    val entryFee = 100_00L // 10,000 minor units = ৳100
    val commission = FinancialEngine.calculateCommission(entryFee)
    assertEquals(10_00L, commission) // ৳10

    val prizeCalc = FinancialEngine.calculateMatchPrize(entryFee)
    assertEquals(200_00L, prizeCalc.totalPool) // ৳200
    assertEquals(10_00L, prizeCalc.commissionAmount) // ৳10
    assertEquals(190_00L, prizeCalc.winnerPrize) // ৳190
  }

  // 3. ৳101 entry boundary -> commission ৳20 -> prize ৳182
  @Test
  fun testCommission_101Bdt_Boundary() {
    val entryFee = 101_00L // 10,100 minor units = ৳101
    val commission = FinancialEngine.calculateCommission(entryFee)
    assertEquals(20_00L, commission) // ৳20

    val prizeCalc = FinancialEngine.calculateMatchPrize(entryFee)
    assertEquals(202_00L, prizeCalc.totalPool) // ৳202
    assertEquals(20_00L, prizeCalc.commissionAmount) // ৳20
    assertEquals(182_00L, prizeCalc.winnerPrize) // ৳182
  }

  // 4. ৳150 entry -> commission ৳20 -> prize ৳280
  @Test
  fun testCommissionAndPrize_150Bdt() {
    val entryFee = 150_00L // 15,000 minor units = ৳150
    val commission = FinancialEngine.calculateCommission(entryFee)
    assertEquals(20_00L, commission) // ৳20

    val prizeCalc = FinancialEngine.calculateMatchPrize(entryFee)
    assertEquals(300_00L, prizeCalc.totalPool) // ৳300
    assertEquals(20_00L, prizeCalc.commissionAmount) // ৳20
    assertEquals(280_00L, prizeCalc.winnerPrize) // ৳280
  }

  // 5. ৳200 entry boundary -> commission ৳20 -> prize ৳380
  @Test
  fun testCommission_200Bdt_Boundary() {
    val entryFee = 200_00L // 20,000 minor units = ৳200
    val commission = FinancialEngine.calculateCommission(entryFee)
    assertEquals(20_00L, commission) // ৳20

    val prizeCalc = FinancialEngine.calculateMatchPrize(entryFee)
    assertEquals(400_00L, prizeCalc.totalPool) // ৳400
    assertEquals(20_00L, prizeCalc.commissionAmount) // ৳20
    assertEquals(380_00L, prizeCalc.winnerPrize) // ৳380
  }

  // 6. ৳201 entry boundary -> commission ৳40 -> prize ৳362
  @Test
  fun testCommission_201Bdt_Boundary() {
    val entryFee = 201_00L // 20,100 minor units = ৳201
    val commission = FinancialEngine.calculateCommission(entryFee)
    assertEquals(40_00L, commission) // ৳40

    val prizeCalc = FinancialEngine.calculateMatchPrize(entryFee)
    assertEquals(402_00L, prizeCalc.totalPool) // ৳402
    assertEquals(40_00L, prizeCalc.commissionAmount) // ৳40
    assertEquals(362_00L, prizeCalc.winnerPrize) // ৳362
  }

  // 7. ৳250 entry -> commission ৳40 -> prize ৳460
  @Test
  fun testCommissionAndPrize_250Bdt() {
    val entryFee = 250_00L // 25,000 minor units = ৳250
    val commission = FinancialEngine.calculateCommission(entryFee)
    assertEquals(40_00L, commission) // ৳40

    val prizeCalc = FinancialEngine.calculateMatchPrize(entryFee)
    assertEquals(500_00L, prizeCalc.totalPool) // ৳500
    assertEquals(40_00L, prizeCalc.commissionAmount) // ৳40
    assertEquals(460_00L, prizeCalc.winnerPrize) // ৳460
  }

  // 8. ৳300 entry -> commission ৳40 -> prize ৳560
  @Test
  fun testCommissionAndPrize_300Bdt() {
    val entryFee = 300_00L // 30,000 minor units = ৳300
    val commission = FinancialEngine.calculateCommission(entryFee)
    assertEquals(40_00L, commission) // ৳40

    val prizeCalc = FinancialEngine.calculateMatchPrize(entryFee)
    assertEquals(600_00L, prizeCalc.totalPool) // ৳600
    assertEquals(40_00L, prizeCalc.commissionAmount) // ৳40
    assertEquals(560_00L, prizeCalc.winnerPrize) // ৳560
  }

  // 9. Invalid/non-positive entry fee validation
  @Test
  fun testInvalidNonPositiveEntryFee() {
    try {
      FinancialEngine.calculateCommission(0L)
      fail("Should have thrown IllegalArgumentException for zero entry fee")
    } catch (e: IllegalArgumentException) {
      assertNotNull(e.message)
    }

    try {
      FinancialEngine.calculateCommission(-1000L)
      fail("Should have thrown IllegalArgumentException for negative entry fee")
    } catch (e: IllegalArgumentException) {
      assertNotNull(e.message)
    }

    try {
      FinancialEngine.calculateMatchPrize(0L)
      fail("Should have thrown IllegalArgumentException for zero entry fee in match prize")
    } catch (e: IllegalArgumentException) {
      assertNotNull(e.message)
    }

    try {
      FinancialEngine.calculateMatchPrize(-5000L)
      fail("Should have thrown IllegalArgumentException for negative entry fee in match prize")
    } catch (e: IllegalArgumentException) {
      assertNotNull(e.message)
    }
  }

  // 10. Prize cannot become negative
  @Test
  fun testPrizeCannotBecomeNegative() {
    // 2 players with very small fee (e.g. 100 minor units = ৳1, total pool = 200 minor units, commission = 1000)
    // Prize pool should clamp safely to 0 rather than negative
    val prizeCalc = FinancialEngine.calculateMatchPrize(100L)
    assertTrue("Prize must never be negative", prizeCalc.winnerPrize >= 0L)
    assertEquals(0L, prizeCalc.winnerPrize)
  }

  // 11. Integer minor-unit precision check
  @Test
  fun testIntegerMinorUnitPrecision() {
    val oddEntryFee = 77_77L // ৳77.77
    val prizeCalc = FinancialEngine.calculateMatchPrize(oddEntryFee)
    assertEquals(155_54L, prizeCalc.totalPool)
    assertEquals(10_00L, prizeCalc.commissionAmount)
    assertEquals(145_54L, prizeCalc.winnerPrize)
    assertEquals(prizeCalc.totalPool - prizeCalc.commissionAmount, prizeCalc.winnerPrize)
  }

  // 12. Deposit approval idempotency check
  @Test
  fun testDepositApproval_Idempotency() {
    val initialWallet = WalletEntity(
      uid = "user_test_123",
      availableBalance = 5000L,
      totalDeposited = 5000L,
    )
    val deposit = DepositEntity(
      depositId = "dep_test_001",
      uid = "user_test_123",
      amount = 10000L,
      method = "BKASH",
      trxId = "TRX123456",
      status = DepositStatus.SUBMITTED.name,
    )

    // First run: Should succeed and credit wallet
    val firstResult = FinancialEngine.processDepositApproval(
      currentWallet = initialWallet,
      deposit = deposit,
      existingTransactions = emptyList(),
    )
    assertTrue(firstResult is FinancialEngine.MutationResult.Success)
    val success1 = firstResult as FinancialEngine.MutationResult.Success
    assertEquals(15000L, success1.wallet.availableBalance)
    assertEquals(15000L, success1.wallet.totalDeposited)

    // Second run with existing transaction: Must be idempotent
    val existingTransactions = listOf(success1.transaction)
    val secondResult = FinancialEngine.processDepositApproval(
      currentWallet = success1.wallet,
      deposit = deposit,
      existingTransactions = existingTransactions,
    )
    assertTrue(secondResult is FinancialEngine.MutationResult.Success)
    val success2 = secondResult as FinancialEngine.MutationResult.Success
    assertTrue("Should indicate already processed", success2.isAlreadyProcessed)
    assertEquals("Wallet balance must remain unchanged", 15000L, success2.wallet.availableBalance)
  }

  // 13. Withdrawal hold: Insufficient balance & idempotency
  @Test
  fun testWithdrawalHold_InsufficientBalanceAndIdempotency() {
    val lowBalanceWallet = WalletEntity(
      uid = "user_test_123",
      availableBalance = 5000L, // ৳50
      pendingBalance = 0L,
    )
    val withdrawal = WithdrawalEntity(
      withdrawalId = "wth_test_001",
      uid = "user_test_123",
      amount = 10000L, // ৳100 (exceeds ৳50 available)
      method = "NAGAD",
      recipientNumber = "01700000000",
      status = WithdrawalStatus.REQUESTED.name,
    )

    val failResult = FinancialEngine.processWithdrawalHold(
      currentWallet = lowBalanceWallet,
      withdrawal = withdrawal,
    )
    assertTrue("Must fail on insufficient balance", failResult is FinancialEngine.MutationResult.Failure)

    // Wallet with sufficient balance
    val fundedWallet = WalletEntity(
      uid = "user_test_123",
      availableBalance = 20000L, // ৳200
      pendingBalance = 0L,
    )
    val holdResult = FinancialEngine.processWithdrawalHold(
      currentWallet = fundedWallet,
      withdrawal = withdrawal,
    )
    assertTrue(holdResult is FinancialEngine.MutationResult.Success)
    val holdSuccess = holdResult as FinancialEngine.MutationResult.Success
    assertEquals(10000L, holdSuccess.wallet.availableBalance) // Deducted from available
    assertEquals(10000L, holdSuccess.wallet.pendingBalance) // Held in escrow

    // Repeat hold: Idempotent
    val repeatHoldResult = FinancialEngine.processWithdrawalHold(
      currentWallet = holdSuccess.wallet,
      withdrawal = withdrawal,
      existingTransactions = listOf(holdSuccess.transaction),
    )
    assertTrue(repeatHoldResult is FinancialEngine.MutationResult.Success)
    assertTrue((repeatHoldResult as FinancialEngine.MutationResult.Success).isAlreadyProcessed)
  }
}
