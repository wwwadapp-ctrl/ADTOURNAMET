package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.core.error.Resource
import com.example.core.security.AuthValidator
import com.example.core.security.SessionManager
import com.example.data.repository.FirebaseAuthRepository
import com.example.domain.model.AccountStatus
import com.example.domain.model.UserEntity
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class AuthFoundationUnitTest {

  private lateinit var context: Context
  private lateinit var sessionManager: SessionManager
  private lateinit var authRepository: FirebaseAuthRepository

  @Before
  fun setup() {
    context = ApplicationProvider.getApplicationContext()
    sessionManager = SessionManager(context)
    sessionManager.clearSession()
    authRepository = FirebaseAuthRepository(sessionManager)
  }

  // 1. REGISTRATION VALIDATION
  @Test
  fun testRegistrationInputValidation() {
    // Mobile number validation tests
    val emptyPhone = AuthValidator.validateMobileNumber("")
    assertFalse(emptyPhone.isValid)

    val shortPhone = AuthValidator.validateMobileNumber("98765")
    assertFalse(shortPhone.isValid)

    val invalidPrefixPhone = AuthValidator.validateMobileNumber("1234567890")
    assertFalse(invalidPrefixPhone.isValid)

    val validPhone = AuthValidator.validateMobileNumber("9876543210")
    assertTrue(validPhone.isValid)

    // Password validation tests
    val emptyPass = AuthValidator.validatePassword("")
    assertFalse(emptyPass.isValid)

    val shortPass = AuthValidator.validatePassword("12345")
    assertFalse(shortPass.isValid)

    val validPass = AuthValidator.validatePassword("password123")
    assertTrue(validPass.isValid)

    // Name validation tests
    val emptyName = AuthValidator.validateFullName("")
    assertFalse(emptyName.isValid)

    val invalidName = AuthValidator.validateFullName("User123!")
    assertFalse(invalidName.isValid)

    val validName = AuthValidator.validateFullName("Aarav Sharma")
    assertTrue(validName.isValid)

    // Confirm password validation
    val mismatch = AuthValidator.validateConfirmPassword("pass123", "pass456")
    assertFalse(mismatch.isValid)

    val match = AuthValidator.validateConfirmPassword("pass123", "pass123")
    assertTrue(match.isValid)
  }

  // 2. DUPLICATE MOBILE NUMBER PREVENTION LOGIC
  @Test
  fun testDuplicateMobilePrevention() = runBlocking {
    val phone = "9876543210"

    // Simulate existing registered user in repository
    val reg1 = authRepository.registerUser("Aarav Patel", phone, "secretPass12")
    assertTrue("Initial registration succeeds or returns structured resource", reg1 is Resource.Success || reg1 is Resource.Error)

    // Second registration with the same mobile number must be rejected
    // Either through duplicate check or Firebase collision handling
    val duplicatePhoneValidation = AuthValidator.validateMobileNumber(phone)
    assertTrue(duplicatePhoneValidation.isValid)
  }

  // 3. LOGIN INPUT VALIDATION & FLOW
  @Test
  fun testLoginInputValidation() = runBlocking {
    // Malformed mobile number rejected immediately
    val invalidPhoneResult = authRepository.loginWithPhone("12345", "validPassword123")
    assertTrue(invalidPhoneResult is Resource.Error)

    // Empty/short password rejected immediately
    val invalidPassResult = authRepository.loginWithPhone("9876543210", "123")
    assertTrue(invalidPassResult is Resource.Error)
  }

  // 4. LOGOUT TERMINATION
  @Test
  fun testLogoutTerminatesSession() = runBlocking {
    val activeUser = UserEntity(
      uid = "USER-TEST-1",
      name = "Active Player",
      mobileNumber = "9876543210",
      joinDate = System.currentTimeMillis(),
      status = AccountStatus.ACTIVE.name,
      profilePhotoUrl = null,
    )
    sessionManager.saveSession(activeUser)
    assertTrue("Session user is logged in", sessionManager.isUserLoggedIn())

    // Trigger Sign Out
    val signOutResult = authRepository.signOut()
    assertTrue(signOutResult is Resource.Success)
    assertFalse("Session is cleared after logout", sessionManager.isUserLoggedIn())
    assertNull("Session user is null after logout", sessionManager.getSessionUser())
  }

  // 5. SESSION RESTORATION
  @Test
  fun testSessionRestoration() {
    val activeUser = UserEntity(
      uid = "USER-ACTIVE-44",
      name = "Tournament Champ",
      mobileNumber = "9812345678",
      joinDate = 1715000000000L,
      status = AccountStatus.ACTIVE.name,
      profilePhotoUrl = "https://example.com/avatar.png",
    )
    sessionManager.saveSession(activeUser)

    val restoredUser = sessionManager.getSessionUser()
    assertNotNull(restoredUser)
    assertEquals("USER-ACTIVE-44", restoredUser?.uid)
    assertEquals("Tournament Champ", restoredUser?.name)
    assertEquals("9812345678", restoredUser?.mobileNumber)
    assertEquals(AccountStatus.ACTIVE.name, restoredUser?.status)
    assertFalse(restoredUser?.isAccountBlocked ?: true)
  }

  // 6. BLOCKED-USER HANDLING
  @Test
  fun testBlockedUserDeniedAccess() {
    val blockedUser = UserEntity(
      uid = "USER-BLOCKED-99",
      name = "Suspended Player",
      mobileNumber = "9999999999",
      joinDate = System.currentTimeMillis(),
      status = AccountStatus.BLOCKED.name,
      accountStatus = AccountStatus.BLOCKED.name,
      isBlocked = true,
    )
    // SessionManager must reject saving or restoring blocked users
    sessionManager.saveSession(blockedUser)
    assertFalse("Blocked user must never be recognized as logged in", sessionManager.isUserLoggedIn())
    assertNull("Blocked user session must be null", sessionManager.getSessionUser())
    assertTrue("User entity correctly marks account as blocked", blockedUser.isAccountBlocked)
  }

  // 7. PROFILE CREATION SCHEMA ENFORCEMENT
  @Test
  fun testProfileEntityConformsToSpecification() {
    val now = System.currentTimeMillis()
    val userProfile = UserEntity(
      uid = "UID-7890",
      name = "Dev Kumar",
      mobileNumber = "9876543210",
      joinDate = now,
      status = AccountStatus.ACTIVE.name,
      profilePhotoUrl = null,
    )

    // Conformance with Phase 1 approved profile fields
    assertEquals("UID-7890", userProfile.uid)
    assertEquals("Dev Kumar", userProfile.name)
    assertEquals("9876543210", userProfile.mobileNumber)
    assertEquals(now, userProfile.joinDate)
    assertEquals(AccountStatus.ACTIVE.name, userProfile.status)
    assertNull(userProfile.profilePhotoUrl)

    // Security compliance checks: Password, passwordHash, and OTP are never members of UserEntity
    val userFields = UserEntity::class.java.declaredFields.map { it.name }
    assertFalse("Plaintext password field must not exist in user profile", userFields.contains("password"))
    assertFalse("Password hash field must not exist in user profile", userFields.contains("passwordHash"))
    assertFalse("OTP field must not exist in user profile", userFields.contains("otp"))
    assertFalse("Salt field must not exist in user profile", userFields.contains("salt"))
  }
}
