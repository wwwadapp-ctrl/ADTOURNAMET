package com.example.ui.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.domain.model.GameType
import com.example.domain.model.MatchEntity
import com.example.domain.model.UserEntity
import com.example.domain.model.WalletEntity
import com.example.ui.components.*
import com.example.ui.theme.*
import kotlinx.coroutines.delay

enum class GuideType {
  DEPOSIT,
  MATCH_JOIN,
  RESULT_SUBMIT,
  RULES,
}

data class GuideBannerItem(
  val id: String,
  val title: String,
  val description: String,
  val ctaText: String,
  val badgeText: String,
  val icon: ImageVector,
  val accentColor: Color,
  val secondaryColor: Color,
  val guideType: GuideType,
)

private val defaultGuideBanners = listOf(
  GuideBannerItem(
    id = "deposit_guide",
    title = "কীভাবে Deposit করবেন?",
    description = "bKash / Nagad দিয়ে সহজেই টাকা Add করুন",
    ctaText = "▶ ভিডিও দেখুন",
    badgeText = "DEPOSIT GUIDE",
    icon = Icons.Default.AccountBalanceWallet,
    accentColor = Gold400,
    secondaryColor = Cyan400,
    guideType = GuideType.DEPOSIT,
  ),
  GuideBannerItem(
    id = "match_join_guide",
    title = "কীভাবে Match Join করবেন?",
    description = "ম্যাচ সিলেক্ট করে 1v1 ব্যাটলে যোগ দিন",
    ctaText = "▶ ভিডিও দেখুন",
    badgeText = "JOIN GUIDE",
    icon = Icons.Default.SportsEsports,
    accentColor = Cyan400,
    secondaryColor = Indigo400,
    guideType = GuideType.MATCH_JOIN,
  ),
  GuideBannerItem(
    id = "result_guide",
    title = "কীভাবে Result Submit করবেন?",
    description = "ম্যাচ শেষে স্ক্রিনশট দিয়ে উইন ক্লেইম করুন",
    ctaText = "▶ ভিডিও দেখুন",
    badgeText = "RESULT GUIDE",
    icon = Icons.Default.EmojiEvents,
    accentColor = Amber400,
    secondaryColor = Emerald400,
    guideType = GuideType.RESULT_SUBMIT,
  ),
  GuideBannerItem(
    id = "rules_guide",
    title = "Tournament Rules জানুন",
    description = "ফেয়ার প্লে ও টুর্নামেন্ট নিয়মাবলী পড়ুন",
    ctaText = "▶ ভিডিও দেখুন",
    badgeText = "FAIR PLAY RULES",
    icon = Icons.Default.Gavel,
    accentColor = Gold400,
    secondaryColor = Rose400,
    guideType = GuideType.RULES,
  ),
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
  viewModel: HomeViewModel,
  currentUser: UserEntity?,
  wallet: WalletEntity?,
  onMatchClick: (String) -> Unit,
  onWalletClick: () -> Unit,
  onDepositClick: () -> Unit,
  onNotificationClick: () -> Unit,
  onProfileClick: () -> Unit,
  onRulesClick: () -> Unit,
  onSupportClick: () -> Unit,
  onAdminClick: () -> Unit,
  onHistoryClick: () -> Unit = {},
  onAllMatchesClick: () -> Unit = {},
  modifier: Modifier = Modifier,
) {
  val uiState by viewModel.uiState.collectAsState()
  val isAdmin = currentUser?.role?.equals("ADMIN", ignoreCase = true) == true ||
      currentUser?.role?.equals("SUPER_ADMIN", ignoreCase = true) == true

  var selectedGuideBanner by remember { mutableStateOf<GuideBannerItem?>(null) }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = Slate900,
              border = BorderStroke(1.dp, Gold400.copy(alpha = 0.7f)),
              modifier = Modifier.size(38.dp),
            ) {
              Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center,
              ) {
                Image(
                  painter = painterResource(id = R.drawable.ic_launcher_foreground),
                  contentDescription = "AD TOURNAMENT",
                  modifier = Modifier.size(34.dp),
                )
              }
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "AD TOURNAMENT",
                style = MaterialTheme.typography.titleMedium.copy(
                  fontWeight = FontWeight.Black,
                  letterSpacing = 1.sp,
                  fontSize = 15.sp,
                ),
                color = Color.White,
              )
              Text(
                text = "1v1 ESPORTS BATTLES",
                style = MaterialTheme.typography.labelSmall.copy(
                  fontWeight = FontWeight.Bold,
                  letterSpacing = 0.5.sp,
                  fontSize = 10.sp,
                ),
                color = Gold400,
              )
            }
          }
        },
        actions = {
          // Notifications icon
          IconButton(
            onClick = onNotificationClick,
            modifier = Modifier.testTag("home_notification_button"),
          ) {
            BadgedBox(
              badge = {
                Badge(
                  containerColor = Rose600,
                  modifier = Modifier.size(8.dp),
                )
              }
            ) {
              Icon(
                imageVector = Icons.Default.Notifications,
                contentDescription = "Notifications",
                tint = Slate300,
                modifier = Modifier.size(24.dp),
              )
            }
          }

          // Profile icon
          IconButton(
            onClick = onProfileClick,
            modifier = Modifier.testTag("home_profile_button"),
          ) {
            Icon(
              imageVector = Icons.Default.Person,
              contentDescription = "Profile",
              tint = Gold400,
              modifier = Modifier.size(26.dp),
            )
          }

          // Admin icon (if admin)
          if (isAdmin) {
            IconButton(
              onClick = onAdminClick,
              modifier = Modifier.testTag("home_admin_button"),
            ) {
              Icon(
                imageVector = Icons.Default.AdminPanelSettings,
                contentDescription = "Admin Panel",
                tint = Cyan400,
                modifier = Modifier.size(24.dp),
              )
            }
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = NavySurface,
        ),
      )
    },
    containerColor = DeepNavyBg,
    modifier = modifier.fillMaxSize(),
  ) { innerPadding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding),
      contentPadding = PaddingValues(bottom = 24.dp),
    ) {
      // 2. PREMIUM GUIDE CAROUSEL
      item {
        HomeGuideCarousel(
          banners = defaultGuideBanners,
          onBannerClick = { banner -> selectedGuideBanner = banner },
        )
      }

      // 3. TOURNAMENT SECTION HEADING
      item {
        TournamentSectionHeading()
      }

      // 4. ALL MATCHES QUICK CARD
      item {
        AllMatchesQuickCard(
          onAllMatchesClick = onAllMatchesClick,
        )
      }

      // 5. GAME FILTER
      item {
        GameFilterSection(
          selectedFilter = uiState.selectedGameFilter,
          onFilterSelect = { viewModel.setGameFilter(it) },
        )
      }

      // 6. AVAILABLE MATCHES HEADER
      item {
        AvailableMatchesHeader(
          onSeeAllClick = onAllMatchesClick,
        )
      }

      // AVAILABLE MATCHES FEED
      when {
        uiState.isLoading -> {
          item {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 32.dp, horizontal = 16.dp),
              contentAlignment = Alignment.Center,
            ) {
              LoadingState(message = "Loading available matches...")
            }
          }
        }
        uiState.errorMessage != null -> {
          item {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 24.dp, horizontal = 16.dp),
            ) {
              ErrorState(
                message = uiState.errorMessage ?: "Failed to load matches",
                onRetry = { viewModel.refresh() },
              )
            }
          }
        }
        uiState.filteredMatches.isEmpty() -> {
          item {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 24.dp, horizontal = 16.dp),
            ) {
              EmptyState(
                title = "No Available Matches",
                description = "All current contests are either in progress or filled. New 1v1 matches are posted frequently by Super Admin.",
                actionButtonText = "Refresh Matches",
                onActionClick = { viewModel.refresh() },
              )
            }
          }
        }
        else -> {
          val homeMatches = uiState.filteredMatches.take(6)
          items(homeMatches, key = { it.matchId }) { match ->
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            ) {
              MatchCard(
                match = match,
                isJoined = uiState.joinedMatchIds.contains(match.matchId) || match.isCodeVisible,
                onCardClick = { onMatchClick(match.matchId) },
                onJoinClick = { onMatchClick(match.matchId) },
                onViewCodeClick = { onMatchClick(match.matchId) },
                onSubmitProofClick = { onMatchClick(match.matchId) },
              )
            }
          }

          if (uiState.filteredMatches.size > 6) {
            item {
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(horizontal = 16.dp, vertical = 12.dp),
              ) {
                TournamentButton(
                  text = "VIEW ALL MATCHES (${uiState.filteredMatches.size})",
                  onClick = onAllMatchesClick,
                  variant = TournamentButtonVariant.OUTLINED,
                  modifier = Modifier.fillMaxWidth(),
                  testTag = "home_view_all_matches_btn",
                )
              }
            }
          }
        }
      }
    }

    // Guide Modal Dialog when CTA is tapped
    selectedGuideBanner?.let { banner ->
      GuideDetailDialog(
        banner = banner,
        onDismiss = { selectedGuideBanner = null },
        onAction = {
          selectedGuideBanner = null
          when (banner.guideType) {
            GuideType.DEPOSIT -> onDepositClick()
            GuideType.MATCH_JOIN -> onAllMatchesClick()
            GuideType.RESULT_SUBMIT -> onAllMatchesClick()
            GuideType.RULES -> onRulesClick()
          }
        },
      )
    }
  }
}

// -----------------------------------------------------------------------
// 2. PREMIUM GUIDE CAROUSEL COMPONENT
// -----------------------------------------------------------------------

@Composable
private fun HomeGuideCarousel(
  banners: List<GuideBannerItem>,
  onBannerClick: (GuideBannerItem) -> Unit,
  modifier: Modifier = Modifier,
) {
  val pagerState = rememberPagerState(pageCount = { banners.size })
  var isPausedByUser by remember { mutableStateOf(false) }

  LaunchedEffect(pagerState.isScrollInProgress) {
    if (pagerState.isScrollInProgress) {
      isPausedByUser = true
    }
  }

  LaunchedEffect(isPausedByUser, pagerState.currentPage) {
    if (isPausedByUser) {
      delay(6000L)
      isPausedByUser = false
    } else {
      delay(4500L)
      if (banners.isNotEmpty()) {
        val nextPage = (pagerState.currentPage + 1) % banners.size
        pagerState.animateScrollToPage(nextPage)
      }
    }
  }

  Column(
    modifier = modifier
      .fillMaxWidth()
      .padding(top = 10.dp, bottom = 4.dp),
  ) {
    HorizontalPager(
      state = pagerState,
      contentPadding = PaddingValues(horizontal = 16.dp),
      pageSpacing = 12.dp,
      modifier = Modifier
        .fillMaxWidth()
        .height(136.dp)
        .testTag("home_guide_carousel"),
    ) { page ->
      val banner = banners[page]
      GuideBannerCard(
        banner = banner,
        onClick = { onBannerClick(banner) },
      )
    }

    Spacer(modifier = Modifier.height(8.dp))

    // Dots indicator
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .testTag("home_guide_indicator_dots"),
      horizontalArrangement = Arrangement.Center,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      banners.indices.forEach { index ->
        val isSelected = pagerState.currentPage == index
        Box(
          modifier = Modifier
            .padding(horizontal = 3.dp)
            .height(5.dp)
            .width(if (isSelected) 20.dp else 5.dp)
            .clip(CircleShape)
            .background(if (isSelected) Gold400 else Slate700),
        )
      }
    }
  }
}

@Composable
private fun GuideBannerCard(
  banner: GuideBannerItem,
  onClick: () -> Unit,
) {
  Surface(
    shape = RoundedCornerShape(16.dp),
    color = Color.Transparent,
    border = BorderStroke(
      1.dp,
      Brush.horizontalGradient(
        listOf(
          banner.accentColor.copy(alpha = 0.55f),
          banner.secondaryColor.copy(alpha = 0.35f),
        )
      ),
    ),
    modifier = Modifier
      .fillMaxWidth()
      .fillMaxHeight()
      .clip(RoundedCornerShape(16.dp))
      .clickable { onClick() }
      .testTag("guide_banner_${banner.id}"),
  ) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(
          Brush.linearGradient(
            colors = listOf(
              Color(0xFF0F172A),
              Color(0xFF1E2640),
              Color(0xFF0F172A),
            )
          )
        )
        .padding(horizontal = 16.dp, vertical = 12.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxSize(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column(
          modifier = Modifier
            .weight(1f)
            .fillMaxHeight(),
          verticalArrangement = Arrangement.SpaceBetween,
        ) {
          Column {
            Surface(
              shape = RoundedCornerShape(4.dp),
              color = banner.accentColor.copy(alpha = 0.15f),
              border = BorderStroke(1.dp, banner.accentColor.copy(alpha = 0.4f)),
            ) {
              Text(
                text = banner.badgeText,
                style = MaterialTheme.typography.labelSmall.copy(
                  fontWeight = FontWeight.Black,
                  fontSize = 9.sp,
                  letterSpacing = 0.8.sp,
                ),
                color = banner.accentColor,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
              )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
              text = banner.title,
              style = MaterialTheme.typography.titleSmall.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
              ),
              color = Color.White,
              maxLines = 1,
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
              text = banner.description,
              style = MaterialTheme.typography.bodySmall.copy(
                fontSize = 11.sp,
              ),
              color = Slate300,
              maxLines = 1,
            )
          }

          Surface(
            shape = RoundedCornerShape(20.dp),
            color = banner.accentColor,
            modifier = Modifier
              .clickable { onClick() }
              .testTag("banner_cta_${banner.id}"),
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(
                text = banner.ctaText,
                style = MaterialTheme.typography.labelSmall.copy(
                  fontWeight = FontWeight.Black,
                  fontSize = 11.sp,
                ),
                color = Slate950,
              )
            }
          }
        }

        Spacer(modifier = Modifier.width(12.dp))

        Box(
          modifier = Modifier
            .size(64.dp)
            .clip(CircleShape)
            .background(
              Brush.radialGradient(
                colors = listOf(
                  banner.accentColor.copy(alpha = 0.25f),
                  Color.Transparent,
                )
              )
            )
            .border(
              1.dp,
              Brush.linearGradient(
                listOf(banner.accentColor.copy(alpha = 0.6f), banner.secondaryColor.copy(alpha = 0.3f))
              ),
              CircleShape,
            ),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            imageVector = banner.icon,
            contentDescription = null,
            tint = banner.accentColor,
            modifier = Modifier.size(32.dp),
          )
        }
      }
    }
  }
}

// -----------------------------------------------------------------------
// 3. TOURNAMENT SECTION HEADING
// -----------------------------------------------------------------------

@Composable
private fun TournamentSectionHeading(modifier: Modifier = Modifier) {
  Row(
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 8.dp),
    verticalAlignment = Alignment.CenterVertically,
  ) {
    HorizontalDivider(
      modifier = Modifier.weight(1f),
      color = Slate800,
      thickness = 1.dp,
    )
    Row(
      verticalAlignment = Alignment.CenterVertically,
      modifier = Modifier.padding(horizontal = 12.dp),
    ) {
      Icon(
        imageVector = Icons.Default.EmojiEvents,
        contentDescription = null,
        tint = Gold400,
        modifier = Modifier.size(16.dp),
      )
      Spacer(modifier = Modifier.width(6.dp))
      Text(
        text = "TOURNAMENTS",
        style = MaterialTheme.typography.titleMedium.copy(
          fontWeight = FontWeight.Black,
          letterSpacing = 2.sp,
          fontSize = 14.sp,
        ),
        color = Gold400,
      )
      Spacer(modifier = Modifier.width(6.dp))
      Icon(
        imageVector = Icons.Default.EmojiEvents,
        contentDescription = null,
        tint = Gold400,
        modifier = Modifier.size(16.dp),
      )
    }
    HorizontalDivider(
      modifier = Modifier.weight(1f),
      color = Slate800,
      thickness = 1.dp,
    )
  }
}

// -----------------------------------------------------------------------
// 4. ALL MATCHES QUICK CARD
// -----------------------------------------------------------------------

@Composable
private fun AllMatchesQuickCard(
  onAllMatchesClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    shape = RoundedCornerShape(14.dp),
    color = Slate900,
    border = BorderStroke(1.dp, Gold400.copy(alpha = 0.45f)),
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 4.dp)
      .clip(RoundedCornerShape(14.dp))
      .clickable { onAllMatchesClick() }
      .testTag("home_all_matches_quick_card"),
  ) {
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .background(
          Brush.horizontalGradient(
            listOf(
              Color(0xFF161D32),
              Color(0xFF1E2744),
              Color(0xFF161D32),
            )
          )
        )
        .padding(horizontal = 14.dp, vertical = 12.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f),
        ) {
          Box(
            modifier = Modifier
              .size(42.dp)
              .clip(RoundedCornerShape(10.dp))
              .background(
                Brush.linearGradient(
                  listOf(Amber700.copy(alpha = 0.35f), Gold500.copy(alpha = 0.15f))
                )
              )
              .border(1.dp, Gold400.copy(alpha = 0.5f), RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center,
          ) {
            Icon(
              imageVector = Icons.Default.EmojiEvents,
              contentDescription = "All Matches",
              tint = Gold400,
              modifier = Modifier.size(24.dp),
            )
          }

          Spacer(modifier = Modifier.width(12.dp))

          Column {
            Text(
              text = "ALL MATCHES",
              style = MaterialTheme.typography.titleSmall.copy(
                fontWeight = FontWeight.Black,
                letterSpacing = 0.5.sp,
                fontSize = 14.sp,
              ),
              color = Color.White,
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
              text = "সব Ludo ও Carrom 1v1 ম্যাচ এক জায়গায়",
              style = MaterialTheme.typography.bodySmall.copy(
                fontSize = 11.sp,
              ),
              color = Slate300,
            )
          }
        }

        Icon(
          imageVector = Icons.Default.ChevronRight,
          contentDescription = "Go to Matches",
          tint = Gold400,
          modifier = Modifier.size(24.dp),
        )
      }
    }
  }
}

// -----------------------------------------------------------------------
// 5. GAME FILTER
// -----------------------------------------------------------------------

@Composable
private fun GameFilterSection(
  selectedFilter: GameType?,
  onFilterSelect: (GameType?) -> Unit,
  modifier: Modifier = Modifier,
) {
  Row(
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 8.dp),
    horizontalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    val filterItems = listOf(
      Triple(null, "ALL GAMES", null),
      Triple(GameType.LUDO, "🎲 LUDO", Icons.Default.Casino),
      Triple(GameType.CARROM, "⚪ CARROM", Icons.Default.Album),
    )

    filterItems.forEach { (type, label, icon) ->
      val isSelected = selectedFilter == type
      Surface(
        shape = RoundedCornerShape(20.dp),
        color = if (isSelected) Gold500 else Slate900,
        border = BorderStroke(1.dp, if (isSelected) Gold400 else Slate800),
        modifier = Modifier
          .weight(1f)
          .height(38.dp)
          .clip(RoundedCornerShape(20.dp))
          .clickable { onFilterSelect(type) }
          .testTag("filter_chip_${type?.name ?: "ALL"}"),
      ) {
        Row(
          modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 4.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.Center,
        ) {
          if (icon != null) {
            Icon(
              imageVector = icon,
              contentDescription = null,
              tint = if (isSelected) Slate950 else if (type == GameType.LUDO) Gold400 else Cyan400,
              modifier = Modifier.size(15.dp),
            )
            Spacer(modifier = Modifier.width(4.dp))
          }
          Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
              fontWeight = if (isSelected) FontWeight.Black else FontWeight.SemiBold,
              fontSize = 11.sp,
            ),
            color = if (isSelected) Slate950 else Color.White,
            maxLines = 1,
          )
        }
      }
    }
  }
}

// -----------------------------------------------------------------------
// 6. AVAILABLE MATCHES HEADER
// -----------------------------------------------------------------------

@Composable
private fun AvailableMatchesHeader(
  onSeeAllClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Row(
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 6.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Text(
      text = "AVAILABLE MATCHES",
      style = MaterialTheme.typography.titleSmall.copy(
        fontWeight = FontWeight.Bold,
        letterSpacing = 0.5.sp,
      ),
      color = Color.White,
    )

    Text(
      text = "See All",
      style = MaterialTheme.typography.labelMedium.copy(
        fontWeight = FontWeight.Bold,
      ),
      color = Gold400,
      modifier = Modifier
        .clickable { onSeeAllClick() }
        .padding(vertical = 4.dp, horizontal = 4.dp)
        .testTag("home_see_all_matches"),
    )
  }
}

// -----------------------------------------------------------------------
// GUIDE DETAIL DIALOG
// -----------------------------------------------------------------------

@Composable
private fun GuideDetailDialog(
  banner: GuideBannerItem,
  onDismiss: () -> Unit,
  onAction: () -> Unit,
) {
  val (actionBtnText, guideSteps) = when (banner.guideType) {
    GuideType.DEPOSIT -> Pair(
      "Deposit পেজে যান",
      listOf(
        "১. Wallet পেজে গিয়ে 'Deposit' বাটনে ট্যাপ করুন।",
        "২. bKash বা Nagad সিলেক্ট করে প্রদত্ত নাম্বারে Cash In / Send Money করুন।",
        "৩. ট্রানজেকশন আইডি (TrxID) ও স্ক্রিনশট সাবমিট করুন।",
        "৪. অ্যাডমিন ভেরিফাই করে ৫-১০ মিনিটের মধ্যে ব্যালেন্স যুক্ত করবে।",
      )
    )
    GuideType.MATCH_JOIN -> Pair(
      "ম্যাচ তালিকা দেখুন",
      listOf(
        "১. হোমপেজ বা Matches পেজ থেকে আপনার পছন্দমতো 1v1 ম্যাচ বেছে নিন।",
        "২. 'JOIN NOW' বাটনে ট্যাপ করে এন্ট্রি ফি পরিশোধ করে স্লট নিশ্চিত করুন।",
        "৩. ম্যাচ শুরুর নির্দিষ্ট সময়ে স্ক্রিনে 'Game Room Code' দেখতে পাবেন।",
        "৪. কোডটি Ludo King বা Carrom গেমে পেস্ট করে ব্যাটল শুরু করুন।",
      )
    )
    GuideType.RESULT_SUBMIT -> Pair(
      "ম্যাচ পেজে যান",
      listOf(
        "১. খেলা শেষ হওয়া মাত্র বিজয়ী স্ক্রিনের পরিষ্কার স্ক্রিনশট নিন।",
        "২. ম্যাচে গিয়ে 'SUBMIT VICTORY PROOF' বাটনে ট্যাপ করুন।",
        "৩. স্ক্রিনশট আপলোড করে সাবমিট বাটনে চাপুন।",
        "৪. রিভিউ সম্পন্ন হলে প্রাইজমানি স্বয়ংক্রিয়ভাবে ওয়ালেটে যুক্ত হবে।",
      )
    )
    GuideType.RULES -> Pair(
      "সম্পূর্ণ নিয়মাবলী পড়ুন",
      listOf(
        "১. কোনো প্রকার হ্যাক, চিট বা ফেক স্ক্রিনশট সম্পূর্ণ নিষিদ্ধ।",
        "২. রুম কোড দেওয়ার ৫ মিনিটের মধ্যে খেলায় অংশ নিতে হবে।",
        "৩. কোনো বিতর্ক দেখা দিলে অ্যাডমিনের সিদ্ধান্তই চূড়ান্ত।",
        "৪. কোনো সমস্যায় তাৎক্ষণিক লাইভ সাপোর্টে যোগাযোগ করুন।",
      )
    )
  }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = banner.icon,
          contentDescription = null,
          tint = banner.accentColor,
          modifier = Modifier.size(24.dp),
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = banner.title,
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          color = Color.White,
        )
      }
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        guideSteps.forEach { step ->
          Text(
            text = step,
            style = MaterialTheme.typography.bodyMedium,
            color = Slate200,
          )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Surface(
          shape = RoundedCornerShape(6.dp),
          color = Slate850,
          border = BorderStroke(1.dp, CardBorder),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Text(
            text = "ℹ️ অফিসিয়াল ভিডিও টিউটোরিয়াল সরাসরি অ্যাপে শীঘ্রই উন্মুক্ত করা হবে।",
            style = MaterialTheme.typography.labelSmall,
            color = Gold400,
            modifier = Modifier.padding(8.dp),
          )
        }
      }
    },
    confirmButton = {
      TournamentButton(
        text = actionBtnText,
        onClick = onAction,
        modifier = Modifier.height(38.dp),
      )
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("বন্ধ করুন", color = Slate400)
      }
    },
    containerColor = NavyCard,
    tonalElevation = 6.dp,
  )
}
