package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.MatchEntity
import com.example.domain.model.MatchStatus
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MatchCard(
  match: MatchEntity,
  modifier: Modifier = Modifier,
  onCardClick: (() -> Unit)? = null,
  onJoinClick: (() -> Unit)? = null,
  onViewCodeClick: (() -> Unit)? = null,
  onSubmitProofClick: (() -> Unit)? = null,
  isJoined: Boolean = false,
) {
  val isLudo = match.gameType.equals("LUDO", ignoreCase = true)
  val isUpcoming = match.status.equals(MatchStatus.UPCOMING.name, ignoreCase = true)
  val isRunning = match.status.equals(MatchStatus.RUNNING.name, ignoreCase = true)
  val isCompleted = match.status.equals(MatchStatus.COMPLETED.name, ignoreCase = true)
  val isCancelled = match.status.equals(MatchStatus.CANCELLED.name, ignoreCase = true)
  val isFull = match.joinedPlayersCount >= match.maxPlayers || match.status.equals(MatchStatus.FULL.name, ignoreCase = true)
  val isCodeAdded = match.status.equals(MatchStatus.CODE_ADDED.name, ignoreCase = true) || match.gameCode.isNotBlank()
  val isResultSubmitted = match.status.equals(MatchStatus.RESULT_SUBMITTED.name, ignoreCase = true)
  val isPaused = match.status.equals(MatchStatus.PAUSED.name, ignoreCase = true)
  val isDisabled = match.status.equals(MatchStatus.DISABLED.name, ignoreCase = true)

  val defaultBorder = if (isJoined) Emerald500.copy(alpha = 0.6f) else MidnightNavyBorder
  val borderColor = when {
    isJoined -> Emerald500.copy(alpha = 0.8f)
    isRunning -> Indigo600
    isCompleted -> NeonEmerald.copy(alpha = 0.6f)
    isCancelled -> Rose600.copy(alpha = 0.5f)
    isPaused || isDisabled -> Amber600.copy(alpha = 0.5f)
    isUpcoming -> Amber500.copy(alpha = 0.4f)
    else -> defaultBorder
  }

  TournamentCard(
    modifier = modifier
      .fillMaxWidth()
      .testTag("match_card_${match.matchId}")
      .then(
        if (onCardClick != null) {
          Modifier.clickable { onCardClick() }
        } else {
          Modifier
        }
      ),
    backgroundColor = MidnightNavyCard,
    borderColor = borderColor,
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Surface(
          color = if (isLudo) Color(0xFF1B1838) else Color(0xFF0C2234),
          shape = RoundedCornerShape(8.dp),
          border = BorderStroke(0.8.dp, if (isLudo) Gold400.copy(alpha = 0.7f) else NeonCyan.copy(alpha = 0.7f)),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Box(
              modifier = Modifier
                .size(20.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(if (isLudo) Gold400.copy(alpha = 0.2f) else NeonCyan.copy(alpha = 0.2f)),
              contentAlignment = Alignment.Center,
            ) {
              Icon(
                imageVector = if (isLudo) Icons.Default.Casino else Icons.Default.Album,
                contentDescription = null,
                tint = if (isLudo) Gold400 else NeonCyan,
                modifier = Modifier.size(13.dp),
              )
            }
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = if (isLudo) "LUDO 1v1" else "CARROM 1v1",
              style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Black,
                letterSpacing = 0.5.sp,
              ),
              color = Color.White,
            )
          }
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = match.matchNumber,
          style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
          color = Slate300,
        )
      }

      MatchStatusBadge(
        status = match.status,
        joinedPlayersCount = match.joinedPlayersCount,
        maxPlayers = match.maxPlayers,
        isJoined = isJoined,
      )
    }

    Spacer(modifier = Modifier.height(10.dp))

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        text = match.title.ifBlank { "${if (isLudo) "Ludo" else "Carrom"} 1v1 Battle" },
        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
        color = Color.White,
        modifier = Modifier.weight(1f),
      )
      if (onCardClick != null) {
        Icon(
          imageVector = Icons.Default.ChevronRight,
          contentDescription = "View Details",
          tint = Slate400,
          modifier = Modifier.size(20.dp),
        )
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    Row(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(10.dp))
        .background(Slate900)
        .border(BorderStroke(0.8.dp, MidnightNavyBorder), RoundedCornerShape(10.dp))
        .padding(horizontal = 14.dp, vertical = 10.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Column {
        Text(text = "ENTRY FEE", style = MaterialTheme.typography.labelSmall, color = Slate400)
        Text(
          text = "৳ ${"%.0f".format(match.entryFee)}",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          color = Color.White,
        )
      }
      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = "FORMAT", style = MaterialTheme.typography.labelSmall, color = Slate400)
        Text(
          text = "1v1 Battle",
          style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
          color = NeonCyan,
        )
      }
      Column(horizontalAlignment = Alignment.End) {
        Text(text = "PRIZE POOL", style = MaterialTheme.typography.labelSmall, color = Slate400)
        Text(
          text = "৳ ${"%.0f".format(match.prizePool)}",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
          color = Gold400,
        )
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    when {
      isCompleted -> {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(Emerald900.copy(alpha = 0.3f))
            .padding(10.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = "Match Completed",
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
            color = Emerald400,
          )
          if (onCardClick != null) {
            Text(
              text = "View Result →",
              style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
              color = Gold400,
            )
          }
        }
      }
      isCancelled -> {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(Rose900.copy(alpha = 0.3f))
            .padding(10.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = "Match Cancelled • Entry fees refunded",
            style = MaterialTheme.typography.bodySmall,
            color = Rose400,
          )
        }
      }
      isPaused || isDisabled -> {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(Amber900.copy(alpha = 0.3f))
            .padding(10.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = if (isPaused) "Match Paused by Super Admin" else "Match Disabled",
            style = MaterialTheme.typography.bodySmall,
            color = Amber400,
          )
        }
      }
      else -> {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          val timeFormatted = remember(match.scheduledTime) {
            if (match.scheduledTime > 0) {
              SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(match.scheduledTime))
            } else {
              "Upcoming"
            }
          }
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Schedule, contentDescription = null, tint = Slate400, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = if (isRunning) "Started at $timeFormatted" else "Starts at $timeFormatted",
              style = MaterialTheme.typography.bodySmall,
              color = Slate400,
            )
          }
          when {
            isJoined -> {
              TournamentButton(
                text = "JOINED",
                onClick = { onCardClick?.invoke() },
                enabled = false,
                variant = TournamentButtonVariant.JOINED,
                modifier = Modifier.height(40.dp),
                testTag = "joined_button_${match.matchId}",
              )
            }
            isRunning -> {
              TournamentButton(
                text = "IN PROGRESS",
                onClick = { onCardClick?.invoke() },
                variant = TournamentButtonVariant.SECONDARY,
                modifier = Modifier.height(40.dp),
                testTag = "in_progress_${match.matchId}",
              )
            }
            isUpcoming -> {
              TournamentButton(
                text = "UPCOMING",
                onClick = { onCardClick?.invoke() },
                enabled = false,
                variant = TournamentButtonVariant.SECONDARY,
                modifier = Modifier.height(40.dp),
                testTag = "upcoming_button_${match.matchId}",
              )
            }
            isFull -> {
              TournamentButton(
                text = "MATCH FULL",
                onClick = { onCardClick?.invoke() },
                enabled = false,
                modifier = Modifier.height(40.dp),
                testTag = "match_full_${match.matchId}",
              )
            }
            else -> {
              TournamentButton(
                text = "JOIN NOW",
                onClick = { onJoinClick?.invoke() ?: onCardClick?.invoke() },
                modifier = Modifier.height(40.dp),
                testTag = "join_button_${match.matchId}",
              )
            }
          }
        }
      }
    }
  }
}

@Composable
fun MatchStatusBadge(
  status: String,
  joinedPlayersCount: Int,
  maxPlayers: Int = 2,
  isJoined: Boolean = false,
) {
  val isFull = joinedPlayersCount >= maxPlayers || status.equals(MatchStatus.FULL.name, ignoreCase = true)
  val isRunning = status.equals(MatchStatus.RUNNING.name, ignoreCase = true)
  val isCompleted = status.equals(MatchStatus.COMPLETED.name, ignoreCase = true)
  val isCancelled = status.equals(MatchStatus.CANCELLED.name, ignoreCase = true)
  val isResultSubmitted = status.equals(MatchStatus.RESULT_SUBMITTED.name, ignoreCase = true)
  val isCodeAdded = status.equals(MatchStatus.CODE_ADDED.name, ignoreCase = true)
  val isPaused = status.equals(MatchStatus.PAUSED.name, ignoreCase = true)
  val isDisabled = status.equals(MatchStatus.DISABLED.name, ignoreCase = true)
  val isUpcoming = status.equals(MatchStatus.UPCOMING.name, ignoreCase = true)

  val (bgColor, textColor, label) = when {
    isJoined -> Triple(Emerald400.copy(alpha = 0.18f), Emerald400, "JOINED")
    isCompleted -> Triple(NeonEmerald.copy(alpha = 0.18f), NeonEmerald, "COMPLETED")
    isCancelled -> Triple(Rose600.copy(alpha = 0.2f), Rose400, "CANCELLED")
    isPaused -> Triple(Amber600.copy(alpha = 0.2f), Amber400, "PAUSED")
    isDisabled -> Triple(Slate700.copy(alpha = 0.5f), Slate400, "DISABLED")
    isUpcoming -> Triple(Amber500.copy(alpha = 0.2f), Amber400, "UPCOMING")
    isRunning -> Triple(Indigo600.copy(alpha = 0.25f), Indigo400, "RUNNING")
    isResultSubmitted -> Triple(Purple600.copy(alpha = 0.25f), Purple400, "REVIEW")
    isCodeAdded -> Triple(NeonCyan.copy(alpha = 0.18f), NeonCyan, "CODE READY")
    isFull -> Triple(Rose600.copy(alpha = 0.2f), Rose400, "FULL ($joinedPlayersCount/$maxPlayers)")
    else -> Triple(NeonCyan.copy(alpha = 0.16f), NeonCyan, "$joinedPlayersCount/$maxPlayers SLOTS")
  }

  Surface(
    color = bgColor,
    shape = RoundedCornerShape(12.dp),
    border = BorderStroke(0.8.dp, textColor.copy(alpha = 0.6f)),
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.labelSmall.copy(
        fontWeight = FontWeight.Black,
        letterSpacing = 0.4.sp,
      ),
      color = textColor,
      modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp),
    )
  }
}
