package com.example.ui.matches

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.error.Resource
import com.example.domain.model.GameType
import com.example.domain.model.MatchEntity
import com.example.domain.repository.MatchRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class MatchesUiState(
  val isLoading: Boolean = true,
  val selectedTab: MatchesTab = MatchesTab.AVAILABLE,
  val selectedGameFilter: GameFilter = GameFilter.ALL,
  val matchesList: List<MatchEntity> = emptyList(),
  val filteredMatches: List<MatchEntity> = emptyList(),
  val joinedMatchIds: Set<String> = emptySet(),
  val errorMessage: String? = null,
)

class MatchesViewModel(
  private val matchRepository: MatchRepository,
  private val userId: String,
  initialTab: MatchesTab = MatchesTab.AVAILABLE,
) : ViewModel() {

  private val _uiState = MutableStateFlow(
    MatchesUiState(
      isLoading = true,
      selectedTab = initialTab,
    )
  )
  val uiState: StateFlow<MatchesUiState> = _uiState.asStateFlow()

  private var fetchJob: Job? = null

  init {
    observeJoinedMatches()
    loadMatchesForCurrentTab()
  }

  private fun observeJoinedMatches() {
    viewModelScope.launch {
      matchRepository.getMyJoinedMatches(userId).collect { res ->
        if (res is Resource.Success) {
          _uiState.value = _uiState.value.copy(
            joinedMatchIds = res.data.map { it.matchId }.toSet()
          )
        }
      }
    }
  }

  fun setTab(tab: MatchesTab) {
    if (_uiState.value.selectedTab == tab && !_uiState.value.isLoading && _uiState.value.errorMessage == null) return
    _uiState.value = _uiState.value.copy(selectedTab = tab)
    loadMatchesForCurrentTab()
  }

  fun setGameFilter(filter: GameFilter) {
    _uiState.value = _uiState.value.copy(
      selectedGameFilter = filter,
      filteredMatches = filterMatches(_uiState.value.matchesList, filter.gameType),
    )
  }

  fun retry() {
    loadMatchesForCurrentTab()
  }

  fun refresh() {
    loadMatchesForCurrentTab()
  }

  fun loadMatchesForCurrentTab() {
    fetchJob?.cancel()
    fetchJob = viewModelScope.launch {
      _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
      val flow = when (_uiState.value.selectedTab) {
        MatchesTab.AVAILABLE -> matchRepository.getAvailableMatches(30)
        MatchesTab.MY_JOINED -> matchRepository.getMyJoinedMatches(userId)
        MatchesTab.UPCOMING -> matchRepository.getUpcomingMatches(30)
        MatchesTab.HISTORY -> matchRepository.getMatchHistory(userId, 30)
      }
      flow.collect { resource ->
        when (resource) {
          is Resource.Loading -> {
            _uiState.value = _uiState.value.copy(isLoading = true)
          }
          is Resource.Success -> {
            val matches = resource.data
            _uiState.value = _uiState.value.copy(
              isLoading = false,
              matchesList = matches,
              filteredMatches = filterMatches(matches, _uiState.value.selectedGameFilter.gameType),
              errorMessage = null,
            )
          }
          is Resource.Error -> {
            _uiState.value = _uiState.value.copy(
              isLoading = false,
              errorMessage = resource.error.userMessage,
            )
          }
          is Resource.Idle -> Unit
        }
      }
    }
  }

  private fun filterMatches(matches: List<MatchEntity>, gameType: GameType?): List<MatchEntity> {
    if (gameType == null) return matches
    return matches.filter { it.gameType.equals(gameType.name, ignoreCase = true) }
  }

  class Factory(
    private val matchRepository: MatchRepository,
    private val userId: String,
    private val initialTab: MatchesTab = MatchesTab.AVAILABLE,
  ) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
      return MatchesViewModel(matchRepository, userId, initialTab) as T
    }
  }
}
