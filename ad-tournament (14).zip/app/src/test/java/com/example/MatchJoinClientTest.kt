package com.example

import com.example.core.error.Resource
import com.example.data.repository.FirebaseMatchRepository
import com.example.data.repository.LocalDataStore
import com.example.domain.model.MatchEntity
import com.example.domain.model.MatchPlayerEntity
import com.example.domain.model.MatchStatus
import com.example.domain.model.UserEntity
import com.example.domain.model.WalletEntity
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.util.concurrent.CopyOnWriteArrayList

class MatchJoinClientTest {

  private val repository = FirebaseMatchRepository()
  private val testUserId = "player_test_001"
  private val testMatchId = "match_test_101"

  @Before
  fun setUp() {
    LocalDataStore.localUsers[testUserId] = UserEntity(
      uid = testUserId,
      userId = testUserId,
      name = "Test Player",
      role = "PLAYER",
      status = "ACTIVE",
    )
    LocalDataStore.localWallets[testUserId] = WalletEntity(
      uid = testUserId,
      userId = testUserId,
      balance = 100.0,
      availableBalance = 10000L,
    )
    LocalDataStore.localMatches[testMatchId] = MatchEntity(
      matchId = testMatchId,
      matchNumber = "#M101",
      title = "Test Tournament",
      status = MatchStatus.AVAILABLE.name,
      entryFee = 50.0,
      entryFeeMinorUnits = 5000L,
      joinedPlayersCount = 0,
      maxPlayers = 2,
    )
    LocalDataStore.localMatchPlayers[testMatchId] = CopyOnWriteArrayList()
    LocalDataStore.localTransactions.clear()
  }

  @Test
  fun testJoinMatch_successDeductsBalanceAndIncrementsCount() = runBlocking {
    val result = repository.joinMatch(testUserId, testMatchId)
    assertTrue("Expected Success, got $result", result is Resource.Success)

    val updatedMatch = LocalDataStore.localMatches[testMatchId]!!
    assertEquals(1, updatedMatch.joinedPlayersCount)
    assertEquals(MatchStatus.AVAILABLE.name, updatedMatch.status)

    val updatedWallet = LocalDataStore.localWallets[testUserId]!!
    assertEquals(5000L, updatedWallet.availableBalance)
    assertEquals(50.0, updatedWallet.balance, 0.01)

    val players = LocalDataStore.localMatchPlayers[testMatchId]!!
    assertEquals(1, players.size)
    assertEquals(testUserId, players[0].effectiveUid)
  }

  @Test
  fun testJoinMatch_becomesFullWhenMaxPlayersReached() = runBlocking {
    val opponentId = "player_test_002"
    LocalDataStore.localUsers[opponentId] = UserEntity(uid = opponentId, userId = opponentId)
    LocalDataStore.localWallets[opponentId] = WalletEntity(uid = opponentId, userId = opponentId, balance = 100.0, availableBalance = 10000L)

    // Player 1 joins
    val res1 = repository.joinMatch(testUserId, testMatchId)
    assertTrue(res1 is Resource.Success)

    // Player 2 joins
    val res2 = repository.joinMatch(opponentId, testMatchId)
    assertTrue(res2 is Resource.Success)

    val updatedMatch = LocalDataStore.localMatches[testMatchId]!!
    assertEquals(2, updatedMatch.joinedPlayersCount)
    assertEquals(MatchStatus.FULL.name, updatedMatch.status)
  }

  @Test
  fun testJoinMatch_insufficientBalanceFails() = runBlocking {
    LocalDataStore.localWallets[testUserId] = WalletEntity(
      uid = testUserId,
      userId = testUserId,
      balance = 10.0,
      availableBalance = 1000L,
    )

    val result = repository.joinMatch(testUserId, testMatchId)
    assertTrue("Expected Error due to low balance, got $result", result is Resource.Error)

    val match = LocalDataStore.localMatches[testMatchId]!!
    assertEquals(0, match.joinedPlayersCount)
  }

  @Test
  fun testJoinMatch_alreadyJoinedFails() = runBlocking {
    val res1 = repository.joinMatch(testUserId, testMatchId)
    assertTrue(res1 is Resource.Success)

    // Second attempt should fail
    val res2 = repository.joinMatch(testUserId, testMatchId)
    assertTrue("Expected Error for duplicate join, got $res2", res2 is Resource.Error)
  }

  @Test
  fun testJoinMatch_upcomingStatusFails() = runBlocking {
    LocalDataStore.localMatches[testMatchId] = LocalDataStore.localMatches[testMatchId]!!.copy(
      status = MatchStatus.UPCOMING.name,
    )

    val result = repository.joinMatch(testUserId, testMatchId)
    assertTrue("Expected Error when joining UPCOMING match, got $result", result is Resource.Error)
    val error = (result as Resource.Error).error
    assertTrue(error.message.contains("not available to join", ignoreCase = true))

    val match = LocalDataStore.localMatches[testMatchId]!!
    assertEquals(0, match.joinedPlayersCount)
  }
}
