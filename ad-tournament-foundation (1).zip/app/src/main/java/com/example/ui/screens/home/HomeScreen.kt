package com.example.ui.screens.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ClipboardManager
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.GameType
import com.example.domain.model.MatchEntity
import com.example.domain.model.MatchStatus
import com.example.domain.model.WalletEntity
import com.example.domain.repository.MatchRepository
import com.example.domain.repository.WalletRepository
import com.example.ui.components.StatusBadge
import com.example.ui.components.TournamentButton
import com.example.ui.components.TournamentButtonVariant
import com.example.ui.components.TournamentCard
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class MatchFilterTab {
  AVAILABLE,
  MY_JOINED,
  UPCOMING
}

@Composable
fun HomeScreen(
  userId: String,
  onNavigateToWallet: () -> Unit,
  onNavigateToNotifications: () -> Unit,
  onNavigateToHistory: () -> Unit,
  matchRepository: MatchRepository,
  walletRepository: WalletRepository,
  modifier: Modifier = Modifier,
) {
  var selectedGameFilter by remember { mutableStateOf<String?>("ALL") } // ALL, LUDO, CARROM
  var selectedTab by remember { mutableStateOf(MatchFilterTab.AVAILABLE) }
  var matchToJoin by remember { mutableStateOf<MatchEntity?>(null) }
  var matchForCodeView by remember { mutableStateOf<MatchEntity?>(null) }
  var matchForProofSubmission by remember { mutableStateOf<MatchEntity?>(null) }
  var toastMessage by remember { mutableStateOf<String?>(null) }

  // Observe Wallet
  val walletResource by walletRepository.getWallet(userId).collectAsState(initial = null)
  val wallet = (walletResource as? com.example.core.error.Resource.Success)?.data

  // Observe Matches based on tab
  val matchesFlow = remember(selectedTab, userId) {
    when (selectedTab) {
      MatchFilterTab.AVAILABLE -> matchRepository.getAvailableMatches(30)
      MatchFilterTab.MY_JOINED -> matchRepository.getMyJoinedMatches(userId)
      MatchFilterTab.UPCOMING -> matchRepository.getUpcomingMatches(30)
    }
  }
  val matchesResource by matchesFlow.collectAsState(initial = null)
  val matchesList = (matchesResource as? com.example.core.error.Resource.Success)?.data ?: emptyList()

  val filteredMatches = remember(matchesList, selectedGameFilter) {
    if (selectedGameFilter == "ALL" || selectedGameFilter == null) {
      matchesList
    } else {
      matchesList.filter { it.gameType.equals(selectedGameFilter, ignoreCase = true) }
    }
  }

  val clipboardManager: ClipboardManager = LocalClipboardManager.current

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(DeepNavyBg)
      .testTag("home_screen"),
  ) {
    // 1. TOP HEADER & APP BRANDING
    HomeTopHeader(
      wallet = wallet,
      onWalletClick = onNavigateToWallet,
      onNotificationClick = onNavigateToNotifications,
    )

    // 2. QUICK WALLET BANNER
    QuickWalletCard(
      wallet = wallet,
      onDepositClick = onNavigateToWallet,
    )

    // 3. GAME FILTER SELECTOR (ALL, LUDO, CARROM)
    GameFilterSelector(
      selectedFilter = selectedGameFilter ?: "ALL",
      onFilterSelect = { selectedGameFilter = it },
    )

    // 4. SECTION TABS (AVAILABLE, MY JOINED, UPCOMING)
    MatchSectionTabs(
      selectedTab = selectedTab,
      onTabSelect = { selectedTab = it },
      joinedCount = if (selectedTab == MatchFilterTab.MY_JOINED) filteredMatches.size else 1,
    )

    // TOAST / SNACKBAR FEEDBACK
    AnimatedVisibility(visible = toastMessage != null) {
      Surface(
        color = Cyan500.copy(alpha = 0.2f),
        border = BorderStroke(1.dp, Cyan400),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 6.dp),
      ) {
        Row(
          modifier = Modifier.padding(10.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Cyan400, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = toastMessage ?: "",
            style = MaterialTheme.typography.bodySmall,
            color = Color.White,
            modifier = Modifier.weight(1f),
          )
          IconButton(
            onClick = { toastMessage = null },
            modifier = Modifier.size(24.dp),
          ) {
            Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = Slate400, modifier = Modifier.size(16.dp))
          }
        }
      }
    }

    // 5. MATCH LIST
    if (filteredMatches.isEmpty()) {
      EmptyMatchesView(selectedTab = selectedTab)
    } else {
      LazyColumn(
        modifier = Modifier
          .fillMaxSize()
          .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp),
      ) {
        items(filteredMatches, key = { it.matchId }) { match ->
          MatchCardItem(
            match = match,
            onJoinClick = { matchToJoin = match },
            onViewCodeClick = { matchForCodeView = match },
            onSubmitProofClick = { matchForProofSubmission = match },
            isJoinedTab = selectedTab == MatchFilterTab.MY_JOINED,
          )
        }
      }
    }
  }

  // DIALOG 1: JOIN MATCH MODAL
  matchToJoin?.let { match ->
    JoinMatchDialog(
      match = match,
      walletBalance = wallet?.balance ?: 0.0,
      onDismiss = { matchToJoin = null },
      onConfirmJoin = {
        matchToJoin = null
        toastMessage = "Joined ${match.matchNumber}! Room code will appear once Super Admin creates the room."
        selectedTab = MatchFilterTab.MY_JOINED
      },
    )
  }

  // DIALOG 2: ROOM CODE VIEW MODAL
  matchForCodeView?.let { match ->
    RoomCodeDetailDialog(
      match = match,
      onDismiss = { matchForCodeView = null },
      onCopyCode = { code ->
        clipboardManager.setText(AnnotatedString(code))
        toastMessage = "Room code $code copied! Open ${match.gameType} and enter code."
      },
      onSubmitProof = {
        matchForCodeView = null
        matchForProofSubmission = match
      },
    )
  }

  // DIALOG 3: SUBMIT WINNER RESULT PROOF
  matchForProofSubmission?.let { match ->
    SubmitResultProofDialog(
      match = match,
      onDismiss = { matchForProofSubmission = null },
      onSubmitSuccess = {
        matchForProofSubmission = null
        toastMessage = "Victory proof submitted for ${match.matchNumber}! Super Admin will verify and credit prize."
      },
    )
  }
}

// ==========================================
// SUB-COMPONENTS
// ==========================================

@Composable
private fun HomeTopHeader(
  wallet: WalletEntity?,
  onWalletClick: () -> Unit,
  onNotificationClick: () -> Unit,
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 12.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween,
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Box(
        modifier = Modifier
          .size(38.dp)
          .clip(CircleShape)
          .background(Brush.linearGradient(listOf(Indigo600, Purple600))),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Default.SportsEsports,
          contentDescription = "AD Tournament",
          tint = Gold400,
          modifier = Modifier.size(22.dp),
        )
      }
      Spacer(modifier = Modifier.width(10.dp))
      Column {
        Text(
          text = "AD TOURNAMENT",
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.Black,
            letterSpacing = 1.sp,
          ),
          color = Color.White,
        )
        Text(
          text = "1v1 Esports Battles",
          style = MaterialTheme.typography.labelSmall,
          color = Gold400,
        )
      }
    }

    Row(verticalAlignment = Alignment.CenterVertically) {
      // Wallet quick pill
      Surface(
        color = Slate900,
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, CardBorder),
        modifier = Modifier
          .clickable { onWalletClick() }
          .testTag("home_header_wallet_pill"),
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = Gold400, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "₹${"%.0f".format(wallet?.balance ?: 0.0)}",
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
            color = Color.White,
          )
        }
      }

      Spacer(modifier = Modifier.width(8.dp))

      // Notification Icon
      IconButton(
        onClick = onNotificationClick,
        modifier = Modifier.testTag("home_notification_button"),
      ) {
        BadgedBox(
          badge = {
            Badge(containerColor = Rose600) {
              Text("2", color = Color.White, fontSize = 10.sp)
            }
          }
        ) {
          Icon(
            imageVector = Icons.Default.Notifications,
            contentDescription = "Notifications",
            tint = Slate300,
            modifier = Modifier.size(24.dp),
          )
        }
      }
    }
  }
}

@Composable
private fun QuickWalletCard(
  wallet: WalletEntity?,
  onDepositClick: () -> Unit,
) {
  Box(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 4.dp)
      .clip(RoundedCornerShape(16.dp))
      .background(
        Brush.horizontalGradient(
          listOf(Color(0xFF1E1B4B), Color(0xFF0F172A))
        )
      )
      .testTag("home_wallet_quick_card"),
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Column {
        Text(
          text = "PLAYABLE BALANCE",
          style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.sp),
          color = Slate400,
        )
        Row(
          verticalAlignment = Alignment.Bottom,
          modifier = Modifier.padding(top = 4.dp),
        ) {
          Text(
            text = "₹${"%.2f".format(wallet?.balance ?: 0.0)}",
            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black),
            color = Gold400,
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "Winning: ₹${"%.0f".format(wallet?.winningBalance ?: 0.0)}",
            style = MaterialTheme.typography.bodySmall,
            color = Emerald500,
          )
        }
      }

      TournamentButton(
        text = "+ DEPOSIT",
        onClick = onDepositClick,
        modifier = Modifier.height(38.dp),
        testTag = "home_deposit_quick_button",
      )
    }
  }
}

@Composable
private fun GameFilterSelector(
  selectedFilter: String,
  onFilterSelect: (String) -> Unit,
) {
  LazyRow(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 8.dp),
    horizontalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    val filters = listOf(
      "ALL" to "All Contests",
      "LUDO" to "Ludo 1v1",
      "CARROM" to "Carrom 1v1",
    )

    items(filters) { (key, label) ->
      val isSelected = selectedFilter.equals(key, ignoreCase = true)
      Surface(
        shape = RoundedCornerShape(20.dp),
        color = if (isSelected) Gold500 else Slate900,
        border = BorderStroke(1.dp, if (isSelected) Gold400 else Slate800),
        modifier = Modifier
          .clickable { onFilterSelect(key) }
          .testTag("filter_chip_$key"),
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          if (key == "LUDO") {
            Icon(
              imageVector = Icons.Default.Casino,
              contentDescription = null,
              tint = if (isSelected) Slate950 else Gold400,
              modifier = Modifier.size(16.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
          } else if (key == "CARROM") {
            Icon(
              imageVector = Icons.Default.Album,
              contentDescription = null,
              tint = if (isSelected) Slate950 else Cyan400,
              modifier = Modifier.size(16.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
          }
          Text(
            text = label,
            style = MaterialTheme.typography.labelMedium.copy(
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
            ),
            color = if (isSelected) Slate950 else Color.White,
          )
        }
      }
    }
  }
}

@Composable
private fun MatchSectionTabs(
  selectedTab: MatchFilterTab,
  onTabSelect: (MatchFilterTab) -> Unit,
  joinedCount: Int,
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 6.dp),
    horizontalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    val tabs = listOf(
      MatchFilterTab.AVAILABLE to "Available",
      MatchFilterTab.MY_JOINED to "My Joined",
      MatchFilterTab.UPCOMING to "Upcoming",
    )

    tabs.forEach { (tab, title) ->
      val isSelected = selectedTab == tab
      Surface(
        shape = RoundedCornerShape(10.dp),
        color = if (isSelected) NavySurface else Color.Transparent,
        border = BorderStroke(1.dp, if (isSelected) Indigo600 else Color.Transparent),
        modifier = Modifier
          .weight(1f)
          .clickable { onTabSelect(tab) }
          .testTag("tab_${tab.name.lowercase()}"),
      ) {
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier.padding(vertical = 10.dp),
        ) {
          Text(
            text = title,
            style = MaterialTheme.typography.labelMedium.copy(
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
            ),
            color = if (isSelected) Cyan400 else Slate400,
          )
        }
      }
    }
  }
}

@Composable
private fun MatchCardItem(
  match: MatchEntity,
  onJoinClick: () -> Unit,
  onViewCodeClick: () -> Unit,
  onSubmitProofClick: () -> Unit,
  isJoinedTab: Boolean,
) {
  val isLudo = match.gameType.equals("LUDO", ignoreCase = true)

  TournamentCard(
    modifier = Modifier.fillMaxWidth(),
    backgroundColor = NavyCard,
    borderColor = if (match.status == MatchStatus.RUNNING.name) Indigo600 else NavyCardBorder,
  ) {
    // Header Row: Match # + Game Badge + Slots
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Surface(
          color = if (isLudo) Indigo600.copy(alpha = 0.2f) else Cyan600.copy(alpha = 0.2f),
          shape = RoundedCornerShape(6.dp),
          border = BorderStroke(1.dp, if (isLudo) Indigo600 else Cyan400),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Icon(
              imageVector = if (isLudo) Icons.Default.Casino else Icons.Default.Album,
              contentDescription = null,
              tint = if (isLudo) Gold400 else Cyan400,
              modifier = Modifier.size(14.dp),
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = match.gameType.uppercase(),
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
              color = Color.White,
            )
          }
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = match.matchNumber,
          style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
          color = Slate300,
        )
      }

      // Slot indicator: 1 / 2, 2 / 2, FULL, RUNNING
      SlotStatusBadge(match = match)
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Match Title
    Text(
      text = match.title,
      style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
      color = Color.White,
    )

    Spacer(modifier = Modifier.height(12.dp))

    // Financial breakdown: Entry Fee & Prize Pool
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(10.dp))
        .background(Slate900)
        .padding(horizontal = 14.dp, vertical = 10.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Column {
        Text(text = "ENTRY FEE", style = MaterialTheme.typography.labelSmall, color = Slate400)
        Text(
          text = "₹${"%.0f".format(match.entryFee)}",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          color = Color.White,
        )
      }

      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = "FORMAT", style = MaterialTheme.typography.labelSmall, color = Slate400)
        Text(
          text = "1v1 Battle",
          style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
          color = Cyan400,
        )
      }

      Column(horizontalAlignment = Alignment.End) {
        Text(text = "PRIZE POOL", style = MaterialTheme.typography.labelSmall, color = Slate400)
        Text(
          text = "₹${"%.0f".format(match.prizePool)}",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
          color = Gold400,
        )
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    // Card Footer Actions
    if (isJoinedTab || match.isCodeVisible) {
      // User is participating in this match
      Column(modifier = Modifier.fillMaxWidth()) {
        if (match.gameCode.isNotBlank()) {
          // Code revealed!
          Surface(
            color = Indigo900.copy(alpha = 0.4f),
            shape = RoundedCornerShape(8.dp),
            border = BorderStroke(1.dp, Indigo600),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Row(
              modifier = Modifier.padding(10.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Column {
                Text(text = "GAME ROOM CODE", style = MaterialTheme.typography.labelSmall, color = Gold400)
                Text(
                  text = match.gameCode,
                  style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black, letterSpacing = 2.sp),
                  color = Color.White,
                )
              }
              TournamentButton(
                text = "VIEW & PLAY",
                onClick = onViewCodeClick,
                modifier = Modifier.height(36.dp),
                testTag = "view_code_${match.matchId}",
              )
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          TournamentButton(
            text = "SUBMIT VICTORY PROOF",
            onClick = onSubmitProofClick,
            variant = TournamentButtonVariant.OUTLINED,
            modifier = Modifier.fillMaxWidth(),
            testTag = "submit_proof_${match.matchId}",
          )
        } else {
          // Waiting for Super Admin
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(8.dp))
              .background(Slate850)
              .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Gold400, strokeWidth = 2.dp)
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = "Super Admin is creating the room code...",
              style = MaterialTheme.typography.bodySmall,
              color = Slate400,
            )
          }
        }
      }
    } else {
      // Normal Available Match Card
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        val timeFormatted = remember(match.scheduledTime) {
          SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(match.scheduledTime))
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.Schedule, contentDescription = null, tint = Slate400, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(text = "Starts at $timeFormatted", style = MaterialTheme.typography.bodySmall, color = Slate400)
        }

        val isFull = match.joinedPlayersCount >= match.maxPlayers
        TournamentButton(
          text = if (isFull) "MATCH FULL" else "JOIN NOW",
          onClick = onJoinClick,
          enabled = !isFull,
          modifier = Modifier.height(40.dp),
          testTag = "join_button_${match.matchId}",
        )
      }
    }
  }
}

@Composable
private fun SlotStatusBadge(match: MatchEntity) {
  val isFull = match.joinedPlayersCount >= match.maxPlayers
  val isRunning = match.status == MatchStatus.RUNNING.name

  val (bgColor, textColor, label) = when {
    isRunning -> Triple(Indigo600.copy(alpha = 0.2f), Indigo400, "RUNNING")
    isFull -> Triple(Rose600.copy(alpha = 0.2f), Rose500, "FULL (2/2)")
    else -> Triple(Emerald600.copy(alpha = 0.2f), Emerald500, "${match.joinedPlayersCount}/${match.maxPlayers} SLOTS")
  }

  Surface(
    color = bgColor,
    shape = RoundedCornerShape(12.dp),
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
      color = textColor,
      modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
    )
  }
}

@Composable
private fun EmptyMatchesView(selectedTab: MatchFilterTab) {
  Box(
    modifier = Modifier
      .fillMaxSize()
      .padding(32.dp),
    contentAlignment = Alignment.Center,
  ) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
      Icon(
        imageVector = Icons.Default.SportsEsports,
        contentDescription = null,
        tint = Slate600,
        modifier = Modifier.size(54.dp),
      )
      Spacer(modifier = Modifier.height(14.dp))
      Text(
        text = when (selectedTab) {
          MatchFilterTab.AVAILABLE -> "No matches currently available"
          MatchFilterTab.MY_JOINED -> "You haven't joined any active matches yet"
          MatchFilterTab.UPCOMING -> "No upcoming matches scheduled right now"
        },
        style = MaterialTheme.typography.titleMedium,
        color = Slate400,
        textAlign = TextAlign.Center,
      )
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = "New 1v1 Ludo and Carrom rooms are added regularly by the Super Admin.",
        style = MaterialTheme.typography.bodySmall,
        color = Slate500,
        textAlign = TextAlign.Center,
      )
    }
  }
}

// ==========================================
// MODAL DIALOGS
// ==========================================

@Composable
fun JoinMatchDialog(
  match: MatchEntity,
  walletBalance: Double,
  onDismiss: () -> Unit,
  onConfirmJoin: () -> Unit,
) {
  val hasSufficientBalance = walletBalance >= match.entryFee

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.SportsEsports, contentDescription = null, tint = Gold400)
        Spacer(modifier = Modifier.width(8.dp))
        Text("Join 1v1 Match", color = Color.White)
      }
    },
    text = {
      Column {
        Text(
          text = match.title,
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          color = Color.White,
        )
        Spacer(modifier = Modifier.height(12.dp))

        // Match Fee vs Balance Row
        Surface(
          color = Slate900,
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Text("Entry Fee:", color = Slate400)
              Text("₹${"%.2f".format(match.entryFee)}", color = Color.White, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Text("Your Playable Balance:", color = Slate400)
              Text("₹${"%.2f".format(walletBalance)}", color = if (hasSufficientBalance) Emerald500 else Rose500, fontWeight = FontWeight.Bold)
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (!hasSufficientBalance) {
          Text(
            text = "Insufficient balance. Please deposit funds in your wallet to join.",
            style = MaterialTheme.typography.bodySmall,
            color = Rose500,
          )
        } else {
          Text(
            text = "By joining, entry fee ₹${"%.0f".format(match.entryFee)} will be held in escrow for match prize.",
            style = MaterialTheme.typography.bodySmall,
            color = Slate400,
          )
        }
      }
    },
    confirmButton = {
      TournamentButton(
        text = if (hasSufficientBalance) "CONFIRM & JOIN" else "INSUFFICIENT BALANCE",
        onClick = onConfirmJoin,
        enabled = hasSufficientBalance,
        testTag = "confirm_join_match_button",
      )
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel", color = Slate400)
      }
    },
    containerColor = NavyCard,
  )
}

@Composable
fun RoomCodeDetailDialog(
  match: MatchEntity,
  onDismiss: () -> Unit,
  onCopyCode: (String) -> Unit,
  onSubmitProof: () -> Unit,
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text("Match Room Details", color = Color.White)
    },
    text = {
      Column {
        Text(
          text = "${match.gameType} 1v1 • ${match.matchNumber}",
          style = MaterialTheme.typography.labelMedium,
          color = Gold400,
        )
        Spacer(modifier = Modifier.height(12.dp))

        // Room code box
        Surface(
          color = Indigo900.copy(alpha = 0.5f),
          shape = RoundedCornerShape(12.dp),
          border = BorderStroke(1.5.dp, Indigo500),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
          ) {
            Text(text = "OFFICIAL GAME CODE", style = MaterialTheme.typography.labelSmall, color = Slate400)
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = match.gameCode,
              style = MaterialTheme.typography.headlineMedium.copy(
                fontWeight = FontWeight.Black,
                letterSpacing = 3.sp,
              ),
              color = Gold400,
            )
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedButton(
              onClick = { onCopyCode(match.gameCode) },
              colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan400),
            ) {
              Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("Copy Code")
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text(
          text = "Instructions:\n1. Copy the code above\n2. Open original ${match.gameType} app\n3. Select 'Play With Friends' & paste code\n4. Winner takes a victory screenshot and submits proof",
          style = MaterialTheme.typography.bodySmall,
          color = Slate300,
        )
      }
    },
    confirmButton = {
      TournamentButton(
        text = "SUBMIT WINNER PROOF",
        onClick = onSubmitProof,
        testTag = "dialog_submit_proof_button",
      )
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Close", color = Slate400)
      }
    },
    containerColor = NavyCard,
  )
}

@Composable
fun SubmitResultProofDialog(
  match: MatchEntity,
  onDismiss: () -> Unit,
  onSubmitSuccess: () -> Unit,
) {
  var isUploading by remember { mutableStateOf(false) }
  var hasProofAttached by remember { mutableStateOf(false) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text("Submit Match Result", color = Color.White)
    },
    text = {
      Column {
        Text(
          text = "Upload victory screenshot for ${match.matchNumber}",
          style = MaterialTheme.typography.bodyMedium,
          color = Slate400,
        )
        Spacer(modifier = Modifier.height(14.dp))

        Surface(
          color = Slate900,
          shape = RoundedCornerShape(10.dp),
          border = BorderStroke(1.dp, if (hasProofAttached) Emerald500 else CardBorder),
          modifier = Modifier
            .fillMaxWidth()
            .clickable {
              hasProofAttached = true
            },
        ) {
          Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
          ) {
            Icon(
              imageVector = if (hasProofAttached) Icons.Default.CheckCircle else Icons.Default.AddPhotoAlternate,
              contentDescription = null,
              tint = if (hasProofAttached) Emerald500 else Cyan400,
              modifier = Modifier.size(36.dp),
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = if (hasProofAttached) "Victory Screenshot Attached (game_victory.png)" else "Tap to Select Victory Screenshot",
              style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
              color = if (hasProofAttached) Emerald500 else Color.White,
              textAlign = TextAlign.Center,
            )
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
          text = "Note: False submissions or manipulated screenshots will result in account suspension. Super Admin reviews all submissions.",
          style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
          color = Rose400,
        )
      }
    },
    confirmButton = {
      TournamentButton(
        text = "SUBMIT FOR REVIEW",
        onClick = {
          onSubmitSuccess()
        },
        enabled = hasProofAttached && !isUploading,
        isLoading = isUploading,
        testTag = "submit_proof_confirm_button",
      )
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel", color = Slate400)
      }
    },
    containerColor = NavyCard,
  )
}
