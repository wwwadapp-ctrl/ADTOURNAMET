package com.example.ui.navigation

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.core.di.AppContainer
import com.example.core.network.NetworkStatus
import com.example.ui.components.NetworkStatusBar
import com.example.ui.screens.auth.*
import com.example.ui.screens.history.HistoryScreen
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.notifications.NotificationsScreen
import com.example.ui.screens.profile.ProfileScreen
import com.example.ui.screens.support.SupportScreen
import com.example.ui.screens.wallet.WalletScreen
import com.example.ui.theme.*

@Composable
fun AdTournamentApp(
  networkStatus: NetworkStatus,
  appContainer: AppContainer,
  navController: NavHostController = rememberNavController(),
) {
  val navBackStackEntry by navController.currentBackStackEntryAsState()
  val currentRoute = navBackStackEntry?.destination?.route ?: Screen.Splash.route

  // Bottom navigation visibility: visible only on main application destinations
  val authRoutes = setOf(
    Screen.Splash.route,
    Screen.Login.route,
    Screen.Register.route,
    Screen.ForgotPassword.route,
  )
  val isBottomBarVisible = currentRoute !in authRoutes

  // Current logged in user ID
  val currentUser by appContainer.authRepository.getCurrentUser().collectAsState(initial = null)
  val currentUserId = currentUser?.userId ?: "AD-USER-9481"

  Scaffold(
    modifier = Modifier
      .fillMaxSize()
      .testTag("ad_tournament_scaffold"),
    containerColor = DeepNavyBg,
    topBar = {
      // Network status indicator displayed globally when connectivity changes
      NetworkStatusBar(networkStatus = networkStatus)
    },
    bottomBar = {
      if (isBottomBarVisible) {
        TournamentBottomNavigationBar(
          currentRoute = currentRoute,
          onNavigate = { screen ->
            navController.navigate(screen.route) {
              popUpTo(Screen.Home.route) {
                saveState = true
              }
              launchSingleTop = true
              restoreState = true
            }
          },
        )
      }
    },
  ) { innerPadding ->
    NavHost(
      navController = navController,
      startDestination = Screen.Splash.route,
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding),
    ) {
      // 1. SPLASH SCREEN
      composable(Screen.Splash.route) {
        SplashScreen(
          onNavigateToHome = {
            navController.navigate(Screen.Home.route) {
              popUpTo(Screen.Splash.route) { inclusive = true }
            }
          },
          onNavigateToLogin = {
            navController.navigate(Screen.Login.route) {
              popUpTo(Screen.Splash.route) { inclusive = true }
            }
          },
          authRepository = appContainer.authRepository,
        )
      }

      // 2. LOGIN SCREEN
      composable(Screen.Login.route) {
        LoginScreen(
          onLoginSuccess = {
            navController.navigate(Screen.Home.route) {
              popUpTo(Screen.Login.route) { inclusive = true }
            }
          },
          onNavigateToRegister = {
            navController.navigate(Screen.Register.route)
          },
          onNavigateToForgotPassword = {
            navController.navigate(Screen.ForgotPassword.route)
          },
          authRepository = appContainer.authRepository,
        )
      }

      // 3. REGISTRATION SCREEN
      composable(Screen.Register.route) {
        RegistrationScreen(
          onRegisterSuccess = {
            navController.navigate(Screen.Home.route) {
              popUpTo(Screen.Register.route) { inclusive = true }
            }
          },
          onNavigateToLogin = {
            navController.popBackStack()
          },
          authRepository = appContainer.authRepository,
        )
      }

      // 4. FORGOT PASSWORD SCREEN
      composable(Screen.ForgotPassword.route) {
        ForgotPasswordScreen(
          onResetSuccess = {
            navController.navigate(Screen.Login.route) {
              popUpTo(Screen.ForgotPassword.route) { inclusive = true }
            }
          },
          onNavigateToLogin = {
            navController.popBackStack()
          },
          authRepository = appContainer.authRepository,
        )
      }

      // 5. HOME SCREEN (CENTRAL DESTINATION)
      composable(Screen.Home.route) {
        HomeScreen(
          userId = currentUserId,
          onNavigateToWallet = {
            navController.navigate(Screen.Wallet.route) {
              popUpTo(Screen.Home.route) { saveState = true }
              launchSingleTop = true
            }
          },
          onNavigateToNotifications = {
            navController.navigate(Screen.Notifications.route)
          },
          onNavigateToHistory = {
            navController.navigate(Screen.History.route) {
              popUpTo(Screen.Home.route) { saveState = true }
              launchSingleTop = true
            }
          },
          matchRepository = appContainer.matchRepository,
          walletRepository = appContainer.walletRepository,
        )
      }

      // 6. WALLET SCREEN
      composable(Screen.Wallet.route) {
        WalletScreen(
          userId = currentUserId,
          walletRepository = appContainer.walletRepository,
        )
      }

      // 7. HISTORY SCREEN
      composable(Screen.History.route) {
        HistoryScreen(
          userId = currentUserId,
          matchRepository = appContainer.matchRepository,
        )
      }

      // 8. PROFILE SCREEN
      composable(Screen.Profile.route) {
        ProfileScreen(
          onSignOut = {
            navController.navigate(Screen.Login.route) {
              popUpTo(0) { inclusive = true }
            }
          },
          authRepository = appContainer.authRepository,
        )
      }

      // 9. SUPPORT SCREEN
      composable(Screen.Support.route) {
        SupportScreen()
      }

      // 10. NOTIFICATIONS SCREEN
      composable(Screen.Notifications.route) {
        NotificationsScreen(
          userId = currentUserId,
          onNavigateBack = { navController.popBackStack() },
          notificationRepository = appContainer.notificationRepository,
        )
      }
    }
  }
}

/**
 * 5-item Primary User Bottom Navigation:
 * Support -> Wallet -> Home (Central Hero) -> History -> Profile
 */
@Composable
private fun TournamentBottomNavigationBar(
  currentRoute: String,
  onNavigate: (Screen) -> Unit,
) {
  Surface(
    color = NavySurface,
    border = BorderStroke(1.dp, NavyCardBorder),
    modifier = Modifier
      .fillMaxWidth()
      .testTag("tournament_bottom_nav"),
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .navigationBarsPadding()
        .padding(vertical = 6.dp),
      horizontalArrangement = Arrangement.SpaceAround,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Screen.primaryNavigation.forEach { screen ->
        val isSelected = currentRoute == screen.route
        val isHome = screen == Screen.Home

        if (isHome) {
          // Central elevated Home button
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
              .clickable { onNavigate(screen) }
              .testTag("bottom_nav_home"),
          ) {
            Box(
              modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(
                  if (isSelected) {
                    Brush.linearGradient(listOf(Gold500, Amber600))
                  } else {
                    Brush.linearGradient(listOf(Indigo600, Purple600))
                  }
                ),
              contentAlignment = Alignment.Center,
            ) {
              Icon(
                imageVector = Icons.Default.Home,
                contentDescription = screen.title,
                tint = if (isSelected) Slate950 else Color.White,
                modifier = Modifier.size(24.dp),
              )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
              text = "Home",
              style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                fontSize = 11.sp,
              ),
              color = if (isSelected) Gold400 else Slate400,
            )
          }
        } else {
          // Standard tab
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
              .clickable { onNavigate(screen) }
              .padding(horizontal = 12.dp, vertical = 4.dp)
              .testTag("bottom_nav_${screen.route}"),
          ) {
            Icon(
              imageVector = screen.icon,
              contentDescription = screen.title,
              tint = if (isSelected) Gold400 else Slate400,
              modifier = Modifier.size(22.dp),
            )
            Spacer(modifier = Modifier.height(3.dp))
            Text(
              text = screen.title,
              style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                fontSize = 10.sp,
              ),
              color = if (isSelected) Gold400 else Slate400,
            )
          }
        }
      }
    }
  }
}
