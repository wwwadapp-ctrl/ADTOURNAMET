package com.example.ui.screens.showcase

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.config.AppEnvironment
import com.example.core.config.FirebaseConfig
import com.example.core.network.NetworkStatus
import com.example.ui.components.*
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ComponentShowcaseScreen(networkStatus: NetworkStatus) {
  var sampleInput by remember { mutableStateOf("") }
  var sampleErrorInput by remember { mutableStateOf("invalid-data") }
  var isButtonLoading by remember { mutableStateOf(false) }
  var showSampleDialog by remember { mutableStateOf(false) }
  var selectedTab by remember { mutableIntStateOf(0) }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    contentPadding = PaddingValues(vertical = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    item {
      TournamentCard(
        backgroundColor = Slate900,
        borderColor = Gold500.copy(alpha = 0.5f),
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.fillMaxWidth(),
        ) {
          Icon(Icons.Default.Build, contentDescription = null, tint = Gold500, modifier = Modifier.size(28.dp))
          Spacer(modifier = Modifier.width(10.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "Phase 1 Foundation Diagnostics",
              style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
              color = Slate50,
            )
            Text(
              text = "Environment: ${AppEnvironment.current.environmentName} | Network: $networkStatus",
              style = MaterialTheme.typography.labelSmall,
              color = Cyan400,
            )
          }
        }
      }
    }

    item {
      PrimaryTabRow(
        selectedTabIndex = selectedTab,
        containerColor = Slate900,
        contentColor = Gold500,
      ) {
        Tab(
          selected = selectedTab == 0,
          onClick = { selectedTab = 0 },
          text = { Text("UI Components", color = if (selectedTab == 0) Gold500 else Slate400) },
        )
        Tab(
          selected = selectedTab == 1,
          onClick = { selectedTab = 1 },
          text = { Text("App States", color = if (selectedTab == 1) Gold500 else Slate400) },
        )
        Tab(
          selected = selectedTab == 2,
          onClick = { selectedTab = 2 },
          text = { Text("12 DB Nodes", color = if (selectedTab == 2) Gold500 else Slate400) },
        )
      }
    }

    when (selectedTab) {
      0 -> {
        // UI COMPONENTS
        item {
          SectionHeader(title = "Reusable Buttons", subtitle = "Variants, states & minimum 48dp touch targets")
          TournamentCard(backgroundColor = Slate850) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
              TournamentButton(
                text = "Primary Action (Tap to toggle loading)",
                onClick = { isButtonLoading = !isButtonLoading },
                isLoading = isButtonLoading,
                modifier = Modifier.fillMaxWidth(),
                testTag = "showcase_primary_btn",
              )

              TournamentButton(
                text = "Secondary Action",
                onClick = {},
                variant = TournamentButtonVariant.SECONDARY,
                modifier = Modifier.fillMaxWidth(),
                testTag = "showcase_secondary_btn",
              )

              TournamentButton(
                text = "Outlined Action",
                onClick = {},
                variant = TournamentButtonVariant.OUTLINED,
                modifier = Modifier.fillMaxWidth(),
                testTag = "showcase_outlined_btn",
              )

              TournamentButton(
                text = "Danger / Reject Action",
                onClick = {},
                variant = TournamentButtonVariant.DANGER,
                modifier = Modifier.fillMaxWidth(),
                testTag = "showcase_danger_btn",
              )

              TournamentButton(
                text = "Disabled State",
                onClick = {},
                enabled = false,
                modifier = Modifier.fillMaxWidth(),
                testTag = "showcase_disabled_btn",
              )

              TournamentButton(
                text = "Launch Test Dialog",
                onClick = { showSampleDialog = true },
                variant = TournamentButtonVariant.OUTLINED,
                modifier = Modifier.fillMaxWidth(),
                testTag = "showcase_dialog_btn",
              )
            }
          }
        }

        item {
          SectionHeader(title = "Input Fields", subtitle = "Standardized tournament text inputs")
          TournamentCard(backgroundColor = Slate850) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
              TournamentTextField(
                value = sampleInput,
                onValueChange = { sampleInput = it },
                label = "Tournament Room Code",
                placeholder = "e.g. LUDO-8921",
                helperText = "Paste the match room code from the original game",
                testTag = "showcase_input_normal",
              )

              TournamentTextField(
                value = sampleErrorInput,
                onValueChange = { sampleErrorInput = it },
                label = "Validated Input with Error State",
                errorMessage = "Invalid format: game code must be alphanumeric",
                testTag = "showcase_input_error",
              )
            }
          }
        }

        item {
          SectionHeader(title = "Status Badges", subtitle = "Match and transaction state indicators")
          TournamentCard(backgroundColor = Slate850) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              StatusBadge(statusText = "LIVE")
              StatusBadge(statusText = "UPCOMING")
              StatusBadge(statusText = "APPROVED")
              StatusBadge(statusText = "REJECTED")
            }
          }
        }
      }

      1 -> {
        // APP STATES
        item {
          SectionHeader(title = "Loading State Foundation")
          TournamentCard(backgroundColor = Slate850) {
            LoadingState(message = "Synchronizing tournament bracket...")
          }
        }

        item {
          SectionHeader(title = "Error State Foundation", subtitle = "Sanitized, user-friendly error UI")
          TournamentCard(backgroundColor = Slate850) {
            ErrorState(
              title = "Connection Interrupted",
              message = "Unable to connect to tournament coordination services. No stack traces or private keys are exposed.",
              onRetry = {},
            )
          }
        }

        item {
          SectionHeader(title = "Empty State Foundation")
          TournamentCard(backgroundColor = Slate850) {
            EmptyState(
              title = "No Upcoming Matches",
              description = "There are currently no active Ludo or Carrom challenges matching your search criteria.",
              actionButtonText = "Refresh Lobby",
              onActionClick = {},
            )
          }
        }
      }

      2 -> {
        // 12 APPROVED DATABASE NODES
        item {
          SectionHeader(
            title = "12 Approved Realtime DB Nodes",
            subtitle = "Architecture schema validation & security policy",
          )
        }

        val approvedNodes = listOf(
          Pair(FirebaseConfig.NODE_USERS, "Player accounts, profiles, registration data"),
          Pair(FirebaseConfig.NODE_WALLETS, "SECURITY: Read-only on client. No client-side balance mutations!"),
          Pair(FirebaseConfig.NODE_TRANSACTIONS, "Immutable financial audit logs (deposits, entries, prizes)"),
          Pair(FirebaseConfig.NODE_MATCHES, "Ludo/Carrom 1v1 match records & Game Codes"),
          Pair(FirebaseConfig.NODE_MATCH_PLAYERS, "Player slots (Slot 1, Slot 2) for joined matches"),
          Pair(FirebaseConfig.NODE_RESULTS, "Winner result proofs, screenshot URLs, approval status"),
          Pair(FirebaseConfig.NODE_DEPOSITS, "Deposit requests and payment screenshot slips"),
          Pair(FirebaseConfig.NODE_WITHDRAWALS, "Player payout requests for admin processing"),
          Pair(FirebaseConfig.NODE_NOTIFICATIONS, "In-app and FCM push notifications"),
          Pair(FirebaseConfig.NODE_ADMIN_USERS, "Super Admin & Moderator role definitions"),
          Pair(FirebaseConfig.NODE_AUDIT_LOGS, "System-wide administrative action logs"),
          Pair(FirebaseConfig.NODE_APP_SETTINGS, "Global thresholds, commission %, maintenance mode"),
        )

        items(approvedNodes.size) { index ->
          val (node, description) = approvedNodes[index]
          val isWallet = node == FirebaseConfig.NODE_WALLETS
          val isSensitive = isWallet || node == FirebaseConfig.NODE_ADMIN_USERS

          TournamentCard(
            backgroundColor = if (isSensitive) Slate850 else Slate900,
            borderColor = if (isSensitive) Gold500.copy(alpha = 0.5f) else CardBorder,
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(
                text = "${index + 1}. /$node",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = if (isSensitive) Gold400 else Cyan400,
              )
              StatusBadge(
                statusText = if (isWallet) "STRICT READ-ONLY" else "APPROVED",
                badgeColor = if (isWallet) Rose500 else Emerald500,
              )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = description,
              style = MaterialTheme.typography.bodyMedium,
              color = Slate400,
            )
          }
        }
      }
    }
  }

  if (showSampleDialog) {
    TournamentDialog(
      title = "Verification Confirmation",
      message = "This is a demonstration of the TournamentDialog component with customizable confirm and dismiss callbacks.",
      onDismiss = { showSampleDialog = false },
      onConfirm = { showSampleDialog = false },
    )
  }
}
