package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(
  val route: String,
  val title: String,
  val icon: ImageVector,
) {
  // AUTHENTICATION & ONBOARDING FLOW
  data object Splash : Screen("splash", "Splash", Icons.Default.SportsEsports)
  data object Login : Screen("login", "Login", Icons.Default.Login)
  data object Register : Screen("register", "Register", Icons.Default.PersonAdd)
  data object ForgotPassword : Screen("forgot_password", "Forgot Password", Icons.Default.LockReset)

  // 5 PRIMARY USER DESTINATIONS (Home is central / default)
  data object Support : Screen("support", "Support", Icons.Default.HeadsetMic)
  data object Wallet : Screen("wallet", "Wallet", Icons.Default.AccountBalanceWallet)
  data object Home : Screen("home", "Home", Icons.Default.Home)
  data object History : Screen("history", "History", Icons.AutoMirrored.Filled.List)
  data object Profile : Screen("profile", "Profile", Icons.Default.Person)

  // SECONDARY USER DESTINATIONS
  data object Notifications : Screen("notifications", "Notifications", Icons.Default.Notifications)

  companion object {
    /**
     * 5 primary bottom navigation items ordered as:
     * Support -> Wallet -> Home (central) -> History -> Profile
     */
    val primaryNavigation: List<Screen>
      get() = listOf(
        Support,
        Wallet,
        Home,
        History,
        Profile,
      )
  }
}

