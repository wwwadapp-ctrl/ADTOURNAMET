package com.example.ui.screens.auth

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.error.Resource
import com.example.core.security.PasswordSecurity
import com.example.domain.repository.AuthRepository
import com.example.ui.components.TournamentButton
import com.example.ui.components.TournamentButtonVariant
import com.example.ui.components.TournamentCard
import com.example.ui.components.TournamentTextField
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// ==========================================
// 1. SPLASH SCREEN
// ==========================================
@Composable
fun SplashScreen(
  onNavigateToHome: () -> Unit,
  onNavigateToLogin: () -> Unit,
  authRepository: AuthRepository,
  modifier: Modifier = Modifier,
) {
  val scope = rememberCoroutineScope()

  LaunchedEffect(Unit) {
    // Elegant splash timer ensuring initialization readiness
    delay(1200)
    if (authRepository.isUserSignedIn()) {
      onNavigateToHome()
    } else {
      onNavigateToLogin()
    }
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(
        Brush.verticalGradient(
          colors = listOf(
            DeepNavyBg,
            Color(0xFF0F172A),
            Color(0xFF1E1B4B),
          )
        )
      )
      .testTag("splash_screen"),
    contentAlignment = Alignment.Center,
  ) {
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
      modifier = Modifier.padding(24.dp),
    ) {
      // Gaming Trophy Emblem
      Box(
        modifier = Modifier
          .size(100.dp)
          .clip(CircleShape)
          .background(
            Brush.radialGradient(
              listOf(Indigo500, Purple600, Color.Transparent)
            )
          ),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Default.EmojiEvents,
          contentDescription = "Tournament Trophy",
          tint = Gold400,
          modifier = Modifier.size(54.dp),
        )
      }

      Spacer(modifier = Modifier.height(24.dp))

      Text(
        text = "AD TOURNAMENT",
        style = MaterialTheme.typography.headlineLarge.copy(
          fontWeight = FontWeight.Black,
          letterSpacing = 2.sp,
        ),
        color = Color.White,
        textAlign = TextAlign.Center,
      )

      Spacer(modifier = Modifier.height(8.dp))

      Text(
        text = "1v1 LUDO & CARROM COORDINATION",
        style = MaterialTheme.typography.labelMedium.copy(
          fontWeight = FontWeight.Bold,
          letterSpacing = 1.sp,
        ),
        color = Gold400,
        textAlign = TextAlign.Center,
      )

      Spacer(modifier = Modifier.height(48.dp))

      CircularProgressIndicator(
        modifier = Modifier.size(32.dp),
        color = Cyan400,
        strokeWidth = 2.5.dp,
      )

      Spacer(modifier = Modifier.height(16.dp))

      Text(
        text = "Initializing Platform Foundation...",
        style = MaterialTheme.typography.bodySmall,
        color = Slate400,
      )
    }
  }
}

// ==========================================
// 2. LOGIN SCREEN (Mobile Number + Password)
// ==========================================
@Composable
fun LoginScreen(
  onLoginSuccess: () -> Unit,
  onNavigateToRegister: () -> Unit,
  onNavigateToForgotPassword: () -> Unit,
  authRepository: AuthRepository,
  modifier: Modifier = Modifier,
) {
  var phoneNumber by remember { mutableStateOf("") }
  var password by remember { mutableStateOf("") }
  var isPasswordVisible by remember { mutableStateOf(false) }
  var isLoading by remember { mutableStateOf(false) }
  var errorMessage by remember { mutableStateOf<String?>(null) }
  val scope = rememberCoroutineScope()

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(
        Brush.verticalGradient(
          colors = listOf(DeepNavyBg, NavySurface, Color(0xFF131B2E))
        )
      )
      .testTag("login_screen"),
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 24.dp, vertical = 32.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Spacer(modifier = Modifier.height(24.dp))

      // App Logo Header
      Box(
        modifier = Modifier
          .size(72.dp)
          .clip(CircleShape)
          .background(
            Brush.linearGradient(listOf(Indigo600, Purple600))
          ),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Default.SportsEsports,
          contentDescription = "AD Tournament Logo",
          tint = Gold400,
          modifier = Modifier.size(38.dp),
        )
      }

      Spacer(modifier = Modifier.height(16.dp))

      Text(
        text = "Welcome to AD TOURNAMENT",
        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
        color = Color.White,
      )

      Text(
        text = "Sign in to play 1v1 Ludo & Carrom contests",
        style = MaterialTheme.typography.bodyMedium,
        color = Slate400,
        modifier = Modifier.padding(top = 4.dp),
      )

      Spacer(modifier = Modifier.height(32.dp))

      // Login Card
      TournamentCard(
        modifier = Modifier.fillMaxWidth(),
        backgroundColor = NavyCard,
        borderColor = NavyCardBorder,
      ) {
        Text(
          text = "PLAYER LOGIN",
          style = MaterialTheme.typography.labelLarge.copy(
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
          ),
          color = Gold400,
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Mobile Number input
        TournamentTextField(
          value = phoneNumber,
          onValueChange = { input ->
            if (input.length <= 10 && input.all { it.isDigit() }) {
              phoneNumber = input
              errorMessage = null
            }
          },
          label = "Mobile Number",
          placeholder = "10-digit number",
          leadingIcon = Icons.Default.Phone,
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
          testTag = "login_phone_input",
          modifier = Modifier.fillMaxWidth(),
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Password input
        TournamentTextField(
          value = password,
          onValueChange = {
            password = it
            errorMessage = null
          },
          label = "Password",
          placeholder = "Enter password",
          leadingIcon = Icons.Default.Lock,
          visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
          trailingIcon = {
            IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
              Icon(
                imageVector = if (isPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                contentDescription = if (isPasswordVisible) "Hide password" else "Show password",
                tint = Slate400,
              )
            }
          },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
          testTag = "login_password_input",
          modifier = Modifier.fillMaxWidth(),
        )

        // Forgot password link
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp),
          horizontalArrangement = Arrangement.End,
        ) {
          Text(
            text = "Forgot Password?",
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
            color = Cyan400,
            modifier = Modifier
              .clickable { onNavigateToForgotPassword() }
              .testTag("login_forgot_password_link")
              .padding(4.dp),
          )
        }

        // Error message banner
        AnimatedVisibility(visible = errorMessage != null) {
          Surface(
            color = Rose600.copy(alpha = 0.15f),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
              .fillMaxWidth()
              .padding(top = 12.dp),
          ) {
            Row(
              modifier = Modifier.padding(10.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(
                imageVector = Icons.Default.ErrorOutline,
                contentDescription = null,
                tint = Rose500,
                modifier = Modifier.size(18.dp),
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = errorMessage ?: "",
                style = MaterialTheme.typography.bodySmall,
                color = Rose500,
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Login CTA
        TournamentButton(
          text = "SIGN IN",
          onClick = {
            if (phoneNumber.length != 10) {
              errorMessage = "Please enter a valid 10-digit mobile number"
              return@TournamentButton
            }
            if (password.isBlank()) {
              errorMessage = "Please enter your password"
              return@TournamentButton
            }

            isLoading = true
            scope.launch {
              val passwordHash = PasswordSecurity.hashPassword(password)
              val result = authRepository.loginWithPhone(phoneNumber, passwordHash)
              isLoading = false
              when (result) {
                is Resource.Success -> {
                  onLoginSuccess()
                }
                is Resource.Error -> {
                  errorMessage = result.error.userMessage
                }
                else -> Unit
              }
            }
          },
          modifier = Modifier.fillMaxWidth(),
          isLoading = isLoading,
          testTag = "login_submit_button",
        )
      }

      Spacer(modifier = Modifier.height(24.dp))

      // Register link
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
      ) {
        Text(
          text = "New to AD TOURNAMENT? ",
          style = MaterialTheme.typography.bodyMedium,
          color = Slate400,
        )
        Text(
          text = "Create Account",
          style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
          color = Gold400,
          modifier = Modifier
            .clickable { onNavigateToRegister() }
            .testTag("login_register_link")
            .padding(4.dp),
        )
      }

      Spacer(modifier = Modifier.height(28.dp))

      // Security Notice
      Surface(
        color = Slate900,
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Row(
          modifier = Modifier.padding(12.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Icon(
            imageVector = Icons.Default.Security,
            contentDescription = null,
            tint = Emerald500,
            modifier = Modifier.size(20.dp),
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = "Cryptographic password hashing. No plain-text passwords stored. One mobile number = one account.",
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
            color = Slate400,
          )
        }
      }
    }
  }
}

// ==========================================
// 3. REGISTRATION SCREEN
// ==========================================
@Composable
fun RegistrationScreen(
  onRegisterSuccess: () -> Unit,
  onNavigateToLogin: () -> Unit,
  authRepository: AuthRepository,
  modifier: Modifier = Modifier,
) {
  var name by remember { mutableStateOf("") }
  var phoneNumber by remember { mutableStateOf("") }
  var password by remember { mutableStateOf("") }
  var confirmPassword by remember { mutableStateOf("") }
  var isPasswordVisible by remember { mutableStateOf(false) }
  var isLoading by remember { mutableStateOf(false) }
  var errorMessage by remember { mutableStateOf<String?>(null) }
  val scope = rememberCoroutineScope()

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(
        Brush.verticalGradient(
          colors = listOf(DeepNavyBg, NavySurface, Color(0xFF131B2E))
        )
      )
      .testTag("registration_screen"),
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 24.dp, vertical = 28.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      // Top bar back button
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        IconButton(
          onClick = onNavigateToLogin,
          modifier = Modifier.testTag("register_back_button"),
        ) {
          Icon(
            imageVector = Icons.Default.ArrowBack,
            contentDescription = "Back to Login",
            tint = Color.White,
          )
        }
        Text(
          text = "Create Account",
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
          color = Color.White,
          modifier = Modifier.padding(start = 8.dp),
        )
      }

      Spacer(modifier = Modifier.height(16.dp))

      Text(
        text = "Register to join 1v1 Ludo and Carrom tournament matches",
        style = MaterialTheme.typography.bodyMedium,
        color = Slate400,
        textAlign = TextAlign.Center,
      )

      Spacer(modifier = Modifier.height(24.dp))

      // Registration Form Card
      TournamentCard(
        modifier = Modifier.fillMaxWidth(),
        backgroundColor = NavyCard,
        borderColor = NavyCardBorder,
      ) {
        // Name
        TournamentTextField(
          value = name,
          onValueChange = {
            name = it
            errorMessage = null
          },
          label = "Full Name",
          placeholder = "e.g. Rahul Verma",
          leadingIcon = Icons.Default.Person,
          testTag = "register_name_input",
          modifier = Modifier.fillMaxWidth(),
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Mobile Number
        TournamentTextField(
          value = phoneNumber,
          onValueChange = { input ->
            if (input.length <= 10 && input.all { it.isDigit() }) {
              phoneNumber = input
              errorMessage = null
            }
          },
          label = "Mobile Number (10 Digits)",
          placeholder = "e.g. 9876543210",
          leadingIcon = Icons.Default.Phone,
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
          testTag = "register_phone_input",
          modifier = Modifier.fillMaxWidth(),
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Password
        TournamentTextField(
          value = password,
          onValueChange = {
            password = it
            errorMessage = null
          },
          label = "Password (Min 6 characters)",
          placeholder = "Enter password",
          leadingIcon = Icons.Default.Lock,
          visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
          trailingIcon = {
            IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
              Icon(
                imageVector = if (isPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                contentDescription = null,
                tint = Slate400,
              )
            }
          },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
          testTag = "register_password_input",
          modifier = Modifier.fillMaxWidth(),
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Confirm Password
        TournamentTextField(
          value = confirmPassword,
          onValueChange = {
            confirmPassword = it
            errorMessage = null
          },
          label = "Confirm Password",
          placeholder = "Re-enter password",
          leadingIcon = Icons.Default.LockClock,
          visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
          testTag = "register_confirm_password_input",
          modifier = Modifier.fillMaxWidth(),
        )

        // Error banner
        AnimatedVisibility(visible = errorMessage != null) {
          Surface(
            color = Rose600.copy(alpha = 0.15f),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
              .fillMaxWidth()
              .padding(top = 12.dp),
          ) {
            Text(
              text = errorMessage ?: "",
              style = MaterialTheme.typography.bodySmall,
              color = Rose500,
              modifier = Modifier.padding(10.dp),
            )
          }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Submit Button
        TournamentButton(
          text = "CREATE ACCOUNT",
          onClick = {
            if (name.trim().isEmpty()) {
              errorMessage = "Please enter your name"
              return@TournamentButton
            }
            if (phoneNumber.length != 10) {
              errorMessage = "Mobile number must be exactly 10 digits"
              return@TournamentButton
            }
            if (password.length < 6) {
              errorMessage = "Password must be at least 6 characters"
              return@TournamentButton
            }
            if (password != confirmPassword) {
              errorMessage = "Passwords do not match"
              return@TournamentButton
            }

            isLoading = true
            scope.launch {
              val passwordHash = PasswordSecurity.hashPassword(password)
              val result = authRepository.registerUser(name, phoneNumber, passwordHash)
              isLoading = false
              when (result) {
                is Resource.Success -> onRegisterSuccess()
                is Resource.Error -> errorMessage = result.error.userMessage
                else -> Unit
              }
            }
          },
          modifier = Modifier.fillMaxWidth(),
          isLoading = isLoading,
          testTag = "register_submit_button",
        )
      }

      Spacer(modifier = Modifier.height(20.dp))

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
      ) {
        Text(
          text = "Already registered? ",
          style = MaterialTheme.typography.bodyMedium,
          color = Slate400,
        )
        Text(
          text = "Sign In",
          style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
          color = Cyan400,
          modifier = Modifier
            .clickable { onNavigateToLogin() }
            .testTag("register_signin_link")
            .padding(4.dp),
        )
      }
    }
  }
}

// ==========================================
// 4. FORGOT PASSWORD / OTP SCREEN
// ==========================================
@Composable
fun ForgotPasswordScreen(
  onResetSuccess: () -> Unit,
  onNavigateToLogin: () -> Unit,
  authRepository: AuthRepository,
  modifier: Modifier = Modifier,
) {
  var phoneNumber by remember { mutableStateOf("") }
  var otpCode by remember { mutableStateOf("") }
  var newPassword by remember { mutableStateOf("") }
  var isOtpSent by remember { mutableStateOf(false) }
  var isLoading by remember { mutableStateOf(false) }
  var statusMessage by remember { mutableStateOf<String?>(null) }
  var isError by remember { mutableStateOf(false) }
  val scope = rememberCoroutineScope()

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(
        Brush.verticalGradient(
          colors = listOf(DeepNavyBg, NavySurface, Color(0xFF131B2E))
        )
      )
      .testTag("forgot_password_screen"),
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 24.dp, vertical = 28.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      // Header
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        IconButton(
          onClick = onNavigateToLogin,
          modifier = Modifier.testTag("forgot_back_button"),
        ) {
          Icon(
            imageVector = Icons.Default.ArrowBack,
            contentDescription = "Back",
            tint = Color.White,
          )
        }
        Text(
          text = "Reset Password",
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
          color = Color.White,
          modifier = Modifier.padding(start = 8.dp),
        )
      }

      Spacer(modifier = Modifier.height(16.dp))

      Text(
        text = "Enter your registered 10-digit mobile number to verify OTP and choose a new password",
        style = MaterialTheme.typography.bodyMedium,
        color = Slate400,
        textAlign = TextAlign.Center,
      )

      Spacer(modifier = Modifier.height(28.dp))

      TournamentCard(
        modifier = Modifier.fillMaxWidth(),
        backgroundColor = NavyCard,
        borderColor = NavyCardBorder,
      ) {
        // Phone Input
        TournamentTextField(
          value = phoneNumber,
          onValueChange = { input ->
            if (input.length <= 10 && input.all { it.isDigit() }) {
              phoneNumber = input
              statusMessage = null
            }
          },
          label = "Mobile Number",
          placeholder = "10-digit registered number",
          leadingIcon = Icons.Default.Phone,
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
          testTag = "forgot_phone_input",
          modifier = Modifier.fillMaxWidth(),
        )

        Spacer(modifier = Modifier.height(16.dp))

        if (!isOtpSent) {
          // Send OTP button
          TournamentButton(
            text = "SEND VERIFICATION OTP",
            onClick = {
              if (phoneNumber.length != 10) {
                isError = true
                statusMessage = "Please enter a valid 10-digit mobile number"
                return@TournamentButton
              }
              isLoading = true
              scope.launch {
                val res = authRepository.sendPasswordResetOtp(phoneNumber)
                isLoading = false
                when (res) {
                  is Resource.Success -> {
                    isOtpSent = true
                    isError = false
                    statusMessage = "OTP sent to +91 $phoneNumber. (Demo OTP: 123456)"
                  }
                  is Resource.Error -> {
                    isError = true
                    statusMessage = res.error.userMessage
                  }
                  else -> Unit
                }
              }
            },
            modifier = Modifier.fillMaxWidth(),
            isLoading = isLoading,
            testTag = "send_otp_button",
          )
        } else {
          // OTP input
          TournamentTextField(
            value = otpCode,
            onValueChange = { input ->
              if (input.length <= 6 && input.all { it.isDigit() }) {
                otpCode = input
                statusMessage = null
              }
            },
            label = "Enter 6-Digit OTP",
            placeholder = "e.g. 123456",
            leadingIcon = Icons.Default.Pin,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            testTag = "forgot_otp_input",
            modifier = Modifier.fillMaxWidth(),
          )

          Spacer(modifier = Modifier.height(14.dp))

          // New Password
          TournamentTextField(
            value = newPassword,
            onValueChange = {
              newPassword = it
              statusMessage = null
            },
            label = "New Password",
            placeholder = "Enter new password",
            leadingIcon = Icons.Default.Lock,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            testTag = "forgot_new_password_input",
            modifier = Modifier.fillMaxWidth(),
          )

          Spacer(modifier = Modifier.height(20.dp))

          // Reset CTA
          TournamentButton(
            text = "CONFIRM & RESET PASSWORD",
            onClick = {
              if (otpCode.length != 6) {
                isError = true
                statusMessage = "Please enter 6-digit OTP"
                return@TournamentButton
              }
              if (newPassword.length < 6) {
                isError = true
                statusMessage = "New password must be at least 6 characters"
                return@TournamentButton
              }

              isLoading = true
              scope.launch {
                val hash = PasswordSecurity.hashPassword(newPassword)
                val res = authRepository.verifyOtpAndResetPassword(phoneNumber, otpCode, hash)
                isLoading = false
                when (res) {
                  is Resource.Success -> onResetSuccess()
                  is Resource.Error -> {
                    isError = true
                    statusMessage = res.error.userMessage
                  }
                  else -> Unit
                }
              }
            },
            modifier = Modifier.fillMaxWidth(),
            isLoading = isLoading,
            testTag = "reset_password_submit_button",
          )
        }

        // Status banner
        AnimatedVisibility(visible = statusMessage != null) {
          Surface(
            color = if (isError) Rose600.copy(alpha = 0.15f) else Emerald600.copy(alpha = 0.15f),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
              .fillMaxWidth()
              .padding(top = 14.dp),
          ) {
            Text(
              text = statusMessage ?: "",
              style = MaterialTheme.typography.bodySmall,
              color = if (isError) Rose500 else Emerald500,
              modifier = Modifier.padding(10.dp),
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(24.dp))

      Text(
        text = "Back to Sign In",
        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
        color = Cyan400,
        modifier = Modifier
          .clickable { onNavigateToLogin() }
          .testTag("forgot_login_link")
          .padding(8.dp),
      )
    }
  }
}
