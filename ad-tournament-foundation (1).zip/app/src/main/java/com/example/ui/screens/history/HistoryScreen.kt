package com.example.ui.screens.history

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.error.Resource
import com.example.domain.model.MatchEntity
import com.example.domain.repository.MatchRepository
import com.example.ui.components.TournamentCard
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoryScreen(
  userId: String,
  matchRepository: MatchRepository,
  modifier: Modifier = Modifier,
) {
  var selectedGameFilter by remember { mutableStateOf("ALL") }

  // Observe match history
  val historyResource by matchRepository.getMatchHistory(userId, 50).collectAsState(initial = null)
  val matches = (historyResource as? Resource.Success)?.data ?: emptyList()

  val filteredMatches = remember(matches, selectedGameFilter) {
    if (selectedGameFilter == "ALL") {
      matches
    } else {
      matches.filter { it.gameType.equals(selectedGameFilter, ignoreCase = true) }
    }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(DeepNavyBg)
      .testTag("history_screen"),
  ) {
    // Top Bar
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 20.dp, vertical = 16.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Icon(
        imageVector = Icons.Default.History,
        contentDescription = null,
        tint = Gold400,
        modifier = Modifier.size(24.dp),
      )
      Spacer(modifier = Modifier.width(10.dp))
      Text(
        text = "MATCH HISTORY",
        style = MaterialTheme.typography.titleLarge.copy(
          fontWeight = FontWeight.Black,
          letterSpacing = 1.sp,
        ),
        color = Color.White,
      )
    }

    // Filter Chips
    LazyRow(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 4.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      val filters = listOf(
        "ALL" to "All Matches",
        "LUDO" to "Ludo 1v1",
        "CARROM" to "Carrom 1v1",
      )
      items(filters) { (key, label) ->
        val isSelected = selectedGameFilter == key
        Surface(
          shape = RoundedCornerShape(16.dp),
          color = if (isSelected) Gold500 else Slate900,
          border = BorderStroke(1.dp, if (isSelected) Gold400 else CardBorder),
          modifier = Modifier
            .clickable { selectedGameFilter = key }
            .testTag("history_filter_$key"),
        ) {
          Text(
            text = label,
            style = MaterialTheme.typography.labelMedium.copy(
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
            ),
            color = if (isSelected) Slate950 else Color.White,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Match List
    if (filteredMatches.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(32.dp),
        contentAlignment = Alignment.Center,
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Icon(Icons.Default.SportsEsports, contentDescription = null, tint = Slate600, modifier = Modifier.size(48.dp))
          Spacer(modifier = Modifier.height(12.dp))
          Text("No completed matches found", color = Slate400, style = MaterialTheme.typography.bodyMedium)
        }
      }
    } else {
      LazyColumn(
        modifier = Modifier
          .fillMaxSize()
          .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 24.dp),
      ) {
        items(filteredMatches, key = { it.matchId }) { match ->
          MatchHistoryCard(match = match, currentUserId = userId)
        }
      }
    }
  }
}

@Composable
private fun MatchHistoryCard(match: MatchEntity, currentUserId: String) {
  val isWinner = match.winnerUserId == currentUserId
  val formattedDate = remember(match.scheduledTime) {
    SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(match.scheduledTime))
  }

  TournamentCard(
    modifier = Modifier.fillMaxWidth(),
    backgroundColor = NavyCard,
    borderColor = if (isWinner) Gold500.copy(alpha = 0.5f) else CardBorder,
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(if (isWinner) Gold500.copy(alpha = 0.2f) else Slate800),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            imageVector = if (isWinner) Icons.Default.EmojiEvents else Icons.Default.Close,
            contentDescription = null,
            tint = if (isWinner) Gold400 else Slate400,
            modifier = Modifier.size(20.dp),
          )
        }

        Spacer(modifier = Modifier.width(10.dp))

        Column {
          Text(
            text = match.title,
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
            color = Color.White,
          )
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = "$formattedDate • ${match.matchNumber}",
            style = MaterialTheme.typography.labelSmall,
            color = Slate400,
          )
        }
      }

      // Result Badge
      Surface(
        color = if (isWinner) Emerald600.copy(alpha = 0.2f) else Slate800,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, if (isWinner) Emerald500 else Slate700),
      ) {
        Text(
          text = if (isWinner) "WON ₹${"%.0f".format(match.prizePool)}" else "RUNNER UP",
          style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
          color = if (isWinner) Emerald500 else Slate400,
          modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
        )
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Match Details Strip
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(8.dp))
        .background(Slate900)
        .padding(horizontal = 12.dp, vertical = 8.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Text(text = "Fee Paid: ₹${"%.0f".format(match.entryFee)}", style = MaterialTheme.typography.labelSmall, color = Slate400)
      Text(text = "Game: ${match.gameType}", style = MaterialTheme.typography.labelSmall, color = Cyan400)
      if (match.gameCode.isNotBlank()) {
        Text(text = "Room: ${match.gameCode}", style = MaterialTheme.typography.labelSmall, color = Gold400)
      }
    }
  }
}
