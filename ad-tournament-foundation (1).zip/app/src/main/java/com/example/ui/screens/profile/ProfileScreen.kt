package com.example.ui.screens.profile

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ClipboardManager
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.UserEntity
import com.example.domain.repository.AuthRepository
import com.example.ui.components.TournamentButton
import com.example.ui.components.TournamentButtonVariant
import com.example.ui.components.TournamentCard
import com.example.ui.components.TournamentTextField
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ProfileScreen(
  onSignOut: () -> Unit,
  authRepository: AuthRepository,
  modifier: Modifier = Modifier,
) {
  val user by authRepository.getCurrentUser().collectAsState(initial = null)
  val scope = rememberCoroutineScope()
  val clipboardManager: ClipboardManager = LocalClipboardManager.current

  var showEditNameDialog by remember { mutableStateOf(false) }
  var showPhotoDialog by remember { mutableStateOf(false) }
  var bannerMessage by remember { mutableStateOf<String?>(null) }

  val joinDateFormatted = remember(user?.createdAt) {
    user?.createdAt?.let {
      SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(Date(it))
    } ?: "May 2024"
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(DeepNavyBg)
      .testTag("profile_screen"),
  ) {
    // Top Bar
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 20.dp, vertical = 16.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Icon(
        imageVector = Icons.Default.Person,
        contentDescription = null,
        tint = Gold400,
        modifier = Modifier.size(24.dp),
      )
      Spacer(modifier = Modifier.width(10.dp))
      Text(
        text = "PLAYER PROFILE",
        style = MaterialTheme.typography.titleLarge.copy(
          fontWeight = FontWeight.Black,
          letterSpacing = 1.sp,
        ),
        color = Color.White,
      )
    }

    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 16.dp),
      contentPadding = PaddingValues(bottom = 28.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      // Banner feedback
      item {
        AnimatedVisibility(visible = bannerMessage != null) {
          Surface(
            color = Cyan500.copy(alpha = 0.15f),
            border = BorderStroke(1.dp, Cyan400),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Row(
              modifier = Modifier.padding(10.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Cyan400, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text(text = bannerMessage ?: "", color = Color.White, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
              IconButton(onClick = { bannerMessage = null }, modifier = Modifier.size(24.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = Slate400, modifier = Modifier.size(16.dp))
              }
            }
          }
        }
      }

      // 1. PROFILE HEADER CARD
      item {
        TournamentCard(
          modifier = Modifier.fillMaxWidth(),
          backgroundColor = NavyCard,
          borderColor = NavyCardBorder,
        ) {
          Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
          ) {
            // Avatar
            Box(
              modifier = Modifier
                .size(80.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Indigo600, Purple600)))
                .clickable { showPhotoDialog = true }
                .testTag("profile_avatar_button"),
              contentAlignment = Alignment.Center,
            ) {
              Icon(
                imageVector = Icons.Default.Person,
                contentDescription = "Avatar",
                tint = Gold400,
                modifier = Modifier.size(46.dp),
              )
              // Camera badge
              Box(
                modifier = Modifier
                  .size(24.dp)
                  .clip(CircleShape)
                  .background(Gold500)
                  .align(Alignment.BottomEnd),
                contentAlignment = Alignment.Center,
              ) {
                Icon(Icons.Default.CameraAlt, contentDescription = "Change Photo", tint = Slate950, modifier = Modifier.size(14.dp))
              }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Name + Edit icon
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.clickable { showEditNameDialog = true },
            ) {
              Text(
                text = user?.displayName ?: "Player",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                color = Color.White,
              )
              Spacer(modifier = Modifier.width(6.dp))
              Icon(
                imageVector = Icons.Default.Edit,
                contentDescription = "Edit Name",
                tint = Gold400,
                modifier = Modifier.size(18.dp),
              )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // User ID (Tappable copy)
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier
                .clickable {
                  val id = user?.userId ?: "AD-USER-9481"
                  clipboardManager.setText(AnnotatedString(id))
                  bannerMessage = "User ID $id copied to clipboard"
                }
                .testTag("copy_user_id_button"),
            ) {
              Text(
                text = "ID: ${user?.userId ?: "AD-USER-9481"}",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                color = Cyan400,
              )
              Spacer(modifier = Modifier.width(4.dp))
              Icon(Icons.Default.ContentCopy, contentDescription = "Copy ID", tint = Cyan400, modifier = Modifier.size(14.dp))
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Mobile number (Non-editable badge)
            Surface(
              color = Slate900,
              shape = RoundedCornerShape(8.dp),
              border = BorderStroke(1.dp, CardBorder),
              modifier = Modifier.fillMaxWidth(),
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Default.Phone, contentDescription = null, tint = Slate400, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    text = "+91 ${user?.phoneNumber ?: "9876543210"}",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                    color = Color.White,
                  )
                }
                Surface(
                  color = Slate800,
                  shape = RoundedCornerShape(6.dp),
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                  ) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = Slate400, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                      text = "LOCKED",
                      style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                      color = Slate400,
                    )
                  }
                }
              }
            }

            Text(
              text = "Mobile number cannot be changed from the app for security & fair play.",
              style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
              color = Slate500,
              modifier = Modifier.padding(top = 4.dp),
            )
          }
        }
      }

      // 2. CAREER STATISTICS GRID
      item {
        Column {
          Text(
            text = "CAREER STATISTICS",
            style = MaterialTheme.typography.titleSmall.copy(
              fontWeight = FontWeight.Bold,
              letterSpacing = 1.sp,
            ),
            color = Gold400,
          )

          Spacer(modifier = Modifier.height(10.dp))

          val totalMatches = user?.totalMatches ?: 38
          val wins = user?.wins ?: 26
          val losses = user?.losses ?: 12
          val winRate = if (totalMatches > 0) ((wins.toDouble() / totalMatches) * 100).toInt() else 0

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            StatBox(title = "MATCHES", value = "$totalMatches", subtitle = "1v1 Battles", modifier = Modifier.weight(1f))
            StatBox(title = "WINS", value = "$wins", subtitle = "$winRate% Win Rate", color = Emerald500, modifier = Modifier.weight(1f))
            StatBox(title = "LOSSES", value = "$losses", subtitle = "Contests", color = Rose500, modifier = Modifier.weight(1f))
          }

          Spacer(modifier = Modifier.height(10.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            StatBox(
              title = "TOTAL WINNINGS",
              value = "₹${"%.0f".format(user?.totalWinnings ?: 1850.0)}",
              subtitle = "All-Time Rewards",
              color = Gold400,
              modifier = Modifier.weight(1f),
            )
            StatBox(
              title = "MEMBER SINCE",
              value = joinDateFormatted,
              subtitle = "Verified Player",
              color = Cyan400,
              modifier = Modifier.weight(1f),
            )
          }
        }
      }

      // 3. FAIR PLAY & ACCOUNT SECURITY
      item {
        TournamentCard(
          modifier = Modifier.fillMaxWidth(),
          backgroundColor = NavyCard,
          borderColor = CardBorder,
        ) {
          Text(
            text = "FAIR PLAY & INTEGRITY",
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
            color = Gold400,
          )
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "• Account Status: Active (Clean Record)\n• Single Account Policy: One mobile number per player\n• Zero Tolerance: Cheating or submitting false game screenshots results in permanent account suspension and forfeiture.",
            style = MaterialTheme.typography.bodySmall,
            color = Slate400,
            lineHeight = 18.sp,
          )
        }
      }

      // 4. LOGOUT BUTTON
      item {
        TournamentButton(
          text = "SIGN OUT",
          onClick = {
            scope.launch {
              authRepository.signOut()
              onSignOut()
            }
          },
          variant = TournamentButtonVariant.DANGER,
          leadingIcon = {
            Icon(Icons.Default.Logout, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
          },
          modifier = Modifier.fillMaxWidth(),
          testTag = "profile_logout_button",
        )
      }
    }
  }

  // EDIT NAME DIALOG
  if (showEditNameDialog) {
    var newName by remember { mutableStateOf(user?.displayName ?: "") }
    AlertDialog(
      onDismissRequest = { showEditNameDialog = false },
      title = { Text("Update Display Name", color = Color.White) },
      text = {
        Column {
          TournamentTextField(
            value = newName,
            onValueChange = { newName = it },
            label = "Player Name",
            placeholder = "Enter new display name",
            leadingIcon = Icons.Default.Person,
            testTag = "edit_name_input",
            modifier = Modifier.fillMaxWidth(),
          )
        }
      },
      confirmButton = {
        TournamentButton(
          text = "SAVE NAME",
          onClick = {
            if (newName.isNotBlank()) {
              scope.launch {
                authRepository.updateDisplayName(user?.userId ?: "", newName)
                showEditNameDialog = false
                bannerMessage = "Display name updated successfully"
              }
            }
          },
          testTag = "confirm_edit_name_button",
        )
      },
      dismissButton = {
        TextButton(onClick = { showEditNameDialog = false }) {
          Text("Cancel", color = Slate400)
        }
      },
      containerColor = NavyCard,
    )
  }

  // EDIT PHOTO DIALOG
  if (showPhotoDialog) {
    AlertDialog(
      onDismissRequest = { showPhotoDialog = false },
      title = { Text("Profile Avatar", color = Color.White) },
      text = {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text(
            text = "Select avatar style or upload custom picture",
            style = MaterialTheme.typography.bodySmall,
            color = Slate400,
          )
          Spacer(modifier = Modifier.height(16.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
          ) {
            listOf(Icons.Default.SportsEsports, Icons.Default.EmojiEvents, Icons.Default.FlashOn).forEach { icon ->
              Box(
                modifier = Modifier
                  .size(52.dp)
                  .clip(CircleShape)
                  .background(Indigo900)
                  .clickable {
                    showPhotoDialog = false
                    bannerMessage = "Profile avatar updated"
                  },
                contentAlignment = Alignment.Center,
              ) {
                Icon(icon, contentDescription = null, tint = Gold400, modifier = Modifier.size(28.dp))
              }
            }
          }
        }
      },
      confirmButton = {
        TextButton(onClick = { showPhotoDialog = false }) {
          Text("Close", color = Cyan400)
        }
      },
      containerColor = NavyCard,
    )
  }
}

@Composable
private fun StatBox(
  title: String,
  value: String,
  subtitle: String,
  color: Color = Color.White,
  modifier: Modifier = Modifier,
) {
  Surface(
    color = NavyCard,
    shape = RoundedCornerShape(12.dp),
    border = BorderStroke(1.dp, CardBorder),
    modifier = modifier,
  ) {
    Column(
      modifier = Modifier.padding(12.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Text(
        text = title,
        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
        color = Slate400,
      )
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = value,
        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
        color = color,
      )
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = subtitle,
        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
        color = Slate500,
      )
    }
  }
}
