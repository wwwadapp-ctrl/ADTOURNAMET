package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Tournament Dark Color Scheme (Primary Focus for Esports / Gaming Experience)
private val TournamentDarkColorScheme = darkColorScheme(
  primary = Gold500,
  onPrimary = Slate950,
  primaryContainer = Amber700,
  onPrimaryContainer = Gold400,
  secondary = Cyan400,
  onSecondary = Slate950,
  secondaryContainer = Slate800,
  onSecondaryContainer = Cyan400,
  tertiary = Emerald500,
  onTertiary = Slate950,
  background = Slate950,
  onBackground = Slate50,
  surface = Slate900,
  onSurface = Slate50,
  surfaceVariant = Slate850,
  onSurfaceVariant = Slate400,
  outline = CardBorder,
  outlineVariant = Slate700,
  error = Rose500,
  onError = Color.White,
)

// Tournament Light Color Scheme (Fallback)
private val TournamentLightColorScheme = lightColorScheme(
  primary = Amber600,
  onPrimary = Color.White,
  primaryContainer = Gold400,
  onPrimaryContainer = Slate950,
  secondary = Cyan500,
  onSecondary = Color.White,
  background = Slate50,
  onBackground = Slate900,
  surface = Color.White,
  onSurface = Slate900,
  surfaceVariant = Slate100,
  onSurfaceVariant = Slate600,
  outline = Slate200,
  error = Rose600,
  onError = Color.White,
)

@Composable
fun AdTournamentTheme(
  darkTheme: Boolean = true, // Default to tournament dark theme
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) TournamentDarkColorScheme else TournamentLightColorScheme

  MaterialTheme(
    colorScheme = colorScheme,
    typography = TournamentTypography,
    content = content,
  )
}

// Retain alias for test compatibility
@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  AdTournamentTheme(darkTheme = darkTheme, content = content)
}

