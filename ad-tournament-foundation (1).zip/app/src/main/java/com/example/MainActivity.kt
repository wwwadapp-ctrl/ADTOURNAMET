package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.network.NetworkStatus
import com.example.ui.navigation.AdTournamentApp
import com.example.ui.theme.AdTournamentTheme
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    val app = application as? AdTournamentApplication
    val container = app?.container ?: com.example.core.di.DefaultAppContainer(applicationContext)
    val networkMonitor = container.networkMonitor

    setContent {
      AdTournamentTheme {
        val networkStatus by networkMonitor.status.collectAsStateWithLifecycle(
          initialValue = NetworkStatus.Available
        )

        AdTournamentApp(
          networkStatus = networkStatus,
          appContainer = container,
        )
      }
    }
  }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
  Text(text = "Hello $name!", modifier = modifier)
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
  MyApplicationTheme { Greeting("Android") }
}
