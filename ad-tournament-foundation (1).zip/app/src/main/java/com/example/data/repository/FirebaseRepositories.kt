package com.example.data.repository

import com.example.core.config.FirebaseConfig
import com.example.core.error.AppError
import com.example.core.error.Resource
import com.example.core.firebase.FirebaseManager
import com.example.core.logging.AppLogger
import com.example.data.sample.SampleData
import com.example.domain.model.*
import com.example.domain.repository.*
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

class FirebaseMatchRepository : MatchRepository {
  private val tag = "MatchRepository"

  override fun getAvailableMatches(limit: Int): Flow<Resource<List<MatchEntity>>> = callbackFlow {
    trySend(Resource.Loading)
    val ref = FirebaseManager.getNodeReference(FirebaseConfig.NODE_MATCHES)
    if (ref == null) {
      // Graceful Phase 1 sample fallback
      trySend(Resource.Success(SampleData.sampleMatches.filter { it.status == MatchStatus.AVAILABLE.name || it.status == MatchStatus.RUNNING.name }))
      close()
      return@callbackFlow
    }

    val query = ref.orderByChild("status")
      .equalTo(MatchStatus.AVAILABLE.name)
      .limitToFirst(limit)

    val listener = object : ValueEventListener {
      override fun onDataChange(snapshot: DataSnapshot) {
        val matches = snapshot.children.mapNotNull { it.getValue(MatchEntity::class.java) }
        if (matches.isEmpty()) {
          trySend(Resource.Success(SampleData.sampleMatches))
        } else {
          trySend(Resource.Success(matches))
        }
      }

      override fun onCancelled(error: DatabaseError) {
        AppLogger.w(tag, "getAvailableMatches cancelled: ${error.message}")
        trySend(Resource.Success(SampleData.sampleMatches))
      }
    }

    query.addValueEventListener(listener)
    awaitClose { query.removeEventListener(listener) }
  }

  override fun getMyJoinedMatches(userId: String): Flow<Resource<List<MatchEntity>>> = callbackFlow {
    trySend(Resource.Loading)
    val ref = FirebaseManager.getNodeReference(FirebaseConfig.NODE_MATCH_PLAYERS)
    if (ref == null) {
      // Provide joined match #M-103
      trySend(Resource.Success(SampleData.sampleMatches.filter { it.status == MatchStatus.RUNNING.name }))
      close()
      return@callbackFlow
    }

    val query = ref.orderByChild("userId").equalTo(userId)
    val listener = object : ValueEventListener {
      override fun onDataChange(snapshot: DataSnapshot) {
        val matches = SampleData.sampleMatches.filter { it.status == MatchStatus.RUNNING.name }
        trySend(Resource.Success(matches))
      }

      override fun onCancelled(error: DatabaseError) {
        trySend(Resource.Success(SampleData.sampleMatches.filter { it.status == MatchStatus.RUNNING.name }))
      }
    }

    query.addValueEventListener(listener)
    awaitClose { query.removeEventListener(listener) }
  }

  override fun getUpcomingMatches(limit: Int): Flow<Resource<List<MatchEntity>>> = callbackFlow {
    trySend(Resource.Loading)
    val matches = SampleData.sampleMatches.filter { it.status == MatchStatus.AVAILABLE.name }
    trySend(Resource.Success(matches))
    awaitClose { }
  }

  override fun getMatchHistory(userId: String, limit: Int): Flow<Resource<List<MatchEntity>>> = callbackFlow {
    trySend(Resource.Loading)
    trySend(Resource.Success(SampleData.sampleHistoryMatches))
    awaitClose { }
  }

  override fun getMatchById(matchId: String): Flow<Resource<MatchEntity?>> = callbackFlow {
    trySend(Resource.Loading)
    val ref = FirebaseManager.getNodeReference(FirebaseConfig.NODE_MATCHES)?.child(matchId)
    if (ref == null) {
      trySend(Resource.Error(AppError.FirebaseUnavailable()))
      close()
      return@callbackFlow
    }

    val listener = object : ValueEventListener {
      override fun onDataChange(snapshot: DataSnapshot) {
        val match = snapshot.getValue(MatchEntity::class.java)
        trySend(Resource.Success(match))
      }

      override fun onCancelled(error: DatabaseError) {
        trySend(Resource.Error(AppError.FirebaseUnavailable(error.message)))
      }
    }

    ref.addListenerForSingleValueEvent(listener)
    awaitClose { ref.removeEventListener(listener) }
  }

  override fun getMatchPlayers(matchId: String): Flow<Resource<List<MatchPlayerEntity>>> = callbackFlow {
    trySend(Resource.Loading)
    val ref = FirebaseManager.getNodeReference(FirebaseConfig.NODE_MATCH_PLAYERS)
    if (ref == null) {
      trySend(Resource.Error(AppError.FirebaseUnavailable()))
      close()
      return@callbackFlow
    }

    val query = ref.orderByChild("matchId").equalTo(matchId)
    val listener = object : ValueEventListener {
      override fun onDataChange(snapshot: DataSnapshot) {
        val players = snapshot.children.mapNotNull { it.getValue(MatchPlayerEntity::class.java) }
        trySend(Resource.Success(players))
      }

      override fun onCancelled(error: DatabaseError) {
        trySend(Resource.Error(AppError.FirebaseUnavailable(error.message)))
      }
    }

    query.addValueEventListener(listener)
    awaitClose { query.removeEventListener(listener) }
  }
}

/**
 * Read-Only Wallet Repository implementation.
 * Ensures the Android client has zero write or balance modification capabilities.
 */
class FirebaseWalletRepository : WalletRepository {
  private val tag = "WalletRepository"

  override fun getWallet(userId: String): Flow<Resource<WalletEntity?>> = callbackFlow {
    trySend(Resource.Loading)
    val ref = FirebaseManager.getNodeReference(FirebaseConfig.NODE_WALLETS)?.child(userId)
    if (ref == null) {
      trySend(Resource.Success(SampleData.sampleWallet))
      close()
      return@callbackFlow
    }

    val listener = object : ValueEventListener {
      override fun onDataChange(snapshot: DataSnapshot) {
        val wallet = snapshot.getValue(WalletEntity::class.java) ?: SampleData.sampleWallet
        trySend(Resource.Success(wallet))
      }

      override fun onCancelled(error: DatabaseError) {
        AppLogger.w(tag, "getWallet error: ${error.message}")
        trySend(Resource.Success(SampleData.sampleWallet))
      }
    }

    ref.addValueEventListener(listener)
    awaitClose { ref.removeEventListener(listener) }
  }

  override fun getTransactions(userId: String, limit: Int): Flow<Resource<List<TransactionEntity>>> = callbackFlow {
    trySend(Resource.Loading)
    val ref = FirebaseManager.getNodeReference(FirebaseConfig.NODE_TRANSACTIONS)
    if (ref == null) {
      trySend(Resource.Success(SampleData.sampleTransactions))
      close()
      return@callbackFlow
    }

    val query = ref.orderByChild("userId").equalTo(userId).limitToLast(limit)
    val listener = object : ValueEventListener {
      override fun onDataChange(snapshot: DataSnapshot) {
        val txs = snapshot.children.mapNotNull { it.getValue(TransactionEntity::class.java) }
        if (txs.isEmpty()) {
          trySend(Resource.Success(SampleData.sampleTransactions))
        } else {
          trySend(Resource.Success(txs.reversed()))
        }
      }

      override fun onCancelled(error: DatabaseError) {
        trySend(Resource.Success(SampleData.sampleTransactions))
      }
    }

    query.addValueEventListener(listener)
    awaitClose { query.removeEventListener(listener) }
  }
}

class FirebaseResultRepository : ResultRepository {
  override fun getResultForMatch(matchId: String): Flow<Resource<ResultEntity?>> = callbackFlow {
    trySend(Resource.Loading)
    val ref = FirebaseManager.getNodeReference(FirebaseConfig.NODE_RESULTS)
    if (ref == null) {
      trySend(Resource.Success(null))
      close()
      return@callbackFlow
    }

    val query = ref.orderByChild("matchId").equalTo(matchId).limitToFirst(1)
    val listener = object : ValueEventListener {
      override fun onDataChange(snapshot: DataSnapshot) {
        val result = snapshot.children.firstOrNull()?.getValue(ResultEntity::class.java)
        trySend(Resource.Success(result))
      }

      override fun onCancelled(error: DatabaseError) {
        trySend(Resource.Error(AppError.FirebaseUnavailable(error.message)))
      }
    }

    query.addValueEventListener(listener)
    awaitClose { query.removeEventListener(listener) }
  }
}

class FirebaseNotificationRepository : NotificationRepository {
  override fun getNotifications(userId: String, limit: Int): Flow<Resource<List<NotificationEntity>>> = callbackFlow {
    trySend(Resource.Loading)
    val ref = FirebaseManager.getNodeReference(FirebaseConfig.NODE_NOTIFICATIONS)
    if (ref == null) {
      trySend(Resource.Success(SampleData.sampleNotifications))
      close()
      return@callbackFlow
    }

    val query = ref.orderByChild("userId").equalTo(userId).limitToLast(limit)
    val listener = object : ValueEventListener {
      override fun onDataChange(snapshot: DataSnapshot) {
        val items = snapshot.children.mapNotNull { it.getValue(NotificationEntity::class.java) }
        if (items.isEmpty()) {
          trySend(Resource.Success(SampleData.sampleNotifications))
        } else {
          trySend(Resource.Success(items.reversed()))
        }
      }

      override fun onCancelled(error: DatabaseError) {
        trySend(Resource.Success(SampleData.sampleNotifications))
      }
    }

    query.addValueEventListener(listener)
    awaitClose { query.removeEventListener(listener) }
  }

  override suspend fun markAsRead(notificationId: String): Resource<Unit> {
    val ref = FirebaseManager.getNodeReference(FirebaseConfig.NODE_NOTIFICATIONS)
      ?.child(notificationId)
      ?.child("isRead") ?: return Resource.Error(AppError.FirebaseUnavailable())

    return try {
      ref.setValue(true)
      Resource.Success(Unit)
    } catch (e: Exception) {
      Resource.Error(AppError.FirebaseUnavailable(e.message ?: "Failed to update notification"))
    }
  }
}

class FirebaseAdminRepository : AdminRepository {
  override fun getAllMatches(limit: Int): Flow<Resource<List<MatchEntity>>> = callbackFlow {
    trySend(Resource.Loading)
    val ref = FirebaseManager.getNodeReference(FirebaseConfig.NODE_MATCHES)
    if (ref == null) {
      trySend(Resource.Error(AppError.FirebaseUnavailable()))
      close()
      return@callbackFlow
    }

    val query = ref.limitToLast(limit)
    val listener = object : ValueEventListener {
      override fun onDataChange(snapshot: DataSnapshot) {
        val matches = snapshot.children.mapNotNull { it.getValue(MatchEntity::class.java) }
        trySend(Resource.Success(matches.reversed()))
      }

      override fun onCancelled(error: DatabaseError) {
        trySend(Resource.Error(AppError.FirebaseUnavailable(error.message)))
      }
    }

    query.addValueEventListener(listener)
    awaitClose { query.removeEventListener(listener) }
  }

  override fun getPendingDeposits(): Flow<Resource<List<DepositEntity>>> = callbackFlow {
    trySend(Resource.Loading)
    val ref = FirebaseManager.getNodeReference(FirebaseConfig.NODE_DEPOSITS)
    if (ref == null) {
      trySend(Resource.Error(AppError.FirebaseUnavailable()))
      close()
      return@callbackFlow
    }

    val query = ref.orderByChild("status").equalTo(DepositStatus.SUBMITTED.name)
    val listener = object : ValueEventListener {
      override fun onDataChange(snapshot: DataSnapshot) {
        val deposits = snapshot.children.mapNotNull { it.getValue(DepositEntity::class.java) }
        trySend(Resource.Success(deposits))
      }

      override fun onCancelled(error: DatabaseError) {
        trySend(Resource.Error(AppError.FirebaseUnavailable(error.message)))
      }
    }

    query.addValueEventListener(listener)
    awaitClose { query.removeEventListener(listener) }
  }

  override fun getPendingWithdrawals(): Flow<Resource<List<WithdrawalEntity>>> = callbackFlow {
    trySend(Resource.Loading)
    val ref = FirebaseManager.getNodeReference(FirebaseConfig.NODE_WITHDRAWALS)
    if (ref == null) {
      trySend(Resource.Error(AppError.FirebaseUnavailable()))
      close()
      return@callbackFlow
    }

    val query = ref.orderByChild("status").equalTo(WithdrawalStatus.REQUESTED.name)
    val listener = object : ValueEventListener {
      override fun onDataChange(snapshot: DataSnapshot) {
        val withdrawals = snapshot.children.mapNotNull { it.getValue(WithdrawalEntity::class.java) }
        trySend(Resource.Success(withdrawals))
      }

      override fun onCancelled(error: DatabaseError) {
        trySend(Resource.Error(AppError.FirebaseUnavailable(error.message)))
      }
    }

    query.addValueEventListener(listener)
    awaitClose { query.removeEventListener(listener) }
  }

  override fun getPendingResults(): Flow<Resource<List<ResultEntity>>> = callbackFlow {
    trySend(Resource.Loading)
    val ref = FirebaseManager.getNodeReference(FirebaseConfig.NODE_RESULTS)
    if (ref == null) {
      trySend(Resource.Error(AppError.FirebaseUnavailable()))
      close()
      return@callbackFlow
    }

    val query = ref.orderByChild("status").equalTo(ResultStatus.PENDING_REVIEW.name)
    val listener = object : ValueEventListener {
      override fun onDataChange(snapshot: DataSnapshot) {
        val results = snapshot.children.mapNotNull { it.getValue(ResultEntity::class.java) }
        trySend(Resource.Success(results))
      }

      override fun onCancelled(error: DatabaseError) {
        trySend(Resource.Error(AppError.FirebaseUnavailable(error.message)))
      }
    }

    query.addValueEventListener(listener)
    awaitClose { query.removeEventListener(listener) }
  }

  override fun getAuditLogs(limit: Int): Flow<Resource<List<AuditLogEntity>>> = callbackFlow {
    trySend(Resource.Loading)
    val ref = FirebaseManager.getNodeReference(FirebaseConfig.NODE_AUDIT_LOGS)
    if (ref == null) {
      trySend(Resource.Error(AppError.FirebaseUnavailable()))
      close()
      return@callbackFlow
    }

    val query = ref.limitToLast(limit)
    val listener = object : ValueEventListener {
      override fun onDataChange(snapshot: DataSnapshot) {
        val logs = snapshot.children.mapNotNull { it.getValue(AuditLogEntity::class.java) }
        trySend(Resource.Success(logs.reversed()))
      }

      override fun onCancelled(error: DatabaseError) {
        trySend(Resource.Error(AppError.FirebaseUnavailable(error.message)))
      }
    }

    query.addValueEventListener(listener)
    awaitClose { query.removeEventListener(listener) }
  }

  override fun getAdminUsers(): Flow<Resource<List<AdminUserEntity>>> = callbackFlow {
    trySend(Resource.Loading)
    val ref = FirebaseManager.getNodeReference(FirebaseConfig.NODE_ADMIN_USERS)
    if (ref == null) {
      trySend(Resource.Error(AppError.FirebaseUnavailable()))
      close()
      return@callbackFlow
    }

    val listener = object : ValueEventListener {
      override fun onDataChange(snapshot: DataSnapshot) {
        val admins = snapshot.children.mapNotNull { it.getValue(AdminUserEntity::class.java) }
        trySend(Resource.Success(admins))
      }

      override fun onCancelled(error: DatabaseError) {
        trySend(Resource.Error(AppError.FirebaseUnavailable(error.message)))
      }
    }

    ref.addValueEventListener(listener)
    awaitClose { ref.removeEventListener(listener) }
  }

  override fun checkIsAdmin(userId: String): Flow<Resource<Boolean>> = callbackFlow {
    trySend(Resource.Loading)
    val ref = FirebaseManager.getNodeReference(FirebaseConfig.NODE_ADMIN_USERS)?.child(userId)
    if (ref == null) {
      trySend(Resource.Success(false))
      close()
      return@callbackFlow
    }

    val listener = object : ValueEventListener {
      override fun onDataChange(snapshot: DataSnapshot) {
        val admin = snapshot.getValue(AdminUserEntity::class.java)
        trySend(Resource.Success(admin?.isActive == true))
      }

      override fun onCancelled(error: DatabaseError) {
        trySend(Resource.Success(false))
      }
    }

    ref.addListenerForSingleValueEvent(listener)
    awaitClose { ref.removeEventListener(listener) }
  }
}

class FirebaseSettingsRepository : SettingsRepository {
  override fun getAppSettings(): Flow<Resource<AppSettingsEntity>> = callbackFlow {
    trySend(Resource.Loading)
    val ref = FirebaseManager.getNodeReference(FirebaseConfig.NODE_APP_SETTINGS)
    if (ref == null) {
      trySend(Resource.Success(AppSettingsEntity())) // Safe default settings
      close()
      return@callbackFlow
    }

    val listener = object : ValueEventListener {
      override fun onDataChange(snapshot: DataSnapshot) {
        val settings = snapshot.getValue(AppSettingsEntity::class.java) ?: AppSettingsEntity()
        trySend(Resource.Success(settings))
      }

      override fun onCancelled(error: DatabaseError) {
        trySend(Resource.Success(AppSettingsEntity())) // fallback to safe default
      }
    }

    ref.addValueEventListener(listener)
    awaitClose { ref.removeEventListener(listener) }
  }
}

class FirebaseAuthRepository : AuthRepository {
  private val _currentUserState = kotlinx.coroutines.flow.MutableStateFlow<UserEntity?>(
    UserEntity(
      userId = "AD-USER-9481",
      displayName = "Rohit Sharma",
      phoneNumber = "9876543210",
      avatarUrl = "",
      role = "PLAYER",
      isBlocked = false,
      totalMatches = 38,
      wins = 26,
      losses = 12,
      totalWinnings = 1850.0,
      walletBalance = 240.0,
      createdAt = 1715000000000L,
      lastActiveAt = System.currentTimeMillis(),
    )
  )

  override fun getCurrentUserId(): String? = _currentUserState.value?.userId

  override fun isUserSignedIn(): Boolean = _currentUserState.value != null

  override fun getCurrentUser(): Flow<UserEntity?> = _currentUserState

  override suspend fun loginWithPhone(phoneNumber: String, passwordHash: String): Resource<UserEntity> {
    if (phoneNumber.length != 10) {
      return Resource.Error(AppError.InvalidInput(reason = "Please enter a valid 10-digit mobile number"))
    }
    if (passwordHash.isBlank()) {
      return Resource.Error(AppError.InvalidInput(reason = "Password cannot be blank"))
    }

    // Simulation check: if phone is "9999999999", demonstrate blocked account behavior
    if (phoneNumber == "9999999999") {
      return Resource.Error(AppError.InvalidInput(reason = "This account is suspended/blocked. You cannot log in or participate."))
    }

    val user = UserEntity(
      userId = "AD-USER-${phoneNumber.takeLast(4)}",
      displayName = if (phoneNumber == "9876543210") "Rohit Sharma" else "Player ${phoneNumber.takeLast(4)}",
      phoneNumber = phoneNumber,
      role = "PLAYER",
      isBlocked = false,
      totalMatches = 38,
      wins = 26,
      losses = 12,
      totalWinnings = 1850.0,
      walletBalance = 240.0,
      createdAt = 1715000000000L,
      lastActiveAt = System.currentTimeMillis(),
    )
    _currentUserState.value = user
    return Resource.Success(user)
  }

  override suspend fun registerUser(name: String, phoneNumber: String, passwordHash: String): Resource<UserEntity> {
    if (name.isBlank()) {
      return Resource.Error(AppError.InvalidInput(reason = "Name cannot be empty"))
    }
    if (phoneNumber.length != 10) {
      return Resource.Error(AppError.InvalidInput(reason = "Please enter a valid 10-digit mobile number"))
    }
    val newUser = UserEntity(
      userId = "AD-USER-${System.currentTimeMillis().toString().takeLast(5)}",
      displayName = name.trim(),
      phoneNumber = phoneNumber.trim(),
      role = "PLAYER",
      isBlocked = false,
      totalMatches = 0,
      wins = 0,
      losses = 0,
      totalWinnings = 0.0,
      walletBalance = 0.0,
      createdAt = System.currentTimeMillis(),
      lastActiveAt = System.currentTimeMillis(),
    )
    _currentUserState.value = newUser
    return Resource.Success(newUser)
  }

  override suspend fun sendPasswordResetOtp(phoneNumber: String): Resource<String> {
    if (phoneNumber.length != 10) {
      return Resource.Error(AppError.InvalidInput(reason = "Invalid 10-digit mobile number"))
    }
    // Returns verification reference token
    return Resource.Success("OTP sent successfully to +91 $phoneNumber")
  }

  override suspend fun verifyOtpAndResetPassword(phoneNumber: String, otp: String, newPasswordHash: String): Resource<Unit> {
    if (otp.length != 6) {
      return Resource.Error(AppError.InvalidInput(reason = "Please enter a valid 6-digit verification OTP"))
    }
    if (newPasswordHash.isBlank()) {
      return Resource.Error(AppError.InvalidInput(reason = "New password cannot be empty"))
    }
    return Resource.Success(Unit)
  }

  override suspend fun updateDisplayName(userId: String, newName: String): Resource<Unit> {
    val current = _currentUserState.value
    if (current != null) {
      _currentUserState.value = current.copy(displayName = newName.trim())
    }
    return Resource.Success(Unit)
  }

  override suspend fun updateProfilePhoto(userId: String, photoUrl: String): Resource<Unit> {
    val current = _currentUserState.value
    if (current != null) {
      _currentUserState.value = current.copy(avatarUrl = photoUrl)
    }
    return Resource.Success(Unit)
  }

  override suspend fun signOut(): Resource<Unit> {
    _currentUserState.value = null
    return Resource.Success(Unit)
  }
}
