package com.example.domain.model

import com.google.firebase.database.IgnoreExtraProperties

/**
 * 1. Approved Node: "users"
 */
@IgnoreExtraProperties
data class UserEntity(
  val userId: String = "",
  val displayName: String = "",
  val phoneNumber: String = "",
  val avatarUrl: String = "",
  val role: String = "PLAYER", // PLAYER, ADMIN
  val isBlocked: Boolean = false,
  val totalMatches: Int = 0,
  val wins: Int = 0,
  val losses: Int = 0,
  val totalWinnings: Double = 0.0,
  val walletBalance: Double = 0.0,
  val createdAt: Long = 0L,
  val lastActiveAt: Long = 0L,
)

/**
 * 2. Approved Node: "wallets"
 * SECURITY NOTICE: Read-only on the client side.
 * Clients MUST NEVER mutate balance directly. All transactions and balances
 * are calculated and verified server-side.
 */
@IgnoreExtraProperties
data class WalletEntity(
  val walletId: String = "",
  val userId: String = "",
  val balance: Double = 0.0, // Available balance
  val winningBalance: Double = 0.0, // Winnings balance
  val lockedBalance: Double = 0.0, // Held / pending balance
  val bonusBalance: Double = 0.0,
  val updatedAt: Long = 0L,
)

/**
 * 3. Approved Node: "transactions"
 */
enum class TransactionType {
  DEPOSIT,
  WITHDRAWAL,
  MATCH_ENTRY_FEE,
  MATCH_PRIZE_CREDIT,
  REFUND,
  ADMIN_ADJUSTMENT,
  COMMISSION
}

enum class TransactionStatus {
  PENDING,
  COMPLETED,
  FAILED,
  CANCELLED
}

@IgnoreExtraProperties
data class TransactionEntity(
  val transactionId: String = "",
  val walletId: String = "",
  val userId: String = "",
  val type: String = TransactionType.DEPOSIT.name,
  val amount: Double = 0.0,
  val beforeBalance: Double = 0.0,
  val afterBalance: Double = 0.0,
  val status: String = TransactionStatus.PENDING.name,
  val referenceId: String = "", // MatchId or PaymentReference
  val source: String = "APP",
  val description: String = "",
  val createdAt: Long = 0L,
)

/**
 * 4. Approved Node: "matches"
 */
enum class GameType {
  LUDO,
  CARROM
}

enum class MatchStatus {
  AVAILABLE,
  FULL,
  CODE_ADDED,
  RUNNING,
  RESULT_SUBMITTED,
  COMPLETED,
  PAUSED,
  DISABLED,
  CANCELLED,
  UPCOMING // Alias for available scheduled
}

@IgnoreExtraProperties
data class MatchEntity(
  val matchId: String = "",
  val matchNumber: String = "",
  val title: String = "",
  val gameType: String = GameType.LUDO.name,
  val entryFee: Double = 0.0,
  val prizePool: Double = 0.0,
  val status: String = MatchStatus.AVAILABLE.name,
  val gameCode: String = "", // Set by Super Admin from external game
  val isCodeVisible: Boolean = false, // Visible only to joined players after being added
  val scheduledTime: Long = 0L,
  val maxPlayers: Int = 2,
  val joinedPlayersCount: Int = 0,
  val winnerUserId: String = "",
  val createdByAdminId: String = "",
  val createdAt: Long = 0L,
)

/**
 * 5. Approved Node: "matchPlayers"
 */
enum class PlayerSlot {
  PLAYER_1,
  PLAYER_2
}

@IgnoreExtraProperties
data class MatchPlayerEntity(
  val matchPlayerId: String = "",
  val matchId: String = "",
  val userId: String = "",
  val username: String = "",
  val slot: String = PlayerSlot.PLAYER_1.name,
  val joinedAt: Long = 0L,
  val isReady: Boolean = false,
)

/**
 * 6. Approved Node: "results"
 */
enum class ResultStatus {
  PENDING_REVIEW,
  APPROVED,
  REJECTED
}

@IgnoreExtraProperties
data class ResultEntity(
  val resultId: String = "",
  val matchId: String = "",
  val submittedByUserId: String = "",
  val claimedWinnerUserId: String = "",
  val proofScreenshotUrl: String = "",
  val status: String = ResultStatus.PENDING_REVIEW.name,
  val reviewNotes: String = "",
  val reviewedByAdminId: String = "",
  val submittedAt: Long = 0L,
  val reviewedAt: Long = 0L,
)

/**
 * 7. Approved Node: "deposits"
 */
enum class DepositStatus {
  SUBMITTED,
  VERIFYING,
  APPROVED,
  REJECTED
}

@IgnoreExtraProperties
data class DepositEntity(
  val depositId: String = "",
  val userId: String = "",
  val amount: Double = 0.0,
  val paymentMethod: String = "",
  val transactionReference: String = "",
  val screenshotProofUrl: String = "",
  val status: String = DepositStatus.SUBMITTED.name,
  val createdAt: Long = 0L,
  val approvedAt: Long = 0L,
)

/**
 * 8. Approved Node: "withdrawals"
 */
enum class WithdrawalStatus {
  REQUESTED,
  PROCESSING,
  COMPLETED,
  REJECTED
}

@IgnoreExtraProperties
data class WithdrawalEntity(
  val withdrawalId: String = "",
  val userId: String = "",
  val amount: Double = 0.0,
  val paymentMethod: String = "", // UPI, Bank Transfer
  val paymentDetails: String = "",
  val status: String = WithdrawalStatus.REQUESTED.name,
  val requestedAt: Long = 0L,
  val processedAt: Long = 0L,
)

/**
 * 9. Approved Node: "notifications"
 */
@IgnoreExtraProperties
data class NotificationEntity(
  val notificationId: String = "",
  val userId: String = "",
  val title: String = "",
  val body: String = "",
  val targetScreen: String = "",
  val isRead: Boolean = false,
  val createdAt: Long = 0L,
)

/**
 * 10. Approved Node: "adminUsers"
 */
@IgnoreExtraProperties
data class AdminUserEntity(
  val adminId: String = "",
  val userId: String = "",
  val email: String = "",
  val role: String = "MODERATOR", // SUPER_ADMIN, MODERATOR
  val permissions: List<String> = emptyList(),
  val isActive: Boolean = true,
  val createdAt: Long = 0L,
)

/**
 * 11. Approved Node: "auditLogs"
 */
@IgnoreExtraProperties
data class AuditLogEntity(
  val logId: String = "",
  val action: String = "",
  val performedByUserId: String = "",
  val targetEntityId: String = "",
  val targetEntityType: String = "",
  val details: String = "",
  val timestamp: Long = 0L,
)

/**
 * 12. Approved Node: "appSettings"
 */
@IgnoreExtraProperties
data class AppSettingsEntity(
  val minDepositAmount: Double = 50.0,
  val minWithdrawalAmount: Double = 100.0,
  val platformCommissionPercent: Double = 10.0,
  val maintenanceMode: Boolean = false,
  val supportWhatsappNumber: String = "",
  val supportTelegramUrl: String = "",
  val appVersionCode: Int = 1,
)
