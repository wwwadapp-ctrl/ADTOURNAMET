package com.example.domain.repository

import com.example.core.error.Resource
import com.example.domain.model.*
import kotlinx.coroutines.flow.Flow

/**
 * Repository interface for match operations.
 * Bounded query design ensures minimal Firebase reads.
 */
interface MatchRepository {
  fun getAvailableMatches(limit: Int = 20): Flow<Resource<List<MatchEntity>>>
  fun getMyJoinedMatches(userId: String): Flow<Resource<List<MatchEntity>>>
  fun getUpcomingMatches(limit: Int = 20): Flow<Resource<List<MatchEntity>>>
  fun getMatchHistory(userId: String, limit: Int = 20): Flow<Resource<List<MatchEntity>>>
  fun getMatchById(matchId: String): Flow<Resource<MatchEntity?>>
  fun getMatchPlayers(matchId: String): Flow<Resource<List<MatchPlayerEntity>>>
}

/**
 * Repository interface for wallet and transaction queries.
 * SECURITY DIRECTIVE: Read-only on the Android client. No client-side balance manipulation.
 */
interface WalletRepository {
  fun getWallet(userId: String): Flow<Resource<WalletEntity?>>
  fun getTransactions(userId: String, limit: Int = 25): Flow<Resource<List<TransactionEntity>>>
}

/**
 * Repository interface for match result submissions and reviews.
 */
interface ResultRepository {
  fun getResultForMatch(matchId: String): Flow<Resource<ResultEntity?>>
}

/**
 * Repository interface for user notifications.
 */
interface NotificationRepository {
  fun getNotifications(userId: String, limit: Int = 30): Flow<Resource<List<NotificationEntity>>>
  suspend fun markAsRead(notificationId: String): Resource<Unit>
}

/**
 * Repository interface for admin operations foundation.
 */
interface AdminRepository {
  fun getAllMatches(limit: Int = 30): Flow<Resource<List<MatchEntity>>>
  fun getPendingDeposits(): Flow<Resource<List<DepositEntity>>>
  fun getPendingWithdrawals(): Flow<Resource<List<WithdrawalEntity>>>
  fun getPendingResults(): Flow<Resource<List<ResultEntity>>>
  fun getAuditLogs(limit: Int = 50): Flow<Resource<List<AuditLogEntity>>>
  fun getAdminUsers(): Flow<Resource<List<AdminUserEntity>>>
  fun checkIsAdmin(userId: String): Flow<Resource<Boolean>>
}

/**
 * Repository interface for app settings and platform configuration.
 */
interface SettingsRepository {
  fun getAppSettings(): Flow<Resource<AppSettingsEntity>>
}

/**
 * Repository interface for authentication foundation (Phase 2 readiness).
 */
interface AuthRepository {
  fun getCurrentUserId(): String?
  fun isUserSignedIn(): Boolean
  fun getCurrentUser(): Flow<UserEntity?>
  suspend fun loginWithPhone(phoneNumber: String, passwordHash: String): Resource<UserEntity>
  suspend fun registerUser(name: String, phoneNumber: String, passwordHash: String): Resource<UserEntity>
  suspend fun sendPasswordResetOtp(phoneNumber: String): Resource<String>
  suspend fun verifyOtpAndResetPassword(phoneNumber: String, otp: String, newPasswordHash: String): Resource<Unit>
  suspend fun updateDisplayName(userId: String, newName: String): Resource<Unit>
  suspend fun updateProfilePhoto(userId: String, photoUrl: String): Resource<Unit>
  suspend fun signOut(): Resource<Unit>
}
