package com.example

import android.app.Application
import com.example.core.di.AppContainer
import com.example.core.di.DefaultAppContainer
import com.example.core.logging.AppLogger

class AdTournamentApplication : Application() {
  lateinit var container: AppContainer
    private set

  override fun onCreate() {
    super.onCreate()
    AppLogger.i("Application", "AD TOURNAMENT Application initializing")
    container = DefaultAppContainer(this)
  }
}
