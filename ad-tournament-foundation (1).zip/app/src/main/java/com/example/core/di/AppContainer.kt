package com.example.core.di

import android.content.Context
import com.example.core.firebase.FirebaseManager
import com.example.core.network.AndroidNetworkMonitor
import com.example.core.network.NetworkMonitor
import com.example.data.repository.*
import com.example.domain.repository.*

/**
 * Clean dependency container providing instances of repositories and core services.
 */
interface AppContainer {
  val networkMonitor: NetworkMonitor
  val matchRepository: MatchRepository
  val walletRepository: WalletRepository
  val resultRepository: ResultRepository
  val notificationRepository: NotificationRepository
  val adminRepository: AdminRepository
  val settingsRepository: SettingsRepository
  val authRepository: AuthRepository
}

class DefaultAppContainer(
  private val context: Context,
) : AppContainer {

  init {
    FirebaseManager.initialize(context)
  }

  override val networkMonitor: NetworkMonitor by lazy {
    AndroidNetworkMonitor(context)
  }

  override val matchRepository: MatchRepository by lazy {
    FirebaseMatchRepository()
  }

  override val walletRepository: WalletRepository by lazy {
    FirebaseWalletRepository()
  }

  override val resultRepository: ResultRepository by lazy {
    FirebaseResultRepository()
  }

  override val notificationRepository: NotificationRepository by lazy {
    FirebaseNotificationRepository()
  }

  override val adminRepository: AdminRepository by lazy {
    FirebaseAdminRepository()
  }

  override val settingsRepository: SettingsRepository by lazy {
    FirebaseSettingsRepository()
  }

  override val authRepository: AuthRepository by lazy {
    FirebaseAuthRepository()
  }
}
