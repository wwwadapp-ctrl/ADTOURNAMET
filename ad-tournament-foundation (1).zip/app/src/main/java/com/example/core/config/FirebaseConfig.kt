package com.example.core.config

/**
 * Approved Firebase Realtime Database node references and paths.
 * strictly adhering to the 12 approved schema nodes in AD TOURNAMENT specifications.
 */
object FirebaseConfig {
  // 12 Approved Realtime Database Root Nodes
  const val NODE_USERS = "users"
  const val NODE_WALLETS = "wallets"
  const val NODE_TRANSACTIONS = "transactions"
  const val NODE_MATCHES = "matches"
  const val NODE_MATCH_PLAYERS = "matchPlayers"
  const val NODE_RESULTS = "results"
  const val NODE_DEPOSITS = "deposits"
  const val NODE_WITHDRAWALS = "withdrawals"
  const val NODE_NOTIFICATIONS = "notifications"
  const val NODE_ADMIN_USERS = "adminUsers"
  const val NODE_AUDIT_LOGS = "auditLogs"
  const val NODE_APP_SETTINGS = "appSettings"

  // Approved Firebase Cloud Storage Paths
  const val STORAGE_RESULTS_PROOF = "proofs/results"
  const val STORAGE_DEPOSIT_PROOF = "proofs/deposits"
  const val STORAGE_USER_AVATARS = "avatars/users"

  // FCM Notification Topics
  const val FCM_TOPIC_ANNOUNCEMENTS = "announcements"
  const val FCM_TOPIC_MATCH_ALERTS = "match_alerts"
  const val FCM_TOPIC_ADMIN_ALERTS = "admin_alerts"
}
