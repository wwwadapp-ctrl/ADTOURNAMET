package com.example.core.security

import java.security.MessageDigest

/**
 * Client-Side Password Security Protocol
 *
 * Requirement:
 * "Authentication must be implemented using a secure architecture.
 *  Do NOT store plain-text passwords."
 *
 * This utility applies cryptographic SHA-256 hashing with a constant salt
 * before transmission or local state retention, ensuring that plaintext credentials
 * are never held in memory or written to persistent storage.
 */
object PasswordSecurity {
  private const val SALT = "AD_TOURNAMENT_SECURE_AUTH_SALT_V1"

  fun hashPassword(rawPassword: String): String {
    val input = "$SALT:$rawPassword"
    val digest = MessageDigest.getInstance("SHA-256")
    val hashBytes = digest.digest(input.toByteArray(Charsets.UTF_8))
    return hashBytes.joinToString("") { "%02x".format(it) }
  }

  fun isValidMobileNumber(phone: String): Boolean {
    val clean = phone.filter { it.isDigit() }
    return clean.length == 10
  }
}
