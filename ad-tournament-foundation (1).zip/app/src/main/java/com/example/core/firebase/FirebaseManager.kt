package com.example.core.firebase

import android.content.Context
import com.example.core.config.FirebaseConfig
import com.example.core.logging.AppLogger
import com.google.firebase.FirebaseApp
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference

/**
 * Safe Firebase provider foundation.
 * Ensures the application never crashes if credentials/configuration are being staged,
 * and encapsulates all node references to the approved schema.
 */
object FirebaseManager {
  private const val TAG = "FirebaseManager"
  private var isInitialized = false

  fun initialize(context: Context) {
    if (isInitialized) return

    try {
      if (FirebaseApp.getApps(context).isEmpty()) {
        val app = FirebaseApp.initializeApp(context)
        AppLogger.i(TAG, "Firebase initialized: ${app != null}")
      } else {
        AppLogger.i(TAG, "Firebase already initialized by content provider")
      }
      isInitialized = true
    } catch (e: Exception) {
      AppLogger.w(TAG, "Firebase initialization handled safely: ${e.message}")
    }
  }

  fun isAvailable(): Boolean {
    return try {
      FirebaseApp.getApps(FirebaseApp.getInstance().applicationContext).isNotEmpty()
    } catch (_: Exception) {
      false
    }
  }

  fun getDatabase(): FirebaseDatabase? {
    return try {
      FirebaseDatabase.getInstance().apply {
        // Enable disk persistence in development/staging if needed
        try {
          setPersistenceEnabled(true)
        } catch (_: Exception) {
          // Persistence can only be set before any other database usage
        }
      }
    } catch (e: Exception) {
      AppLogger.w(TAG, "Realtime Database unavailable: ${e.message}")
      null
    }
  }

  fun getNodeReference(nodeName: String): DatabaseReference? {
    return getDatabase()?.getReference(nodeName)
  }

  fun getStorage(): FirebaseStorage? {
    return try {
      FirebaseStorage.getInstance()
    } catch (e: Exception) {
      AppLogger.w(TAG, "Cloud Storage unavailable: ${e.message}")
      null
    }
  }

  fun getStorageReference(path: String): StorageReference? {
    return getStorage()?.getReference(path)
  }
}
