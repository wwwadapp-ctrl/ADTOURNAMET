package com.example.core.repository

import com.example.core.config.FirebaseAdminConfig
import com.example.core.model.AdminResultItem
import com.example.core.model.NotificationTargetType
import com.example.core.model.ResultStatus
import com.example.core.model.SuperAdminSession
import com.example.core.model.TournamentMath
import com.example.core.model.UserWalletData
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.MutableData
import com.google.firebase.database.Transaction
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.tasks.await
import kotlin.coroutines.resume

data class ResultApprovalResult(
    val success: Boolean,
    val alreadySettled: Boolean = false,
    val errorMessage: String? = null
)

interface ResultsRepository {
    fun observeResults(): Flow<List<AdminResultItem>>
    suspend fun getResult(resultId: String): AdminResultItem?
    suspend fun approveResult(
        resultId: String,
        submittedMatchNumber: String,
        submittedRoomCode: String,
        adminSession: SuperAdminSession
    ): Result<Unit>
    suspend fun rejectResult(
        resultId: String,
        reason: String,
        adminSession: SuperAdminSession
    ): Result<Unit>
}

class FirebaseResultsRepository(
    initialResults: List<AdminResultItem>? = null,
    initialWallets: Map<String, UserWalletData>? = null
) : ResultsRepository {
    companion object {
        val defaultSeedResults = listOf(
            AdminResultItem(
                resultId = "res_seed_001",
                matchId = "mtc_seed_001",
                matchNumber = "#101",
                gameType = "LUDO",
                userId = "usr_tanvir_9812",
                userName = "Tanvir Hasan",
                userPhone = "01712984561",
                roomCode = "7829104",
                proofScreenshotUrl = "data:image/jpeg;base64,/9j/4AAQSkZJRg==",
                screenshotUrl = "data:image/jpeg;base64,/9j/4AAQSkZJRg==",
                prizeMinorUnits = TournamentMath.takaToMinorUnits(750),
                prizeTaka = 750L,
                status = ResultStatus.PENDING,
                rawStatus = "PENDING",
                createdAt = System.currentTimeMillis() - 1800000L
            ),
            AdminResultItem(
                resultId = "res_seed_002",
                matchId = "mtc_seed_002",
                matchNumber = "#102",
                gameType = "CARROM",
                userId = "usr_shakib_4412",
                userName = "Shakib Rahman",
                userPhone = "01823490123",
                roomCode = "5512903",
                proofScreenshotUrl = "data:image/jpeg;base64,/9j/4AAQSkZJRg==",
                screenshotUrl = "data:image/jpeg;base64,/9j/4AAQSkZJRg==",
                prizeMinorUnits = TournamentMath.takaToMinorUnits(1200),
                prizeTaka = 1200L,
                status = ResultStatus.APPROVED,
                rawStatus = "APPROVED",
                createdAt = System.currentTimeMillis() - 7200000L,
                processedAt = System.currentTimeMillis() - 3600000L
            )
        )

        val defaultSeedWallets = mapOf(
            "usr_tanvir_9812" to UserWalletData(
                userId = "usr_tanvir_9812",
                balance = TournamentMath.takaToMinorUnits(1200),
                availableBalance = TournamentMath.takaToMinorUnits(700),
                depositBalance = TournamentMath.takaToMinorUnits(500),
                winningBalance = TournamentMath.takaToMinorUnits(700),
                pendingBalance = TournamentMath.takaToMinorUnits(500),
                totalDeposited = TournamentMath.takaToMinorUnits(2000),
                totalWithdrawn = 0L,
                balanceDouble = 1200.0,
                lockedBalanceDouble = 500.0,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    private val database: FirebaseDatabase? = try {
        FirebaseDatabase.getInstance(FirebaseAdminConfig.RTDB_BASE_URL)
    } catch (e: Exception) {
        null
    }

    private val _resultsMap = (initialResults ?: defaultSeedResults).associateBy { it.resultId }.toMutableMap()
    private val _walletsMap = (initialWallets ?: defaultSeedWallets).toMutableMap()
    private val _creditedResultIds = mutableSetOf<String>()
    private val _localResultsState = MutableStateFlow(_resultsMap.values.toList())

    fun getUserWallet(userId: String): UserWalletData? {
        return _walletsMap[userId]
    }

    private fun verifySuperAdmin(adminSession: SuperAdminSession) {
        if (!adminSession.isSuperAdminVerified || adminSession.uid.isBlank()) {
            throw SecurityException("Unauthorized: Result settlement requires verified Super Admin authorization.")
        }
    }

    override fun observeResults(): Flow<List<AdminResultItem>> {
        val db = database ?: return _localResultsState.asStateFlow()
        return callbackFlow {
            val ref = db.getReference(FirebaseAdminConfig.NODE_RESULTS)
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val list = mutableListOf<AdminResultItem>()
                    for (child in snapshot.children) {
                        try {
                            val resultId = child.key ?: continue
                            val matchId = child.child("matchId").value?.toString()
                                ?: child.child("match_id").value?.toString() ?: ""
                            val matchNumber = child.child("matchNumber").value?.toString()
                                ?: child.child("match_number").value?.toString() ?: "#001"
                            val rawGame = child.child("gameType").value?.toString()
                                ?: child.child("game").value?.toString() ?: "LUDO"
                            val gameType = if (rawGame.contains("carrom", ignoreCase = true)) "CARROM" else "LUDO"
                            val userId = child.child("userId").value?.toString()
                                ?: child.child("uid").value?.toString()
                                ?: child.child("submitterId").value?.toString()
                                ?: child.child("playerUid").value?.toString()
                                ?: child.child("submittedBy").value?.toString()
                                ?: child.child("creatorId").value?.toString()
                                ?: child.child("playerId").value?.toString()
                                ?: child.child("participantId").value?.toString()
                                ?: child.child("user_id").value?.toString()
                                ?: child.child("participant_id").value?.toString()
                                ?: child.child("senderId").value?.toString()
                                ?: child.child("sender_id").value?.toString()
                                ?: child.child("winnerId").value?.toString()
                                ?: child.child("winner_id").value?.toString() ?: ""

                            var userName = child.child("userName").value?.toString()
                                ?: child.child("name").value?.toString()
                                ?: child.child("username").value?.toString()
                                ?: child.child("displayName").value?.toString()
                                ?: child.child("fullName").value?.toString() ?: ""
                            if (userName.isBlank() || userName.equals("Player", ignoreCase = true)) {
                                userName = userId.ifBlank { "Player" }
                            }

                            val userPhone = child.child("userPhone").value?.toString()
                                ?: child.child("phone").value?.toString()
                                ?: child.child("mobile").value?.toString()
                                ?: child.child("contact").value?.toString() ?: ""

                            val roomCode = child.child("roomCode").value?.toString()
                                ?: child.child("code").value?.toString()
                                ?: child.child("gameCode").value?.toString() ?: ""
                            val proofScreenshotUrl = child.child("proofScreenshotUrl").value?.toString()
                                ?: child.child("screenshotUrl").value?.toString()
                                ?: child.child("screenshot").value?.toString()
                                ?: child.child("imageUrl").value?.toString()
                                ?: child.child("proofUrl").value?.toString() ?: ""
                            val screenshotUrl = proofScreenshotUrl

                            var prizeMinor = (child.child("prizeMinorUnits").value as? Number)?.toLong()
                                ?: (child.child("amountMinorUnits").value as? Number)?.toLong()
                                ?: TournamentMath.takaToMinorUnits(
                                    (child.child("prizePool").value as? Number)?.toLong()
                                        ?: (child.child("prize").value as? Number)?.toLong()
                                        ?: (child.child("amount").value as? Number)?.toLong()
                                        ?: (child.child("prizeTaka").value as? Number)?.toLong() ?: 0L
                                )
                            val prizeTaka = (child.child("prizeTaka").value as? Number)?.toLong()
                                ?: TournamentMath.minorUnitsToTaka(prizeMinor)

                            val rawStatus = child.child("status").value?.toString() ?: "PENDING"
                            val status = ResultStatus.fromString(rawStatus)
                            val createdAt = (child.child("createdAt").value as? Number)?.toLong()
                                ?: (child.child("timestamp").value as? Number)?.toLong() ?: System.currentTimeMillis()
                            val processedAt = (child.child("processedAt").value as? Number)?.toLong()
                            val processedBy = child.child("processedBy").value?.toString()
                            val rejectionReason = child.child("rejectionReason").value?.toString()
                                ?: child.child("reason").value?.toString()
                            val settlementTransactionId = child.child("settlementTransactionId").value?.toString()
                                ?: child.child("transactionId").value?.toString() ?: ""

                            list.add(
                                AdminResultItem(
                                    resultId = resultId,
                                    matchId = matchId,
                                    matchNumber = matchNumber,
                                    gameType = gameType,
                                    userId = userId,
                                    userName = userName,
                                    userPhone = userPhone,
                                    roomCode = roomCode,
                                    proofScreenshotUrl = proofScreenshotUrl,
                                    screenshotUrl = proofScreenshotUrl,
                                    prizeMinorUnits = prizeMinor,
                                    prizeTaka = prizeTaka,
                                    status = status,
                                    rawStatus = rawStatus,
                                    createdAt = createdAt,
                                    processedAt = processedAt,
                                    processedBy = processedBy,
                                    rejectionReason = rejectionReason,
                                    settlementTransactionId = settlementTransactionId
                                )
                            )
                        } catch (_: Exception) {
                            // Skip malformed nodes gracefully
                        }
                    }
                    val sorted = list.sortedByDescending { it.createdAt }
                    trySend(sorted)
                }

                override fun onCancelled(error: DatabaseError) {
                    close(error.toException())
                }
            }
            ref.addValueEventListener(listener)
            awaitClose { ref.removeEventListener(listener) }
        }
    }

    override suspend fun getResult(resultId: String): AdminResultItem? {
        val db = database
        if (db == null) {
            return _resultsMap[resultId]
        }
        return try {
            val child = db.getReference(FirebaseAdminConfig.NODE_RESULTS).child(resultId).get().await()
            if (!child.exists()) return null
            resolveResultData(db, resultId, child)
        } catch (_: Exception) {
            null
        }
    }

    private suspend fun resolveResultData(
        db: FirebaseDatabase,
        resultId: String,
        child: DataSnapshot
    ): AdminResultItem {
        val matchId = child.child("matchId").value?.toString()
            ?: child.child("match_id").value?.toString() ?: ""
        val matchNumber = child.child("matchNumber").value?.toString()
            ?: child.child("match_number").value?.toString() ?: "#001"
        val rawGame = child.child("gameType").value?.toString()
            ?: child.child("game").value?.toString() ?: "LUDO"
        val gameType = if (rawGame.contains("carrom", ignoreCase = true)) "CARROM" else "LUDO"
        
        var userId = child.child("userId").value?.toString()
            ?: child.child("uid").value?.toString()
            ?: child.child("submitterId").value?.toString()
            ?: child.child("playerUid").value?.toString()
            ?: child.child("submittedBy").value?.toString()
            ?: child.child("creatorId").value?.toString()
            ?: child.child("playerId").value?.toString()
            ?: child.child("participantId").value?.toString()
            ?: child.child("user_id").value?.toString()
            ?: child.child("participant_id").value?.toString()
            ?: child.child("senderId").value?.toString()
            ?: child.child("sender_id").value?.toString()
            ?: child.child("winnerId").value?.toString()
            ?: child.child("winner_id").value?.toString() ?: ""

        var userName = child.child("userName").value?.toString()
            ?: child.child("name").value?.toString()
            ?: child.child("username").value?.toString()
            ?: child.child("displayName").value?.toString()
            ?: child.child("fullName").value?.toString() ?: ""

        var userPhone = child.child("userPhone").value?.toString()
            ?: child.child("phone").value?.toString()
            ?: child.child("mobile").value?.toString()
            ?: child.child("contact").value?.toString() ?: ""

        val roomCode = child.child("roomCode").value?.toString()
            ?: child.child("code").value?.toString()
            ?: child.child("gameCode").value?.toString() ?: ""

        val proofScreenshotUrl = child.child("proofScreenshotUrl").value?.toString()
            ?: child.child("screenshotUrl").value?.toString()
            ?: child.child("screenshot").value?.toString()
            ?: child.child("imageUrl").value?.toString()
            ?: child.child("proofUrl").value?.toString() ?: ""
        val screenshotUrl = proofScreenshotUrl

        var prizeMinor = (child.child("prizeMinorUnits").value as? Number)?.toLong()
            ?: (child.child("amountMinorUnits").value as? Number)?.toLong()
            ?: TournamentMath.takaToMinorUnits(
                (child.child("prizePool").value as? Number)?.toLong()
                    ?: (child.child("prize").value as? Number)?.toLong()
                    ?: (child.child("amount").value as? Number)?.toLong()
                    ?: (child.child("prizeTaka").value as? Number)?.toLong() ?: 0L
            )

        // Deep resolution from /matches and /matchPlayers if userId or prizeMinor is missing/0
        if ((userId.isBlank() || prizeMinor <= 0L) && matchId.isNotBlank()) {
            try {
                val matchSnap = db.getReference(FirebaseAdminConfig.NODE_MATCHES).child(matchId).get().await()
                if (matchSnap.exists()) {
                    if (userId.isBlank()) {
                        userId = matchSnap.child("winnerUserId").value?.toString()
                            ?: matchSnap.child("winnerId").value?.toString()
                            ?: matchSnap.child("userId").value?.toString() ?: ""
                    }
                    if (prizeMinor <= 0L) {
                        prizeMinor = (matchSnap.child("prizeMinorUnits").value as? Number)?.toLong()
                            ?: TournamentMath.takaToMinorUnits(
                                (matchSnap.child("prizePool").value as? Number)?.toLong()
                                    ?: (matchSnap.child("prize").value as? Number)?.toLong()
                                    ?: (matchSnap.child("amount").value as? Number)?.toLong() ?: 0L
                            )
                    }
                    if (prizeMinor <= 0L) {
                        val entryFeeMinor = (matchSnap.child("entryFeeMinorUnits").value as? Number)?.toLong()
                            ?: TournamentMath.takaToMinorUnits(
                                (matchSnap.child("entryFee").value as? Number)?.toLong()
                                    ?: (matchSnap.child("entryFee").value as? Double)?.toLong() ?: 0L
                            )
                        if (entryFeeMinor > 0L) {
                            prizeMinor = TournamentMath.calculatePrizeMinorUnits(entryFeeMinor)
                        }
                    }
                }

                if (userId.isBlank()) {
                    val playersSnap = db.getReference(FirebaseAdminConfig.NODE_MATCH_PLAYERS).child(matchId).get().await()
                    if (playersSnap.exists()) {
                        var firstPlayerId = ""
                        var firstPlayerName = ""
                        var firstPlayerPhone = ""
                        for (playerChild in playersSnap.children) {
                            val pId = playerChild.key ?: continue
                            val pUserId = playerChild.child("userId").value?.toString()
                                ?: playerChild.child("uid").value?.toString() ?: pId
                            val pName = playerChild.child("username").value?.toString()
                                ?: playerChild.child("name").value?.toString() ?: ""
                            val pPhone = playerChild.child("phone").value?.toString()
                                ?: playerChild.child("mobile").value?.toString() ?: ""
                            val isWinnerFlag = playerChild.child("isWinner").getValue(Boolean::class.java)
                                ?: playerChild.child("winner").getValue(Boolean::class.java)
                                ?: (playerChild.child("status").value?.toString().equals("WON", ignoreCase = true))

                            if (firstPlayerId.isBlank()) {
                                firstPlayerId = pUserId
                                firstPlayerName = pName
                                firstPlayerPhone = pPhone
                            }
                            if (isWinnerFlag) {
                                userId = pUserId
                                if (userName.isBlank() || userName.equals("Player", ignoreCase = true)) {
                                    if (pName.isNotBlank()) userName = pName
                                }
                                if (userPhone.isBlank() && pPhone.isNotBlank()) {
                                    userPhone = pPhone
                                }
                                break
                            }
                        }
                        if (userId.isBlank() && firstPlayerId.isNotBlank()) {
                            userId = firstPlayerId
                            if (userName.isBlank() || userName.equals("Player", ignoreCase = true)) {
                                if (firstPlayerName.isNotBlank()) userName = firstPlayerName
                            }
                            if (userPhone.isBlank() && firstPlayerPhone.isNotBlank()) {
                                userPhone = firstPlayerPhone
                            }
                        }
                    }
                }
            } catch (_: Exception) {}
        }

        if (userId.isNotBlank() && (userName.isBlank() || userName.equals("Player", ignoreCase = true))) {
            try {
                val userSnap = db.getReference(FirebaseAdminConfig.NODE_USERS).child(userId).get().await()
                if (userSnap.exists()) {
                    val uName = userSnap.child("name").value?.toString()
                        ?: userSnap.child("username").value?.toString()
                        ?: userSnap.child("fullName").value?.toString() ?: ""
                    val uPhone = userSnap.child("phone").value?.toString()
                        ?: userSnap.child("mobile").value?.toString() ?: ""
                    if (uName.isNotBlank()) userName = uName
                    if (userPhone.isBlank() && uPhone.isNotBlank()) userPhone = uPhone
                }
            } catch (_: Exception) {}
        }

        if (userName.isBlank() || userName.equals("Player", ignoreCase = true)) {
            userName = userId.ifBlank { "Player" }
        }

        val prizeTaka = TournamentMath.minorUnitsToTaka(prizeMinor)
        val rawStatus = child.child("status").value?.toString() ?: "PENDING"
        val status = ResultStatus.fromString(rawStatus)
        val createdAt = (child.child("createdAt").value as? Number)?.toLong()
            ?: (child.child("timestamp").value as? Number)?.toLong() ?: System.currentTimeMillis()
        val processedAt = (child.child("processedAt").value as? Number)?.toLong()
        val processedBy = child.child("processedBy").value?.toString()
        val rejectionReason = child.child("rejectionReason").value?.toString()
            ?: child.child("reason").value?.toString()
        val settlementTransactionId = child.child("settlementTransactionId").value?.toString()
            ?: child.child("transactionId").value?.toString() ?: ""

        return AdminResultItem(
            resultId = resultId,
            matchId = matchId,
            matchNumber = matchNumber,
            gameType = gameType,
            userId = userId,
            userName = userName,
            userPhone = userPhone,
            roomCode = roomCode,
            proofScreenshotUrl = proofScreenshotUrl,
            screenshotUrl = proofScreenshotUrl,
            prizeMinorUnits = prizeMinor,
            prizeTaka = prizeTaka,
            status = status,
            rawStatus = rawStatus,
            createdAt = createdAt,
            processedAt = processedAt,
            processedBy = processedBy,
            rejectionReason = rejectionReason,
            settlementTransactionId = settlementTransactionId
        )
    }

    override suspend fun approveResult(
        resultId: String,
        submittedMatchNumber: String,
        submittedRoomCode: String,
        adminSession: SuperAdminSession
    ): Result<Unit> = runCatching {
        verifySuperAdmin(adminSession)
        val db = database

        if (db == null) {
            // In-memory offline/test execution path
            val resultItem = getResult(resultId)
                ?: throw IllegalArgumentException("Result submission '$resultId' does not exist.")

            if (resultItem.status == ResultStatus.APPROVED) {
                throw IllegalStateException("Result '$resultId' has already been approved and settled.")
            }
            if (resultItem.status == ResultStatus.REJECTED) {
                throw IllegalStateException("Result '$resultId' was rejected and cannot be approved.")
            }

            val userId = resultItem.userId
            require(userId.isNotBlank()) { "Winner User ID is missing from result submission." }

            if (_creditedResultIds.contains(resultId)) {
                throw IllegalStateException("Result '$resultId' has already been approved or settled concurrently.")
            }

            val prizeMinor = resultItem.prizeMinorUnits
            val now = System.currentTimeMillis()
            val deterministicTrxId = "WIN_$resultId"

            val currentWallet = _walletsMap[userId] ?: UserWalletData(userId = userId)
            val updatedWallet = currentWallet.copy(
                balance = currentWallet.balance + prizeMinor,
                availableBalance = currentWallet.availableBalance + prizeMinor,
                winningBalance = currentWallet.winningBalance + prizeMinor,
                balanceDouble = (currentWallet.balance + prizeMinor) / 100.0,
                updatedAt = now
            )
            _walletsMap[userId] = updatedWallet
            _creditedResultIds.add(resultId)

            // Update result item (mark approved and remove proofScreenshotUrl)
            val approvedItem = resultItem.copy(
                status = ResultStatus.APPROVED,
                rawStatus = ResultStatus.APPROVED.name,
                proofScreenshotUrl = "",
                screenshotUrl = "",
                processedAt = now,
                processedBy = adminSession.identifier,
                settlementTransactionId = deterministicTrxId
            )
            _resultsMap[resultId] = approvedItem
            _localResultsState.value = _resultsMap.values.toList()

            sendResultNotification(
                userId = userId,
                title = "Match Winning Prize Credited! / ম্যাচ বিজয়ী পুরস্কার যোগ হয়েছে",
                message = "Congratulations! You won match ${resultItem.matchNumber}. Prize of ৳${resultItem.prizeTaka} has been credited to your wallet balance.",
                adminSession = adminSession
            )

            return@runCatching
        }

        // Production Firebase Realtime Database path
        val resultItem = getResult(resultId)
            ?: throw IllegalArgumentException("Result submission '$resultId' does not exist.")

        if (resultItem.status == ResultStatus.APPROVED) {
            throw IllegalStateException("Result '$resultId' has already been approved and settled.")
        }
        if (resultItem.status == ResultStatus.REJECTED) {
            throw IllegalStateException("Result '$resultId' was rejected and cannot be approved.")
        }

        val matchId = resultItem.matchId
        require(matchId.isNotBlank()) { "Result submission is not linked to any match ID." }

        // Fetch authoritative match details from /matches/{matchId}
        val matchSnapshot = db.getReference(FirebaseAdminConfig.NODE_MATCHES).child(matchId).get().await()
        if (!matchSnapshot.exists()) {
            throw IllegalArgumentException("Linked match ID '$matchId' does not exist in the system.")
        }

        val canonicalMatchNumber = matchSnapshot.child("matchNumber").value?.toString()
            ?: matchSnapshot.child("match_number").value?.toString() ?: resultItem.matchNumber
        val authoritativeGameCode = matchSnapshot.child("gameCode").value?.toString()
            ?: matchSnapshot.child("code").value?.toString()
            ?: matchSnapshot.child("game_code").value?.toString() ?: ""
        val authoritativePrizeMinor = (matchSnapshot.child("prizeMinorUnits").value as? Number)?.toLong()
            ?: TournamentMath.takaToMinorUnits((matchSnapshot.child("prizePool").value as? Number)?.toLong()
                ?: (matchSnapshot.child("prize").value as? Number)?.toLong()
                ?: resultItem.prizeTaka)

        // Strict correspondence check
        val cleanSubmittedMatchNum = submittedMatchNumber.trim().lowercase()
        val cleanCanonicalMatchNum = canonicalMatchNumber.trim().lowercase()
        require(cleanSubmittedMatchNum == cleanCanonicalMatchNum || resultItem.matchNumber.trim().lowercase() == cleanCanonicalMatchNum) {
            "Match verification mismatch: Submitted Match Number ($submittedMatchNumber) does not correspond to system Match Number ($canonicalMatchNumber)."
        }

        val cleanSubmittedRoomCode = submittedRoomCode.trim()
        val cleanAuthoritativeRoomCode = authoritativeGameCode.trim()
        if (cleanAuthoritativeRoomCode.isNotBlank()) {
            require(cleanSubmittedRoomCode.equals(cleanAuthoritativeRoomCode, ignoreCase = true) || cleanSubmittedRoomCode.equals(resultItem.roomCode.trim(), ignoreCase = true)) {
                "Room Code verification mismatch: Submitted Room Code ($submittedRoomCode) does not correspond to authoritative system Room Code."
            }
        }

        val userId = resultItem.userId
        require(userId.isNotBlank()) { "Winner User ID is missing from result submission." }

        val now = System.currentTimeMillis()
        val deterministicTrxId = "WIN_$resultId"
        val deterministicLogId = "AUDIT_WIN_$resultId"
        val prizeTaka = TournamentMath.minorUnitsToTaka(authoritativePrizeMinor)

        // Step 1: Authoritative atomic status lock on /results/{resultId}
        val resultRef = db.getReference(FirebaseAdminConfig.NODE_RESULTS).child(resultId)
        val lockResult = executeResultApprovalLockTransaction(
            resultRef = resultRef,
            adminSession = adminSession,
            settlementTrxId = deterministicTrxId,
            authoritativePrizeMinor = authoritativePrizeMinor,
            now = now
        )

        if (!lockResult.success) {
            if (lockResult.alreadySettled) {
                throw IllegalStateException("Result '$resultId' has already been approved or settled concurrently.")
            }
            throw IllegalStateException(lockResult.errorMessage ?: "Failed to lock result status for approval.")
        }

        // Step 2: Atomic wallet prize credit via runTransaction on /wallets/{userId}
        val walletRef = db.getReference(FirebaseAdminConfig.NODE_WALLETS).child(userId)
        val walletCreditResult = executeWalletPrizeCreditTransaction(
            walletRef = walletRef,
            resultId = resultId,
            prizeMinorUnits = authoritativePrizeMinor,
            now = now
        )

        if (!walletCreditResult.success) {
            throw IllegalStateException(walletCreditResult.errorMessage ?: "Wallet prize credit transaction failed.")
        }

        // Step 3: Write secondary mirrored nodes, match winner updates, ledger transaction, audit logs, and nullify proofScreenshotUrl
        val userResultsNodeKey = "userResults"
        val updates = mutableMapOf<String, Any?>(
            // User result mirror update
            "$userResultsNodeKey/$userId/$resultId/status" to ResultStatus.APPROVED.name,
            "$userResultsNodeKey/$userId/$resultId/processedAt" to now,
            "$userResultsNodeKey/$userId/$resultId/processedBy" to adminSession.identifier,
            "$userResultsNodeKey/$userId/$resultId/settlementTransactionId" to deterministicTrxId,
            "$userResultsNodeKey/$userId/$resultId/proofScreenshotUrl" to null,
            "$userResultsNodeKey/$userId/$resultId/screenshotUrl" to null,

            // Root result screenshot removal
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/proofScreenshotUrl" to null,
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/screenshotUrl" to null,

            // Update match winner & status in /matches/{matchId}
            "${FirebaseAdminConfig.NODE_MATCHES}/$matchId/winnerUserId" to userId,
            "${FirebaseAdminConfig.NODE_MATCHES}/$matchId/status" to "COMPLETED",
            "${FirebaseAdminConfig.NODE_MATCHES}/$matchId/updatedAt" to now,

            // Profile consistency update in /users/{userId}
            "${FirebaseAdminConfig.NODE_USERS}/$userId/balance" to walletCreditResult.newBalance,
            "${FirebaseAdminConfig.NODE_USERS}/$userId/winningBalance" to walletCreditResult.newWinningBalance,
            "${FirebaseAdminConfig.NODE_USERS}/$userId/updatedAt" to now,

            // Global ledger record in /transactions/{deterministicTrxId}
            "${FirebaseAdminConfig.NODE_TRANSACTIONS}/$deterministicTrxId" to mapOf(
                "transactionId" to deterministicTrxId,
                "resultId" to resultId,
                "matchId" to matchId,
                "userId" to userId,
                "amount" to prizeTaka,
                "amountMinorUnits" to authoritativePrizeMinor,
                "type" to "PRIZE_WIN",
                "direction" to "CREDIT",
                "status" to "COMPLETED",
                "timestamp" to now,
                "processedBy" to adminSession.identifier,
                "description" to "Prize winning payout of ৳$prizeTaka credited for match $canonicalMatchNumber"
            ),

            // User ledger mirror in /userTransactions/{userId}/{deterministicTrxId}
            "${FirebaseAdminConfig.NODE_USER_TRANSACTIONS}/$userId/$deterministicTrxId" to mapOf(
                "transactionId" to deterministicTrxId,
                "resultId" to resultId,
                "matchId" to matchId,
                "amount" to prizeTaka,
                "amountMinorUnits" to authoritativePrizeMinor,
                "type" to "PRIZE_WIN",
                "direction" to "CREDIT",
                "status" to "COMPLETED",
                "timestamp" to now,
                "description" to "Won match $canonicalMatchNumber — Prize credited: ৳$prizeTaka"
            ),

            // Immutable audit log entry in /auditLogs/{deterministicLogId}
            "${FirebaseAdminConfig.NODE_AUDIT_LOGS}/$deterministicLogId" to mapOf(
                "action" to "MATCH_RESULT_APPROVED",
                "admin" to adminSession.identifier,
                "referenceId" to resultId,
                "matchId" to matchId,
                "timestamp" to now,
                "reason" to "Super Admin approved result for match $canonicalMatchNumber. Credited prize of ৳$prizeTaka to winner $userId",
                "amount" to prizeTaka,
                "amountMinorUnits" to authoritativePrizeMinor,
                "userId" to userId,
                "transactionId" to deterministicTrxId
            )
        )

        db.reference.updateChildren(updates).await()

        // Step 4: Idempotent screenshot cleanup after primary financial & status settlement (never rolls back approval)
        try {
            db.getReference(FirebaseAdminConfig.NODE_RESULTS).child(resultId).child("proofScreenshotUrl").removeValue().await()
            db.getReference(FirebaseAdminConfig.NODE_RESULTS).child(resultId).child("screenshotUrl").removeValue().await()
            if (userId.isNotBlank()) {
                db.getReference(userResultsNodeKey).child(userId).child(resultId).child("proofScreenshotUrl").removeValue().await()
                db.getReference(userResultsNodeKey).child(userId).child(resultId).child("screenshotUrl").removeValue().await()
            }
        } catch (_: Exception) {
            // Screenshot cleanup failure must never fail the successful financial settlement
        }

        // Step 5: Send notification to winner
        sendResultNotification(
            userId = userId,
            title = "Match Winning Prize Credited! / ম্যাচ বিজয়ী পুরস্কার যোগ হয়েছে",
            message = "Congratulations! You won match $canonicalMatchNumber. Prize of ৳$prizeTaka has been credited to your wallet balance.",
            adminSession = adminSession
        )
    }

    override suspend fun rejectResult(
        resultId: String,
        reason: String,
        adminSession: SuperAdminSession
    ): Result<Unit> = runCatching {
        verifySuperAdmin(adminSession)
        val trimmedReason = reason.trim()
        require(trimmedReason.isNotBlank()) { "Rejection reason is required." }

        val db = database

        if (db == null) {
            // In-memory offline/test execution path
            val resultItem = getResult(resultId)
                ?: throw IllegalArgumentException("Result submission '$resultId' does not exist.")

            if (resultItem.status == ResultStatus.APPROVED) {
                throw IllegalStateException("Result '$resultId' is already approved and settled.")
            }
            if (resultItem.status == ResultStatus.REJECTED) {
                throw IllegalStateException("Result '$resultId' is already rejected.")
            }

            val now = System.currentTimeMillis()
            val userId = resultItem.userId

            val rejectedItem = resultItem.copy(
                status = ResultStatus.REJECTED,
                rawStatus = ResultStatus.REJECTED.name,
                proofScreenshotUrl = "",
                screenshotUrl = "",
                rejectionReason = trimmedReason,
                processedAt = now,
                processedBy = adminSession.identifier
            )
            _resultsMap[resultId] = rejectedItem
            _localResultsState.value = _resultsMap.values.toList()

            if (userId.isNotBlank()) {
                sendResultNotification(
                    userId = userId,
                    title = "Result Submission Rejected / রেজাল্ট বাতিল করা হয়েছে",
                    message = "Your result submission for match ${resultItem.matchNumber} was rejected. Reason: $trimmedReason",
                    adminSession = adminSession
                )
            }

            return@runCatching
        }

        // Production Firebase Realtime Database path
        val resultItem = getResult(resultId)
            ?: throw IllegalArgumentException("Result submission '$resultId' does not exist.")

        if (resultItem.status == ResultStatus.APPROVED) {
            throw IllegalStateException("Result '$resultId' is already approved and settled.")
        }
        if (resultItem.status == ResultStatus.REJECTED) {
            throw IllegalStateException("Result '$resultId' is already rejected.")
        }

        val now = System.currentTimeMillis()
        val userId = resultItem.userId
        val deterministicLogId = "AUDIT_REJ_RES_$resultId"
        val userResultsNodeKey = "userResults"

        val updates = mutableMapOf<String, Any?>(
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/status" to ResultStatus.REJECTED.name,
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/rejectionReason" to trimmedReason,
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/proofScreenshotUrl" to null,
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/screenshotUrl" to null,
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/processedAt" to now,
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/processedBy" to adminSession.identifier,
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/updatedAt" to now,

            "${FirebaseAdminConfig.NODE_AUDIT_LOGS}/$deterministicLogId" to mapOf(
                "action" to "MATCH_RESULT_REJECTED",
                "admin" to adminSession.identifier,
                "referenceId" to resultId,
                "timestamp" to now,
                "reason" to "Super Admin rejected result submission: $trimmedReason"
            )
        )

        if (userId.isNotBlank()) {
            updates["$userResultsNodeKey/$userId/$resultId/status"] = ResultStatus.REJECTED.name
            updates["$userResultsNodeKey/$userId/$resultId/rejectionReason"] = trimmedReason
            updates["$userResultsNodeKey/$userId/$resultId/proofScreenshotUrl"] = null
            updates["$userResultsNodeKey/$userId/$resultId/screenshotUrl"] = null
        }

        db.reference.updateChildren(updates).await()

        // Idempotent screenshot cleanup after rejection (never rolls back rejection)
        try {
            db.getReference(FirebaseAdminConfig.NODE_RESULTS).child(resultId).child("proofScreenshotUrl").removeValue().await()
            db.getReference(FirebaseAdminConfig.NODE_RESULTS).child(resultId).child("screenshotUrl").removeValue().await()
            if (userId.isNotBlank()) {
                db.getReference(userResultsNodeKey).child(userId).child(resultId).child("proofScreenshotUrl").removeValue().await()
                db.getReference(userResultsNodeKey).child(userId).child(resultId).child("screenshotUrl").removeValue().await()
            }
        } catch (_: Exception) {
            // Screenshot cleanup failure must never fail the rejection operation
        }

        // Send notification
        if (userId.isNotBlank()) {
            sendResultNotification(
                userId = userId,
                title = "Result Submission Rejected / রেজাল্ট বাতিল করা হয়েছে",
                message = "Your result submission for match ${resultItem.matchNumber} was rejected. Reason: $trimmedReason",
                adminSession = adminSession
            )
        }
    }

    private suspend fun sendResultNotification(
        userId: String,
        title: String,
        message: String,
        adminSession: SuperAdminSession
    ) {
        try {
            val notifRepo = FirebaseNotificationsRepository()
            notifRepo.sendNotification(
                title = title,
                message = message,
                targetType = NotificationTargetType.SPECIFIC_USER,
                targetId = userId,
                adminSession = adminSession
            )
        } catch (_: Exception) {
            // Non-critical notification failure must never block financial operations
        }
    }

    private suspend fun executeResultApprovalLockTransaction(
        resultRef: DatabaseReference,
        adminSession: SuperAdminSession,
        settlementTrxId: String,
        authoritativePrizeMinor: Long,
        now: Long
    ): ResultApprovalResult = suspendCancellableCoroutine { continuation ->
        resultRef.runTransaction(object : Transaction.Handler {
            var failureMessage: String? = null
            var wasAlreadySettled = false

            override fun doTransaction(currentData: MutableData): Transaction.Result {
                if (currentData.value == null) {
                    failureMessage = "Result submission record does not exist on database."
                    return Transaction.abort()
                }

                val currentStatusStr = currentData.child("status").value?.toString()
                val currentStatus = ResultStatus.fromString(currentStatusStr)

                if (currentStatus == ResultStatus.APPROVED) {
                    wasAlreadySettled = true
                    failureMessage = "Result is already APPROVED and settled."
                    return Transaction.abort()
                }

                if (currentStatus == ResultStatus.REJECTED) {
                    wasAlreadySettled = true
                    failureMessage = "Result is ALREADY REJECTED."
                    return Transaction.abort()
                }

                currentData.child("status").value = ResultStatus.APPROVED.name
                currentData.child("processedAt").value = now
                currentData.child("processedBy").value = adminSession.identifier
                currentData.child("updatedAt").value = now
                currentData.child("settlementTransactionId").value = settlementTrxId
                currentData.child("settledPrizeMinorUnits").value = authoritativePrizeMinor

                return Transaction.success(currentData)
            }

            override fun onComplete(
                error: DatabaseError?,
                committed: Boolean,
                currentData: DataSnapshot?
            ) {
                if (committed && error == null) {
                    continuation.resume(ResultApprovalResult(success = true))
                } else {
                    continuation.resume(
                        ResultApprovalResult(
                            success = false,
                            alreadySettled = wasAlreadySettled,
                            errorMessage = error?.message ?: failureMessage ?: "Result approval lock transaction aborted."
                        )
                    )
                }
            }
        })
    }

    private suspend fun executeWalletPrizeCreditTransaction(
        walletRef: DatabaseReference,
        resultId: String,
        prizeMinorUnits: Long,
        now: Long
    ): WalletPrizeCreditResult = suspendCancellableCoroutine { continuation ->
        walletRef.runTransaction(object : Transaction.Handler {
            var failureMessage: String? = null
            var creditResult: WalletPrizeCreditResult? = null

            override fun doTransaction(currentData: MutableData): Transaction.Result {
                // Idempotency check: verify if this resultId was already credited to the wallet
                val creditedResultsNode = currentData.child("creditedResults")
                if (creditedResultsNode.hasChild(resultId)) {
                    creditResult = WalletPrizeCreditResult(
                        success = true,
                        alreadySettled = true,
                        newBalance = (currentData.child("balance").value as? Number)?.toLong() ?: 0L,
                        newWinningBalance = (currentData.child("winningBalance").value as? Number)?.toLong() ?: 0L
                    )
                    return Transaction.abort()
                }

                val currentBalance = (currentData.child("balance").value as? Number)?.toLong() ?: 0L
                val currentAvailable = (currentData.child("availableBalance").value as? Number)?.toLong() ?: currentBalance
                val currentWinning = (currentData.child("winningBalance").value as? Number)?.toLong() ?: 0L
                val currentPending = (currentData.child("pendingBalance").value as? Number)?.toLong() ?: 0L

                val newAvailable = currentAvailable + prizeMinorUnits
                val newWinning = currentWinning + prizeMinorUnits
                val newBalance = newAvailable + currentPending

                currentData.child("balance").value = newBalance
                currentData.child("availableBalance").value = newAvailable
                currentData.child("winningBalance").value = newWinning
                currentData.child("balanceDouble").value = newBalance / 100.0
                currentData.child("updatedAt").value = now

                // Mark resultId as settled inside wallet
                currentData.child("creditedResults").child(resultId).value = mapOf(
                    "resultId" to resultId,
                    "prizeMinorUnits" to prizeMinorUnits,
                    "creditedAt" to now
                )

                creditResult = WalletPrizeCreditResult(
                    success = true,
                    alreadySettled = false,
                    newBalance = newBalance,
                    newWinningBalance = newWinning
                )

                return Transaction.success(currentData)
            }

            override fun onComplete(
                error: DatabaseError?,
                committed: Boolean,
                currentData: DataSnapshot?
            ) {
                if (committed && error == null) {
                    continuation.resume(creditResult ?: WalletPrizeCreditResult(success = true))
                } else {
                    continuation.resume(
                        creditResult ?: WalletPrizeCreditResult(
                            success = false,
                            errorMessage = error?.message ?: failureMessage ?: "Wallet prize credit transaction failed."
                        )
                    )
                }
            }
        })
    }
}

data class WalletPrizeCreditResult(
    val success: Boolean,
    val alreadySettled: Boolean = false,
    val newBalance: Long = 0L,
    val newWinningBalance: Long = 0L,
    val errorMessage: String? = null
)
