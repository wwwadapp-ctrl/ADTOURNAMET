package com.example.core.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.GoldLight
import com.example.ui.theme.StatusInfo
import com.example.ui.theme.StatusLive
import com.example.ui.theme.StatusPending
import com.example.ui.theme.StatusRejected
import com.example.ui.theme.TextMuted
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Authoritative 10 Match Statuses from the User App domain + safe UNKNOWN fallback.
 */
enum class MatchStatus(val label: String, val badgeColor: Color) {
    AVAILABLE("Available", StatusLive),
    FULL("Full", StatusPending),
    CODE_ADDED("Code Added", CyanSecondary),
    RUNNING("Running", StatusRejected),
    RESULT_SUBMITTED("Result Submitted", GoldLight),
    COMPLETED("Completed", TextMuted),
    PAUSED("Paused", StatusPending),
    DISABLED("Disabled", StatusRejected),
    CANCELLED("Cancelled", StatusRejected),
    UPCOMING("Upcoming", StatusInfo),
    UNKNOWN("Unknown", TextMuted);

    companion object {
        fun fromString(status: String?): MatchStatus {
            if (status.isNullOrBlank()) return UNKNOWN
            return when (status.trim().uppercase()) {
                "AVAILABLE" -> AVAILABLE
                "FULL" -> FULL
                "CODE_ADDED", "CODEADDED" -> CODE_ADDED
                "RUNNING" -> RUNNING
                "RESULT_SUBMITTED", "RESULTSUBMITTED" -> RESULT_SUBMITTED
                "COMPLETED" -> COMPLETED
                "PAUSED" -> PAUSED
                "DISABLED" -> DISABLED
                "CANCELLED" -> CANCELLED
                "UPCOMING" -> UPCOMING
                else -> UNKNOWN
            }
        }
    }
}

/**
 * Pure calculation engine for tournament commissions and prize distributions.
 * All authoritative financial math is performed using Long minor units (৳1 = 100 minor units).
 */
object TournamentMath {
    const val MINOR_UNITS_PER_TAKA = 100L
    const val MAX_PLAYERS = 2

    fun takaToMinorUnits(taka: Long): Long = taka * MINOR_UNITS_PER_TAKA
    fun minorUnitsToTaka(minorUnits: Long): Long = minorUnits / MINOR_UNITS_PER_TAKA

    /**
     * Commission rules:
     * Commission PER PLAYER = Entry Fee ÷ 10
     * Calculated in minor units: entryFeeMinorUnits / 10
     */
    fun calculateCommissionMinorUnits(entryFeeMinorUnits: Long): Long {
        require(entryFeeMinorUnits >= 0) { "Entry fee cannot be negative" }
        return entryFeeMinorUnits / 10L
    }

    /**
     * Prize = Total Entry Collected - Total Commission
     * Total Entry Collected = entryFeeMinorUnits * MAX_PLAYERS
     * Total Commission = (calculateCommissionMinorUnits(entryFeeMinorUnits)) * MAX_PLAYERS
     */
    fun calculatePrizeMinorUnits(entryFeeMinorUnits: Long): Long {
        require(entryFeeMinorUnits >= 0) { "Entry fee cannot be negative" }
        val commissionPerPlayer = calculateCommissionMinorUnits(entryFeeMinorUnits)
        val totalCommission = commissionPerPlayer * MAX_PLAYERS
        val totalPool = entryFeeMinorUnits * MAX_PLAYERS
        return maxOf(0L, totalPool - totalCommission)
    }

    fun calculateCommissionTaka(entryFeeTaka: Long): Long {
        val entryFeeMinor = takaToMinorUnits(entryFeeTaka)
        val totalCommissionMinor = calculateCommissionMinorUnits(entryFeeMinor) * MAX_PLAYERS
        return minorUnitsToTaka(totalCommissionMinor)
    }

    fun calculatePrizeTaka(entryFeeTaka: Long): Long {
        return minorUnitsToTaka(calculatePrizeMinorUnits(takaToMinorUnits(entryFeeTaka)))
    }

    fun formatTaka(minorUnits: Long): String {
        return "৳${minorUnitsToTaka(minorUnits)}"
    }

    fun formatTakaAmount(taka: Long): String {
        return "৳$taka"
    }

    /**
     * Generates a preview list for bulk match creation.
     */
    fun generateBulkPreview(request: BulkMatchRequest): List<BulkMatchPreviewItem> {
        val startNumLong = request.startingNumber.trim().trimStart('#').toLongOrNull()
            ?: throw IllegalArgumentException("Starting number must be a valid numeric value.")
        
        val prefix = if (request.startingNumber.trim().startsWith("#")) "#" else ""
        val commissionTaka = calculateCommissionTaka(request.entryFeeTaka)
        val prizeTaka = calculatePrizeTaka(request.entryFeeTaka)

        return (0 until request.quantity).map { index ->
            val matchNum = "$prefix${startNumLong + index}"
            val scheduledTs = request.scheduledStartTimestamp + (index * request.intervalMinutes * 60 * 1000L)
            val timeFormatted = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(scheduledTs))
            val title = "${if (request.gameType.contains("CARROM", ignoreCase = true)) "Carrom" else "Ludo"} 1v1 $matchNum"
            BulkMatchPreviewItem(
                matchNumber = matchNum,
                title = title,
                gameType = if (request.gameType.contains("CARROM", ignoreCase = true)) "CARROM" else "LUDO",
                entryFeeTaka = request.entryFeeTaka,
                prizeTaka = prizeTaka,
                commissionTaka = commissionTaka,
                scheduledTimestamp = scheduledTs,
                formattedTime = timeFormatted
            )
        }
    }

    /**
     * Generates a preview list for auto batch match creation with 20-min interval and ৳20 fee increment.
     */
    fun generateAutoBatchPreview(request: AutoBatchMatchRequest): List<AutoBatchPreviewItem> {
        require(request.quantity in 1..100) { "Number of matches must be between 1 and 100." }
        require(request.startingEntryFeeTaka in 0..10000L) { "Starting entry fee must be between ৳0 and ৳10,000." }
        require(request.firstScheduledTimestamp > 0) { "Valid first scheduled time is required." }

        val maxFee = try {
            Math.addExact(
                request.startingEntryFeeTaka,
                Math.multiplyExact((request.quantity - 1).toLong(), 20L)
            )
        } catch (e: ArithmeticException) {
            throw IllegalArgumentException("Starting entry fee or quantity is too large, causing arithmetic overflow.")
        }
        require(maxFee <= 10000L) { "Calculated maximum entry fee exceeds limit of ৳10,000." }

        val prefix = "#"
        val baseMatchNumber = 101L

        return (0 until request.quantity).map { index ->
            val n = index + 1
            val matchNum = "$prefix${baseMatchNumber + index}"
            val entryFee = Math.addExact(
                request.startingEntryFeeTaka,
                Math.multiplyExact((n - 1).toLong(), 20L)
            )
            val scheduledTs = Math.addExact(
                request.firstScheduledTimestamp,
                Math.multiplyExact(Math.multiplyExact((n - 1).toLong(), 20L), 60L * 1000L)
            )
            val timeFormatted = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(scheduledTs))
            val isCarrom = (n % 5 == 0)
            val gameName = if (isCarrom) "Carrom" else "Ludo"
            val gameType = if (isCarrom) "CARROM" else "LUDO"
            val title = "$gameName 1v1 $matchNum"

            val entryFeeMinor = takaToMinorUnits(entryFee)
            val commissionPerPlayerMinor = calculateCommissionMinorUnits(entryFeeMinor)
            val totalCommissionMinor = Math.multiplyExact(commissionPerPlayerMinor, MAX_PLAYERS.toLong())
            val prizeMinor = calculatePrizeMinorUnits(entryFeeMinor)
            val prizeTaka = minorUnitsToTaka(prizeMinor)
            val commissionTaka = minorUnitsToTaka(totalCommissionMinor)

            AutoBatchPreviewItem(
                matchNumber = matchNum,
                title = title,
                gameType = gameType,
                entryFeeTaka = entryFee,
                prizeTaka = prizeTaka,
                commissionTaka = commissionTaka,
                scheduledTimestamp = scheduledTs,
                formattedTime = timeFormatted
            )
        }
    }
}

/**
 * Domain entity for an Admin Match item matching the exact User App canonical schema.
 */
data class AdminMatchItem(
    val matchId: String,
    val matchNumber: String,
    val title: String,
    val gameType: String, // "LUDO" or "CARROM"
    val entryFee: Double,
    val prizePool: Double,
    val status: MatchStatus,
    val rawStatus: String,
    val gameCode: String,
    val isCodeVisible: Boolean,
    val scheduledTime: Long,
    val maxPlayers: Int = TournamentMath.MAX_PLAYERS,
    val joinedPlayersCount: Int,
    val winnerUserId: String = "",
    val createdByAdminId: String = "",
    val createdAt: Long = 0L,
    val entryFeeMinorUnits: Long = 0L,
    val prizeMinorUnits: Long = 0L,
    val scheduledAt: Long = 0L,
    val updatedAt: Long = 0L,
    val startedAt: Long? = null,
    val cancelReason: String? = null
) {
    val displayGameType: String get() = if (gameType.contains("carrom", ignoreCase = true)) "Carrom" else "Ludo"
    val entryFeeTaka: Long get() = if (entryFeeMinorUnits > 0) {
        TournamentMath.minorUnitsToTaka(entryFeeMinorUnits)
    } else {
        entryFee.toLong()
    }
    val prizeTaka: Long get() = if (prizeMinorUnits > 0) {
        TournamentMath.minorUnitsToTaka(prizeMinorUnits)
    } else {
        prizePool.toLong()
    }
    val commissionTaka: Long get() = TournamentMath.calculateCommissionTaka(entryFeeTaka)
    val needsRoomCode: Boolean get() = (status == MatchStatus.FULL || joinedPlayersCount >= maxPlayers) &&
            gameCode.isBlank() &&
            status != MatchStatus.CODE_ADDED &&
            status != MatchStatus.RUNNING &&
            status != MatchStatus.COMPLETED &&
            status != MatchStatus.CANCELLED
    val formattedScheduledTime: String get() {
        val ts = if (scheduledAt > 0) scheduledAt else scheduledTime
        return if (ts > 0) {
            SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(ts))
        } else {
            "Scheduled"
        }
    }
}

/**
 * Player participation entity matching /matchPlayers/$matchId/$userId.
 */
data class MatchPlayerDetails(
    val matchPlayerId: String,
    val matchId: String,
    val userId: String,
    val username: String,
    val slot: String, // "PLAYER_1", "PLAYER_2"
    val joinedAt: Long,
    val isReady: Boolean,
    val uid: String,
    val entryFeeMinorUnits: Long,
    val status: String // "JOINED", "LOST", "WON"
) {
    val displaySlot: String get() = when (slot.uppercase()) {
        "PLAYER_1" -> "Player 1"
        "PLAYER_2" -> "Player 2"
        else -> slot
    }
    val formattedJoinedAt: String get() {
        return if (joinedAt > 0) {
            SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(joinedAt))
        } else {
            "Joined"
        }
    }
}

/**
 * Aggregated summary counts for the Matches screen.
 */
data class MatchSummary(
    val totalMatches: Int = 0,
    val upcomingMatches: Int = 0,
    val availableMatches: Int = 0,
    val runningMatches: Int = 0,
    val resultPendingMatches: Int = 0,
    val completedMatches: Int = 0,
    val actionRequiredMatches: Int = 0
)

/**
 * Request payload for creating a single match.
 */
data class CreateMatchRequest(
    val gameType: String, // "LUDO" or "CARROM"
    val matchNumber: String,
    val title: String,
    val entryFeeTaka: Long,
    val scheduledTimestamp: Long,
    val maxPlayers: Int = TournamentMath.MAX_PLAYERS
)

/**
 * Request payload for bulk creating matches.
 */
data class BulkMatchRequest(
    val quantity: Int,
    val gameType: String, // "LUDO" or "CARROM"
    val entryFeeTaka: Long,
    val startingNumber: String,
    val scheduledStartTimestamp: Long,
    val intervalMinutes: Int,
    val maxPlayers: Int = TournamentMath.MAX_PLAYERS
)

/**
 * Preview item for bulk match creation.
 */
data class BulkMatchPreviewItem(
    val matchNumber: String,
    val title: String,
    val gameType: String,
    val entryFeeTaka: Long,
    val prizeTaka: Long,
    val commissionTaka: Long,
    val scheduledTimestamp: Long,
    val formattedTime: String
)

/**
 * Request payload for auto batch match creation.
 */
data class AutoBatchMatchRequest(
    val quantity: Int,
    val gameType: String = "AUTO", // automated 4 Ludo + 1 Carrom pattern
    val startingEntryFeeTaka: Long,
    val firstScheduledTimestamp: Long,
    val maxPlayers: Int = TournamentMath.MAX_PLAYERS
)

/**
 * Preview item for auto batch match creation.
 */
data class AutoBatchPreviewItem(
    val matchNumber: String,
    val title: String,
    val gameType: String,
    val entryFeeTaka: Long,
    val prizeTaka: Long,
    val commissionTaka: Long,
    val scheduledTimestamp: Long,
    val formattedTime: String
)
