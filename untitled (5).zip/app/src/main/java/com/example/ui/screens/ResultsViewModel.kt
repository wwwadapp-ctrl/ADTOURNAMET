package com.example.ui.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.auth.AdminSessionManager
import com.example.core.model.AdminAuthState
import com.example.core.model.AdminResultItem
import com.example.core.model.SuperAdminSession
import com.example.core.model.TournamentMath
import com.example.core.repository.FirebaseResultsRepository
import com.example.core.repository.ResultsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface ResultsUiState {
    data object Loading : ResultsUiState
    data class Success(
        val allResults: List<AdminResultItem>,
        val filteredResults: List<AdminResultItem>,
        val pendingCount: Int,
        val approvedCount: Int,
        val rejectedCount: Int
    ) : ResultsUiState
    data class Error(val message: String) : ResultsUiState
}

class ResultsViewModel(
    private val repository: ResultsRepository = FirebaseResultsRepository(),
    private val sessionManager: AdminSessionManager = AdminSessionManager.getInstance()
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedTab = MutableStateFlow("PENDING") // "PENDING", "ALL", "APPROVED", "REJECTED"
    val selectedTab: StateFlow<String> = _selectedTab.asStateFlow()

    private val _selectedResultForDetails = MutableStateFlow<AdminResultItem?>(null)
    val selectedResultForDetails: StateFlow<AdminResultItem?> = _selectedResultForDetails.asStateFlow()

    private val _isDetailsModalOpen = MutableStateFlow(false)
    val isDetailsModalOpen: StateFlow<Boolean> = _isDetailsModalOpen.asStateFlow()

    private val _selectedResultForFullImage = MutableStateFlow<String?>(null)
    val selectedResultForFullImage: StateFlow<String?> = _selectedResultForFullImage.asStateFlow()

    private val _isFullImageModalOpen = MutableStateFlow(false)
    val isFullImageModalOpen: StateFlow<Boolean> = _isFullImageModalOpen.asStateFlow()

    private val _isApproveConfirmOpen = MutableStateFlow(false)
    val isApproveConfirmOpen: StateFlow<Boolean> = _isApproveConfirmOpen.asStateFlow()

    private val _isRejectConfirmOpen = MutableStateFlow(false)
    val isRejectConfirmOpen: StateFlow<Boolean> = _isRejectConfirmOpen.asStateFlow()

    private val _rejectReasonInput = MutableStateFlow("")
    val rejectReasonInput: StateFlow<String> = _rejectReasonInput.asStateFlow()

    private val _processingResultIds = MutableStateFlow<Set<String>>(emptySet())
    val processingResultIds: StateFlow<Set<String>> = _processingResultIds.asStateFlow()

    private val _feedbackMessage = MutableStateFlow<String?>(null)
    val feedbackMessage: StateFlow<String?> = _feedbackMessage.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private var pendingFocusResultId: String? = null

    fun setPendingFocusResultId(resultId: String?) {
        if (!resultId.isNullOrBlank()) {
            pendingFocusResultId = resultId
            checkAndFocusResult()
        }
    }

    fun checkAndFocusResult() {
        val targetId = pendingFocusResultId ?: return
        val currentState = uiState.value
        if (currentState is ResultsUiState.Success) {
            val match = currentState.allResults.find { it.resultId == targetId }
            if (match != null) {
                openDetailsModal(match)
                pendingFocusResultId = null
            }
        }
    }

    val uiState: StateFlow<ResultsUiState> = combine(
        repository.observeResults(),
        _searchQuery,
        _selectedTab
    ) { results, query, tab ->
        val trimmed = query.trim().lowercase()

        val matchingQuery = if (trimmed.isBlank()) {
            results
        } else {
            results.filter { res ->
                res.matchNumber.lowercase().contains(trimmed) ||
                        res.roomCode.lowercase().contains(trimmed) ||
                        res.userName.lowercase().contains(trimmed) ||
                        res.userPhone.contains(trimmed) ||
                        res.userId.lowercase().contains(trimmed)
            }
        }

        val matchingStatus = when (tab) {
            "PENDING" -> matchingQuery.filter { it.isPending }
            "APPROVED" -> matchingQuery.filter { it.isApproved }
            "REJECTED" -> matchingQuery.filter { it.isRejected }
            else -> matchingQuery
        }

        val pending = results.filter { it.isPending }
        val approved = results.filter { it.isApproved }
        val rejected = results.filter { it.isRejected }

        ResultsUiState.Success(
            allResults = results,
            filteredResults = matchingStatus,
            pendingCount = pending.size,
            approvedCount = approved.size,
            rejectedCount = rejected.size
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = ResultsUiState.Loading
    )

    private fun getVerifiedSession(): SuperAdminSession? {
        return when (val state = sessionManager.authState.value) {
            is AdminAuthState.Authenticated -> {
                if (!state.session.isSuperAdminVerified || state.session.uid.isBlank()) {
                    _errorMessage.value = "Unauthorized: Session is not a verified Super Admin."
                    null
                } else {
                    state.session
                }
            }
            else -> {
                _errorMessage.value = "Unauthorized: Action requires active Super Admin authentication session."
                null
            }
        }
    }

    fun onSearchQueryChanged(newQuery: String) {
        _searchQuery.value = newQuery
    }

    fun onTabChanged(tab: String) {
        _selectedTab.value = tab
    }

    fun openDetailsModal(result: AdminResultItem) {
        _selectedResultForDetails.value = result
        _isDetailsModalOpen.value = true
    }

    fun closeDetailsModal() {
        _isDetailsModalOpen.value = false
        _selectedResultForDetails.value = null
    }

    fun openFullImageModal(imageUrl: String) {
        if (imageUrl.isNotBlank()) {
            _selectedResultForFullImage.value = imageUrl
            _isFullImageModalOpen.value = true
        }
    }

    fun closeFullImageModal() {
        _isFullImageModalOpen.value = false
        _selectedResultForFullImage.value = null
    }

    fun openApproveConfirm(result: AdminResultItem) {
        if (result.userId.isBlank()) {
            _errorMessage.value = "Cannot approve result: Winner User ID is missing."
            return
        }
        val effectivePrizeMinor = if (result.prizeMinorUnits > 0L) result.prizeMinorUnits else TournamentMath.takaToMinorUnits(result.prizeTaka)
        if (effectivePrizeMinor <= 0L) {
            _errorMessage.value = "Cannot approve result: Prize amount is ৳0."
            return
        }
        _selectedResultForDetails.value = result
        _isApproveConfirmOpen.value = true
    }

    fun closeApproveConfirm() {
        _isApproveConfirmOpen.value = false
    }

    fun openRejectConfirm(result: AdminResultItem) {
        _selectedResultForDetails.value = result
        _rejectReasonInput.value = ""
        _isRejectConfirmOpen.value = true
    }

    fun closeRejectConfirm() {
        _isRejectConfirmOpen.value = false
        _rejectReasonInput.value = ""
    }

    fun onRejectReasonChanged(reason: String) {
        _rejectReasonInput.value = reason
    }

    fun dismissFeedback() {
        _feedbackMessage.value = null
        _errorMessage.value = null
    }

    fun approveResult(result: AdminResultItem) {
        val session = getVerifiedSession() ?: return
        if (_processingResultIds.value.contains(result.resultId)) return

        if (result.userId.isBlank()) {
            _errorMessage.value = "Cannot approve result: Winner User ID is missing."
            return
        }
        val effectivePrizeMinor = if (result.prizeMinorUnits > 0L) result.prizeMinorUnits else TournamentMath.takaToMinorUnits(result.prizeTaka)
        if (effectivePrizeMinor <= 0L) {
            _errorMessage.value = "Cannot approve result: Prize amount is ৳0."
            return
        }

        viewModelScope.launch {
            _processingResultIds.value = _processingResultIds.value + result.resultId
            closeApproveConfirm()
            closeDetailsModal()

            repository.approveResult(
                resultId = result.resultId,
                submittedMatchNumber = result.matchNumber,
                submittedRoomCode = result.roomCode,
                adminSession = session
            ).onSuccess {
                _feedbackMessage.value = "Successfully approved match ${result.matchNumber} result & credited winner ৳${TournamentMath.minorUnitsToTaka(result.prizeMinorUnits)}!"
            }.onFailure { error ->
                _errorMessage.value = error.localizedMessage ?: "Failed to approve result."
            }

            _processingResultIds.value = _processingResultIds.value - result.resultId
        }
    }

    fun rejectResult(result: AdminResultItem, reason: String) {
        val session = getVerifiedSession() ?: return
        if (_processingResultIds.value.contains(result.resultId)) return

        val trimmedReason = reason.trim()
        if (trimmedReason.isBlank()) {
            _errorMessage.value = "Please provide a rejection reason."
            return
        }

        viewModelScope.launch {
            _processingResultIds.value = _processingResultIds.value + result.resultId
            closeRejectConfirm()
            closeDetailsModal()

            repository.rejectResult(
                resultId = result.resultId,
                reason = trimmedReason,
                adminSession = session
            ).onSuccess {
                _feedbackMessage.value = "Successfully rejected result submission for match ${result.matchNumber}."
            }.onFailure { error ->
                _errorMessage.value = error.localizedMessage ?: "Failed to reject result."
            }

            _processingResultIds.value = _processingResultIds.value - result.resultId
        }
    }
}
