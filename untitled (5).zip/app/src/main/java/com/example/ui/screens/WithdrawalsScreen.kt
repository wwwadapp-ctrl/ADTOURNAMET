package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.core.model.AdminWithdrawalItem
import com.example.core.model.WithdrawalStatus
import com.example.navigation.AdminSection
import com.example.ui.components.SectionHeader
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.NavyBorder
import com.example.ui.theme.NavyDeepest
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavySurfaceElevated
import com.example.ui.theme.NavySurfaceHighlight
import com.example.ui.theme.StatusLive
import com.example.ui.theme.StatusPending
import com.example.ui.theme.StatusRejected
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextOnGold
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun WithdrawalsScreen(
    modifier: Modifier = Modifier,
    viewModel: WithdrawalsViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val confirmApproveTarget by viewModel.confirmApproveTarget.collectAsState()
    val confirmRejectTarget by viewModel.confirmRejectTarget.collectAsState()
    val rejectionReasonInput by viewModel.rejectionReasonInput.collectAsState()
    val context = LocalContext.current

    LaunchedEffect(uiState.feedbackMessage) {
        uiState.feedbackMessage?.let {
            Toast.makeText(context, it, Toast.LENGTH_LONG).show()
            viewModel.clearFeedback()
        }
    }

    LaunchedEffect(uiState.errorMessage) {
        uiState.errorMessage?.let {
            Toast.makeText(context, it, Toast.LENGTH_LONG).show()
            viewModel.clearFeedback()
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NavyDeepest)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        SectionHeader(
            title = AdminSection.WITHDRAWALS.title,
            subtitle = "Settle active wallet reservations and disburse player payouts",
            icon = AdminSection.WITHDRAWALS.icon
        )

        // Queue Metric Stats Chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val tabs = listOf(
                "PENDING" to "Pending (${uiState.pendingWithdrawals.size})",
                "COMPLETED" to "Completed",
                "REJECTED" to "Rejected"
            )

            tabs.forEach { (tabKey, label) ->
                val isSelected = uiState.selectedTab == tabKey
                FilterChip(
                    selected = isSelected,
                    onClick = { viewModel.selectTab(tabKey) },
                    label = { Text(label, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = GoldPrimary,
                        selectedLabelColor = TextOnGold,
                        containerColor = NavySurfaceElevated,
                        labelColor = TextSecondary
                    ),
                    border = BorderStroke(1.dp, if (isSelected) GoldPrimary else NavyBorder),
                    modifier = Modifier.testTag("tab_chip_$tabKey")
                )
            }
        }

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.updateSearchQuery(it) },
            placeholder = { Text("Search by User ID, number, TrxID...", color = TextMuted) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = TextMuted) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextMuted)
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = NavySurface,
                unfocusedContainerColor = NavySurface,
                focusedBorderColor = CyanSecondary,
                unfocusedBorderColor = NavyBorder,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("withdrawal_search_input")
        )

        // Main List
        val displayList = uiState.historicalWithdrawals

        if (displayList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.AccountBalanceWallet,
                        contentDescription = null,
                        tint = TextMuted,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (uiState.selectedTab == "PENDING") "No pending withdrawals to settle" else "No ${uiState.selectedTab.lowercase()} withdrawals found",
                        color = TextMuted,
                        fontSize = 14.sp
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(displayList, key = { it.withdrawalId }) { item ->
                    val isProcessing = uiState.processingIds.contains(item.withdrawalId)
                    WithdrawalItemCard(
                        item = item,
                        isProcessing = isProcessing,
                        onApprove = { viewModel.openApproveDialog(item) },
                        onReject = { viewModel.openRejectDialog(item) }
                    )
                }
            }
        }
    }

    // Confirmation Dialog: Approve Settlement
    confirmApproveTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { viewModel.dismissApproveDialog() },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = StatusLive)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Approve Withdrawal Settlement", color = TextPrimary, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Are you sure you want to approve this withdrawal? This will atomically settle the wallet reservation and record the payout disbursement.",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Surface(
                        color = NavySurfaceElevated,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, NavyBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Amount: ${target.formattedAmountTaka}", fontWeight = FontWeight.Bold, color = GoldPrimary)
                            Text("Recipient: ${target.recipientNumber} (${target.method})", color = TextPrimary)
                            Text("User ID: ${target.userId}", color = TextSecondary, fontSize = 12.sp)
                            Text("Withdrawal ID: ${target.withdrawalId}", color = TextMuted, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.confirmApprove() },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusLive, contentColor = NavyDeepest),
                    modifier = Modifier.testTag("confirm_approve_btn")
                ) {
                    Text("Confirm Payout & Settle", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.dismissApproveDialog() }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = NavySurface,
            shape = RoundedCornerShape(16.dp)
        )
    }

    // Confirmation Dialog: Reject & Release Reservation
    confirmRejectTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { viewModel.dismissRejectDialog() },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = StatusRejected)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Reject & Release Hold", color = TextPrimary, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Rejecting will refund the reserved amount (${target.formattedAmountTaka}) back to the user's available wallet balance.",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                    OutlinedTextField(
                        value = rejectionReasonInput,
                        onValueChange = { viewModel.updateRejectionReason(it) },
                        placeholder = { Text("Enter required audit rejection reason...", color = TextMuted) },
                        label = { Text("Rejection Reason *", color = TextSecondary) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = NavySurfaceElevated,
                            unfocusedContainerColor = NavySurfaceElevated,
                            focusedBorderColor = StatusRejected,
                            unfocusedBorderColor = NavyBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("rejection_reason_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.confirmReject() },
                    enabled = rejectionReasonInput.trim().isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = StatusRejected, contentColor = TextPrimary),
                    modifier = Modifier.testTag("confirm_reject_btn")
                ) {
                    Text("Reject & Refund User", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.dismissRejectDialog() }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = NavySurface,
            shape = RoundedCornerShape(16.dp)
        )
    }
}

@Composable
private fun WithdrawalItemCard(
    item: AdminWithdrawalItem,
    isProcessing: Boolean,
    onApprove: () -> Unit,
    onReject: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = NavySurface),
        border = BorderStroke(1.dp, if (item.isActionable) NavyBorder else NavySurfaceHighlight),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("withdrawal_card_${item.withdrawalId}")
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header Row: Method + Status Badge + Amount
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(NavySurfaceHighlight),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Payment, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(20.dp))
                    }
                    Column {
                        Text(item.method.uppercase(), fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 14.sp)
                        Text(item.recipientNumber, color = CyanSecondary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = item.formattedAmountTaka,
                        fontWeight = FontWeight.ExtraBold,
                        color = GoldPrimary,
                        fontSize = 18.sp
                    )
                    StatusBadge(status = item.status)
                }
            }

            // User and timing details
            Surface(
                color = NavySurfaceElevated,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("User UID:", color = TextMuted, fontSize = 11.sp)
                        Text(item.userId, color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                    if (item.createdAt > 0L) {
                        val formattedDate = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(item.createdAt))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Requested At:", color = TextMuted, fontSize = 11.sp)
                            Text(formattedDate, color = TextSecondary, fontSize = 11.sp)
                        }
                    }
                    if (!item.rejectionReason.isNullOrBlank()) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Reason:", color = StatusRejected, fontSize = 11.sp)
                            Text(item.rejectionReason, color = StatusRejected, fontSize = 11.sp, maxLines = 1)
                        }
                    }
                }
            }

            // Action Buttons for PENDING / REQUESTED
            if (item.isActionable) {
                if (isProcessing) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(22.dp), color = GoldPrimary, strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Settling transaction in Firebase...", color = TextSecondary, fontSize = 12.sp)
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = onReject,
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusRejected),
                            border = BorderStroke(1.dp, StatusRejected),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("reject_btn_${item.withdrawalId}")
                        ) {
                            Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Reject", fontSize = 13.sp)
                        }

                        Button(
                            onClick = onApprove,
                            colors = ButtonDefaults.buttonColors(containerColor = StatusLive, contentColor = NavyDeepest),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("approve_btn_${item.withdrawalId}")
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Approve", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusBadge(status: WithdrawalStatus) {
    val (bgColor, textColor, label) = when (status) {
        WithdrawalStatus.COMPLETED -> Triple(StatusLive.copy(alpha = 0.15f), StatusLive, "COMPLETED")
        WithdrawalStatus.REJECTED -> Triple(StatusRejected.copy(alpha = 0.15f), StatusRejected, "REJECTED")
        WithdrawalStatus.PENDING, WithdrawalStatus.REQUESTED -> Triple(StatusPending.copy(alpha = 0.15f), StatusPending, "REQUESTED")
    }

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(6.dp),
        border = BorderStroke(1.dp, textColor.copy(alpha = 0.4f))
    ) {
        Text(
            text = label,
            color = textColor,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}
