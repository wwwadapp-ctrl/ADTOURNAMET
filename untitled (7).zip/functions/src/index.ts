import * as functions from "firebase-functions";
import * as admin from "firebase-admin";

admin.initializeApp();

export const sendRoomCodePushNotification = functions.database
  .ref("/matches/{matchId}/gameCode")
  .onWrite(async (change, context) => {
    const matchId = context.params.matchId;
    const beforeVal = change.before.val();
    const afterVal = change.after.val();

    const wasBlank = !beforeVal || String(beforeVal).trim() === "";
    const isNowNonBlank = afterVal && String(afterVal).trim() !== "";

    // Trigger only when previous was blank AND new gameCode is non-blank
    if (!wasBlank || !isNowNonBlank) {
      return null;
    }

    try {
      // 1. Read participants from /matchPlayers/{matchId}
      const matchPlayersSnapshot = await admin
        .database()
        .ref(`/matchPlayers/${matchId}`)
        .get();

      if (!matchPlayersSnapshot.exists()) {
        console.log(`No participants found for match ${matchId}`);
        return null;
      }

      const playersData = matchPlayersSnapshot.val();
      const uids = new Set<string>();

      if (playersData) {
        if (Array.isArray(playersData)) {
          playersData.forEach((player) => {
            if (player && (player.uid || player.userId)) {
              uids.add(String(player.uid || player.userId));
            }
          });
        } else if (typeof playersData === "object") {
          Object.values(playersData).forEach((player: any) => {
            if (player && (player.uid || player.userId)) {
              uids.add(String(player.uid || player.userId));
            }
          });
        }
      }

      if (uids.size === 0) {
        console.log(`No valid participant UIDs found for match ${matchId}`);
        return null;
      }

      // 2. Read FCM tokens for each participant from /userFcmTokens/{uid}
      const allTokens: string[] = [];

      for (const uid of uids) {
        try {
          const tokenSnapshot = await admin
            .database()
            .ref(`/userFcmTokens/${uid}`)
            .get();

          if (tokenSnapshot.exists()) {
            const tokenData = tokenSnapshot.val();
            if (tokenData) {
              if (typeof tokenData === "object") {
                Object.values(tokenData).forEach((tokenRecord: any) => {
                  if (
                    tokenRecord &&
                    typeof tokenRecord.token === "string" &&
                    tokenRecord.token.trim() !== ""
                  ) {
                    allTokens.push(tokenRecord.token.trim());
                  }
                });
              }
            }
          }
        } catch (tokenErr) {
          console.error(`Failed to fetch tokens for user ${uid}:`, tokenErr);
        }
      }

      // Deduplicate tokens
      const uniqueTokens = Array.from(new Set(allTokens));

      if (uniqueTokens.length === 0) {
        console.log(`No FCM tokens found for participants of match ${matchId}`);
        return null;
      }

      // 3. Send FCM notification
      const title = "Game Room Code Available! / রুম কোড যোগ করা হয়েছে";
      const body = "Room code for your match has been published. Open match details to view.";

      for (const token of uniqueTokens) {
        try {
          await admin.messaging().send({
            token: token,
            notification: {
              title: title,
              body: body,
            },
            data: {
              matchId: matchId,
              type: "ROOM_CODE",
            },
          });
        } catch (sendErr) {
          console.error(`Failed to send FCM push to token ${token}:`, sendErr);
        }
      }

      console.log(`Successfully processed room code push notifications for match ${matchId}`);
      return null;
    } catch (err) {
      console.error(`Error processing room code push notification for match ${matchId}:`, err);
      return null;
    }
  });
