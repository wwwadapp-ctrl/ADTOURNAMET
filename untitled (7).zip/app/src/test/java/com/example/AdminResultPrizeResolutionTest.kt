package com.example

import com.example.core.model.AdminMatchItem
import com.example.core.model.AdminResultItem
import com.example.core.model.ResultStatus
import com.example.core.model.SuperAdminSession
import com.example.core.model.TournamentMath
import com.example.core.model.UserWalletData
import com.example.core.repository.FirebaseResultsRepository
import com.example.core.repository.ResultPrizeResolver
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class AdminResultPrizeResolutionTest {

    private val adminSession = SuperAdminSession(
        uid = "superadmin_test_uid",
        identifier = "Super Admin (Test)",
        isSuperAdminVerified = true
    )

    private fun createTestMatch(
        matchId: String,
        matchNumber: String = "#001",
        gameType: String = "LUDO",
        entryFee: Double = 55.0,
        prizePool: Double = 99.0,
        entryFeeMinorUnits: Long = 5500L,
        prizeMinorUnits: Long = 9900L
    ) = AdminMatchItem(
        matchId = matchId,
        matchNumber = matchNumber,
        title = "$gameType 1v1 $matchNumber",
        gameType = gameType,
        entryFee = entryFee,
        prizePool = prizePool,
        status = com.example.core.model.MatchStatus.AVAILABLE,
        rawStatus = "AVAILABLE",
        gameCode = "12345678",
        isCodeVisible = true,
        scheduledTime = System.currentTimeMillis(),
        joinedPlayersCount = 2,
        entryFeeMinorUnits = entryFeeMinorUnits,
        prizeMinorUnits = prizeMinorUnits
    )

    @Test
    fun testResultWithValidMatchIdResolvesCorrectMatchPrize() = runBlocking {
        val matchId = "mtc_match_001"
        val userId = "usr_winner_789"

        // Authoritative match with ৳55 entry and ৳99 prize
        val entryFeeMinor = TournamentMath.takaToMinorUnits(55L) // 5500L
        val expectedPrizeMinor = TournamentMath.calculatePrizeMinorUnits(entryFeeMinor) // 9900L
        val expectedPrizeTaka = TournamentMath.minorUnitsToTaka(expectedPrizeMinor) // 99L

        val match = createTestMatch(
            matchId = matchId,
            matchNumber = "#001",
            gameType = "LUDO",
            entryFee = 55.0,
            prizePool = 99.0,
            entryFeeMinorUnits = entryFeeMinor,
            prizeMinorUnits = expectedPrizeMinor
        )

        // Result submitted by user app without prizeMinorUnits (default 0L)
        val pendingResultWithoutPrize = AdminResultItem(
            resultId = "res_001",
            matchId = matchId,
            matchNumber = "#001",
            gameType = "LUDO",
            userId = userId,
            userName = "Winner Player",
            roomCode = "12345678",
            proofScreenshotUrl = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==",
            prizeMinorUnits = 0L,
            prizeTaka = 0L,
            status = ResultStatus.PENDING
        )

        val repository = FirebaseResultsRepository(
            initialResults = listOf(pendingResultWithoutPrize),
            initialMatches = mapOf(matchId to match)
        )

        // 1. Resolve through getResult
        val resolvedResult = repository.getResult("res_001")
        assertNotNull("Result must be resolved", resolvedResult)
        assertEquals("Authoritative prize minor units must match match prize", expectedPrizeMinor, resolvedResult!!.prizeMinorUnits)
        assertEquals("Authoritative prize taka must match match prize in taka", expectedPrizeTaka, resolvedResult.prizeTaka)

        // 2. Resolve through observeResults flow
        val resultsList = repository.observeResults().first()
        val itemInList = resultsList.firstOrNull { it.resultId == "res_001" }
        assertNotNull("Item must be present in observeResults flow", itemInList)
        assertEquals(expectedPrizeMinor, itemInList!!.prizeMinorUnits)
        assertEquals(expectedPrizeTaka, itemInList.prizeTaka)
    }

    @Test
    fun testMinorUnitsConvertedCorrectlyForDisplay() {
        // ৳99 for ৳55 entry match
        val entryFeeMinor = TournamentMath.takaToMinorUnits(55L)
        val prizeMinor99 = TournamentMath.calculatePrizeMinorUnits(entryFeeMinor) // 9900L
        assertEquals(9900L, prizeMinor99)
        assertEquals(99L, TournamentMath.minorUnitsToTaka(prizeMinor99))
        assertEquals("৳99", TournamentMath.formatTaka(prizeMinor99))

        val resultItem99 = AdminResultItem(
            resultId = "res_test_99",
            prizeMinorUnits = prizeMinor99,
            prizeTaka = TournamentMath.minorUnitsToTaka(prizeMinor99)
        )
        assertEquals("৳99", resultItem99.formattedPrize)

        // ৳750
        val prizeMinor750 = TournamentMath.takaToMinorUnits(750L) // 75000L
        val resultItem750 = AdminResultItem(
            resultId = "res_test_750",
            prizeMinorUnits = prizeMinor750,
            prizeTaka = 750L
        )
        assertEquals("৳750", resultItem750.formattedPrize)
    }

    @Test
    fun testZeroDefaultPrizeNotUsedWhenMatchContainsValidPrize() {
        // Match contains prizeMinorUnits = 9900L, result contains prizeMinorUnits = 0L
        val resolved = ResultPrizeResolver.resolvePrizeMinorUnits(
            matchPrizeMinorUnits = 9900L,
            matchPrizePoolTaka = 99.0,
            matchEntryFeeMinorUnits = 5500L,
            matchEntryFeeTaka = 55.0,
            resultPrizeMinorUnits = 0L,
            resultPrizePoolTaka = 0.0
        )
        assertEquals("Must resolve to 9900L, not 0L default", 9900L, resolved)
    }

    @Test
    fun testPrizeResolutionFallbackToPrizePoolIfMinorUnitsMissingOrZero() {
        // Match prizeMinorUnits is 0, but prizePool is 99.0
        val resolved = ResultPrizeResolver.resolvePrizeMinorUnits(
            matchPrizeMinorUnits = 0L,
            matchPrizePoolTaka = 99.0,
            matchEntryFeeMinorUnits = 0L,
            matchEntryFeeTaka = 0.0,
            resultPrizeMinorUnits = 0L,
            resultPrizePoolTaka = 0.0
        )
        assertEquals("Must fallback to match prizePool 99.0 => 9900L", 9900L, resolved)
    }

    @Test
    fun testPrizeResolutionFallbackToEntryFeeTournamentMath() {
        // Match prizeMinorUnits and prizePool are 0, but entryFeeMinorUnits is 5500L
        val resolved = ResultPrizeResolver.resolvePrizeMinorUnits(
            matchPrizeMinorUnits = 0L,
            matchPrizePoolTaka = 0.0,
            matchEntryFeeMinorUnits = 5500L,
            matchEntryFeeTaka = 55.0,
            resultPrizeMinorUnits = 0L,
            resultPrizePoolTaka = 0.0
        )
        val expected = TournamentMath.calculatePrizeMinorUnits(5500L) // 9900L
        assertEquals("Must calculate prize from entryFeeMinorUnits via TournamentMath", expected, resolved)
    }

    @Test
    fun testApproveResultBlocksZeroPrize() = runBlocking {
        val matchId = "mtc_zero_prize"
        val userId = "usr_winner_zero"

        val match = createTestMatch(
            matchId = matchId,
            matchNumber = "#000",
            entryFee = 0.0,
            prizePool = 0.0,
            entryFeeMinorUnits = 0L,
            prizeMinorUnits = 0L
        )

        val pendingResult = AdminResultItem(
            resultId = "res_zero",
            matchId = matchId,
            matchNumber = "#000",
            userId = userId,
            userName = "Zero Player",
            roomCode = "000000",
            prizeMinorUnits = 0L,
            prizeTaka = 0L,
            status = ResultStatus.PENDING
        )

        val repository = FirebaseResultsRepository(
            initialResults = listOf(pendingResult),
            initialMatches = mapOf(matchId to match),
            initialWallets = mapOf(userId to UserWalletData(userId = userId, balance = 1000L))
        )

        val approveResult = repository.approveResult(
            resultId = "res_zero",
            submittedMatchNumber = "#000",
            submittedRoomCode = "000000",
            adminSession = adminSession
        )

        assertTrue("Approval must fail if prize is 0", approveResult.isFailure)
        val errorMsg = approveResult.exceptionOrNull()?.message ?: ""
        assertTrue("Error message must indicate ৳0 prize cannot be approved", errorMsg.contains("0"))

        val wallet = repository.getUserWallet(userId)
        assertEquals("Wallet balance must not change on failed approval", 1000L, wallet!!.balance)
    }

    @Test
    fun testApproveResultCreditsResolvedMatchPrizeToWinnerWallet() = runBlocking {
        val matchId = "mtc_live_001"
        val userId = "usr_live_winner"

        val entryFeeMinor = TournamentMath.takaToMinorUnits(55L) // 5500L
        val prizeMinor = TournamentMath.calculatePrizeMinorUnits(entryFeeMinor) // 9900L (৳99)

        val match = createTestMatch(
            matchId = matchId,
            matchNumber = "#001",
            gameType = "LUDO",
            prizeMinorUnits = prizeMinor,
            prizePool = 99.0
        )

        // Result without prize
        val pendingResult = AdminResultItem(
            resultId = "res_live_001",
            matchId = matchId,
            matchNumber = "#001",
            userId = userId,
            userName = "Live Winner",
            roomCode = "ROOM123",
            prizeMinorUnits = 0L,
            prizeTaka = 0L,
            status = ResultStatus.PENDING
        )

        val initialWallet = UserWalletData(
            userId = userId,
            balance = 10000L,
            availableBalance = 5000L,
            winningBalance = 2000L
        )

        val repository = FirebaseResultsRepository(
            initialResults = listOf(pendingResult),
            initialMatches = mapOf(matchId to match),
            initialWallets = mapOf(userId to initialWallet)
        )

        val approveResult = repository.approveResult(
            resultId = "res_live_001",
            submittedMatchNumber = "#001",
            submittedRoomCode = "ROOM123",
            adminSession = adminSession
        )

        assertTrue("Approve must succeed with resolved prize", approveResult.isSuccess)

        val updatedWallet = repository.getUserWallet(userId)
        assertNotNull(updatedWallet)
        assertEquals("Available balance must be credited by 9900 minor units", 5000L + prizeMinor, updatedWallet!!.availableBalance)
        assertEquals("Winning balance must be credited by 9900 minor units", 2000L + prizeMinor, updatedWallet.winningBalance)
        assertEquals("Total balance must be credited by 9900 minor units", 10000L + prizeMinor, updatedWallet.balance)
    }

    @Test
    fun testAddResultDynamicallyResolvesPrizeFromExistingMatch() = runBlocking {
        val repository = FirebaseResultsRepository()
        val matchId = "mtc_dynamic_001"
        val match = createTestMatch(
            matchId = matchId,
            matchNumber = "#001",
            entryFee = 55.0,
            prizePool = 99.0,
            entryFeeMinorUnits = 5500L,
            prizeMinorUnits = 9900L
        )
        repository.setMatch(match)

        val pendingResult = AdminResultItem(
            resultId = "res_dynamic_001",
            matchId = matchId,
            matchNumber = "#001",
            userId = "usr_dynamic_winner",
            prizeMinorUnits = 0L,
            prizeTaka = 0L,
            status = ResultStatus.PENDING
        )
        repository.addResult(pendingResult)

        val resolved = repository.getResult("res_dynamic_001")
        assertNotNull(resolved)
        assertEquals(9900L, resolved!!.prizeMinorUnits)
        assertEquals(99L, resolved.prizeTaka)
        assertEquals("৳99", resolved.formattedPrize)
    }
}
