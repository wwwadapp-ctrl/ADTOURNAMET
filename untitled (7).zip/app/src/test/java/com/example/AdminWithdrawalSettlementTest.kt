package com.example

import com.example.core.model.ActiveWithdrawalReservation
import com.example.core.model.SuperAdminSession
import com.example.core.model.TournamentMath
import com.example.core.model.UserWalletData
import com.example.core.model.WithdrawalStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Authoritative financial settlement verification tests for Admin App Phase 3B.3.
 * Validates wallet state transitions, reservation matching, idempotency, race conditions,
 * Double field synchronization, and security checks.
 */
class AdminWithdrawalSettlementTest {

    private val superAdminSession = SuperAdminSession(
        uid = "GuIxwtI4hLQIoKOOt3V2XKnFhiB2",
        identifier = "01711112222",
        isSuperAdminVerified = true
    )

    private val unverifiedSession = SuperAdminSession(
        uid = "unverified_user",
        identifier = "01800000000",
        isSuperAdminVerified = false
    )

    /**
     * Helper mimicking the exact atomic transaction logic executed by executeWalletApprovalTransaction.
     */
    private fun simulateApprovalTransaction(
        initialWallet: UserWalletData,
        withdrawalId: String,
        requiredAmountMinor: Long
    ): Pair<Boolean, UserWalletData> {
        // 1. Verify reservation exists
        val reservation = initialWallet.activeWithdrawals[withdrawalId]
            ?: return Pair(false, initialWallet)

        // 2. Require amount matches exactly
        if (reservation.amountMinorUnits != requiredAmountMinor) {
            return Pair(false, initialWallet)
        }

        // 3. Require pendingBalance >= amountMinorUnits
        if (initialWallet.pendingBalance < requiredAmountMinor) {
            return Pair(false, initialWallet)
        }

        // 4. Calculate new values
        val newPending = initialWallet.pendingBalance - requiredAmountMinor
        val newTotalWithdrawn = initialWallet.totalWithdrawn + requiredAmountMinor
        val syncBalanceDouble = initialWallet.availableBalance / 100.0
        val syncLockedBalanceDouble = newPending / 100.0

        // 5. Remove only this reservation, preserving other active reservations and activeJoins
        val updatedReservations = initialWallet.activeWithdrawals.toMutableMap()
        updatedReservations.remove(withdrawalId)

        val updatedWallet = initialWallet.copy(
            pendingBalance = newPending,
            totalWithdrawn = newTotalWithdrawn,
            balanceDouble = syncBalanceDouble,
            lockedBalanceDouble = syncLockedBalanceDouble,
            activeWithdrawals = updatedReservations
        )

        return Pair(true, updatedWallet)
    }

    /**
     * Helper mimicking the exact atomic transaction logic executed by executeWalletRejectionTransaction.
     */
    private fun simulateRejectionTransaction(
        initialWallet: UserWalletData,
        withdrawalId: String,
        requiredAmountMinor: Long,
        reason: String
    ): Pair<Boolean, UserWalletData> {
        if (reason.trim().isBlank()) {
            return Pair(false, initialWallet)
        }

        // 1. Verify reservation exists
        val reservation = initialWallet.activeWithdrawals[withdrawalId]
            ?: return Pair(false, initialWallet)

        // 2. Require amount matches exactly
        if (reservation.amountMinorUnits != requiredAmountMinor) {
            return Pair(false, initialWallet)
        }

        // 3. Require pendingBalance >= requiredAmountMinor
        if (initialWallet.pendingBalance < requiredAmountMinor) {
            return Pair(false, initialWallet)
        }

        // 4. Calculate new values (release hold back to availableBalance)
        val newAvail = initialWallet.availableBalance + requiredAmountMinor
        val newPending = initialWallet.pendingBalance - requiredAmountMinor
        val syncBalanceDouble = newAvail / 100.0
        val syncLockedBalanceDouble = newPending / 100.0

        // 5. Remove only this reservation
        val updatedReservations = initialWallet.activeWithdrawals.toMutableMap()
        updatedReservations.remove(withdrawalId)

        val updatedWallet = initialWallet.copy(
            availableBalance = newAvail,
            pendingBalance = newPending,
            balanceDouble = syncBalanceDouble,
            lockedBalanceDouble = syncLockedBalanceDouble,
            activeWithdrawals = updatedReservations
        )

        return Pair(true, updatedWallet)
    }

    @Test
    fun test1_validApprovalSettlesPendingAndIncreasesTotalWithdrawn() {
        val initialWallet = UserWalletData(
            userId = "usr_001",
            availableBalance = 50000L, // ৳500
            pendingBalance = 20000L,   // ৳200
            totalWithdrawn = 10000L,   // ৳100
            activeWithdrawals = mapOf(
                "W101" to ActiveWithdrawalReservation(
                    withdrawalId = "W101",
                    amountMinorUnits = 20000L,
                    status = "REQUESTED",
                    transactionId = "TRX_W101"
                )
            )
        )

        val (success, settledWallet) = simulateApprovalTransaction(
            initialWallet = initialWallet,
            withdrawalId = "W101",
            requiredAmountMinor = 20000L
        )

        assertTrue("Approval transaction must succeed", success)
        assertEquals(50000L, settledWallet.availableBalance) // Available remains unchanged
        assertEquals(0L, settledWallet.pendingBalance)        // Pending decremented by 20000
        assertEquals(30000L, settledWallet.totalWithdrawn)     // Total withdrawn incremented
        assertNull(settledWallet.activeWithdrawals["W101"])   // Reservation consumed
        assertEquals(500.0, settledWallet.balanceDouble, 0.001) // balance synced to available / 100.0
        assertEquals(0.0, settledWallet.lockedBalanceDouble, 0.001) // lockedBalance synced to pending / 100.0
    }

    @Test
    fun test2_validRejectionRefundsPendingBackToAvailable() {
        val initialWallet = UserWalletData(
            userId = "usr_002",
            availableBalance = 30000L, // ৳300
            pendingBalance = 15000L,   // ৳150
            totalWithdrawn = 5000L,
            activeWithdrawals = mapOf(
                "W102" to ActiveWithdrawalReservation(
                    withdrawalId = "W102",
                    amountMinorUnits = 15000L,
                    status = "REQUESTED"
                )
            )
        )

        val (success, rejectedWallet) = simulateRejectionTransaction(
            initialWallet = initialWallet,
            withdrawalId = "W102",
            requiredAmountMinor = 15000L,
            reason = "Invalid Nagad account number"
        )

        assertTrue("Rejection transaction must succeed", success)
        assertEquals(45000L, rejectedWallet.availableBalance) // 30000 + 15000 refunded
        assertEquals(0L, rejectedWallet.pendingBalance)        // 15000 - 15000
        assertEquals(5000L, rejectedWallet.totalWithdrawn)     // Unchanged
        assertNull(rejectedWallet.activeWithdrawals["W102"])
        assertEquals(450.0, rejectedWallet.balanceDouble, 0.001)
        assertEquals(0.0, rejectedWallet.lockedBalanceDouble, 0.001)
    }

    @Test
    fun test3_missingReservationAbortsSettlementWithoutModifyingWallet() {
        val initialWallet = UserWalletData(
            userId = "usr_003",
            availableBalance = 50000L,
            pendingBalance = 20000L,
            activeWithdrawals = emptyMap() // No reservation for W103
        )

        val (success, wallet) = simulateApprovalTransaction(
            initialWallet = initialWallet,
            withdrawalId = "W103",
            requiredAmountMinor = 20000L
        )

        assertFalse("Approval must fail when reservation is missing", success)
        assertEquals(initialWallet, wallet) // Wallet completely unmodified
    }

    @Test
    fun test4_reservationAmountMismatchAbortsSettlement() {
        val initialWallet = UserWalletData(
            userId = "usr_004",
            availableBalance = 50000L,
            pendingBalance = 10000L,
            activeWithdrawals = mapOf(
                "W104" to ActiveWithdrawalReservation(
                    withdrawalId = "W104",
                    amountMinorUnits = 10000L // Reservation is ৳100
                )
            )
        )

        // Request attempts to claim ৳150 (15000L)
        val (success, wallet) = simulateApprovalTransaction(
            initialWallet = initialWallet,
            withdrawalId = "W104",
            requiredAmountMinor = 15000L
        )

        assertFalse("Approval must abort if reservation amount does not match", success)
        assertEquals(initialWallet, wallet)
    }

    @Test
    fun test5_insufficientPendingBalanceAbortsSettlement() {
        val initialWallet = UserWalletData(
            userId = "usr_005",
            availableBalance = 50000L,
            pendingBalance = 5000L, // Only 5000 pending
            activeWithdrawals = mapOf(
                "W105" to ActiveWithdrawalReservation(
                    withdrawalId = "W105",
                    amountMinorUnits = 10000L // But reservation says 10000
                )
            )
        )

        val (success, wallet) = simulateApprovalTransaction(
            initialWallet = initialWallet,
            withdrawalId = "W105",
            requiredAmountMinor = 10000L
        )

        assertFalse("Approval must abort if pendingBalance is less than requiredAmountMinor", success)
        assertEquals(initialWallet, wallet)
    }

    @Test
    fun test6_doubleApprovalIsIdempotentAndCannotPayTwice() {
        val initialWallet = UserWalletData(
            userId = "usr_006",
            availableBalance = 100000L,
            pendingBalance = 25000L,
            totalWithdrawn = 0L,
            activeWithdrawals = mapOf(
                "W106" to ActiveWithdrawalReservation(
                    withdrawalId = "W106",
                    amountMinorUnits = 25000L
                )
            )
        )

        // First approval
        val (firstSuccess, walletAfterFirst) = simulateApprovalTransaction(
            initialWallet = initialWallet,
            withdrawalId = "W106",
            requiredAmountMinor = 25000L
        )
        assertTrue(firstSuccess)
        assertEquals(25000L, walletAfterFirst.totalWithdrawn)
        assertEquals(0L, walletAfterFirst.pendingBalance)

        // Second approval attempt (double tap or concurrent admin approval)
        val (secondSuccess, walletAfterSecond) = simulateApprovalTransaction(
            initialWallet = walletAfterFirst,
            withdrawalId = "W106",
            requiredAmountMinor = 25000L
        )

        assertFalse("Second approval must fail safely because reservation was already removed", secondSuccess)
        assertEquals(25000L, walletAfterSecond.totalWithdrawn) // No double payout!
    }

    @Test
    fun test7_doubleRejectionCannotRefundTwice() {
        val initialWallet = UserWalletData(
            userId = "usr_007",
            availableBalance = 10000L,
            pendingBalance = 10000L,
            activeWithdrawals = mapOf(
                "W107" to ActiveWithdrawalReservation(
                    withdrawalId = "W107",
                    amountMinorUnits = 10000L
                )
            )
        )

        // First reject
        val (firstSuccess, walletAfterFirst) = simulateRejectionTransaction(
            initialWallet = initialWallet,
            withdrawalId = "W107",
            requiredAmountMinor = 10000L,
            reason = "Account closed"
        )
        assertTrue(firstSuccess)
        assertEquals(20000L, walletAfterFirst.availableBalance)

        // Second reject attempt
        val (secondSuccess, walletAfterSecond) = simulateRejectionTransaction(
            initialWallet = walletAfterFirst,
            withdrawalId = "W107",
            requiredAmountMinor = 10000L,
            reason = "Account closed"
        )

        assertFalse("Second rejection must fail safely without second refund", secondSuccess)
        assertEquals(20000L, walletAfterSecond.availableBalance)
    }

    @Test
    fun test8_approveAndRejectRaceResultsInExactlyOneSettlement() {
        val initialWallet = UserWalletData(
            userId = "usr_008",
            availableBalance = 50000L,
            pendingBalance = 20000L,
            totalWithdrawn = 0L,
            activeWithdrawals = mapOf(
                "W108" to ActiveWithdrawalReservation(
                    withdrawalId = "W108",
                    amountMinorUnits = 20000L
                )
            )
        )

        // Suppose Admin A's approve transaction wins the race:
        val (approveSuccess, walletAfterApprove) = simulateApprovalTransaction(
            initialWallet = initialWallet,
            withdrawalId = "W108",
            requiredAmountMinor = 20000L
        )
        assertTrue(approveSuccess)

        // Admin B's reject transaction arrives milliseconds later:
        val (rejectSuccess, walletAfterRejectAttempt) = simulateRejectionTransaction(
            initialWallet = walletAfterApprove,
            withdrawalId = "W108",
            requiredAmountMinor = 20000L,
            reason = "Duplicate attempt"
        )

        assertFalse("Subsequent reject must be rejected because reservation lock is already consumed", rejectSuccess)
        assertEquals(0L, walletAfterRejectAttempt.pendingBalance)
        assertEquals(50000L, walletAfterRejectAttempt.availableBalance)
        assertEquals(20000L, walletAfterRejectAttempt.totalWithdrawn)
    }

    @Test
    fun test9_otherActiveWithdrawalsAreStrictlyPreserved() {
        val initialWallet = UserWalletData(
            userId = "usr_009",
            availableBalance = 80000L,
            pendingBalance = 50000L, // 20000 (W109A) + 30000 (W109B)
            activeWithdrawals = mapOf(
                "W109A" to ActiveWithdrawalReservation(withdrawalId = "W109A", amountMinorUnits = 20000L),
                "W109B" to ActiveWithdrawalReservation(withdrawalId = "W109B", amountMinorUnits = 30000L)
            )
        )

        val (success, settledWallet) = simulateApprovalTransaction(
            initialWallet = initialWallet,
            withdrawalId = "W109A",
            requiredAmountMinor = 20000L
        )

        assertTrue(success)
        assertNull(settledWallet.activeWithdrawals["W109A"]) // W109A removed
        assertNotNull(settledWallet.activeWithdrawals["W109B"]) // W109B perfectly preserved!
        assertEquals(30000L, settledWallet.activeWithdrawals["W109B"]?.amountMinorUnits)
        assertEquals(30000L, settledWallet.pendingBalance)
    }

    @Test
    fun test10_walletBalanceConsistencyInvariantsMaintained() {
        val initialWallet = UserWalletData(
            userId = "usr_010",
            availableBalance = 75000L, // ৳750
            pendingBalance = 25000L,   // ৳250
            activeWithdrawals = mapOf(
                "W110" to ActiveWithdrawalReservation(withdrawalId = "W110", amountMinorUnits = 25000L)
            )
        )

        val (success, settled) = simulateApprovalTransaction(
            initialWallet = initialWallet,
            withdrawalId = "W110",
            requiredAmountMinor = 25000L
        )

        assertTrue(success)
        // Verify balance == availableBalance / 100.0
        assertEquals(settled.availableBalance / 100.0, settled.balanceDouble, 0.0001)
        // Verify lockedBalance == pendingBalance / 100.0
        assertEquals(settled.pendingBalance / 100.0, settled.lockedBalanceDouble, 0.0001)
    }

    @Test
    fun test11_blankRejectionReasonIsRejected() {
        val initialWallet = UserWalletData(
            userId = "usr_011",
            availableBalance = 20000L,
            pendingBalance = 10000L,
            activeWithdrawals = mapOf(
                "W111" to ActiveWithdrawalReservation(withdrawalId = "W111", amountMinorUnits = 10000L)
            )
        )

        val (success, wallet) = simulateRejectionTransaction(
            initialWallet = initialWallet,
            withdrawalId = "W111",
            requiredAmountMinor = 10000L,
            reason = "   " // Whitespace only
        )

        assertFalse("Rejection must fail if reason is blank", success)
        assertEquals(initialWallet, wallet)
    }

    @Test
    fun test12_unauthorizedAdminSessionFailsVerification() {
        assertFalse("Unverified admin session must not pass isSuperAdminVerified", unverifiedSession.isSuperAdminVerified)
        assertTrue("Super Admin session must pass isSuperAdminVerified", superAdminSession.isSuperAdminVerified)
    }

    @Test
    fun test13_withdrawalStatusParsing() {
        assertEquals(WithdrawalStatus.COMPLETED, WithdrawalStatus.fromString("COMPLETED"))
        assertEquals(WithdrawalStatus.COMPLETED, WithdrawalStatus.fromString("APPROVED"))
        assertEquals(WithdrawalStatus.REJECTED, WithdrawalStatus.fromString("REJECTED"))
        assertEquals(WithdrawalStatus.PENDING, WithdrawalStatus.fromString("PENDING"))
        assertEquals(WithdrawalStatus.REQUESTED, WithdrawalStatus.fromString("REQUESTED"))
        assertEquals(WithdrawalStatus.REQUESTED, WithdrawalStatus.fromString(null))
    }

    @Test
    fun test14_tournamentMathConversion() {
        assertEquals(10000L, TournamentMath.takaToMinorUnits(100))
        assertEquals(100L, 10000L / 100L)
    }
}
