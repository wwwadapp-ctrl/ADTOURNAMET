package com.example.core.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.core.model.AdminResultItem

object WinningProofNotificationHelper {
    private const val CHANNEL_ID = "winning_proof_submission_channel"
    private const val CHANNEL_NAME = "Winning Proof Submissions"
    private const val PREFS_NAME = "winning_proof_notified_prefs"
    private const val KEY_NOTIFIED_IDS = "notified_result_ids"

    fun showWinningProofNotification(context: Context, item: AdminResultItem) {
        val resultId = item.resultId
        if (resultId.isBlank()) return

        // Duplicate prevention check using SharedPreferences + in-memory state
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val notifiedSet = prefs.getStringSet(KEY_NOTIFIED_IDS, emptySet()) ?: emptySet()
        if (notifiedSet.contains(resultId)) {
            return // Already notified
        }

        // Save to notified set to prevent duplicate notifications
        val newSet = notifiedSet.toMutableSet()
        newSet.add(resultId)
        prefs.edit().putStringSet(KEY_NOTIFIED_IDS, newSet).apply()

        createNotificationChannel(context)

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("navigate_to", "results")
            putExtra("focus_result_id", resultId)
        }

        val pendingIntentFlags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }

        val pendingIntent = PendingIntent.getActivity(context, resultId.hashCode(), intent, pendingIntentFlags)

        val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        val matchNum = if (item.matchNumber.isNotBlank()) item.matchNumber else "#001"
        val roomCode = if (item.roomCode.isNotBlank()) item.roomCode else "N/A"

        val title = "🏆 Winning Proof Submitted"
        val bodyText = "Match #$matchNum\nRoom Code: $roomCode"

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_agenda)
            .setContentTitle(title)
            .setContentText("Match #$matchNum — Room Code: $roomCode")
            .setStyle(NotificationCompat.BigTextStyle().bigText("Admin review required for submitted winning proof.\n$bodyText"))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setAutoCancel(true)
            .setSound(soundUri)
            .setVibrate(longArrayOf(0, 300, 200, 300))
            .setContentIntent(pendingIntent)
            .build()

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(resultId.hashCode(), notification)
    }

    private fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alerts admin when new tournament winning proofs are submitted"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 300, 200, 300)
                setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION), null)
            }
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }
}
