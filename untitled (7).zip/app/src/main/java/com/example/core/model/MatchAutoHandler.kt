package com.example.core.model

/**
     * Authoritative Match Auto-Handling / Auto-Delete and Refund Helper.
     * Implements 1-hour and 2-hour rule timing, state protections, and idempotent refund safety.
     */
object MatchAutoHandler {
    const val ONE_HOUR_MS = 3600_000L
    const val TWO_HOURS_MS = 7200_000L

    /**
     * Evaluates whether a match is eligible for automatic cleanup / expiration deletion
     * based on authoritative server time, match status, lifecycle reference timestamp,
     * and pending Winning Proof protection.
     */
    fun isEligibleForCleanup(
        match: AdminMatchItem,
        currentTime: Long,
        hasPendingWinningProof: Boolean
    ): Boolean {
        // Rule: Never delete a match with a pending Winning Proof requiring Admin review
        if (hasPendingWinningProof) return false

        val scheduledTime = if (match.scheduledAt > 0) match.scheduledAt else match.scheduledTime
        if (scheduledTime <= 0L) return false

        return when (match.status) {
            MatchStatus.UPCOMING,
            MatchStatus.AVAILABLE,
            MatchStatus.FULL,
            MatchStatus.CODE_ADDED -> {
                // Rule 1: Eligible after exactly 1 hour from scheduled time
                currentTime >= (scheduledTime + ONE_HOUR_MS)
            }
            MatchStatus.RUNNING -> {
                // Rule 2: Active matches protected at 1 hour; eligible after 2 hours from startedAt or scheduledTime
                val refTime = if (match.startedAt != null && match.startedAt > 0) match.startedAt else scheduledTime
                currentTime >= (refTime + TWO_HOURS_MS)
            }
            MatchStatus.RESULT_SUBMITTED -> {
                // Rule 2: Eligible after 2 hours from updatedAt or scheduledTime
                val refTime = if (match.updatedAt > 0) match.updatedAt else scheduledTime
                currentTime >= (refTime + TWO_HOURS_MS)
            }
            MatchStatus.COMPLETED -> {
                // Rule 2: Eligible after 2 hours from updatedAt or scheduledTime
                val refTime = if (match.updatedAt > 0) match.updatedAt else scheduledTime
                currentTime >= (refTime + TWO_HOURS_MS)
            }
            else -> {
                // CANCELLED, PAUSED, DISABLED, UNKNOWN managed separately or ignored
                false
            }
        }
    }

    /**
     * Determines whether an expired match requires a player entry fee refund.
     * - Exactly 1 player joined: Refund required.
     * - 0 players joined: No refund needed.
     * - 2 players joined: Lifecycle rules apply (no expiration refund unless cancelled per protocol).
     */
    fun requiresRefund(match: AdminMatchItem): Boolean {
        return match.joinedPlayersCount == 1
    }

    /**
     * Idempotent refund processor tracker to ensure a player is never refunded twice
     * and duplicate refund transactions are prevented if the cleanup routine runs multiple times.
     */
    class IdempotentRefundTracker {
        private val refundedMatchIds = mutableSetOf<String>()

        fun processRefundOnce(matchId: String, action: () -> Unit): Boolean {
            synchronized(refundedMatchIds) {
                if (refundedMatchIds.contains(matchId)) {
                    return false // Already refunded; prevent duplicate execution
                }
                action()
                refundedMatchIds.add(matchId)
                return true
            }
        }

        fun isRefunded(matchId: String): Boolean {
            synchronized(refundedMatchIds) {
                return refundedMatchIds.contains(matchId)
            }
        }
    }
}
