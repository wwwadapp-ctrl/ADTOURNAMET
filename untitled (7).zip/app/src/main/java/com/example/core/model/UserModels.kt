package com.example.core.model

/**
 * Domain entity representing a registered player in the AD TOURNAMENT platform.
 * Synchronized with authoritative Firebase RTDB /users node.
 */
data class AdminUserItem(
    val uid: String = "",
    val name: String = "",
    val phone: String = "",
    val email: String = "",
    val isBanned: Boolean = false,
    val status: String = "ACTIVE", // "ACTIVE", "BANNED", "BLOCKED"
    val balanceMinor: Long = 0L,
    val depositBalanceMinor: Long = 0L,
    val winningBalanceMinor: Long = 0L,
    val matchesPlayed: Int = 0,
    val matchesWon: Int = 0,
    val joinedAt: Long = 0L,
    val banReason: String = "",
    val bannedAt: Long = 0L,
    val deviceModel: String = ""
) {
    val displayName: String
        get() = when {
            name.isNotBlank() -> name
            phone.isNotBlank() -> phone
            else -> "Player #${uid.takeLast(6).uppercase()}"
        }

    val formattedPhone: String
        get() = if (phone.isNotBlank()) phone else "Not Registered"

    val formattedTotalBalance: String
        get() = TournamentMath.formatTaka(balanceMinor)

    val formattedDepositBalance: String
        get() = TournamentMath.formatTaka(depositBalanceMinor)

    val formattedWinningBalance: String
        get() = TournamentMath.formatTaka(winningBalanceMinor)

    val isActive: Boolean
        get() = !isBanned &&
                !status.equals("BANNED", ignoreCase = true) &&
                !status.equals("BLOCKED", ignoreCase = true)
}

/**
 * High-level summary of registered players for the Users Directory.
 */
data class UsersSummary(
    val totalUsers: Int = 0,
    val activeUsers: Int = 0,
    val bannedUsers: Int = 0
)
