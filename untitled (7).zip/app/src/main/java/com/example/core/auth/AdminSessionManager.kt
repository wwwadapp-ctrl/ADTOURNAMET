package com.example.core.auth

import com.example.core.model.AdminAuthState
import com.example.core.model.AuthResult
import com.example.core.model.SuperAdminAuthStatus
import com.example.core.model.SuperAdminSession
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Authoritative session manager for the AD TOURNAMENT Super Admin Panel.
 * Enforces zero-auto-login, strictly single Super Admin authorization, and safe session revocation.
 */
class AdminSessionManager(
    private var authRepository: AdminAuthRepository = FirebaseAuthRepository()
) {
    private val _authState = MutableStateFlow<AdminAuthState>(AdminAuthState.Unauthenticated)
    val authState: StateFlow<AdminAuthState> = _authState.asStateFlow()

    fun updateRepository(repository: AdminAuthRepository) {
        this.authRepository = repository
    }

    /**
     * Verifies if a valid, authoritatively verified Super Admin session already exists.
     * If session is missing or unauthorized, state remains or is set to Unauthenticated.
     */
    suspend fun checkExistingSession() {
        val current = authRepository.getCurrentSession()
        if (current == null) {
            _authState.value = AdminAuthState.Unauthenticated
            return
        }
        _authState.value = AdminAuthState.Loading
        when (val status = authRepository.verifySuperAdminAuthorization(current.uid)) {
            is SuperAdminAuthStatus.Authorized -> {
                _authState.value = AdminAuthState.Authenticated(status.session)
            }
            is SuperAdminAuthStatus.Unauthorized -> {
                authRepository.signOut()
                _authState.value = AdminAuthState.AccessDenied(status.reason)
            }
            is SuperAdminAuthStatus.BackendPending -> {
                authRepository.signOut()
                _authState.value = AdminAuthState.AccessDenied(status.message)
            }
        }
    }

    /**
     * Executes authentication and authoritative Super Admin verification.
     */
    suspend fun login(identifier: String, password: String): AuthResult {
        if (identifier.isBlank()) {
            return AuthResult.Failure("Admin mobile number or identifier is required.")
        }
        if (password.isBlank()) {
            return AuthResult.Failure("Admin password is required.")
        }

        _authState.value = AdminAuthState.Loading
        val result = authRepository.signIn(identifier.trim(), password)
        when (result) {
            is AuthResult.Success -> {
                _authState.value = AdminAuthState.Authenticated(result.session)
            }
            is AuthResult.AccessDenied -> {
                _authState.value = AdminAuthState.AccessDenied(result.reason)
            }
            is AuthResult.Failure -> {
                _authState.value = AdminAuthState.Unauthenticated
            }
        }
        return result
    }

    /**
     * Revokes Super Admin session and resets state to Unauthenticated.
     */
    suspend fun logout() {
        authRepository.signOut()
        _authState.value = AdminAuthState.Unauthenticated
    }

    companion object {
        @Volatile
        private var defaultInstance: AdminSessionManager? = null

        fun getInstance(customRepo: AdminAuthRepository? = null): AdminSessionManager {
            return defaultInstance ?: synchronized(this) {
                defaultInstance ?: AdminSessionManager(
                    customRepo ?: FirebaseAuthRepository()
                ).also { defaultInstance = it }
            }
        }

        // For unit testing isolation
        fun resetForTesting(newManager: AdminSessionManager? = null) {
            defaultInstance = newManager
        }
    }
}
