package com.example.core.model

/**
 * Target routing type for platform notifications.
 */
enum class NotificationTargetType(val value: String) {
    SPECIFIC_USER("SPECIFIC_USER"),
    MATCH_PARTICIPANTS("MATCH_PARTICIPANTS"),
    ALL_USERS("ALL_USERS");

    companion object {
        fun fromString(raw: String?): NotificationTargetType {
            val normalized = raw?.trim()?.uppercase() ?: return ALL_USERS
            return when (normalized) {
                "SPECIFIC_USER" -> SPECIFIC_USER
                "MATCH_PARTICIPANTS" -> MATCH_PARTICIPANTS
                else -> ALL_USERS
            }
        }
    }
}

/**
 * Domain entity representing a persistent notification record stored at:
 * /notifications/{notificationId}
 */
data class AdminNotificationItem(
    val id: String = "",
    val title: String = "",
    val message: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val targetType: String = NotificationTargetType.ALL_USERS.value,
    val targetId: String = "ALL",
    val senderAdmin: String = ""
) {
    val validatedTargetType: NotificationTargetType
        get() = NotificationTargetType.fromString(targetType)

    val isBroadcast: Boolean
        get() = validatedTargetType == NotificationTargetType.ALL_USERS

    val isUserSpecific: Boolean
        get() = validatedTargetType == NotificationTargetType.SPECIFIC_USER

    val isMatchParticipants: Boolean
        get() = validatedTargetType == NotificationTargetType.MATCH_PARTICIPANTS
}
