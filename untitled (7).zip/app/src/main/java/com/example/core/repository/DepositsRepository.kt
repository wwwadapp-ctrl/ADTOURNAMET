package com.example.core.repository

import android.util.Log
import com.example.core.config.FirebaseAdminConfig
import com.example.core.model.AdminDepositItem
import com.example.core.model.DepositStatus
import com.example.core.model.NotificationTargetType
import com.example.core.model.SuperAdminSession
import com.example.core.model.TournamentMath
import com.example.core.model.UserWalletData
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.MutableData
import com.google.firebase.database.Transaction
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.tasks.await
import java.util.UUID
import kotlin.coroutines.resume

/**
 * Result data holder for atomic wallet deposit credit transactions.
 */
data class WalletDepositCreditResult(
    val success: Boolean,
    val creditedAmountMinorUnits: Long = 0L,
    val newAvailableBalance: Long = 0L,
    val newDepositBalance: Long = 0L,
    val newTotalDeposited: Long = 0L,
    val alreadySettled: Boolean = false,
    val errorMessage: String? = null
)

/**
 * Result data holder for authoritative deposit status lock transactions.
 */
data class DepositStatusLockResult(
    val success: Boolean,
    val alreadySettled: Boolean = false,
    val currentStatus: DepositStatus = DepositStatus.PENDING,
    val errorMessage: String? = null
)

/**
 * Interface for managing deposit requests, executing direct wallet credits, and logging audit events.
 */
interface DepositsRepository {
    fun observeDeposits(): Flow<List<AdminDepositItem>>
    suspend fun getWallet(userId: String): UserWalletData?
    suspend fun getDeposit(depositId: String): AdminDepositItem?
    suspend fun approveDeposit(
        depositId: String,
        actualReceivedMinorUnits: Long,
        adminSession: SuperAdminSession
    ): Result<Unit>
    suspend fun rejectDeposit(depositId: String, reason: String, adminSession: SuperAdminSession): Result<Unit>
}

/**
 * Production Firebase Realtime Database repository executing direct wallet credit top-up and audit logging.
 * Long minor units (paisa) are the authoritative financial source of truth.
 */
class FirebaseDepositsRepository(
    initialDeposits: List<AdminDepositItem>? = null,
    initialWallets: Map<String, UserWalletData>? = null
) : DepositsRepository {
    private val database: FirebaseDatabase? = try {
        if (FirebaseDatabase.getInstance().app != null) {
            FirebaseDatabase.getInstance(FirebaseAdminConfig.RTDB_BASE_URL)
        } else {
            null
        }
    } catch (e: Exception) {
        null
    }

    companion object {
        val defaultSeedDeposits: List<AdminDepositItem> = listOf(
            AdminDepositItem(
                id = "dep_tanvir_01",
                userId = "usr_tanvir_9812",
                userName = "Tanvir Hasan",
                userPhone = "01712345678",
                amountTaka = 500,
                amountMinorUnits = TournamentMath.takaToMinorUnits(500),
                transactionId = "8N2J91823A",
                paymentMethod = "bKash",
                senderNumber = "01712345678",
                receiverNumber = "01700000000",
                status = DepositStatus.PENDING,
                createdAt = System.currentTimeMillis() - 3600000L
            ),
            AdminDepositItem(
                id = "dep_shakib_02",
                userId = "usr_shakib_4412",
                userName = "Shakib Rahman",
                userPhone = "01823490123",
                amountTaka = 300,
                amountMinorUnits = TournamentMath.takaToMinorUnits(300),
                transactionId = "4M2K91823B",
                paymentMethod = "Nagad",
                senderNumber = "01823490123",
                receiverNumber = "01800000000",
                status = DepositStatus.PENDING,
                createdAt = System.currentTimeMillis() - 7200000L
            ),
            AdminDepositItem(
                id = "dep_fahim_03",
                userId = "usr_fahim_3321",
                userName = "Fahim Ahmed",
                userPhone = "01678123456",
                amountTaka = 200,
                amountMinorUnits = TournamentMath.takaToMinorUnits(200),
                transactionId = "7K9L12891C",
                paymentMethod = "bKash",
                senderNumber = "01678123456",
                receiverNumber = "01700000000",
                status = DepositStatus.APPROVED,
                createdAt = System.currentTimeMillis() - 86400000L,
                processedAt = System.currentTimeMillis() - 85000000L,
                processedBy = "01700000000"
            )
        )

        val defaultSeedWallets: Map<String, UserWalletData> = mapOf(
            "usr_tanvir_9812" to UserWalletData(
                userId = "usr_tanvir_9812",
                balance = TournamentMath.takaToMinorUnits(850),
                availableBalance = TournamentMath.takaToMinorUnits(850),
                depositBalance = TournamentMath.takaToMinorUnits(500),
                winningBalance = TournamentMath.takaToMinorUnits(350),
                pendingBalance = 0L,
                totalDeposited = TournamentMath.takaToMinorUnits(1500),
                totalWithdrawn = TournamentMath.takaToMinorUnits(650),
                balanceDouble = 850.0,
                lockedBalanceDouble = 0.0,
                updatedAt = System.currentTimeMillis()
            ),
            "usr_shakib_4412" to UserWalletData(
                userId = "usr_shakib_4412",
                balance = TournamentMath.takaToMinorUnits(1200),
                availableBalance = TournamentMath.takaToMinorUnits(1200),
                depositBalance = TournamentMath.takaToMinorUnits(500),
                winningBalance = TournamentMath.takaToMinorUnits(700),
                pendingBalance = 0L,
                totalDeposited = TournamentMath.takaToMinorUnits(2000),
                totalWithdrawn = TournamentMath.takaToMinorUnits(800),
                balanceDouble = 1200.0,
                lockedBalanceDouble = 0.0,
                updatedAt = System.currentTimeMillis()
            ),
            "usr_mehedi_7731" to UserWalletData(
                userId = "usr_mehedi_7731",
                balance = TournamentMath.takaToMinorUnits(150),
                availableBalance = TournamentMath.takaToMinorUnits(150),
                depositBalance = TournamentMath.takaToMinorUnits(150),
                winningBalance = 0L,
                pendingBalance = 0L,
                totalDeposited = TournamentMath.takaToMinorUnits(150),
                totalWithdrawn = 0L,
                balanceDouble = 150.0,
                lockedBalanceDouble = 0.0,
                updatedAt = System.currentTimeMillis()
            ),
            "usr_fahim_3321" to UserWalletData(
                userId = "usr_fahim_3321",
                balance = TournamentMath.takaToMinorUnits(420),
                availableBalance = TournamentMath.takaToMinorUnits(420),
                depositBalance = TournamentMath.takaToMinorUnits(100),
                winningBalance = TournamentMath.takaToMinorUnits(320),
                pendingBalance = 0L,
                totalDeposited = TournamentMath.takaToMinorUnits(500),
                totalWithdrawn = TournamentMath.takaToMinorUnits(80),
                balanceDouble = 420.0,
                lockedBalanceDouble = 0.0,
                updatedAt = System.currentTimeMillis()
            ),
            "usr_rakib_5589" to UserWalletData(
                userId = "usr_rakib_5589",
                balance = TournamentMath.takaToMinorUnits(2400),
                availableBalance = TournamentMath.takaToMinorUnits(2400),
                depositBalance = TournamentMath.takaToMinorUnits(1000),
                winningBalance = TournamentMath.takaToMinorUnits(1400),
                pendingBalance = 0L,
                totalDeposited = TournamentMath.takaToMinorUnits(3000),
                totalWithdrawn = TournamentMath.takaToMinorUnits(600),
                balanceDouble = 2400.0,
                lockedBalanceDouble = 0.0,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    // In-memory cache for observed deposits and wallets in live/offline environment
    private val localDepositsState = MutableStateFlow<List<AdminDepositItem>>(
        initialDeposits ?: defaultSeedDeposits
    )
    private val localWalletsState = (initialWallets ?: defaultSeedWallets).toMutableMap()

    private fun verifySuperAdmin(adminSession: SuperAdminSession) {
        if (!adminSession.isSuperAdminVerified || adminSession.uid.isBlank()) {
            throw SecurityException("Unauthorized: Deposit operations require verified Super Admin session.")
        }
    }

    override fun observeDeposits(): Flow<List<AdminDepositItem>> {
        val db = database
        if (db == null) {
            return localDepositsState.asStateFlow()
        }

        return callbackFlow {
            val ref = db.getReference(FirebaseAdminConfig.NODE_DEPOSITS)
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val parsedList = mutableListOf<AdminDepositItem>()
                    for (child in snapshot.children) {
                        val id = child.key ?: child.child("id").value?.toString() ?: ""
                        if (id.isBlank()) continue

                        val userId = child.child("userId").value?.toString()
                            ?: child.child("uid").value?.toString()
                            ?: ""
                        val userName = child.child("userName").value?.toString()
                            ?: child.child("name").value?.toString()
                            ?: ""
                        val userPhone = child.child("userPhone").value?.toString()
                            ?: child.child("phone").value?.toString()
                            ?: child.child("senderNumber").value?.toString()
                            ?: ""

                        val rawMinor = (child.child("amountMinorUnits").value as? Number)?.toLong()
                            ?: (child.child("amount").value as? Number)?.toLong()
                            ?: (child.child("amountTaka").value as? Number)?.toLong()?.let {
                                TournamentMath.takaToMinorUnits(it)
                            }
                            ?: 0L

                        val rawAmount = (child.child("amountTaka").value as? Number)?.toLong()
                            ?: (rawMinor / 100L)

                        val trxId = child.child("transactionId").value?.toString()
                            ?: child.child("trxId").value?.toString()
                            ?: child.child("trxID").value?.toString()
                            ?: ""
                        val method = child.child("paymentMethod").value?.toString()
                            ?: child.child("method").value?.toString()
                            ?: "bKash"
                        val sender = child.child("senderNumber").value?.toString() ?: ""
                        val receiver = child.child("receiverNumber").value?.toString() ?: ""
                        val statusStr = child.child("status").value?.toString()
                        val status = DepositStatus.fromString(statusStr)

                        val createdAt = (child.child("createdAt").value as? Number)?.toLong()
                            ?: (child.child("timestamp").value as? Number)?.toLong()
                            ?: 0L
                        val processedAt = (child.child("processedAt").value as? Number)?.toLong()
                        val processedBy = child.child("processedBy").value?.toString()
                        val rejectReason = child.child("rejectionReason").value?.toString()

                        parsedList.add(
                            AdminDepositItem(
                                id = id,
                                userId = userId,
                                userName = userName,
                                userPhone = userPhone,
                                amountTaka = rawAmount,
                                amountMinorUnits = rawMinor,
                                transactionId = trxId,
                                paymentMethod = method,
                                senderNumber = sender,
                                receiverNumber = receiver,
                                status = status,
                                createdAt = createdAt,
                                processedAt = processedAt,
                                processedBy = processedBy,
                                rejectionReason = rejectReason
                            )
                        )
                    }

                    // Sort newest first
                    parsedList.sortByDescending { it.createdAt }
                    localDepositsState.value = parsedList
                    trySend(parsedList)
                }

                override fun onCancelled(error: DatabaseError) {
                    close(error.toException())
                }
            }
            ref.addValueEventListener(listener)
            awaitClose { ref.removeEventListener(listener) }
        }
    }

    override suspend fun getDeposit(depositId: String): AdminDepositItem? {
        val db = database ?: return localDepositsState.value.find { it.id == depositId }
        return try {
            val child = db.getReference(FirebaseAdminConfig.NODE_DEPOSITS).child(depositId).get().await()
            if (!child.exists()) return null

            val id = child.key ?: depositId
            val userId = child.child("userId").value?.toString()
                ?: child.child("uid").value?.toString()
                ?: ""
            val userName = child.child("userName").value?.toString()
                ?: child.child("name").value?.toString()
                ?: ""
            val userPhone = child.child("userPhone").value?.toString()
                ?: child.child("phone").value?.toString()
                ?: child.child("senderNumber").value?.toString()
                ?: ""

            val rawMinor = (child.child("amountMinorUnits").value as? Number)?.toLong()
                ?: (child.child("amount").value as? Number)?.toLong()
                ?: (child.child("amountTaka").value as? Number)?.toLong()?.let {
                    TournamentMath.takaToMinorUnits(it)
                }
                ?: 0L

            val rawAmount = (child.child("amountTaka").value as? Number)?.toLong()
                ?: (rawMinor / 100L)

            val trxId = child.child("transactionId").value?.toString()
                ?: child.child("trxId").value?.toString()
                ?: child.child("trxID").value?.toString()
                ?: ""
            val method = child.child("paymentMethod").value?.toString()
                ?: child.child("method").value?.toString()
                ?: "bKash"
            val sender = child.child("senderNumber").value?.toString() ?: ""
            val receiver = child.child("receiverNumber").value?.toString() ?: ""
            val statusStr = child.child("status").value?.toString()
            val status = DepositStatus.fromString(statusStr)

            val createdAt = (child.child("createdAt").value as? Number)?.toLong()
                ?: (child.child("timestamp").value as? Number)?.toLong()
                ?: 0L
            val processedAt = (child.child("processedAt").value as? Number)?.toLong()
            val processedBy = child.child("processedBy").value?.toString()
            val rejectReason = child.child("rejectionReason").value?.toString()

            AdminDepositItem(
                id = id,
                userId = userId,
                userName = userName,
                userPhone = userPhone,
                amountTaka = rawAmount,
                amountMinorUnits = rawMinor,
                transactionId = trxId,
                paymentMethod = method,
                senderNumber = sender,
                receiverNumber = receiver,
                status = status,
                createdAt = createdAt,
                processedAt = processedAt,
                processedBy = processedBy,
                rejectionReason = rejectReason
            )
        } catch (_: Exception) {
            localDepositsState.value.find { it.id == depositId }
        }
    }

    override suspend fun getWallet(userId: String): UserWalletData? {
        val db = database
        if (db != null) {
            try {
                val snap = db.getReference(FirebaseAdminConfig.NODE_WALLETS).child(userId).get().await()
                if (snap.exists()) {
                    val bal = (snap.child("balance").value as? Number)?.toLong() ?: 0L
                    val avail = (snap.child("availableBalance").value as? Number)?.toLong() ?: bal
                    val dep = (snap.child("depositBalance").value as? Number)?.toLong() ?: 0L
                    val win = (snap.child("winningBalance").value as? Number)?.toLong() ?: 0L
                    val pending = (snap.child("pendingBalance").value as? Number)?.toLong() ?: 0L
                    val totalDep = (snap.child("totalDeposited").value as? Number)?.toLong() ?: 0L
                    val totalWith = (snap.child("totalWithdrawn").value as? Number)?.toLong() ?: 0L
                    val balDouble = (snap.child("balanceDouble").value as? Number)?.toDouble() ?: (bal / 100.0)
                    val lockedDouble = (snap.child("lockedBalanceDouble").value as? Number)?.toDouble() ?: (pending / 100.0)
                    val updated = (snap.child("updatedAt").value as? Number)?.toLong() ?: 0L
                    return UserWalletData(
                        userId = userId,
                        balance = bal,
                        availableBalance = avail,
                        depositBalance = dep,
                        winningBalance = win,
                        pendingBalance = pending,
                        totalDeposited = totalDep,
                        totalWithdrawn = totalWith,
                        balanceDouble = balDouble,
                        lockedBalanceDouble = lockedDouble,
                        updatedAt = updated
                    )
                }
            } catch (_: Exception) {
            }
        }
        return localWalletsState[userId]
    }

    override suspend fun approveDeposit(
        depositId: String,
        actualReceivedMinorUnits: Long,
        adminSession: SuperAdminSession
    ): Result<Unit> = runCatching {
        verifySuperAdmin(adminSession)

        val deposit = getDeposit(depositId)
            ?: throw IllegalArgumentException("Deposit with ID '$depositId' does not exist.")

        if (deposit.status == DepositStatus.APPROVED) {
            throw IllegalStateException("Deposit '$depositId' is already APPROVED. Operation aborted.")
        }
        if (deposit.status == DepositStatus.REJECTED) {
            throw IllegalStateException("Deposit '$depositId' is already REJECTED and cannot be approved.")
        }
        if (deposit.status != DepositStatus.PENDING) {
            throw IllegalStateException("Deposit '$depositId' is not in PENDING status (current: ${deposit.status.name}).")
        }

        val userId = deposit.userId
        require(userId.isNotBlank()) { "Target User ID is required to credit wallet." }

        val requestedMinorUnits = if (deposit.amountMinorUnits > 0L) {
            deposit.amountMinorUnits
        } else {
            TournamentMath.takaToMinorUnits(deposit.amountTaka)
        }

        require(requestedMinorUnits > 0L) {
            "Requested deposit amount must be strictly greater than 0."
        }
        require(actualReceivedMinorUnits > 0L) {
            "Actual received amount must be strictly greater than 0."
        }
        require(actualReceivedMinorUnits == requestedMinorUnits) {
            "Amount verification mismatch: Admin verified $actualReceivedMinorUnits paisa (৳${actualReceivedMinorUnits / 100}) but user requested $requestedMinorUnits paisa (৳${requestedMinorUnits / 100}). Approval blocked."
        }

        val now = System.currentTimeMillis()
        val deterministicTrxId = if (deposit.transactionId.isNotBlank()) {
            deposit.transactionId.trim()
        } else {
            "DEP_$depositId"
        }
        val deterministicLogId = "AUDIT_DEP_$depositId"
        val amountTaka = requestedMinorUnits / 100L

        val db = database
        if (db == null) {
            // Offline / JVM unit test environment: execute in-memory atomic update
            val currentDeposits = localDepositsState.value.toMutableList()
            val index = currentDeposits.indexOfFirst { it.id == depositId }
            if (index >= 0) {
                currentDeposits[index] = deposit.copy(
                    status = DepositStatus.APPROVED,
                    processedAt = now,
                    processedBy = adminSession.identifier
                )
                localDepositsState.value = currentDeposits
            }

            val existingWallet = localWalletsState[userId] ?: UserWalletData(userId = userId)
            val newAvail = existingWallet.availableBalance + requestedMinorUnits
            val newDep = existingWallet.depositBalance + requestedMinorUnits
            val newTotalDep = existingWallet.totalDeposited + requestedMinorUnits
            val newTotalBal = newAvail + existingWallet.pendingBalance

            localWalletsState[userId] = existingWallet.copy(
                balance = newTotalBal,
                availableBalance = newAvail,
                depositBalance = newDep,
                totalDeposited = newTotalDep,
                balanceDouble = newTotalBal / 100.0,
                lockedBalanceDouble = existingWallet.pendingBalance / 100.0,
                updatedAt = now
            )
            sendDepositNotification(
                userId = userId,
                title = "Deposit Approved / ডিপোজিট অনুমোদিত",
                message = "Your deposit of ৳$amountTaka has been approved and credited to your wallet.",
                adminSession = adminSession
            )
            return@runCatching
        }

        // Step 1: Secure Authoritative Idempotency Lock on /deposits/{depositId} via runTransaction
        val depositRef = db.getReference(FirebaseAdminConfig.NODE_DEPOSITS).child(depositId)
        val lockResult = executeDepositStatusLockTransaction(
            depositRef = depositRef,
            adminSession = adminSession,
            verifiedAmountMinor = requestedMinorUnits,
            deterministicTrxId = deterministicTrxId,
            now = now
        )

        if (!lockResult.success) {
            if (lockResult.alreadySettled) {
                throw IllegalStateException("Deposit '$depositId' has already been approved or settled concurrently.")
            }
            throw IllegalStateException(lockResult.errorMessage ?: "Failed to lock deposit status.")
        }

        // Step 2: Atomic Wallet Credit via runTransaction on /wallets/{userId}
        val walletRef = db.getReference(FirebaseAdminConfig.NODE_WALLETS).child(userId)
        val creditResult = executeWalletDepositCreditTransaction(
            walletRef = walletRef,
            depositId = depositId,
            creditedAmountMinor = requestedMinorUnits,
            now = now
        )

        if (!creditResult.success) {
            throw IllegalStateException(creditResult.errorMessage ?: "Wallet credit transaction failed.")
        }

        // Step 3: Write secondary mirrored nodes, ledger records, and audit logs
        val updates = hashMapOf<String, Any?>(
            // User-specific deposit mirror
            "${FirebaseAdminConfig.NODE_USER_DEPOSITS}/$userId/$depositId/status" to DepositStatus.APPROVED.name,
            "${FirebaseAdminConfig.NODE_USER_DEPOSITS}/$userId/$depositId/processedAt" to now,
            "${FirebaseAdminConfig.NODE_USER_DEPOSITS}/$userId/$depositId/updatedAt" to now,
            "${FirebaseAdminConfig.NODE_USER_DEPOSITS}/$userId/$depositId/processedBy" to adminSession.identifier,

            // Profile consistency mirror in /users/{userId} (Long minor units)
            "${FirebaseAdminConfig.NODE_USERS}/$userId/balance" to creditResult.newAvailableBalance,
            "${FirebaseAdminConfig.NODE_USERS}/$userId/depositBalance" to creditResult.newDepositBalance,
            "${FirebaseAdminConfig.NODE_USERS}/$userId/updatedAt" to now,

            // Deterministic global ledger transaction record (/transactions/{deterministicTrxId})
            "${FirebaseAdminConfig.NODE_TRANSACTIONS}/$deterministicTrxId" to hashMapOf(
                "transactionId" to deterministicTrxId,
                "depositId" to depositId,
                "userId" to userId,
                "amount" to amountTaka,
                "amountMinorUnits" to requestedMinorUnits,
                "type" to "DEPOSIT",
                "direction" to "CREDIT",
                "status" to "COMPLETED",
                "paymentMethod" to deposit.paymentMethod,
                "senderNumber" to deposit.senderNumber,
                "receiverNumber" to deposit.receiverNumber,
                "timestamp" to now,
                "processedBy" to adminSession.identifier,
                "description" to "Wallet credited ৳$amountTaka via ${deposit.paymentMethod} deposit approval"
            ),

            // Deterministic user ledger mirror (/userTransactions/{userId}/{deterministicTrxId})
            "${FirebaseAdminConfig.NODE_USER_TRANSACTIONS}/$userId/$deterministicTrxId" to hashMapOf(
                "transactionId" to deterministicTrxId,
                "depositId" to depositId,
                "amount" to amountTaka,
                "amountMinorUnits" to requestedMinorUnits,
                "type" to "DEPOSIT",
                "direction" to "CREDIT",
                "status" to "COMPLETED",
                "paymentMethod" to deposit.paymentMethod,
                "timestamp" to now,
                "description" to "Deposit of ৳$amountTaka approved and credited"
            ),

            // Deterministic audit log entry (/auditLogs/{deterministicLogId})
            "${FirebaseAdminConfig.NODE_AUDIT_LOGS}/$deterministicLogId" to hashMapOf(
                "action" to "DEPOSIT_APPROVED",
                "admin" to adminSession.identifier,
                "referenceId" to depositId,
                "timestamp" to now,
                "reason" to "Super Admin approved deposit of ৳$amountTaka for User $userId (TrxID: $deterministicTrxId)",
                "amount" to amountTaka,
                "amountMinorUnits" to requestedMinorUnits,
                "userId" to userId,
                "transactionId" to deterministicTrxId
            )
        )

        try {
            db.reference.updateChildren(updates).await()
        } catch (e: Exception) {
            // Two-phase failure handling: Deposit lock & wallet credit were already committed atomically.
            // Do NOT rollback or re-credit wallet on retry.
            throw IllegalStateException(
                "Wallet credited successfully, but auxiliary ledger/mirror update failed: ${e.localizedMessage}. The deposit is settled; do NOT re-approve."
            )
        }

        // Update local in-memory cache
        val currentDeposits = localDepositsState.value.toMutableList()
        val index = currentDeposits.indexOfFirst { it.id == depositId }
        if (index >= 0) {
            currentDeposits[index] = deposit.copy(
                status = DepositStatus.APPROVED,
                processedAt = now,
                processedBy = adminSession.identifier
            )
            localDepositsState.value = currentDeposits
        }

        val existingWallet = localWalletsState[userId] ?: UserWalletData(userId = userId)
        localWalletsState[userId] = existingWallet.copy(
            balance = creditResult.newAvailableBalance + existingWallet.pendingBalance,
            availableBalance = creditResult.newAvailableBalance,
            depositBalance = creditResult.newDepositBalance,
            totalDeposited = creditResult.newTotalDeposited,
            balanceDouble = creditResult.newAvailableBalance / 100.0,
            lockedBalanceDouble = existingWallet.pendingBalance / 100.0,
            updatedAt = now
        )

        try {
            val notifRepo = FirebaseNotificationsRepository()
            notifRepo.sendNotification(
                title = "Deposit Approved / ডিপোজিট অনুমোদিত",
                message = "Your deposit of ৳$amountTaka has been approved and credited to your wallet.",
                targetType = NotificationTargetType.SPECIFIC_USER,
                targetId = userId,
                adminSession = adminSession
            )
        } catch (_: Exception) {}
    }

    override suspend fun rejectDeposit(
        depositId: String,
        reason: String,
        adminSession: SuperAdminSession
    ): Result<Unit> = runCatching {
        verifySuperAdmin(adminSession)

        val trimmedReason = reason.trim()
        require(trimmedReason.isNotBlank()) {
            "Rejection reason cannot be blank. An explanatory audit reason is required."
        }

        val deposit = getDeposit(depositId)
            ?: throw IllegalArgumentException("Deposit with ID '$depositId' does not exist.")

        if (deposit.status == DepositStatus.APPROVED) {
            throw IllegalStateException("Deposit '$depositId' is already APPROVED and cannot be rejected.")
        }
        if (deposit.status == DepositStatus.REJECTED) {
            throw IllegalStateException("Deposit '$depositId' is already REJECTED.")
        }
        if (deposit.status != DepositStatus.PENDING) {
            throw IllegalStateException("Only PENDING deposits can be rejected (current: ${deposit.status.name}).")
        }

        val now = System.currentTimeMillis()
        val deterministicLogId = "AUDIT_REJ_$depositId"
        val userId = deposit.userId

        val db = database
        if (db == null) {
            // Offline / JVM unit test environment: execute in-memory rejection update
            val currentDeposits = localDepositsState.value.toMutableList()
            val index = currentDeposits.indexOfFirst { it.id == depositId }
            if (index >= 0) {
                currentDeposits[index] = deposit.copy(
                    status = DepositStatus.REJECTED,
                    rejectionReason = trimmedReason,
                    processedAt = now,
                    processedBy = adminSession.identifier
                )
                localDepositsState.value = currentDeposits
            }
            sendDepositNotification(
                userId = userId,
                title = "Deposit Rejected / ডিপোজিট বাতিল",
                message = "Your deposit request of ৳${deposit.amountTaka} has been rejected. Reason: $trimmedReason",
                adminSession = adminSession
            )
            return@runCatching
        }

        // Execute atomic status lock on deposit record from PENDING -> REJECTED
        val depositRef = db.getReference(FirebaseAdminConfig.NODE_DEPOSITS).child(depositId)
        val rejectLockResult = executeDepositRejectionLockTransaction(
            depositRef = depositRef,
            adminSession = adminSession,
            reason = trimmedReason,
            now = now
        )

        if (!rejectLockResult.success) {
            throw IllegalStateException(rejectLockResult.errorMessage ?: "Failed to lock deposit rejection status.")
        }

        // Write secondary mirror updates and audit log
        val updates = hashMapOf<String, Any?>(
            "${FirebaseAdminConfig.NODE_USER_DEPOSITS}/$userId/$depositId/status" to DepositStatus.REJECTED.name,
            "${FirebaseAdminConfig.NODE_USER_DEPOSITS}/$userId/$depositId/rejectionReason" to trimmedReason,
            "${FirebaseAdminConfig.NODE_USER_DEPOSITS}/$userId/$depositId/processedAt" to now,
            "${FirebaseAdminConfig.NODE_USER_DEPOSITS}/$userId/$depositId/updatedAt" to now,
            "${FirebaseAdminConfig.NODE_USER_DEPOSITS}/$userId/$depositId/processedBy" to adminSession.identifier,

            "${FirebaseAdminConfig.NODE_AUDIT_LOGS}/$deterministicLogId" to hashMapOf(
                "action" to "DEPOSIT_REJECTED",
                "admin" to adminSession.identifier,
                "referenceId" to depositId,
                "timestamp" to now,
                "reason" to "Super Admin rejected deposit of ৳${deposit.amountTaka}: $trimmedReason",
                "amount" to deposit.amountTaka,
                "amountMinorUnits" to deposit.amountMinorUnits,
                "userId" to userId,
                "rejectionReason" to trimmedReason,
                "transactionId" to deposit.transactionId
            )
        )

        try {
            db.reference.updateChildren(updates).await()
        } catch (_: Exception) {
        }

        val currentDeposits = localDepositsState.value.toMutableList()
        val index = currentDeposits.indexOfFirst { it.id == depositId }
        if (index >= 0) {
            currentDeposits[index] = deposit.copy(
                status = DepositStatus.REJECTED,
                rejectionReason = trimmedReason,
                processedAt = now,
                processedBy = adminSession.identifier
            )
            localDepositsState.value = currentDeposits
        }

        try {
            val notifRepo = FirebaseNotificationsRepository()
            notifRepo.sendNotification(
                title = "Deposit Rejected / ডিপোজিট বাতিল",
                message = "Your deposit request of ৳${deposit.amountTaka} has been rejected. Reason: $trimmedReason",
                targetType = NotificationTargetType.SPECIFIC_USER,
                targetId = userId,
                adminSession = adminSession
            )
        } catch (_: Exception) {}
    }

    private suspend fun executeDepositStatusLockTransaction(
        depositRef: DatabaseReference,
        adminSession: SuperAdminSession,
        verifiedAmountMinor: Long,
        deterministicTrxId: String,
        now: Long
    ): DepositStatusLockResult = suspendCancellableCoroutine { continuation ->
        depositRef.runTransaction(object : Transaction.Handler {
            var failureMessage: String? = null
            var wasAlreadySettled = false

            override fun doTransaction(currentData: MutableData): Transaction.Result {
                if (currentData.value == null) {
                    failureMessage = "Deposit record does not exist on database."
                    return Transaction.abort()
                }

                val currentStatusStr = currentData.child("status").value?.toString()
                val currentStatus = DepositStatus.fromString(currentStatusStr)

                if (currentStatus == DepositStatus.APPROVED) {
                    wasAlreadySettled = true
                    failureMessage = "Deposit is already APPROVED."
                    return Transaction.abort()
                }

                if (currentStatus == DepositStatus.REJECTED) {
                    wasAlreadySettled = true
                    failureMessage = "Deposit is already REJECTED."
                    return Transaction.abort()
                }

                if (currentStatus != DepositStatus.PENDING) {
                    failureMessage = "Deposit status is not PENDING ($currentStatusStr)."
                    return Transaction.abort()
                }

                // Transition PENDING -> APPROVED
                currentData.child("status").value = DepositStatus.APPROVED.name
                currentData.child("processedAt").value = now
                currentData.child("processedBy").value = adminSession.identifier
                currentData.child("updatedAt").value = now
                currentData.child("settledAmountMinorUnits").value = verifiedAmountMinor
                currentData.child("settledTransactionId").value = deterministicTrxId

                return Transaction.success(currentData)
            }

            override fun onComplete(
                error: DatabaseError?,
                committed: Boolean,
                currentData: DataSnapshot?
            ) {
                if (committed && error == null) {
                    continuation.resume(DepositStatusLockResult(success = true))
                } else {
                    continuation.resume(
                        DepositStatusLockResult(
                            success = false,
                            alreadySettled = wasAlreadySettled,
                            errorMessage = error?.message ?: failureMessage ?: "Deposit lock transaction aborted or conflicted."
                        )
                    )
                }
            }
        })
    }

    private suspend fun executeDepositRejectionLockTransaction(
        depositRef: DatabaseReference,
        adminSession: SuperAdminSession,
        reason: String,
        now: Long
    ): DepositStatusLockResult = suspendCancellableCoroutine { continuation ->
        depositRef.runTransaction(object : Transaction.Handler {
            var failureMessage: String? = null
            var wasAlreadySettled = false

            override fun doTransaction(currentData: MutableData): Transaction.Result {
                if (currentData.value == null) {
                    failureMessage = "Deposit record does not exist on database."
                    return Transaction.abort()
                }

                val currentStatusStr = currentData.child("status").value?.toString()
                val currentStatus = DepositStatus.fromString(currentStatusStr)

                if (currentStatus != DepositStatus.PENDING) {
                    wasAlreadySettled = true
                    failureMessage = "Deposit is already in status '$currentStatusStr' and cannot be rejected."
                    return Transaction.abort()
                }

                // Transition PENDING -> REJECTED
                currentData.child("status").value = DepositStatus.REJECTED.name
                currentData.child("rejectionReason").value = reason
                currentData.child("processedAt").value = now
                currentData.child("processedBy").value = adminSession.identifier
                currentData.child("updatedAt").value = now

                return Transaction.success(currentData)
            }

            override fun onComplete(
                error: DatabaseError?,
                committed: Boolean,
                currentData: DataSnapshot?
            ) {
                if (committed && error == null) {
                    continuation.resume(DepositStatusLockResult(success = true))
                } else {
                    continuation.resume(
                        DepositStatusLockResult(
                            success = false,
                            alreadySettled = wasAlreadySettled,
                            errorMessage = error?.message ?: failureMessage ?: "Deposit rejection lock transaction aborted."
                        )
                    )
                }
            }
        })
    }

    private suspend fun executeWalletDepositCreditTransaction(
        walletRef: DatabaseReference,
        depositId: String,
        creditedAmountMinor: Long,
        now: Long
    ): WalletDepositCreditResult = suspendCancellableCoroutine { continuation ->
        walletRef.runTransaction(object : Transaction.Handler {
            var failureMessage: String? = null
            var resultHolder: WalletDepositCreditResult? = null

            override fun doTransaction(currentData: MutableData): Transaction.Result {
                // Idempotency check: verify if this depositId was already credited
                val creditedDepositsNode = currentData.child("creditedDeposits")
                if (creditedDepositsNode.hasChild(depositId)) {
                    resultHolder = WalletDepositCreditResult(
                        success = true,
                        alreadySettled = true,
                        creditedAmountMinorUnits = creditedAmountMinor
                    )
                    return Transaction.abort()
                }

                // 1. Read existing balances in authoritative Long minor units (paisa)
                val currentAvail = (currentData.child("availableBalance").value as? Number)?.toLong()
                    ?: (currentData.child("balance").value as? Number)?.toLong()
                    ?: 0L
                val currentDep = (currentData.child("depositBalance").value as? Number)?.toLong() ?: 0L
                val currentTotalDep = (currentData.child("totalDeposited").value as? Number)?.toLong() ?: 0L
                val currentPending = (currentData.child("pendingBalance").value as? Number)?.toLong() ?: 0L

                // 2. Atomically calculate new balances
                val newAvail = currentAvail + creditedAmountMinor
                val newDep = currentDep + creditedAmountMinor
                val newTotalDep = currentTotalDep + creditedAmountMinor
                val newTotalBalance = newAvail + currentPending

                // 3. Synchronize Double mirror fields
                val syncBalanceDouble = newTotalBalance / 100.0
                val syncLockedDouble = currentPending / 100.0

                // 4. Update balance fields without overwriting unrelated children (activeJoins, activeWithdrawals preserved)
                currentData.child("availableBalance").value = newAvail
                currentData.child("depositBalance").value = newDep
                currentData.child("totalDeposited").value = newTotalDep
                currentData.child("balance").value = newTotalBalance
                currentData.child("balanceDouble").value = syncBalanceDouble
                currentData.child("lockedBalanceDouble").value = syncLockedDouble
                currentData.child("updatedAt").value = now

                // Record settlement marker under /wallets/{userId}/creditedDeposits/{depositId}
                creditedDepositsNode.child(depositId).value = hashMapOf(
                    "creditedAmountMinorUnits" to creditedAmountMinor,
                    "timestamp" to now
                )

                resultHolder = WalletDepositCreditResult(
                    success = true,
                    creditedAmountMinorUnits = creditedAmountMinor,
                    newAvailableBalance = newAvail,
                    newDepositBalance = newDep,
                    newTotalDeposited = newTotalDep
                )

                return Transaction.success(currentData)
            }

            override fun onComplete(
                error: DatabaseError?,
                committed: Boolean,
                currentData: DataSnapshot?
            ) {
                if (committed && error == null) {
                    val res = resultHolder ?: WalletDepositCreditResult(success = true)
                    continuation.resume(res)
                } else if (resultHolder?.alreadySettled == true) {
                    continuation.resume(resultHolder!!)
                } else {
                    val err = error?.message ?: failureMessage ?: "Wallet credit transaction aborted or conflicted."
                    continuation.resume(
                        WalletDepositCreditResult(
                            success = false,
                            errorMessage = err
                        )
                    )
                }
            }
        })
    }

    private suspend fun sendDepositNotification(
        userId: String,
        title: String,
        message: String,
        adminSession: SuperAdminSession
    ) {
        try {
            val notifRepo = FirebaseNotificationsRepository()
            val result = notifRepo.sendNotification(
                title = title,
                message = message,
                targetType = NotificationTargetType.SPECIFIC_USER,
                targetId = userId,
                adminSession = adminSession
            )
            if (result.isFailure) {
                Log.e("DepositsRepository", "Failed to send deposit notification: ${result.exceptionOrNull()?.message}", result.exceptionOrNull())
            }
        } catch (e: Exception) {
            Log.e("DepositsRepository", "Exception sending deposit notification", e)
        }
    }
}
