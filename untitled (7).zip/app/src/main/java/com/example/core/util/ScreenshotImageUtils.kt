package com.example.core.util

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64

/**
 * Utility functions for safely decoding and rendering Base64 image payloads and Data URIs.
 * Designed to handle User App winning screenshot proofs stored in /results/{resultId}/proofScreenshotUrl.
 */
object ScreenshotImageUtils {

    /**
     * Extracts pure Base64 payload from data URI or raw Base64 string.
     * e.g., "data:image/jpeg;base64,/9j/4AAQSkZJRg..." -> "/9j/4AAQSkZJRg..."
     */
    fun extractBase64Payload(input: String?): String? {
        if (input.isNullOrBlank()) return null
        val trimmed = input.trim()
        val payload = if (trimmed.contains(",")) {
            trimmed.substringAfter(",")
        } else {
            trimmed
        }.trim()
        return if (payload.isNotBlank()) payload else null
    }

    /**
     * Checks if a string represents a Base64 image data URI or Base64 payload.
     */
    fun isBase64Image(input: String?): Boolean {
        if (input.isNullOrBlank()) return false
        val trimmed = input.trim()
        if (trimmed.startsWith("data:image/", ignoreCase = true)) return true
        if (trimmed.startsWith("http://", ignoreCase = true) || trimmed.startsWith("https://", ignoreCase = true)) return false
        val payload = extractBase64Payload(trimmed) ?: return false
        return payload.length >= 8 && payload.take(64).all {
            it.isLetterOrDigit() || it == '+' || it == '/' || it == '=' || it == '\n' || it == '\r'
        }
    }

    /**
     * Decodes Base64 data URI or raw Base64 string to a byte array.
     * Uses android.util.Base64 with fallback to java.util.Base64 for pure JVM test environments.
     */
    fun decodeBase64ToBytes(input: String?): ByteArray? {
        val payload = extractBase64Payload(input) ?: return null
        val clean = payload.replace("\n", "").replace("\r", "").replace(" ", "")
        if (clean.isBlank()) return null

        return try {
            Base64.decode(clean, Base64.DEFAULT)
        } catch (_: Throwable) {
            try {
                java.util.Base64.getDecoder().decode(clean)
            } catch (_: Throwable) {
                null
            }
        }
    }

    /**
     * Checks if a byte array starts with recognizable image magic bytes (PNG, JPEG, GIF, WEBP, BMP).
     */
    fun hasValidImageHeader(bytes: ByteArray?): Boolean {
        if (bytes == null || bytes.size < 3) return false
        // PNG: 89 50 4E 47
        if (bytes.size >= 4 &&
            bytes[0] == 0x89.toByte() &&
            bytes[1] == 0x50.toByte() &&
            bytes[2] == 0x4E.toByte() &&
            bytes[3] == 0x47.toByte()
        ) return true

        // JPEG: FF D8 FF
        if (bytes[0] == 0xFF.toByte() &&
            bytes[1] == 0xD8.toByte() &&
            bytes[2] == 0xFF.toByte()
        ) return true

        // GIF: GIF8
        if (bytes.size >= 4 &&
            bytes[0] == 'G'.code.toByte() &&
            bytes[1] == 'I'.code.toByte() &&
            bytes[2] == 'F'.code.toByte()
        ) return true

        // WEBP: RIFF....WEBP
        if (bytes.size >= 12 &&
            bytes[0] == 'R'.code.toByte() &&
            bytes[1] == 'I'.code.toByte() &&
            bytes[2] == 'F'.code.toByte() &&
            bytes[3] == 'F'.code.toByte() &&
            bytes[8] == 'W'.code.toByte() &&
            bytes[9] == 'E'.code.toByte() &&
            bytes[10] == 'B'.code.toByte() &&
            bytes[11] == 'P'.code.toByte()
        ) return true

        // BMP: BM
        if (bytes[0] == 0x42.toByte() && bytes[1] == 0x4D.toByte()) return true

        return false
    }

    /**
     * Decodes Base64 data URI or raw Base64 string to an Android Bitmap.
     * Returns null if input is missing, malformed, or unable to be parsed into an image.
     */
    fun decodeBase64ToBitmap(input: String?): Bitmap? {
        val bytes = decodeBase64ToBytes(input) ?: return null
        if (!hasValidImageHeader(bytes)) return null
        return try {
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        } catch (_: Throwable) {
            null
        }
    }
}
