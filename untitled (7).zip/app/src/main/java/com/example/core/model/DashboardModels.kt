package com.example.core.model

/**
 * Domain models for the AD TOURNAMENT Super Admin Dashboard.
 * Designed for aggregate, integer-safe real-time Firebase RTDB telemetry.
 */

data class DashboardOverviewStats(
    // Primary Metrics
    val totalUsers: Long = 0L,
    val totalMatches: Long = 0L,
    val pendingDeposits: Long = 0L,
    val pendingWithdrawals: Long = 0L,
    // Secondary Operational Metrics
    val availableMatches: Long = 0L,
    val runningMatches: Long = 0L,
    val resultPending: Long = 0L,
    val blockedUsers: Long = 0L
)

enum class MatchLifecycleStatus(val label: String) {
    AVAILABLE("AVAILABLE"),
    FULL("FULL"),
    CODE_ADDED("CODE ADDED"),
    RUNNING("RUNNING"),
    RESULT_SUBMITTED("RESULT SUBMITTED"),
    COMPLETED("COMPLETED");

    companion object {
        fun fromString(raw: String?): MatchLifecycleStatus {
            val normalized = raw?.trim()?.uppercase()?.replace(" ", "_") ?: return AVAILABLE
            return when (normalized) {
                "AVAILABLE" -> AVAILABLE
                "FULL" -> FULL
                "CODE_ADDED", "CODEADDED" -> CODE_ADDED
                "RUNNING", "LIVE" -> RUNNING
                "RESULT_SUBMITTED", "RESULTSUBMITTED", "RESULT_PENDING" -> RESULT_SUBMITTED
                "COMPLETED", "FINISHED" -> COMPLETED
                else -> AVAILABLE
            }
        }
    }
}

data class TodayMatchItem(
    val id: String,
    val matchNumber: String,
    val gameType: String, // "Ludo" or "Carrom"
    val entryFee: Long,
    val prize: Long,
    val scheduledTime: String,
    val scheduledTimestamp: Long = 0L,
    val status: MatchLifecycleStatus = MatchLifecycleStatus.AVAILABLE,
    val joinedCount: Int = 0,
    val maxPlayers: Int = 2,
    val gameCode: String = ""
) {
    val joinedFraction: String
        get() = "$joinedCount/$maxPlayers"

    val needsRoomCode: Boolean
        get() = (status == MatchLifecycleStatus.FULL || joinedCount >= maxPlayers) &&
                gameCode.isBlank() &&
                status != MatchLifecycleStatus.CODE_ADDED &&
                status != MatchLifecycleStatus.RUNNING &&
                status != MatchLifecycleStatus.COMPLETED
}

data class ActionRequiredSummary(
    val pendingDepositsCount: Long = 0L,
    val pendingWithdrawalsCount: Long = 0L,
    val pendingResultsCount: Long = 0L,
    val fullMatchesNeedingCodeCount: Long = 0L
) {
    val totalPendingActions: Long
        get() = pendingDepositsCount + pendingWithdrawalsCount + pendingResultsCount + fullMatchesNeedingCodeCount

    val hasPendingActions: Boolean
        get() = totalPendingActions > 0L
}

data class AdminActivityLogItem(
    val id: String,
    val action: String,
    val time: String,
    val timestamp: Long = 0L,
    val admin: String,
    val referenceId: String
)

sealed class DashboardUiState {
    object Loading : DashboardUiState()
    
    data class Success(
        val overviewStats: DashboardOverviewStats = DashboardOverviewStats(),
        val todayMatches: List<TodayMatchItem> = emptyList(),
        val actionRequired: ActionRequiredSummary = ActionRequiredSummary(),
        val recentActivity: List<AdminActivityLogItem> = emptyList(),
        val lastUpdatedTimestamp: Long = System.currentTimeMillis()
    ) : DashboardUiState()
    
    data class Error(
        val message: String
    ) : DashboardUiState()
}
