package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = GoldPrimary,
    onPrimary = TextOnGold,
    primaryContainer = GoldDark,
    onPrimaryContainer = TextPrimary,
    secondary = CyanSecondary,
    onSecondary = NavyDark,
    secondaryContainer = NavySurfaceHighlight,
    onSecondaryContainer = CyanLight,
    tertiary = CyanLight,
    onTertiary = NavyDark,
    background = NavyDeepest,
    onBackground = TextPrimary,
    surface = NavySurface,
    onSurface = TextPrimary,
    surfaceVariant = NavySurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = NavyBorder,
    outlineVariant = NavyBorderLight,
    error = StatusRejected,
    onError = Color.White
)

@Composable
fun ADAdminTheme(
    content: @Composable () -> Unit
) {
    // AD TOURNAMENT Admin uses a dedicated Dark Navy & Gold/Cyan gaming aesthetic
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}

// Backward-compatibility alias for template tests if referenced
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    ADAdminTheme(content = content)
}
