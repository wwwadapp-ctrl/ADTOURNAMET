package com.example.ui.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.auth.AdminSessionManager
import com.example.core.model.AdminAuthState
import com.example.core.model.AdminDepositItem
import com.example.core.model.DepositSummary
import com.example.core.model.SuperAdminSession
import com.example.core.model.TournamentMath
import com.example.core.repository.DepositsRepository
import com.example.core.repository.FirebaseDepositsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface DepositsUiState {
    data object Loading : DepositsUiState
    data class Success(
        val allDeposits: List<AdminDepositItem>,
        val filteredDeposits: List<AdminDepositItem>,
        val summary: DepositSummary
    ) : DepositsUiState
    data class Error(val message: String) : DepositsUiState
}

class DepositsViewModel(
    private val repository: DepositsRepository = FirebaseDepositsRepository(),
    private val sessionManager: AdminSessionManager = AdminSessionManager.getInstance()
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedTab = MutableStateFlow("PENDING") // "PENDING", "ALL", "APPROVED", "REJECTED"
    val selectedTab: StateFlow<String> = _selectedTab.asStateFlow()

    private val _selectedPaymentFilter = MutableStateFlow("ALL") // "ALL", "bKash", "Nagad", "Rocket"
    val selectedPaymentFilter: StateFlow<String> = _selectedPaymentFilter.asStateFlow()

    private val _selectedDepositForDetails = MutableStateFlow<AdminDepositItem?>(null)
    val selectedDepositForDetails: StateFlow<AdminDepositItem?> = _selectedDepositForDetails.asStateFlow()

    private val _isDetailsModalOpen = MutableStateFlow(false)
    val isDetailsModalOpen: StateFlow<Boolean> = _isDetailsModalOpen.asStateFlow()

    private val _isApproveConfirmOpen = MutableStateFlow(false)
    val isApproveConfirmOpen: StateFlow<Boolean> = _isApproveConfirmOpen.asStateFlow()

    private val _isRejectConfirmOpen = MutableStateFlow(false)
    val isRejectConfirmOpen: StateFlow<Boolean> = _isRejectConfirmOpen.asStateFlow()

    private val _rejectReasonInput = MutableStateFlow("")
    val rejectReasonInput: StateFlow<String> = _rejectReasonInput.asStateFlow()

    // Exact amount verification field (in Taka, entered by Admin)
    private val _actualReceivedAmountInput = MutableStateFlow("")
    val actualReceivedAmountInput: StateFlow<String> = _actualReceivedAmountInput.asStateFlow()

    // Transient in-flight processing set to prevent repeated tap double submissions
    private val _processingDepositIds = MutableStateFlow<Set<String>>(emptySet())
    val processingDepositIds: StateFlow<Set<String>> = _processingDepositIds.asStateFlow()

    private val _isSubmitting = MutableStateFlow(false)
    val isSubmitting: StateFlow<Boolean> = _isSubmitting.asStateFlow()

    private val _feedbackMessage = MutableStateFlow<String?>(null)
    val feedbackMessage: StateFlow<String?> = _feedbackMessage.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    val uiState: StateFlow<DepositsUiState> = combine(
        repository.observeDeposits(),
        _searchQuery,
        _selectedTab,
        _selectedPaymentFilter
    ) { deposits, query, tab, paymentMethod ->
        val trimmed = query.trim().lowercase()

        val matchingQuery = if (trimmed.isBlank()) {
            deposits
        } else {
            deposits.filter { dep ->
                dep.transactionId.lowercase().contains(trimmed) ||
                        dep.userId.lowercase().contains(trimmed) ||
                        dep.userName.lowercase().contains(trimmed) ||
                        dep.userPhone.contains(trimmed) ||
                        dep.senderNumber.contains(trimmed)
            }
        }

        val matchingStatus = when (tab) {
            "PENDING" -> matchingQuery.filter { it.isPending }
            "APPROVED" -> matchingQuery.filter { it.isApproved }
            "REJECTED" -> matchingQuery.filter { it.isRejected }
            else -> matchingQuery
        }

        val finalFiltered = if (paymentMethod == "ALL") {
            matchingStatus
        } else {
            matchingStatus.filter { it.paymentMethod.equals(paymentMethod, ignoreCase = true) }
        }

        val pending = deposits.filter { it.isPending }
        val approved = deposits.filter { it.isApproved }
        val rejected = deposits.filter { it.isRejected }

        val summary = DepositSummary(
            pendingCount = pending.size,
            approvedCount = approved.size,
            rejectedCount = rejected.size,
            totalPendingAmountTaka = pending.sumOf { it.amountTaka },
            totalApprovedAmountTaka = approved.sumOf { it.amountTaka }
        )

        DepositsUiState.Success(
            allDeposits = deposits,
            filteredDeposits = finalFiltered,
            summary = summary
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = DepositsUiState.Loading
    )

    private fun getVerifiedSession(): SuperAdminSession? {
        return when (val state = sessionManager.authState.value) {
            is AdminAuthState.Authenticated -> {
                if (!state.session.isSuperAdminVerified || state.session.uid.isBlank()) {
                    _errorMessage.value = "Unauthorized: Session is not a verified Super Admin."
                    null
                } else {
                    state.session
                }
            }
            else -> {
                _errorMessage.value = "Unauthorized: Action requires active Super Admin authentication session."
                null
            }
        }
    }

    fun onSearchQueryChanged(newQuery: String) {
        _searchQuery.value = newQuery
    }

    fun onTabSelected(tab: String) {
        _selectedTab.value = tab
    }

    fun onPaymentFilterSelected(method: String) {
        _selectedPaymentFilter.value = method
    }

    fun openDepositDetails(deposit: AdminDepositItem) {
        _selectedDepositForDetails.value = deposit
        _isDetailsModalOpen.value = true
    }

    fun closeDepositDetails() {
        _isDetailsModalOpen.value = false
        _selectedDepositForDetails.value = null
    }

    fun openApproveDialog(deposit: AdminDepositItem) {
        _selectedDepositForDetails.value = deposit
        _actualReceivedAmountInput.value = ""
        _isApproveConfirmOpen.value = true
    }

    fun closeApproveDialog() {
        _isApproveConfirmOpen.value = false
        _actualReceivedAmountInput.value = ""
    }

    fun setActualReceivedAmount(amountText: String) {
        _actualReceivedAmountInput.value = amountText
    }

    fun openRejectDialog(deposit: AdminDepositItem) {
        _selectedDepositForDetails.value = deposit
        _rejectReasonInput.value = ""
        _isRejectConfirmOpen.value = true
    }

    fun closeRejectDialog() {
        _isRejectConfirmOpen.value = false
        _rejectReasonInput.value = ""
    }

    fun setRejectReason(reason: String) {
        _rejectReasonInput.value = reason
    }

    fun confirmApproveDeposit() {
        val deposit = _selectedDepositForDetails.value ?: return

        // 1. Session verification check (BLOCK if unauthenticated or unverified)
        val adminSession = getVerifiedSession() ?: return

        // 2. Prevent concurrent / double submission on same deposit ID
        if (_processingDepositIds.value.contains(deposit.id)) return

        // 3. Exact received amount parsing and validation
        val inputRaw = _actualReceivedAmountInput.value.trim()
        if (inputRaw.isBlank()) {
            _errorMessage.value = "Please enter the actual received amount from gateway ledger."
            return
        }

        val parsedAmountTaka = inputRaw.toLongOrNull()
        if (parsedAmountTaka == null || parsedAmountTaka <= 0L) {
            _errorMessage.value = "Invalid received amount. Must be a positive whole number (Taka)."
            return
        }

        val receivedMinorUnits = TournamentMath.takaToMinorUnits(parsedAmountTaka)
        val expectedMinorUnits = if (deposit.amountMinorUnits > 0L) {
            deposit.amountMinorUnits
        } else {
            TournamentMath.takaToMinorUnits(deposit.amountTaka)
        }

        if (receivedMinorUnits != expectedMinorUnits) {
            _errorMessage.value = "Amount Mismatch: You entered ৳$parsedAmountTaka but the requested deposit is ৳${expectedMinorUnits / 100}. Approval is strictly blocked."
            return
        }

        viewModelScope.launch {
            _isSubmitting.value = true
            _processingDepositIds.value = _processingDepositIds.value + deposit.id
            closeApproveDialog()

            val result = repository.approveDeposit(
                depositId = deposit.id,
                actualReceivedMinorUnits = receivedMinorUnits,
                adminSession = adminSession
            )

            _isSubmitting.value = false
            _processingDepositIds.value = _processingDepositIds.value - deposit.id

            result.fold(
                onSuccess = {
                    _feedbackMessage.value = "Deposit #${deposit.id.takeLast(6)} of ৳$parsedAmountTaka APPROVED! Wallet credited directly."
                    closeDepositDetails()
                },
                onFailure = { err ->
                    _errorMessage.value = "Approval failed: ${err.localizedMessage}"
                }
            )
        }
    }

    fun confirmRejectDeposit() {
        val deposit = _selectedDepositForDetails.value ?: return

        val adminSession = getVerifiedSession() ?: return

        if (_processingDepositIds.value.contains(deposit.id)) return

        val reason = _rejectReasonInput.value.trim()
        if (reason.isBlank()) {
            _errorMessage.value = "Rejection reason cannot be blank. Enter a clear explanation."
            return
        }

        viewModelScope.launch {
            _isSubmitting.value = true
            _processingDepositIds.value = _processingDepositIds.value + deposit.id
            closeRejectDialog()

            val result = repository.rejectDeposit(deposit.id, reason, adminSession)

            _isSubmitting.value = false
            _processingDepositIds.value = _processingDepositIds.value - deposit.id

            result.fold(
                onSuccess = {
                    _feedbackMessage.value = "Deposit #${deposit.id.takeLast(6)} (TrxID: ${deposit.transactionId}) REJECTED."
                    closeDepositDetails()
                },
                onFailure = { err ->
                    _errorMessage.value = "Rejection failed: ${err.localizedMessage}"
                }
            )
        }
    }

    fun clearFeedbackMessage() {
        _feedbackMessage.value = null
    }

    fun clearErrorMessage() {
        _errorMessage.value = null
    }
}
