package com.example.ui.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.auth.AdminSessionManager
import com.example.core.model.AdminAuthState
import com.example.core.model.AdminWithdrawalItem
import com.example.core.model.SuperAdminSession
import com.example.core.repository.FirebaseWithdrawalsRepository
import com.example.core.repository.WithdrawalsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * UI State for the Admin Withdrawal Settlement management screen.
 */
data class WithdrawalsUiState(
    val isLoading: Boolean = false,
    val pendingWithdrawals: List<AdminWithdrawalItem> = emptyList(),
    val historicalWithdrawals: List<AdminWithdrawalItem> = emptyList(),
    val selectedTab: String = "PENDING", // "PENDING", "COMPLETED", "REJECTED"
    val processingIds: Set<String> = emptySet(),
    val feedbackMessage: String? = null,
    val errorMessage: String? = null
)

class WithdrawalsViewModel(
    private val repository: WithdrawalsRepository = FirebaseWithdrawalsRepository(),
    private val sessionManager: AdminSessionManager = AdminSessionManager.getInstance()
) : ViewModel() {

    private val _selectedTab = MutableStateFlow("PENDING")
    val selectedTab: StateFlow<String> = _selectedTab.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _processingIds = MutableStateFlow<Set<String>>(emptySet())
    val processingIds: StateFlow<Set<String>> = _processingIds.asStateFlow()

    private val _feedbackMessage = MutableStateFlow<String?>(null)
    val feedbackMessage: StateFlow<String?> = _feedbackMessage.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    // Dialog control states
    private val _confirmApproveTarget = MutableStateFlow<AdminWithdrawalItem?>(null)
    val confirmApproveTarget: StateFlow<AdminWithdrawalItem?> = _confirmApproveTarget.asStateFlow()

    private val _confirmRejectTarget = MutableStateFlow<AdminWithdrawalItem?>(null)
    val confirmRejectTarget: StateFlow<AdminWithdrawalItem?> = _confirmRejectTarget.asStateFlow()

    private val _rejectionReasonInput = MutableStateFlow("")
    val rejectionReasonInput: StateFlow<String> = _rejectionReasonInput.asStateFlow()

    val uiState: StateFlow<WithdrawalsUiState> = combine(
        repository.observeWithdrawals(),
        _selectedTab,
        _searchQuery
    ) { withdrawals: List<AdminWithdrawalItem>, tab: String, query: String ->
        val filtered = if (query.isBlank()) {
            withdrawals
        } else {
            val q = query.trim().lowercase()
            withdrawals.filter { item ->
                item.withdrawalId.lowercase().contains(q) ||
                    item.userId.lowercase().contains(q) ||
                    item.recipientNumber.lowercase().contains(q) ||
                    item.transactionId.lowercase().contains(q) ||
                    item.method.lowercase().contains(q)
            }
        }

        val pendingList = filtered.filter { it.isActionable }
        val completedList = filtered.filter { it.isCompleted }
        val rejectedList = filtered.filter { it.isRejected }

        WithdrawalsUiState(
            isLoading = false,
            pendingWithdrawals = pendingList,
            historicalWithdrawals = when (tab) {
                "COMPLETED" -> completedList
                "REJECTED" -> rejectedList
                else -> pendingList
            },
            selectedTab = tab,
            processingIds = _processingIds.value,
            feedbackMessage = _feedbackMessage.value,
            errorMessage = _errorMessage.value
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = WithdrawalsUiState(isLoading = true)
    )

    fun selectTab(tab: String) {
        _selectedTab.value = tab
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun clearFeedback() {
        _feedbackMessage.value = null
        _errorMessage.value = null
    }

    fun openApproveDialog(item: AdminWithdrawalItem) {
        _confirmApproveTarget.value = item
    }

    fun dismissApproveDialog() {
        _confirmApproveTarget.value = null
    }

    fun openRejectDialog(item: AdminWithdrawalItem) {
        _confirmRejectTarget.value = item
        _rejectionReasonInput.value = ""
    }

    fun updateRejectionReason(reason: String) {
        _rejectionReasonInput.value = reason
    }

    fun dismissRejectDialog() {
        _confirmRejectTarget.value = null
        _rejectionReasonInput.value = ""
    }

    private fun getVerifiedAdminSession(): SuperAdminSession? {
        return when (val state = sessionManager.authState.value) {
            is AdminAuthState.Authenticated -> state.session
            else -> {
                _errorMessage.value = "Unauthorized: Action requires active Super Admin session."
                null
            }
        }
    }

    fun confirmApprove() {
        val target = _confirmApproveTarget.value ?: return
        val session = getVerifiedAdminSession() ?: return

        if (_processingIds.value.contains(target.withdrawalId)) return

        viewModelScope.launch {
            _processingIds.value = _processingIds.value + target.withdrawalId
            dismissApproveDialog()

            val result = repository.approveWithdrawal(target.withdrawalId, session)
            _processingIds.value = _processingIds.value - target.withdrawalId

            result.fold(
                onSuccess = {
                    _feedbackMessage.value = "Withdrawal #${target.withdrawalId.takeLast(6)} approved successfully. Wallet settled."
                },
                onFailure = { err ->
                    _errorMessage.value = "Approval failed: ${err.localizedMessage}"
                }
            )
        }
    }

    fun confirmReject() {
        val target = _confirmRejectTarget.value ?: return
        val session = getVerifiedAdminSession() ?: return
        val reason = _rejectionReasonInput.value.trim()

        if (reason.isBlank()) {
            _errorMessage.value = "Rejection reason cannot be blank."
            return
        }

        if (_processingIds.value.contains(target.withdrawalId)) return

        viewModelScope.launch {
            _processingIds.value = _processingIds.value + target.withdrawalId
            dismissRejectDialog()

            val result = repository.rejectWithdrawal(target.withdrawalId, reason, session)
            _processingIds.value = _processingIds.value - target.withdrawalId

            result.fold(
                onSuccess = {
                    _feedbackMessage.value = "Withdrawal #${target.withdrawalId.takeLast(6)} rejected. Funds released back to user."
                },
                onFailure = { err ->
                    _errorMessage.value = "Rejection failed: ${err.localizedMessage}"
                }
            )
        }
    }
}
