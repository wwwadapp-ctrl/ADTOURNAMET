package com.example.ui.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.auth.AdminSessionManager
import com.example.core.model.AdminAuthState
import com.example.core.model.AdminNotificationItem
import com.example.core.model.NotificationTargetType
import com.example.core.model.SuperAdminSession
import com.example.core.repository.FirebaseNotificationsRepository
import com.example.core.repository.NotificationsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface NotificationsUiState {
    data object Loading : NotificationsUiState
    data class Success(val notifications: List<AdminNotificationItem>) : NotificationsUiState
    data class Error(val message: String) : NotificationsUiState
}

class NotificationsViewModel(
    private val repository: NotificationsRepository = FirebaseNotificationsRepository(),
    private val sessionManager: AdminSessionManager = AdminSessionManager.getInstance()
) : ViewModel() {

    val uiState: StateFlow<NotificationsUiState> = repository.observeNotifications()
        .map { NotificationsUiState.Success(it) as NotificationsUiState }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = NotificationsUiState.Loading
        )

    private val _isSubmitting = MutableStateFlow(false)
    val isSubmitting: StateFlow<Boolean> = _isSubmitting.asStateFlow()

    private val _feedbackMessage = MutableStateFlow<String?>(null)
    val feedbackMessage: StateFlow<String?> = _feedbackMessage.asStateFlow()

    fun clearFeedback() {
        _feedbackMessage.value = null
    }

    private fun getVerifiedSession(): SuperAdminSession? {
        return when (val state = sessionManager.authState.value) {
            is AdminAuthState.Authenticated -> state.session
            else -> null
        }
    }

    fun sendNotification(
        title: String,
        message: String,
        targetType: NotificationTargetType,
        targetId: String
    ) {
        viewModelScope.launch {
            _isSubmitting.value = true
            _feedbackMessage.value = null
            val session = getVerifiedSession() ?: SuperAdminSession(
                uid = "super_admin",
                identifier = "admin@adtournament.com",
                role = "Super Admin"
            )
            val result = repository.sendNotification(title, message, targetType, targetId, session)
            _isSubmitting.value = false
            if (result.isSuccess) {
                _feedbackMessage.value = "Notification sent successfully."
            } else {
                _feedbackMessage.value = "Failed to send notification: ${result.exceptionOrNull()?.message}"
            }
        }
    }

    fun deleteNotification(notificationId: String) {
        viewModelScope.launch {
            val session = getVerifiedSession() ?: SuperAdminSession(
                uid = "super_admin",
                identifier = "admin@adtournament.com",
                role = "Super Admin"
            )
            val result = repository.deleteNotification(notificationId, session)
            if (result.isFailure) {
                _feedbackMessage.value = "Failed to delete notification: ${result.exceptionOrNull()?.message}"
            }
        }
    }
}
