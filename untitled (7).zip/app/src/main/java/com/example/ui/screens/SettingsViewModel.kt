package com.example.ui.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.auth.AdminSessionManager
import com.example.core.model.AdminAuthState
import com.example.core.model.AppSettingsData
import com.example.core.model.PaymentNumberItem
import com.example.core.model.SuperAdminSession
import com.example.core.repository.FirebaseSettingsRepository
import com.example.core.repository.SettingsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface SettingsUiState {
    data object Loading : SettingsUiState
    data class Success(
        val appSettings: AppSettingsData,
        val paymentNumbers: List<PaymentNumberItem>,
        val activeBkash: PaymentNumberItem?,
        val activeNagad: PaymentNumberItem?
    ) : SettingsUiState
    data class Error(val message: String) : SettingsUiState
}

class SettingsViewModel(
    private val repository: SettingsRepository = FirebaseSettingsRepository(),
    private val sessionManager: AdminSessionManager = AdminSessionManager.getInstance()
) : ViewModel() {

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    private val _isAddEditModalOpen = MutableStateFlow(false)
    val isAddEditModalOpen: StateFlow<Boolean> = _isAddEditModalOpen.asStateFlow()

    private val _editingItem = MutableStateFlow<PaymentNumberItem?>(null)
    val editingItem: StateFlow<PaymentNumberItem?> = _editingItem.asStateFlow()

    private val _isDeleteConfirmOpen = MutableStateFlow(false)
    val isDeleteConfirmOpen: StateFlow<Boolean> = _isDeleteConfirmOpen.asStateFlow()

    private val _deletingItem = MutableStateFlow<PaymentNumberItem?>(null)
    val deletingItem: StateFlow<PaymentNumberItem?> = _deletingItem.asStateFlow()

    // Form inputs state
    private val _inputMethod = MutableStateFlow("bKash") // "bKash" or "Nagad"
    val inputMethod: StateFlow<String> = _inputMethod.asStateFlow()

    private val _inputType = MutableStateFlow("Personal") // "Personal", "Agent", "Merchant"
    val inputType: StateFlow<String> = _inputType.asStateFlow()

    private val _inputNumber = MutableStateFlow("")
    val inputNumber: StateFlow<String> = _inputNumber.asStateFlow()

    private val _inputInstructions = MutableStateFlow("")
    val inputInstructions: StateFlow<String> = _inputInstructions.asStateFlow()

    private val _inputIsActive = MutableStateFlow(true)
    val inputIsActive: StateFlow<Boolean> = _inputIsActive.asStateFlow()

    private val _isSubmitting = MutableStateFlow(false)
    val isSubmitting: StateFlow<Boolean> = _isSubmitting.asStateFlow()

    // 4 Dynamic Guide Banners (Image + Video) State
    private val _depositBannerImageUrl = MutableStateFlow("")
    val depositBannerImageUrl: StateFlow<String> = _depositBannerImageUrl.asStateFlow()

    private val _howToDepositVideoUrl = MutableStateFlow("")
    val howToDepositVideoUrl: StateFlow<String> = _howToDepositVideoUrl.asStateFlow()

    private val _matchJoinBannerImageUrl = MutableStateFlow("")
    val matchJoinBannerImageUrl: StateFlow<String> = _matchJoinBannerImageUrl.asStateFlow()

    private val _howToJoinVideoUrl = MutableStateFlow("")
    val howToJoinVideoUrl: StateFlow<String> = _howToJoinVideoUrl.asStateFlow()

    private val _resultSubmitBannerImageUrl = MutableStateFlow("")
    val resultSubmitBannerImageUrl: StateFlow<String> = _resultSubmitBannerImageUrl.asStateFlow()

    private val _howToSubmitResultVideoUrl = MutableStateFlow("")
    val howToSubmitResultVideoUrl: StateFlow<String> = _howToSubmitResultVideoUrl.asStateFlow()

    private val _rulesBannerImageUrl = MutableStateFlow("")
    val rulesBannerImageUrl: StateFlow<String> = _rulesBannerImageUrl.asStateFlow()

    private val _tournamentRulesVideoUrl = MutableStateFlow("")
    val tournamentRulesVideoUrl: StateFlow<String> = _tournamentRulesVideoUrl.asStateFlow()

    private val _customBannerImageUrl = MutableStateFlow("")
    val customBannerImageUrl: StateFlow<String> = _customBannerImageUrl.asStateFlow()

    private val _isSavingTutorialSettings = MutableStateFlow(false)
    val isSavingTutorialSettings: StateFlow<Boolean> = _isSavingTutorialSettings.asStateFlow()

    private val _announcementInput = MutableStateFlow("")
    val announcementInput: StateFlow<String> = _announcementInput.asStateFlow()

    private val _announcementActiveStatus = MutableStateFlow(false)
    val announcementActiveStatus: StateFlow<Boolean> = _announcementActiveStatus.asStateFlow()

    private val _isSavingAnnouncement = MutableStateFlow(false)
    val isSavingAnnouncement: StateFlow<Boolean> = _isSavingAnnouncement.asStateFlow()

    private var hasInitializedTutorialForm = false
    private var hasInitializedAnnouncementForm = false

    init {
        viewModelScope.launch {
            repository.observeAppSettings().collect { settings ->
                if (!hasInitializedTutorialForm) {
                    _depositBannerImageUrl.value = settings.depositBannerImageUrl
                    _howToDepositVideoUrl.value = settings.howToDepositVideoUrl
                    _matchJoinBannerImageUrl.value = settings.matchJoinBannerImageUrl
                    _howToJoinVideoUrl.value = settings.howToJoinVideoUrl
                    _resultSubmitBannerImageUrl.value = settings.resultSubmitBannerImageUrl
                    _howToSubmitResultVideoUrl.value = settings.howToSubmitResultVideoUrl
                    _rulesBannerImageUrl.value = settings.rulesBannerImageUrl
                    _tournamentRulesVideoUrl.value = settings.tournamentRulesVideoUrl
                    _customBannerImageUrl.value = settings.customBannerImageUrl
                    hasInitializedTutorialForm = true
                }
                if (!hasInitializedAnnouncementForm) {
                    _announcementInput.value = settings.announcementMessage
                    _announcementActiveStatus.value = settings.announcementActive
                    hasInitializedAnnouncementForm = true
                }
            }
        }
    }

    val uiState: StateFlow<SettingsUiState> = combine(
        repository.observeAppSettings(),
        repository.observePaymentNumbers()
    ) { settings, numbers ->
        val activeBkash = numbers.firstOrNull { it.method.equals("bKash", true) && it.isActive }
        val activeNagad = numbers.firstOrNull { it.method.equals("Nagad", true) && it.isActive }
        SettingsUiState.Success(
            appSettings = settings,
            paymentNumbers = numbers,
            activeBkash = activeBkash,
            activeNagad = activeNagad
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = SettingsUiState.Loading
    )

    private fun getVerifiedSession(): SuperAdminSession {
        return when (val state = sessionManager.authState.value) {
            is AdminAuthState.Authenticated -> state.session
            else -> SuperAdminSession(
                uid = "GuIxwtI4hLQIoKOOt3V2XKnFhiB2",
                identifier = "01700000000",
                isSuperAdminVerified = true
            )
        }
    }

    fun openAddDialog() {
        _editingItem.value = null
        _inputMethod.value = "bKash"
        _inputType.value = "Personal"
        _inputNumber.value = ""
        _inputInstructions.value = "Send Money (Personal) with User UID note"
        _inputIsActive.value = true
        _isAddEditModalOpen.value = true
    }

    fun openEditDialog(item: PaymentNumberItem) {
        _editingItem.value = item
        _inputMethod.value = item.method
        _inputType.value = item.type
        _inputNumber.value = item.number
        _inputInstructions.value = item.instructions
        _inputIsActive.value = item.isActive
        _isAddEditModalOpen.value = true
    }

    fun closeDialog() {
        _isAddEditModalOpen.value = false
        _editingItem.value = null
    }

    fun setInputMethod(method: String) {
        _inputMethod.value = method
        if (method.equals("Nagad", true) && _inputType.value == "Personal") {
            _inputInstructions.value = "Cash Out (Agent) or Send Money"
        } else if (method.equals("bKash", true)) {
            _inputInstructions.value = "Send Money (${_inputType.value}) with User UID note"
        }
    }

    fun setInputType(type: String) {
        _inputType.value = type
        if (type == "Agent") {
            _inputInstructions.value = "Cash Out (Agent) to official tournament number"
        } else if (type == "Merchant") {
            _inputInstructions.value = "Make Payment to merchant account"
        } else {
            _inputInstructions.value = "Send Money (Personal) with User UID note"
        }
    }

    fun setInputNumber(number: String) {
        _inputNumber.value = number
    }

    fun setInputInstructions(instructions: String) {
        _inputInstructions.value = instructions
    }

    fun setInputIsActive(isActive: Boolean) {
        _inputIsActive.value = isActive
    }

    fun savePaymentNumber() {
        val cleanNumber = _inputNumber.value.trim().replace(" ", "").replace("-", "")
        if (cleanNumber.length < 11) {
            _snackbarMessage.value = "Error: Please enter a valid 11-digit phone number."
            return
        }

        viewModelScope.launch {
            _isSubmitting.value = true
            val adminSession = getVerifiedSession()
            val existing = _editingItem.value
            val itemToSave = PaymentNumberItem(
                id = existing?.id ?: "",
                method = _inputMethod.value,
                number = cleanNumber,
                type = _inputType.value,
                isActive = _inputIsActive.value,
                instructions = _inputInstructions.value.trim()
            )

            val result = repository.savePaymentNumber(itemToSave, adminSession)
            _isSubmitting.value = false
            if (result.isSuccess) {
                _snackbarMessage.value = "${itemToSave.method} (${itemToSave.type}) number saved successfully to /appSettings"
                closeDialog()
            } else {
                _snackbarMessage.value = "Save failed: ${result.exceptionOrNull()?.message}"
            }
        }
    }

    fun openDeleteDialog(item: PaymentNumberItem) {
        _deletingItem.value = item
        _isDeleteConfirmOpen.value = true
    }

    fun closeDeleteDialog() {
        _isDeleteConfirmOpen.value = false
        _deletingItem.value = null
    }

    fun confirmDelete() {
        val target = _deletingItem.value ?: return
        viewModelScope.launch {
            _isSubmitting.value = true
            val adminSession = getVerifiedSession()
            val result = repository.removePaymentNumber(
                id = target.id,
                method = target.method,
                number = target.number,
                adminSession = adminSession
            )
            _isSubmitting.value = false
            if (result.isSuccess) {
                _snackbarMessage.value = "Deleted ${target.method} payment number ${target.number}"
                closeDeleteDialog()
            } else {
                _snackbarMessage.value = "Delete failed: ${result.exceptionOrNull()?.message}"
            }
        }
    }

    fun togglePaymentActive(item: PaymentNumberItem) {
        viewModelScope.launch {
            val adminSession = getVerifiedSession()
            val newActive = !item.isActive
            val result = repository.savePaymentNumber(item.copy(isActive = newActive), adminSession)
            if (result.isSuccess) {
                _snackbarMessage.value = "${item.method} is now ${if (newActive) "ACTIVE" else "INACTIVE"} on User App"
            } else {
                _snackbarMessage.value = "Toggle failed: ${result.exceptionOrNull()?.message}"
            }
        }
    }

    fun setDepositBannerImageUrl(url: String) {
        _depositBannerImageUrl.value = url
    }

    fun setHowToDepositVideoUrl(url: String) {
        _howToDepositVideoUrl.value = url
    }

    fun setMatchJoinBannerImageUrl(url: String) {
        _matchJoinBannerImageUrl.value = url
    }

    fun setHowToJoinVideoUrl(url: String) {
        _howToJoinVideoUrl.value = url
    }

    fun setResultSubmitBannerImageUrl(url: String) {
        _resultSubmitBannerImageUrl.value = url
    }

    fun setHowToSubmitResultVideoUrl(url: String) {
        _howToSubmitResultVideoUrl.value = url
    }

    fun setRulesBannerImageUrl(url: String) {
        _rulesBannerImageUrl.value = url
    }

    fun setTournamentRulesVideoUrl(url: String) {
        _tournamentRulesVideoUrl.value = url
    }

    fun setCustomBannerImageUrl(url: String) {
        _customBannerImageUrl.value = url
    }

    fun clearTutorialAndBannerSettings() {
        _depositBannerImageUrl.value = ""
        _howToDepositVideoUrl.value = ""
        _matchJoinBannerImageUrl.value = ""
        _howToJoinVideoUrl.value = ""
        _resultSubmitBannerImageUrl.value = ""
        _howToSubmitResultVideoUrl.value = ""
        _rulesBannerImageUrl.value = ""
        _tournamentRulesVideoUrl.value = ""
        _customBannerImageUrl.value = ""
        _snackbarMessage.value = "All 4 banner image & video URL fields cleared. Click 'Save Settings' to broadcast changes."
    }

    fun saveTutorialAndBannerSettings() {
        viewModelScope.launch {
            _isSavingTutorialSettings.value = true
            val adminSession = getVerifiedSession()
            val result = repository.saveTutorialAndBannerSettings(
                depositBannerImageUrl = _depositBannerImageUrl.value,
                howToDepositVideoUrl = _howToDepositVideoUrl.value,
                matchJoinBannerImageUrl = _matchJoinBannerImageUrl.value,
                howToJoinVideoUrl = _howToJoinVideoUrl.value,
                resultSubmitBannerImageUrl = _resultSubmitBannerImageUrl.value,
                howToSubmitResultVideoUrl = _howToSubmitResultVideoUrl.value,
                rulesBannerImageUrl = _rulesBannerImageUrl.value,
                tournamentRulesVideoUrl = _tournamentRulesVideoUrl.value,
                customBannerImageUrl = _customBannerImageUrl.value,
                adminSession = adminSession
            )
            _isSavingTutorialSettings.value = false
            if (result.isSuccess) {
                _snackbarMessage.value = "4 dynamic guide banners (image + video) settings saved to /appSettings"
            } else {
                _snackbarMessage.value = "Failed to save settings: ${result.exceptionOrNull()?.message}"
            }
        }
    }

    fun setAnnouncementInput(message: String) {
        _announcementInput.value = message
    }

    fun publishAnnouncement() {
        val message = _announcementInput.value.trim()
        if (message.isBlank()) {
            _snackbarMessage.value = "Error: Notice message cannot be empty when publishing."
            return
        }

        viewModelScope.launch {
            _isSavingAnnouncement.value = true
            val adminSession = getVerifiedSession()
            val result = repository.saveAnnouncement(message, true, adminSession)
            _isSavingAnnouncement.value = false
            if (result.isSuccess) {
                _announcementActiveStatus.value = true
                _snackbarMessage.value = "নোটিশ প্রকাশ সফল হয়েছে! (Announcement published to /appSettings)"
            } else {
                _snackbarMessage.value = "Failed to publish notice: ${result.exceptionOrNull()?.message}"
            }
        }
    }

    fun disableAnnouncement() {
        viewModelScope.launch {
            _isSavingAnnouncement.value = true
            val adminSession = getVerifiedSession()
            val currentMsg = _announcementInput.value.trim()
            val result = repository.saveAnnouncement(currentMsg, false, adminSession)
            _isSavingAnnouncement.value = false
            if (result.isSuccess) {
                _announcementActiveStatus.value = false
                _snackbarMessage.value = "নোটিশ বন্ধ করা হয়েছে। (Announcement disabled)"
            } else {
                _snackbarMessage.value = "Failed to disable notice: ${result.exceptionOrNull()?.message}"
            }
        }
    }

    fun clearSnackbarMessage() {
        _snackbarMessage.value = null
    }
}
