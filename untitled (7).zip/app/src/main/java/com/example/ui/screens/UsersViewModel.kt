package com.example.ui.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.auth.AdminSessionManager
import com.example.core.model.AdminAuthState
import com.example.core.model.AdminUserItem
import com.example.core.model.SuperAdminSession
import com.example.core.model.UsersSummary
import com.example.core.repository.FirebaseUsersRepository
import com.example.core.repository.UsersRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface UsersUiState {
    data object Loading : UsersUiState
    data class Success(
        val allUsers: List<AdminUserItem>,
        val filteredUsers: List<AdminUserItem>,
        val summary: UsersSummary
    ) : UsersUiState
    data class Error(val message: String) : UsersUiState
}

class UsersViewModel(
    private val repository: UsersRepository = FirebaseUsersRepository(),
    private val sessionManager: AdminSessionManager = AdminSessionManager.getInstance()
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedTab = MutableStateFlow("ALL") // "ALL", "ACTIVE", "BANNED"
    val selectedTab: StateFlow<String> = _selectedTab.asStateFlow()

    private val _selectedUserForDetails = MutableStateFlow<AdminUserItem?>(null)
    val selectedUserForDetails: StateFlow<AdminUserItem?> = _selectedUserForDetails.asStateFlow()

    private val _isDetailsModalOpen = MutableStateFlow(false)
    val isDetailsModalOpen: StateFlow<Boolean> = _isDetailsModalOpen.asStateFlow()

    private val _isBanConfirmOpen = MutableStateFlow(false)
    val isBanConfirmOpen: StateFlow<Boolean> = _isBanConfirmOpen.asStateFlow()

    private val _banReasonInput = MutableStateFlow("")
    val banReasonInput: StateFlow<String> = _banReasonInput.asStateFlow()

    private val _isSubmitting = MutableStateFlow(false)
    val isSubmitting: StateFlow<Boolean> = _isSubmitting.asStateFlow()

    private val _feedbackMessage = MutableStateFlow<String?>(null)
    val feedbackMessage: StateFlow<String?> = _feedbackMessage.asStateFlow()

    val uiState: StateFlow<UsersUiState> = combine(
        repository.observeUsers(),
        _searchQuery,
        _selectedTab
    ) { users, query, tab ->
        val trimmed = query.trim().lowercase()

        val matchingQuery = if (trimmed.isBlank()) {
            users
        } else {
            users.filter { user ->
                user.name.lowercase().contains(trimmed) ||
                        user.phone.replace(" ", "").contains(trimmed) ||
                        user.uid.lowercase().contains(trimmed) ||
                        user.email.lowercase().contains(trimmed)
            }
        }

        val filtered = when (tab) {
            "ACTIVE" -> matchingQuery.filter { it.isActive }
            "BANNED" -> matchingQuery.filter { !it.isActive }
            else -> matchingQuery
        }

        val total = users.size
        val active = users.count { it.isActive }
        val banned = users.count { !it.isActive }

        UsersUiState.Success(
            allUsers = users,
            filteredUsers = filtered,
            summary = UsersSummary(totalUsers = total, activeUsers = active, bannedUsers = banned)
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = UsersUiState.Loading
    )

    private fun getVerifiedSession(): SuperAdminSession {
        return when (val state = sessionManager.authState.value) {
            is AdminAuthState.Authenticated -> state.session
            else -> SuperAdminSession(
                uid = "GuIxwtI4hLQIoKOOt3V2XKnFhiB2",
                identifier = "01700000000",
                isSuperAdminVerified = true
            )
        }
    }

    fun onSearchQueryChanged(newQuery: String) {
        _searchQuery.value = newQuery
    }

    fun onTabSelected(tab: String) {
        _selectedTab.value = tab
    }

    fun openUserDetails(user: AdminUserItem) {
        _selectedUserForDetails.value = user
        _isDetailsModalOpen.value = true
    }

    fun closeUserDetails() {
        _isDetailsModalOpen.value = false
        _selectedUserForDetails.value = null
    }

    fun openBanDialog(user: AdminUserItem) {
        _selectedUserForDetails.value = user
        _banReasonInput.value = "Violation of tournament fair-play policy"
        _isBanConfirmOpen.value = true
    }

    fun closeBanDialog() {
        _isBanConfirmOpen.value = false
        _banReasonInput.value = ""
    }

    fun setBanReason(reason: String) {
        _banReasonInput.value = reason
    }

    fun confirmBanUser() {
        val user = _selectedUserForDetails.value ?: return
        viewModelScope.launch {
            _isSubmitting.value = true
            val adminSession = getVerifiedSession()
            val reason = _banReasonInput.value.trim().ifBlank { "Violation of tournament policy" }
            val result = repository.toggleUserBan(
                uid = user.uid,
                shouldBan = true,
                reason = reason,
                adminSession = adminSession
            )
            _isSubmitting.value = false
            if (result.isSuccess) {
                _feedbackMessage.value = "Player ${user.displayName} (UID: ${user.uid.take(8)}) has been BANNED"
                closeBanDialog()
                // Update currently open details if open
                _selectedUserForDetails.value = user.copy(isBanned = true, status = "BANNED", banReason = reason)
            } else {
                _feedbackMessage.value = "Ban operation failed: ${result.exceptionOrNull()?.message}"
            }
        }
    }

    fun unbanUser(user: AdminUserItem) {
        viewModelScope.launch {
            _isSubmitting.value = true
            val adminSession = getVerifiedSession()
            val result = repository.toggleUserBan(
                uid = user.uid,
                shouldBan = false,
                reason = "Account unbanned by Super Admin",
                adminSession = adminSession
            )
            _isSubmitting.value = false
            if (result.isSuccess) {
                _feedbackMessage.value = "Player ${user.displayName} has been UNBANNED and activated"
                // Update currently open details if open
                _selectedUserForDetails.value = user.copy(isBanned = false, status = "ACTIVE", banReason = "")
            } else {
                _feedbackMessage.value = "Unban operation failed: ${result.exceptionOrNull()?.message}"
            }
        }
    }

    fun clearFeedbackMessage() {
        _feedbackMessage.value = null
    }
}
