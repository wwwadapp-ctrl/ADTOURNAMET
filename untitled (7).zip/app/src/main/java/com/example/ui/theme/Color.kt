package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Navy Palette (Gaming / Tournament Dashboard)
val NavyDeepest = Color(0xFF070B14)
val NavyDark = Color(0xFF0C1322)
val NavySurface = Color(0xFF131D31)
val NavySurfaceElevated = Color(0xFF1A2640)
val NavySurfaceHighlight = Color(0xFF223254)
val NavyBorder = Color(0xFF233558)
val NavyBorderLight = Color(0xFF324876)

// Gold Primary Accent (Esports Trophy / Super Admin)
val GoldPrimary = Color(0xFFFFC837)
val GoldLight = Color(0xFFFFDF70)
val GoldDark = Color(0xFFD69A12)
val GoldGlow = Color(0x33FFC837)

// Cyan / Blue Secondary Accent (Neon Tech / Gaming HUD)
val CyanSecondary = Color(0xFF00D2FF)
val CyanLight = Color(0xFF70E5FF)
val CyanDark = Color(0xFF009BC4)
val CyanGlow = Color(0x3300D2FF)

// Status & Alert Indicators
val StatusLive = Color(0xFF00E676)
val StatusPending = Color(0xFFFFAB00)
val StatusRejected = Color(0xFFFF5252)
val StatusInfo = Color(0xFF40C4FF)

// Neutral Text & Icons
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
val TextOnGold = Color(0xFF0C1322)
