package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.core.model.AdminUserItem
import com.example.core.model.UsersSummary
import com.example.navigation.AdminSection
import com.example.ui.components.SectionHeader
import com.example.ui.components.SectionShellHeroCard
import com.example.ui.components.SecurityLockNotice
import com.example.ui.theme.CyanLight
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.NavyBorder
import com.example.ui.theme.NavyBorderLight
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyDeepest
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavySurfaceElevated
import com.example.ui.theme.NavySurfaceHighlight
import com.example.ui.theme.StatusLive
import com.example.ui.theme.StatusPending
import com.example.ui.theme.StatusRejected
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextOnGold
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun UsersScreen(
    modifier: Modifier = Modifier,
    viewModel: UsersViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedTab by viewModel.selectedTab.collectAsState()
    val selectedUserForDetails by viewModel.selectedUserForDetails.collectAsState()
    val isDetailsModalOpen by viewModel.isDetailsModalOpen.collectAsState()
    val isBanConfirmOpen by viewModel.isBanConfirmOpen.collectAsState()
    val banReasonInput by viewModel.banReasonInput.collectAsState()
    val isSubmitting by viewModel.isSubmitting.collectAsState()
    val feedbackMessage by viewModel.feedbackMessage.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current

    LaunchedEffect(feedbackMessage) {
        feedbackMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearFeedbackMessage()
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            SectionHeader(
                title = AdminSection.USERS.title,
                subtitle = "Registered Players & Esports Roster Governance",
                icon = AdminSection.USERS.icon
            )

            SectionShellHeroCard(
                section = AdminSection.USERS,
                statusText = "SYNCHRONIZED WITH /users"
            )

            when (val state = uiState) {
                is UsersUiState.Loading -> {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = GoldPrimary)
                    }
                }
                is UsersUiState.Error -> {
                    Text(
                        text = "Error loading users: ${state.message}",
                        color = StatusRejected,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                is UsersUiState.Success -> {
                    // High-level summary metrics cards
                    UsersSummaryBanner(summary = state.summary)

                    // Search input field
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { viewModel.onSearchQueryChanged(it) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("users_search_input"),
                        placeholder = { Text("Search by phone, name, or UID...", color = TextMuted) },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "Search",
                                tint = CyanLight
                            )
                        },
                        trailingIcon = {
                            if (searchQuery.isNotBlank()) {
                                IconButton(onClick = { viewModel.onSearchQueryChanged("") }) {
                                    Icon(
                                        imageVector = Icons.Default.Clear,
                                        contentDescription = "Clear search",
                                        tint = TextSecondary
                                    )
                                }
                            }
                        },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = NavyBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedContainerColor = NavySurfaceElevated,
                            unfocusedContainerColor = NavySurfaceElevated
                        ),
                        shape = RoundedCornerShape(10.dp)
                    )

                    // Filter chips row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = selectedTab == "ALL",
                            onClick = { viewModel.onTabSelected("ALL") },
                            label = { Text("All (${state.summary.totalUsers})") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = GoldPrimary,
                                selectedLabelColor = TextOnGold,
                                containerColor = NavySurface,
                                labelColor = TextSecondary
                            )
                        )

                        FilterChip(
                            selected = selectedTab == "ACTIVE",
                            onClick = { viewModel.onTabSelected("ACTIVE") },
                            label = { Text("Active (${state.summary.activeUsers})") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = StatusLive.copy(alpha = 0.2f),
                                selectedLabelColor = StatusLive,
                                containerColor = NavySurface,
                                labelColor = TextSecondary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = selectedTab == "ACTIVE",
                                borderColor = if (selectedTab == "ACTIVE") StatusLive else NavyBorder
                            )
                        )

                        FilterChip(
                            selected = selectedTab == "BANNED",
                            onClick = { viewModel.onTabSelected("BANNED") },
                            label = { Text("Banned (${state.summary.bannedUsers})") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = StatusRejected.copy(alpha = 0.2f),
                                selectedLabelColor = StatusRejected,
                                containerColor = NavySurface,
                                labelColor = TextSecondary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = selectedTab == "BANNED",
                                borderColor = if (selectedTab == "BANNED") StatusRejected else NavyBorder
                            )
                        )
                    }

                    // User List Cards
                    if (state.filteredUsers.isEmpty()) {
                        EmptyUsersStateCard(
                            query = searchQuery,
                            onClearSearch = { viewModel.onSearchQueryChanged("") }
                        )
                    } else {
                        state.filteredUsers.forEach { user ->
                            UserItemCard(
                                user = user,
                                onClick = { viewModel.openUserDetails(user) }
                            )
                        }
                    }
                }
            }

            SecurityLockNotice(
                title = "Strict Anti-Fraud & User Governance",
                description = "Account suspensions block login and match entry immediately. Player wallet adjustments remain strictly controlled by authoritative backend systems."
            )

            Spacer(modifier = Modifier.height(30.dp))
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(16.dp)
        )
    }

    // Esports Player Details Modal
    if (isDetailsModalOpen && selectedUserForDetails != null) {
        UserDetailsDialog(
            user = selectedUserForDetails!!,
            isSubmitting = isSubmitting,
            onDismiss = { viewModel.closeUserDetails() },
            onBanClick = { viewModel.openBanDialog(selectedUserForDetails!!) },
            onUnbanClick = { viewModel.unbanUser(selectedUserForDetails!!) },
            onCopy = { text, label ->
                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
            }
        )
    }

    // Ban Confirmation Dialog
    if (isBanConfirmOpen && selectedUserForDetails != null) {
        BanUserConfirmDialog(
            user = selectedUserForDetails!!,
            reason = banReasonInput,
            isSubmitting = isSubmitting,
            onReasonChange = { viewModel.setBanReason(it) },
            onDismiss = { viewModel.closeBanDialog() },
            onConfirm = { viewModel.confirmBanUser() }
        )
    }
}

@Composable
private fun UsersSummaryBanner(summary: UsersSummary) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Total Users
        Card(
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(containerColor = NavySurfaceElevated),
            border = BorderStroke(1.dp, NavyBorder)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "TOTAL PLAYERS",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${summary.totalUsers}",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Active Users
        Card(
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(containerColor = NavySurfaceElevated),
            border = BorderStroke(1.dp, StatusLive.copy(alpha = 0.4f))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "ACTIVE",
                    style = MaterialTheme.typography.labelSmall,
                    color = StatusLive,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${summary.activeUsers}",
                    style = MaterialTheme.typography.titleLarge,
                    color = StatusLive,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Banned Users
        Card(
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(containerColor = NavySurfaceElevated),
            border = BorderStroke(1.dp, if (summary.bannedUsers > 0) StatusRejected.copy(alpha = 0.5f) else NavyBorder)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "BANNED",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (summary.bannedUsers > 0) StatusRejected else TextMuted,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${summary.bannedUsers}",
                    style = MaterialTheme.typography.titleLarge,
                    color = if (summary.bannedUsers > 0) StatusRejected else TextSecondary,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun UserItemCard(
    user: AdminUserItem,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("user_item_${user.uid}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = NavySurfaceElevated),
        border = BorderStroke(
            1.dp,
            if (!user.isActive) StatusRejected.copy(alpha = 0.4f) else NavyBorder
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                // User Avatar initial
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .background(
                            if (user.isActive) GoldPrimary.copy(alpha = 0.2f) else StatusRejected.copy(alpha = 0.2f),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = user.displayName.take(1).uppercase(),
                        style = MaterialTheme.typography.titleMedium,
                        color = if (user.isActive) GoldPrimary else StatusRejected,
                        fontWeight = FontWeight.Bold
                    )
                }

                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = user.displayName,
                            style = MaterialTheme.typography.titleSmall,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )

                        // Status Badge
                        Surface(
                            color = if (user.isActive) StatusLive.copy(alpha = 0.15f) else StatusRejected.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(
                                1.dp,
                                if (user.isActive) StatusLive.copy(alpha = 0.4f) else StatusRejected.copy(alpha = 0.5f)
                            )
                        ) {
                            Text(
                                text = if (user.isActive) "ACTIVE" else "BANNED",
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall,
                                color = if (user.isActive) StatusLive else StatusRejected,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Phone & UID
                    Text(
                        text = "${user.formattedPhone} • UID: ${user.uid.take(10)}...",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Wallet Balance badge
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(
                    text = user.formattedTotalBalance,
                    style = MaterialTheme.typography.titleSmall,
                    color = GoldLight,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Balance",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextMuted,
                    fontSize = 10.sp
                )
            }
        }
    }
}

@Composable
private fun EmptyUsersStateCard(
    query: String,
    onClearSearch: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = NavySurfaceElevated),
        border = BorderStroke(1.dp, NavyBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Search,
                contentDescription = null,
                tint = TextMuted,
                modifier = Modifier.size(36.dp)
            )
            Text(
                text = if (query.isNotBlank()) "No players matching '$query'" else "No players registered",
                style = MaterialTheme.typography.titleSmall,
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Registered player profiles appear dynamically from Firebase /users.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
            if (query.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Button(
                    onClick = onClearSearch,
                    colors = ButtonDefaults.buttonColors(containerColor = NavySurfaceHighlight),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Clear Search Query", color = TextPrimary)
                }
            }
        }
    }
}

@Composable
private fun UserDetailsDialog(
    user: AdminUserItem,
    isSubmitting: Boolean,
    onDismiss: () -> Unit,
    onBanClick: () -> Unit,
    onUnbanClick: () -> Unit,
    onCopy: (String, String) -> Unit
) {
    Dialog(onDismissRequest = { if (!isSubmitting) onDismiss() }) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = NavyDark),
            border = BorderStroke(
                1.5.dp,
                if (user.isActive) GoldPrimary.copy(alpha = 0.7f) else StatusRejected.copy(alpha = 0.7f)
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header with Avatar & Name
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .background(
                                if (user.isActive) GoldPrimary.copy(alpha = 0.2f) else StatusRejected.copy(alpha = 0.2f),
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = user.displayName.take(1).uppercase(),
                            style = MaterialTheme.typography.titleLarge,
                            color = if (user.isActive) GoldPrimary else StatusRejected,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = user.displayName,
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )

                        // Status Chip
                        Surface(
                            color = if (user.isActive) StatusLive.copy(alpha = 0.15f) else StatusRejected.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(
                                1.dp,
                                if (user.isActive) StatusLive.copy(alpha = 0.5f) else StatusRejected.copy(alpha = 0.5f)
                            )
                        ) {
                            Text(
                                text = if (user.isActive) "ACTIVE PLAYER" else "ACCOUNT BANNED / SUSPENDED",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall,
                                color = if (user.isActive) StatusLive else StatusRejected,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Phone & UID Details
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = NavySurface),
                    border = BorderStroke(1.dp, NavyBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Phone Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Phone Number", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                Text(
                                    user.formattedPhone,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            IconButton(onClick = { onCopy(user.phone, "Phone Number") }, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "Copy phone", tint = CyanLight, modifier = Modifier.size(16.dp))
                            }
                        }

                        // UID Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Player UID", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                Text(
                                    user.uid,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CyanLight,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            IconButton(onClick = { onCopy(user.uid, "Player UID") }, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "Copy UID", tint = CyanLight, modifier = Modifier.size(16.dp))
                            }
                        }

                        if (user.email.isNotBlank()) {
                            Text("Email: ${user.email}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }

                        if (user.deviceModel.isNotBlank()) {
                            Text("Registered Device: ${user.deviceModel}", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                        }
                    }
                }

                // If Banned: Show Ban Reason
                if (!user.isActive) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = StatusRejected.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, StatusRejected.copy(alpha = 0.4f))
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = StatusRejected, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Suspension Reason", style = MaterialTheme.typography.labelSmall, color = StatusRejected, fontWeight = FontWeight.Bold)
                            }
                            Text(
                                text = user.banReason.ifBlank { "Policy violation or fraud prevention" },
                                style = MaterialTheme.typography.bodySmall,
                                color = TextPrimary
                            )
                        }
                    }
                }

                // Wallet Balance Breakdown
                Text(
                    text = "Wallet Balance Breakdown",
                    style = MaterialTheme.typography.titleSmall,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Total
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(NavySurfaceElevated, RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Column {
                            Text("Total", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 10.sp)
                            Text(user.formattedTotalBalance, style = MaterialTheme.typography.titleSmall, color = GoldLight, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Deposit Balance
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(NavySurface, RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Column {
                            Text("Deposits", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 10.sp)
                            Text(user.formattedDepositBalance, style = MaterialTheme.typography.bodyMedium, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    // Winning Balance
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(NavySurface, RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Column {
                            Text("Winnings", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 10.sp)
                            Text(user.formattedWinningBalance, style = MaterialTheme.typography.bodyMedium, color = StatusLive, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }

                // Esports Gameplay Stats
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(NavySurface, RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Column {
                            Text("Matches Played", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            Text("${user.matchesPlayed}", style = MaterialTheme.typography.titleSmall, color = TextPrimary, fontWeight = FontWeight.Bold)
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(NavySurface, RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Column {
                            Text("Matches Won", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            Text("${user.matchesWon}", style = MaterialTheme.typography.titleSmall, color = CyanLight, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Action Buttons: Ban / Unban
                if (user.isActive) {
                    Button(
                        onClick = onBanClick,
                        enabled = !isSubmitting,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = StatusRejected,
                            contentColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("ban_user_button")
                    ) {
                        Icon(Icons.Default.Block, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Ban / Suspend Player Account", fontWeight = FontWeight.Bold)
                    }
                } else {
                    Button(
                        onClick = onUnbanClick,
                        enabled = !isSubmitting,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = StatusLive,
                            contentColor = TextOnGold
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("unban_user_button")
                    ) {
                        if (isSubmitting) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = TextOnGold, strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Default.LockOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Unban & Restore Player Account", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Close Button
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Close Details", color = TextSecondary)
                }
            }
        }
    }
}

@Composable
private fun BanUserConfirmDialog(
    user: AdminUserItem,
    reason: String,
    isSubmitting: Boolean,
    onReasonChange: (String) -> Unit,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    Dialog(onDismissRequest = { if (!isSubmitting) onDismiss() }) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = NavyDark),
            border = BorderStroke(1.5.dp, StatusRejected)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = StatusRejected,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = "Suspend Player Account?",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = "Suspending ${user.displayName} (UID: ${user.uid}) will immediately block them from joining tournaments and logging in. An immutable audit entry will be recorded under /auditLogs.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )

                Text(
                    text = "Reason for Suspension",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextPrimary,
                    fontWeight = FontWeight.SemiBold
                )

                OutlinedTextField(
                    value = reason,
                    onValueChange = onReasonChange,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("ban_reason_input"),
                    placeholder = { Text("e.g. Violation of tournament policy or fraud", color = TextMuted) },
                    singleLine = false,
                    maxLines = 3,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = StatusRejected,
                        unfocusedBorderColor = NavyBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = NavySurface,
                        unfocusedContainerColor = NavySurface
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = onDismiss,
                        enabled = !isSubmitting
                    ) {
                        Text("Cancel", color = TextSecondary)
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = onConfirm,
                        enabled = !isSubmitting,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = StatusRejected,
                            contentColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("confirm_ban_submit")
                    ) {
                        if (isSubmitting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                color = TextPrimary,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text("Confirm Ban", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
