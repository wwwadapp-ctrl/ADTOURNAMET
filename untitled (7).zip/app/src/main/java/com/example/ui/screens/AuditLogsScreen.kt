package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.navigation.AdminSection
import com.example.ui.components.SectionHeader
import com.example.ui.components.SectionShellHeroCard
import com.example.ui.components.SecurityLockNotice
import com.example.ui.components.StructuralQueueCard

@Composable
fun AuditLogsScreen(
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        SectionHeader(
            title = AdminSection.AUDIT_LOGS.title,
            subtitle = AdminSection.AUDIT_LOGS.subtitle,
            icon = AdminSection.AUDIT_LOGS.icon
        )

        SectionShellHeroCard(
            section = AdminSection.AUDIT_LOGS,
            statusText = "IMMUTABLE AUDIT TRAIL"
        )

        SecurityLockNotice(
            title = "Authoritative /auditLogs Node Record",
            description = "All match creation, status mutations, game room code updates, and admin logins are immutably logged into Firebase RTDB under /auditLogs."
        )

        StructuralQueueCard(
            title = "Recent Immutable System Logs",
            items = listOf(
                "MATCH_CREATED • Super Admin" to "Just Now",
                "MATCH_CODE_ADDED • Room Code Published" to "12m ago",
                "SUPER_ADMIN_AUTHENTICATED • Session Issued" to "35m ago",
                "SYSTEM_TELEMETRY_CHECK • Passed" to "1h ago"
            ),
            badgeLabel = "IMMUTABLE NODE"
        )

        Spacer(modifier = Modifier.height(20.dp))
    }
}
