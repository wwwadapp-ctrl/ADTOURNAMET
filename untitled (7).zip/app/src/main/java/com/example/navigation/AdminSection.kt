package com.example.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.HistoryEdu
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PeopleAlt
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.ui.graphics.vector.ImageVector

enum class AdminCategory(val label: String) {
    OVERVIEW("ওভারভিউ"),
    TOURNAMENT_OPS("টুর্নামেন্ট অপারেশন"),
    FINANCIAL_OVERSIGHT("আর্থিক তদারকি"),
    GOVERNANCE("গভর্নেন্স ও সিকিউরিটি")
}

enum class AdminSection(
    val route: String,
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val category: AdminCategory
) {
    DASHBOARD(
        route = "dashboard",
        title = "হোম",
        subtitle = "সিস্টেম ওভারভিউ ও রিয়েলটাইম টেলিমেট্রি",
        icon = Icons.Default.Dashboard,
        category = AdminCategory.OVERVIEW
    ),
    MATCHES(
        route = "matches",
        title = "ম্যাচ",
        subtitle = "টুর্নামেন্ট ব্র্যাকেট, ফিxture ও রুম কোড ব্যবস্থাপনা",
        icon = Icons.Default.SportsEsports,
        category = AdminCategory.TOURNAMENT_OPS
    ),
    RESULTS(
        route = "results",
        title = "ফলাফল",
        subtitle = "ম্যাচ স্কোর, জয়ী স্ক্রিনশট ও যাচাইকরণ",
        icon = Icons.Default.EmojiEvents,
        category = AdminCategory.TOURNAMENT_OPS
    ),
    DEPOSITS(
        route = "deposits",
        title = "ডিপোজিট",
        subtitle = "প্লেয়ার ডিপোজিট পুনর্মিলন ও গেটওয়ে লেজার",
        icon = Icons.Default.AccountBalanceWallet,
        category = AdminCategory.FINANCIAL_OVERSIGHT
    ),
    WITHDRAWALS(
        route = "withdrawals",
        title = "উত্তোলন",
        subtitle = "পেমেন্ট অনুরোধ ও সুপার অ্যাডমিন ডিসবার্সমেন্ট কিউ",
        icon = Icons.Default.Payments,
        category = AdminCategory.FINANCIAL_OVERSIGHT
    ),
    USERS(
        route = "users",
        title = "ইউজার",
        subtitle = "প্লেয়ার রোস্টার, অ্যাকাউন্ট স্ট্যাটাস ও ব্যান প্রয়োগ",
        icon = Icons.Default.PeopleAlt,
        category = AdminCategory.GOVERNANCE
    ),
    NOTIFICATIONS(
        route = "notifications",
        title = "বিজ্ঞপ্তি",
        subtitle = "গ্লোবাল অ্যানাউন্সমেন্ট ও ইন-গেম পুশ বুলেটিন",
        icon = Icons.Default.Notifications,
        category = AdminCategory.GOVERNANCE
    ),
    AUDIT_LOGS(
        route = "audit_logs",
        title = "অডিট লগ",
        subtitle = "ইমিউটেবল সিকিউরিটি লগ ও সিস্টেম ইভেন্ট",
        icon = Icons.Default.HistoryEdu,
        category = AdminCategory.GOVERNANCE
    ),
    SETTINGS(
        route = "settings",
        title = "সেটিংস",
        subtitle = "ফায়ারবেস সংযোগ, রিজিওন ও অ্যাডমিন প্যারামিটার",
        icon = Icons.Default.Settings,
        category = AdminCategory.GOVERNANCE
    );

    companion object {
        fun fromRoute(route: String?): AdminSection {
            return entries.firstOrNull { it.route == route } ?: DASHBOARD
        }
    }
}
