package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.ui.MainAdminApp
import com.example.ui.theme.ADAdminTheme

/**
 * Root Activity for AD Tournament Admin application.
 * Boots edge-to-edge Compose rendering with the Navy & Gold esports theme
 * and authoritative Super Admin session state observation.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val navigateTo = intent?.getStringExtra("navigate_to")
        val focusResultId = intent?.getStringExtra("focus_result_id")

        setContent {
            ADAdminTheme {
                MainAdminApp(
                    initialNavigateTo = navigateTo,
                    initialFocusResultId = focusResultId
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val navigateTo = intent.getStringExtra("navigate_to")
        val focusResultId = intent.getStringExtra("focus_result_id")
        setContent {
            ADAdminTheme {
                MainAdminApp(
                    initialNavigateTo = navigateTo,
                    initialFocusResultId = focusResultId
                )
            }
        }
    }
}

