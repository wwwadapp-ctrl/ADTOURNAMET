package com.example.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.example.core.di.AppContainer
import com.example.ui.admin.AdminScreen
import com.example.ui.admin.AdminViewModel
import com.example.ui.auth.*
import com.example.ui.home.HomeScreen
import com.example.ui.home.HomeViewModel
import com.example.ui.match.MatchDetailScreen
import com.example.ui.match.MatchDetailViewModel
import com.example.ui.profile.ProfileScreen
import com.example.ui.profile.ProfileViewModel
import com.example.ui.wallet.*

object Destinations {
  const val LOGIN = "login"
  const val REGISTER = "register"
  const val FORGOT_PASSWORD = "forgot_password"
  const val OTP = "otp/{phone}"
  const val RESET_PASSWORD = "reset_password/{phone}/{otp}"
  const val HOME = "home"
  const val MATCH_DETAIL = "match_detail/{matchId}"
  const val WALLET = "wallet"
  const val DEPOSIT = "deposit"
  const val WITHDRAW = "withdraw"
  const val TRANSACTIONS = "transactions"
  const val PROFILE = "profile"
  const val ADMIN = "admin"

  fun otp(phone: String) = "otp/$phone"
  fun resetPassword(phone: String, otp: String) = "reset_password/$phone/$otp"
  fun matchDetail(matchId: String) = "match_detail/$matchId"
}

@Composable
fun AppNavigation(
  navController: NavHostController,
  container: AppContainer,
) {
  val startDestination = if (container.authRepository.isUserSignedIn()) {
    Destinations.HOME
  } else {
    Destinations.LOGIN
  }

  val authViewModel: AuthViewModel = viewModel(
    factory = AuthViewModel.Factory(container.authRepository)
  )

  val currentUser by authViewModel.currentUser.collectAsState()
  val activeUserId = currentUser?.userId ?: "AD-USER-9481"

  NavHost(
    navController = navController,
    startDestination = startDestination,
  ) {
    composable(Destinations.LOGIN) {
      LoginScreen(
        viewModel = authViewModel,
        onLoginSuccess = {
          navController.navigate(Destinations.HOME) {
            popUpTo(Destinations.LOGIN) { inclusive = true }
          }
        },
        onNavigateToRegister = { navController.navigate(Destinations.REGISTER) },
        onNavigateToForgotPassword = { navController.navigate(Destinations.FORGOT_PASSWORD) },
      )
    }

    composable(Destinations.REGISTER) {
      RegisterScreen(
        viewModel = authViewModel,
        onRegisterSuccess = {
          navController.navigate(Destinations.HOME) {
            popUpTo(Destinations.REGISTER) { inclusive = true }
          }
        },
        onNavigateToLogin = { navController.popBackStack() },
      )
    }

    composable(Destinations.FORGOT_PASSWORD) {
      ForgotPasswordScreen(
        viewModel = authViewModel,
        onNavigateToOtp = { phone -> navController.navigate(Destinations.otp(phone)) },
        onNavigateBack = { navController.popBackStack() },
      )
    }

    composable(
      route = Destinations.OTP,
      arguments = listOf(navArgument("phone") { type = NavType.StringType }),
    ) { backStackEntry ->
      val phone = backStackEntry.arguments?.getString("phone") ?: ""
      OtpScreen(
        phoneNumber = phone,
        viewModel = authViewModel,
        onOtpVerified = { verifiedPhone, otp ->
          navController.navigate(Destinations.resetPassword(verifiedPhone, otp))
        },
        onNavigateBack = { navController.popBackStack() },
      )
    }

    composable(
      route = Destinations.RESET_PASSWORD,
      arguments = listOf(
        navArgument("phone") { type = NavType.StringType },
        navArgument("otp") { type = NavType.StringType },
      ),
    ) { backStackEntry ->
      val phone = backStackEntry.arguments?.getString("phone") ?: ""
      val otp = backStackEntry.arguments?.getString("otp") ?: ""
      ResetPasswordScreen(
        phoneNumber = phone,
        otp = otp,
        viewModel = authViewModel,
        onResetSuccess = {
          navController.navigate(Destinations.LOGIN) {
            popUpTo(Destinations.LOGIN) { inclusive = true }
          }
        },
        onNavigateBack = { navController.popBackStack() },
      )
    }

    composable(Destinations.HOME) {
      val homeViewModel: HomeViewModel = viewModel(
        factory = HomeViewModel.Factory(container.matchRepository)
      )
      val walletViewModel: WalletViewModel = viewModel(
        factory = WalletViewModel.Factory(container.walletRepository, activeUserId)
      )
      val walletUiState by walletViewModel.uiState.collectAsState()
      val walletBalance = walletUiState.wallet?.availableBalance ?: 0L

      HomeScreen(
        viewModel = homeViewModel,
        currentUser = currentUser,
        walletBalance = walletBalance,
        onMatchClick = { matchId -> navController.navigate(Destinations.matchDetail(matchId)) },
        onWalletClick = { navController.navigate(Destinations.WALLET) },
        onProfileClick = { navController.navigate(Destinations.PROFILE) },
        onAdminClick = { navController.navigate(Destinations.ADMIN) },
      )
    }

    composable(
      route = Destinations.MATCH_DETAIL,
      arguments = listOf(navArgument("matchId") { type = NavType.StringType }),
    ) { backStackEntry ->
      val matchId = backStackEntry.arguments?.getString("matchId") ?: ""
      val isAdmin = currentUser?.role == "SUPER_ADMIN" || currentUser?.role == "ADMIN"
      val detailViewModel: MatchDetailViewModel = viewModel(
        factory = MatchDetailViewModel.Factory(
          matchRepository = container.matchRepository,
          resultRepository = container.resultRepository,
          matchId = matchId,
          currentUserId = activeUserId,
          isAdmin = isAdmin,
        )
      )
      MatchDetailScreen(
        viewModel = detailViewModel,
        onNavigateBack = { navController.popBackStack() },
        onViewRoomCode = { /* In-screen */ },
        onSubmitProof = { /* In-screen */ },
      )
    }

    composable(Destinations.WALLET) {
      val walletViewModel: WalletViewModel = viewModel(
        factory = WalletViewModel.Factory(container.walletRepository, activeUserId)
      )
      WalletScreen(
        viewModel = walletViewModel,
        onNavigateBack = { navController.popBackStack() },
        onNavigateToDeposit = { navController.navigate(Destinations.DEPOSIT) },
        onNavigateToWithdraw = { navController.navigate(Destinations.WITHDRAW) },
        onNavigateToTransactions = { navController.navigate(Destinations.TRANSACTIONS) },
      )
    }

    composable(Destinations.DEPOSIT) {
      val walletViewModel: WalletViewModel = viewModel(
        factory = WalletViewModel.Factory(container.walletRepository, activeUserId)
      )
      DepositScreen(
        viewModel = walletViewModel,
        onNavigateBack = { navController.popBackStack() },
      )
    }

    composable(Destinations.WITHDRAW) {
      val walletViewModel: WalletViewModel = viewModel(
        factory = WalletViewModel.Factory(container.walletRepository, activeUserId)
      )
      WithdrawScreen(
        viewModel = walletViewModel,
        onNavigateBack = { navController.popBackStack() },
      )
    }

    composable(Destinations.TRANSACTIONS) {
      val walletViewModel: WalletViewModel = viewModel(
        factory = WalletViewModel.Factory(container.walletRepository, activeUserId)
      )
      TransactionsScreen(
        viewModel = walletViewModel,
        onNavigateBack = { navController.popBackStack() },
      )
    }

    composable(Destinations.PROFILE) {
      val profileViewModel: ProfileViewModel = viewModel(
        factory = ProfileViewModel.Factory(container.authRepository)
      )
      ProfileScreen(
        viewModel = profileViewModel,
        user = currentUser,
        onNavigateBack = { navController.popBackStack() },
        onSignedOut = {
          navController.navigate(Destinations.LOGIN) {
            popUpTo(Destinations.HOME) { inclusive = true }
          }
        },
      )
    }

    composable(Destinations.ADMIN) {
      val adminViewModel: AdminViewModel = viewModel(
        factory = AdminViewModel.Factory(container.adminRepository, activeUserId)
      )
      AdminScreen(
        viewModel = adminViewModel,
        onNavigateBack = { navController.popBackStack() },
      )
    }
  }
}
