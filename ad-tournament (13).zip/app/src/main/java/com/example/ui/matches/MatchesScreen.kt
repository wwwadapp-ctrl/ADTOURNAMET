package com.example.ui.matches

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.core.error.Resource
import com.example.domain.model.GameType
import com.example.domain.model.MatchEntity
import com.example.domain.model.MatchStatus
import com.example.domain.repository.MatchRepository
import com.example.ui.components.EmptyState
import com.example.ui.components.ErrorState
import com.example.ui.components.LoadingState
import com.example.ui.components.MatchCard
import com.example.ui.theme.*

enum class MatchesTab(val label: String) {
  AVAILABLE("Available"),
  MY_JOINED("My Joined"),
  UPCOMING("Upcoming"),
  HISTORY("History"),
}

enum class GameFilter(val label: String, val gameType: GameType?) {
  ALL("All Games", null),
  LUDO("Ludo 1v1", GameType.LUDO),
  CARROM("Carrom 1v1", GameType.CARROM),
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MatchesScreen(
  userId: String,
  onNavigateToMatchDetails: (String) -> Unit,
  matchRepository: MatchRepository,
  modifier: Modifier = Modifier,
  initialTab: MatchesTab = MatchesTab.AVAILABLE,
  onHistoryClick: () -> Unit = {},
  viewModel: MatchesViewModel = viewModel(
    key = "MatchesViewModel_${userId}_${initialTab.name}",
    factory = MatchesViewModel.Factory(matchRepository, userId, initialTab),
  ),
) {
  val uiState by viewModel.uiState.collectAsState()
  val selectedTab = uiState.selectedTab
  val selectedGameFilter = uiState.selectedGameFilter

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Column {
            Text(
              text = "Tournament Matches",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = Color.White,
            )
            Text(
              text = "Real-time 1v1 Ludo & Carrom Battles",
              style = MaterialTheme.typography.labelSmall,
              color = Slate400,
            )
          }
        },
        actions = {
          IconButton(
            onClick = onHistoryClick,
            modifier = Modifier.testTag("matches_history_btn"),
          ) {
            Icon(
              imageVector = Icons.Default.History,
              contentDescription = "Match History",
              tint = Gold400,
            )
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = NavySurface,
        ),
      )
    },
    containerColor = DeepNavyBg,
    modifier = modifier.fillMaxSize(),
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .background(MidnightBackgroundGradient)
        .padding(innerPadding),
    ) {
      // 1. Primary Filter Tabs: Available, My Joined, Upcoming, History
      PrimaryTabRow(
        selectedTab = selectedTab,
        onTabSelected = { viewModel.setTab(it) },
      )

      // 2. Game Filter Chips: All, Ludo 1v1, Carrom 1v1
      GameFilterRow(
        selectedFilter = selectedGameFilter,
        onFilterSelected = { viewModel.setGameFilter(it) },
      )

      // 3. Match List / Loading / Error / Empty Content
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(horizontal = 16.dp),
      ) {
        if (uiState.isLoading) {
          LoadingState(message = "Loading ${selectedTab.label.lowercase()} matches...")
        } else if (uiState.errorMessage != null) {
          ErrorState(
            message = uiState.errorMessage ?: "Failed to load matches",
            onRetry = {
              viewModel.retry()
            },
          )
        } else {
          val filteredMatches = uiState.filteredMatches

          if (filteredMatches.isEmpty()) {
            val (emptyTitle, emptyMsg) = when (selectedTab) {
              MatchesTab.AVAILABLE -> Pair(
                "No Available Matches",
                "All current contests are either in progress or filled. New 1v1 matches are posted frequently by Super Admin."
              )
              MatchesTab.MY_JOINED -> Pair(
                "No Joined Matches",
                "You have not joined any active tournaments yet. Check the Available tab to enter a 1v1 match!"
              )
              MatchesTab.UPCOMING -> Pair(
                "No Upcoming Tournaments",
                "Upcoming scheduled contests will appear here. Stay tuned for special weekend tournaments!"
              )
              MatchesTab.HISTORY -> Pair(
                "No Match History",
                "Your completed matches and tournament results will be archived here."
              )
            }
            EmptyState(
              title = emptyTitle,
              description = emptyMsg,
              actionButtonText = if (selectedTab != MatchesTab.AVAILABLE) "Browse Available Matches" else null,
              onActionClick = if (selectedTab != MatchesTab.AVAILABLE) {
                { viewModel.setTab(MatchesTab.AVAILABLE) }
              } else null,
            )
          } else {
            LazyColumn(
              modifier = Modifier
                .fillMaxSize()
                .testTag("matches_list"),
              verticalArrangement = Arrangement.spacedBy(12.dp),
              contentPadding = PaddingValues(vertical = 14.dp),
            ) {
              items(
                items = filteredMatches,
                key = { it.matchId },
              ) { match ->
                MatchCard(
                  match = match,
                  isJoined = selectedTab == MatchesTab.MY_JOINED || match.isCodeVisible,
                  onCardClick = { onNavigateToMatchDetails(match.matchId) },
                  onJoinClick = { onNavigateToMatchDetails(match.matchId) },
                  onViewCodeClick = { onNavigateToMatchDetails(match.matchId) },
                  onSubmitProofClick = { onNavigateToMatchDetails(match.matchId) },
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun PrimaryTabRow(
  selectedTab: MatchesTab,
  onTabSelected: (MatchesTab) -> Unit,
) {
  Surface(
    color = MidnightNavyCard,
    border = BorderStroke(0.8.dp, MidnightNavyBorder),
    modifier = Modifier.fillMaxWidth(),
  ) {
    ScrollableTabRow(
      selectedTabIndex = selectedTab.ordinal,
      containerColor = Color.Transparent,
      contentColor = Gold400,
      edgePadding = 16.dp,
      divider = {},
    ) {
      MatchesTab.values().forEach { tab ->
        val isSelected = selectedTab == tab
        Tab(
          selected = isSelected,
          onClick = { onTabSelected(tab) },
          text = {
            Text(
              text = tab.label,
              style = MaterialTheme.typography.labelLarge.copy(
                fontWeight = if (isSelected) FontWeight.Black else FontWeight.Medium,
              ),
              color = if (isSelected) Gold400 else Slate400,
            )
          },
          modifier = Modifier.testTag("tab_${tab.name.lowercase()}"),
        )
      }
    }
  }
}

@Composable
private fun GameFilterRow(
  selectedFilter: GameFilter,
  onFilterSelected: (GameFilter) -> Unit,
) {
  LazyRow(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 10.dp),
    horizontalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    items(GameFilter.values()) { filter ->
      val isSelected = selectedFilter == filter
      val accentColor = when (filter) {
        GameFilter.ALL -> Indigo400
        GameFilter.LUDO -> Gold400
        GameFilter.CARROM -> NeonCyan
      }

      Surface(
        color = if (isSelected) Color.Transparent else MidnightNavyCard,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(
          0.8.dp,
          if (isSelected) Gold400 else MidnightNavyBorder,
        ),
        shadowElevation = if (isSelected) 4.dp else 1.dp,
        modifier = Modifier
          .clip(RoundedCornerShape(14.dp))
          .then(
            if (isSelected) {
              Modifier.background(ElectricAmberGradient)
            } else {
              Modifier
            }
          )
          .testTag("filter_${filter.name.lowercase()}"),
        onClick = { onFilterSelected(filter) },
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          // 3D Isometric Tactile Icon Container
          Box(
            modifier = Modifier
              .size(22.dp)
              .clip(RoundedCornerShape(6.dp))
              .then(
                if (isSelected) {
                  Modifier.background(Slate950.copy(alpha = 0.25f))
                } else {
                  Modifier.background(
                    Brush.radialGradient(
                      colors = listOf(
                        accentColor.copy(alpha = 0.3f),
                        Color.Transparent,
                      )
                    )
                  )
                }
              )
              .border(
                0.8.dp,
                if (isSelected) Slate950.copy(alpha = 0.35f) else accentColor.copy(alpha = 0.5f),
                RoundedCornerShape(6.dp),
              ),
            contentAlignment = Alignment.Center,
          ) {
            Icon(
              imageVector = when (filter) {
                GameFilter.ALL -> Icons.Default.SportsEsports
                GameFilter.LUDO -> Icons.Default.Casino
                GameFilter.CARROM -> Icons.Default.Album
              },
              contentDescription = null,
              tint = if (isSelected) Slate950 else accentColor,
              modifier = Modifier.size(14.dp),
            )
          }

          Spacer(modifier = Modifier.width(8.dp))

          Text(
            text = filter.label,
            style = MaterialTheme.typography.labelMedium.copy(
              fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
              fontSize = 12.sp,
              letterSpacing = 0.3.sp,
            ),
            color = if (isSelected) Slate950 else Color.White,
          )
        }
      }
    }
  }
}
