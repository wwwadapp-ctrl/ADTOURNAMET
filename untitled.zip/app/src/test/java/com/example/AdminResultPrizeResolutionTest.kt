package com.example

import com.example.core.model.AdminMatchItem
import com.example.core.model.AdminResultItem
import com.example.core.model.ResultStatus
import com.example.core.model.SuperAdminSession
import com.example.core.model.TournamentMath
import com.example.core.model.UserWalletData
import com.example.core.repository.FirebaseResultsRepository
import com.example.core.repository.ResultPrizeResolver
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class AdminResultPrizeResolutionTest {

    private val adminSession = SuperAdminSession(
        uid = "superadmin_test_uid",
        identifier = "Super Admin (Test)",
        isSuperAdminVerified = true
    )

    private fun createTestMatch(
        matchId: String,
        matchNumber: String = "#001",
        gameType: String = "LUDO",
        entryFee: Double = 5500.0,
        prizePool: Double = 9900.0,
        entryFeeMinorUnits: Long = 5500L,
        prizeMinorUnits: Long = 9900L
    ) = AdminMatchItem(
        matchId = matchId,
        matchNumber = matchNumber,
        title = "$gameType 1v1 $matchNumber",
        gameType = gameType,
        entryFee = entryFee,
        prizePool = prizePool,
        status = com.example.core.model.MatchStatus.AVAILABLE,
        rawStatus = "AVAILABLE",
        gameCode = "12345678",
        isCodeVisible = true,
        scheduledTime = System.currentTimeMillis(),
        joinedPlayersCount = 2,
        entryFeeMinorUnits = entryFeeMinorUnits,
        prizeMinorUnits = prizeMinorUnits
    )

    @Test
    fun testResultWithValidMatchIdResolvesCorrectMatchPrize() = runBlocking {
        val matchId = "mtc_match_001"
        val userId = "usr_winner_789"

        // Authoritative match with ৳55 entry and ৳99 prize
        val entryFeeMinor = TournamentMath.takaToMinorUnits(55L) // 5500L
        val expectedPrizeMinor = TournamentMath.calculatePrizeMinorUnits(entryFeeMinor) // 9900L
        val expectedPrizeTaka = TournamentMath.minorUnitsToTaka(expectedPrizeMinor) // 99L

        val match = createTestMatch(
            matchId = matchId,
            matchNumber = "#001",
            gameType = "LUDO",
            entryFee = 5500.0,
            prizePool = 9900.0,
            entryFeeMinorUnits = entryFeeMinor,
            prizeMinorUnits = expectedPrizeMinor
        )

        // Result submitted by user app without prizeMinorUnits (default 0L)
        val pendingResultWithoutPrize = AdminResultItem(
            resultId = "res_001",
            matchId = matchId,
            matchNumber = "#001",
            gameType = "LUDO",
            userId = userId,
            userName = "Winner Player",
            roomCode = "12345678",
            proofScreenshotUrl = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==",
            prizeMinorUnits = 0L,
            prizeTaka = 0.0,
            status = ResultStatus.PENDING
        )

        val repository = FirebaseResultsRepository(
            initialResults = listOf(pendingResultWithoutPrize),
            initialMatches = mapOf(matchId to match)
        )

        // 1. Resolve through getResult
        val resolvedResult = repository.getResult("res_001")
        assertNotNull("Result must be resolved", resolvedResult)
        assertEquals("Authoritative prize minor units must match match prize", expectedPrizeMinor, resolvedResult!!.prizeMinorUnits)
        assertEquals("Authoritative prize taka must match match prize in taka", expectedPrizeTaka.toDouble(), resolvedResult.prizeTaka, 0.001)

        // 2. Resolve through observeResults flow
        val resultsList = repository.observeResults().first()
        val itemInList = resultsList.firstOrNull { it.resultId == "res_001" }
        assertNotNull("Item must be present in observeResults flow", itemInList)
        assertEquals(expectedPrizeMinor, itemInList!!.prizeMinorUnits)
        assertEquals(expectedPrizeTaka.toDouble(), itemInList.prizeTaka, 0.001)
    }

    @Test
    fun testMinorUnitsConvertedCorrectlyForDisplay() {
        // ৳99 for ৳55 entry match
        val entryFeeMinor = TournamentMath.takaToMinorUnits(55L)
        val prizeMinor99 = TournamentMath.calculatePrizeMinorUnits(entryFeeMinor) // 9900L
        assertEquals(9900L, prizeMinor99)
        assertEquals(99L, TournamentMath.minorUnitsToTaka(prizeMinor99))
        assertEquals("৳99", TournamentMath.formatTaka(prizeMinor99))

        val resultItem99 = AdminResultItem(
            resultId = "res_test_99",
            prizeMinorUnits = prizeMinor99,
            prizeTaka = TournamentMath.minorUnitsToTakaDouble(prizeMinor99)
        )
        assertEquals("৳99", resultItem99.formattedPrize)

        // ৳750
        val prizeMinor750 = TournamentMath.takaToMinorUnits(750L) // 75000L
        val resultItem750 = AdminResultItem(
            resultId = "res_test_750",
            prizeMinorUnits = prizeMinor750,
            prizeTaka = 750.0
        )
        assertEquals("৳750", resultItem750.formattedPrize)
    }

    @Test
    fun testZeroDefaultPrizeNotUsedWhenMatchContainsValidPrize() {
        // Match contains prizeMinorUnits = 9900L, result contains prizeMinorUnits = 0L
        val resolved = ResultPrizeResolver.resolvePrizeMinorUnits(
            matchPrizeMinorUnits = 9900L,
            matchPrizePoolTaka = 99.0,
            matchEntryFeeMinorUnits = 5500L,
            matchEntryFeeTaka = 55.0,
            resultPrizeMinorUnits = 0L,
            resultPrizePoolTaka = 0.0
        )
        assertEquals("Must resolve to 9900L, not 0L default", 9900L, resolved)
    }

    @Test
    fun testPrizeResolutionFallbackToPrizePoolIfMinorUnitsMissingOrZero() {
        // Match prizeMinorUnits is 0, but prizePool is 99.0
        val resolved = ResultPrizeResolver.resolvePrizeMinorUnits(
            matchPrizeMinorUnits = 0L,
            matchPrizePoolTaka = 9900.0,
            matchEntryFeeMinorUnits = 0L,
            matchEntryFeeTaka = 0.0,
            resultPrizeMinorUnits = 0L,
            resultPrizePoolTaka = 0.0
        )
        assertEquals("Must resolve to 9900L from minor units in prizePool field", 9900L, resolved)
    }

    @Test
    fun testPrizeResolutionFallbackToEntryFeeTournamentMath() {
        // Match prizeMinorUnits and prizePool are 0, but entryFeeMinorUnits is 5500L
        val resolved = ResultPrizeResolver.resolvePrizeMinorUnits(
            matchPrizeMinorUnits = 0L,
            matchPrizePoolTaka = 0.0,
            matchEntryFeeMinorUnits = 5500L,
            matchEntryFeeTaka = 5500.0,
            resultPrizeMinorUnits = 0L,
            resultPrizePoolTaka = 0.0
        )
        val expected = TournamentMath.calculatePrizeMinorUnits(5500L) // 9900L
        assertEquals("Must calculate prize from entryFeeMinorUnits via TournamentMath", expected, resolved)
    }

    @Test
    fun testApproveResultBlocksZeroPrize() = runBlocking {
        val matchId = "mtc_zero_prize"
        val userId = "usr_winner_zero"

        val match = createTestMatch(
            matchId = matchId,
            matchNumber = "#000",
            entryFee = 0.0,
            prizePool = 0.0,
            entryFeeMinorUnits = 0L,
            prizeMinorUnits = 0L
        )

        val pendingResult = AdminResultItem(
            resultId = "res_zero",
            matchId = matchId,
            matchNumber = "#000",
            userId = userId,
            userName = "Zero Player",
            roomCode = "000000",
            prizeMinorUnits = 0L,
            prizeTaka = 0.0,
            status = ResultStatus.PENDING
        )

        val repository = FirebaseResultsRepository(
            initialResults = listOf(pendingResult),
            initialMatches = mapOf(matchId to match),
            initialWallets = mapOf(userId to UserWalletData(userId = userId, balance = 1000L))
        )

        val approveResult = repository.approveResult(
            resultId = "res_zero",
            submittedMatchNumber = "#000",
            submittedRoomCode = "000000",
            adminSession = adminSession
        )

        assertTrue("Approval must fail if prize is 0", approveResult.isFailure)
        val errorMsg = approveResult.exceptionOrNull()?.message ?: ""
        assertTrue("Error message must indicate ৳0 prize cannot be approved", errorMsg.contains("0"))

        val wallet = repository.getUserWallet(userId)
        assertEquals("Wallet balance must not change on failed approval", 1000L, wallet!!.balance)
    }

    @Test
    fun testApproveResultCreditsResolvedMatchPrizeToWinnerWallet() = runBlocking {
        val matchId = "mtc_live_001"
        val userId = "usr_live_winner"

        val entryFeeMinor = TournamentMath.takaToMinorUnits(55L) // 5500L
        val prizeMinor = TournamentMath.calculatePrizeMinorUnits(entryFeeMinor) // 9900L (৳99)

        val match = createTestMatch(
            matchId = matchId,
            matchNumber = "#001",
            gameType = "LUDO",
            prizeMinorUnits = prizeMinor,
            prizePool = 99.0
        )

        // Result without prize
        val pendingResult = AdminResultItem(
            resultId = "res_live_001",
            matchId = matchId,
            matchNumber = "#001",
            userId = userId,
            userName = "Live Winner",
            roomCode = "ROOM123",
            prizeMinorUnits = 0L,
            prizeTaka = 0.0,
            status = ResultStatus.PENDING
        )

        val initialWallet = UserWalletData(
            userId = userId,
            balance = 10000L,
            availableBalance = 5000L,
            winningBalance = 2000L
        )

        val repository = FirebaseResultsRepository(
            initialResults = listOf(pendingResult),
            initialMatches = mapOf(matchId to match),
            initialWallets = mapOf(userId to initialWallet)
        )

        val approveResult = repository.approveResult(
            resultId = "res_live_001",
            submittedMatchNumber = "#001",
            submittedRoomCode = "ROOM123",
            adminSession = adminSession
        )

        assertTrue("Approve must succeed with resolved prize", approveResult.isSuccess)

        val updatedWallet = repository.getUserWallet(userId)
        assertNotNull(updatedWallet)
        assertEquals("Available balance must be credited by 9900 minor units", 5000L + prizeMinor, updatedWallet!!.availableBalance)
        assertEquals("Winning balance must be credited by 9900 minor units", 2000L + prizeMinor, updatedWallet.winningBalance)
        assertEquals("Total balance must be credited by 9900 minor units", 10000L + prizeMinor, updatedWallet.balance)
    }

    @Test
    fun testAddResultDynamicallyResolvesPrizeFromExistingMatch() = runBlocking {
        val repository = FirebaseResultsRepository()
        val matchId = "mtc_dynamic_001"
        val match = createTestMatch(
            matchId = matchId,
            matchNumber = "#001",
            entryFee = 55.0,
            prizePool = 99.0,
            entryFeeMinorUnits = 5500L,
            prizeMinorUnits = 9900L
        )
        repository.setMatch(match)

        val pendingResult = AdminResultItem(
            resultId = "res_dynamic_001",
            matchId = matchId,
            matchNumber = "#001",
            userId = "usr_dynamic_winner",
            prizeMinorUnits = 0L,
            prizeTaka = 0.0,
            status = ResultStatus.PENDING
        )
        repository.addResult(pendingResult)

        val resolved = repository.getResult("res_dynamic_001")
        assertNotNull(resolved)
        assertEquals(9900L, resolved!!.prizeMinorUnits)
        assertEquals(99.0, resolved.prizeTaka, 0.001)
        assertEquals("৳99", resolved.formattedPrize)
    }

    @Test
    fun testRejectResult_SetsStatusRejected_DoesNotCreditWallet_LocksProof() = runBlocking {
        val repository = FirebaseResultsRepository()
        val userId = "usr_reject_test_1"
        val matchId = "mtc_reject_test_1"
        val resultId = "res_reject_001"

        repository.setUserWallet(
            userId,
            UserWalletData(
                userId = userId,
                balance = 15000L,
                availableBalance = 10000L,
                winningBalance = 5000L
            )
        )

        val pendingResult = AdminResultItem(
            resultId = resultId,
            matchId = matchId,
            matchNumber = "#001",
            userId = userId,
            prizeMinorUnits = 9900L,
            prizeTaka = 99.0,
            status = ResultStatus.PENDING,
            proofScreenshotUrl = "https://example.com/screenshot.jpg"
        )
        repository.addResult(pendingResult)

        // Perform rejection
        val rejectResult = repository.rejectResult(
            resultId = resultId,
            reason = "Invalid room screenshot / ভুয়া স্ক্রিনশট",
            adminSession = adminSession
        )
        assertTrue("Reject must succeed", rejectResult.isSuccess)

        // 1. Verify status is REJECTED and proof is cleared
        val resultAfterReject = repository.getResult(resultId)
        assertNotNull(resultAfterReject)
        assertEquals(ResultStatus.REJECTED, resultAfterReject!!.status)
        assertEquals("Invalid room screenshot / ভুয়া স্ক্রিনশট", resultAfterReject.rejectionReason)
        assertTrue("Proof screenshot must be cleared", resultAfterReject.proofScreenshotUrl.isBlank())

        // 2. STRICT AUDIT: Wallet must NOT be touched or credited
        val walletAfterReject = repository.getUserWallet(userId)
        assertNotNull(walletAfterReject)
        assertEquals(15000L, walletAfterReject!!.balance)
        assertEquals(10000L, walletAfterReject.availableBalance)
        assertEquals(5000L, walletAfterReject.winningBalance)
    }

    @Test
    fun testApproveResult_GuardsCompletedMatch_PreventsDuplicatePayouts() = runBlocking {
        val repository = FirebaseResultsRepository()
        val matchId = "mtc_guard_001"
        val winnerId = "usr_winner_guard"
        val impostorId = "usr_impostor_guard"

        val match = createTestMatch(
            matchId = matchId,
            matchNumber = "#001",
            prizeMinorUnits = 9900L
        )
        repository.setMatch(match)

        repository.setUserWallet(winnerId, UserWalletData(userId = winnerId, balance = 1000L, availableBalance = 1000L))
        repository.setUserWallet(impostorId, UserWalletData(userId = impostorId, balance = 1000L, availableBalance = 1000L))

        val winnerResult = AdminResultItem(
            resultId = "res_guard_winner",
            matchId = matchId,
            matchNumber = "#001",
            userId = winnerId,
            prizeMinorUnits = 9900L,
            prizeTaka = 99.0,
            status = ResultStatus.PENDING
        )
        val impostorResult = AdminResultItem(
            resultId = "res_guard_impostor",
            matchId = matchId,
            matchNumber = "#001",
            userId = impostorId,
            prizeMinorUnits = 9900L,
            prizeTaka = 99.0,
            status = ResultStatus.PENDING
        )
        repository.addResult(winnerResult)
        repository.addResult(impostorResult)

        // Approve legitimate winner
        val firstApproval = repository.approveResult(
            resultId = "res_guard_winner",
            submittedMatchNumber = "#001",
            submittedRoomCode = "12345678",
            adminSession = adminSession
        )
        assertTrue("First approval must succeed", firstApproval.isSuccess)

        // Try to approve another result on the now COMPLETED match -> Must fail immediately
        val duplicateApproval = repository.approveResult(
            resultId = "res_guard_impostor",
            submittedMatchNumber = "#001",
            submittedRoomCode = "12345678",
            adminSession = adminSession
        )
        assertTrue("Duplicate approval on completed match must fail", duplicateApproval.isFailure)
        assertTrue(
            "Failure message must explain match is already COMPLETED or settled",
            duplicateApproval.exceptionOrNull()?.message?.contains("COMPLETED") == true ||
            duplicateApproval.exceptionOrNull()?.message?.contains("already been approved") == true
        )

        // Impostor wallet must NOT receive any credit
        val impostorWallet = repository.getUserWallet(impostorId)
        assertNotNull(impostorWallet)
        assertEquals(1000L, impostorWallet!!.balance)
    }

    @Test
    fun testApproveResult_AutomaticLoserHandling_OpponentResultLost_OpponentNoWalletCredit() = runBlocking {
        val repository = FirebaseResultsRepository()
        val matchId = "mtc_1v1_duel_001"
        val winnerId = "usr_duel_winner"
        val loserId = "usr_duel_loser"

        val match = createTestMatch(
            matchId = matchId,
            matchNumber = "#001",
            prizeMinorUnits = 9900L
        )
        repository.setMatch(match)

        // Set up 1v1 match players
        repository.setMatchPlayers(
            matchId = matchId,
            players = listOf(
                com.example.core.model.MatchPlayerDetails(
                    matchPlayerId = "mp_1",
                    matchId = matchId,
                    userId = winnerId,
                    username = "WinnerPlayer",
                    slot = "PLAYER_1",
                    joinedAt = System.currentTimeMillis(),
                    isReady = true,
                    uid = winnerId,
                    entryFeeMinorUnits = 5500L,
                    status = "JOINED"
                ),
                com.example.core.model.MatchPlayerDetails(
                    matchPlayerId = "mp_2",
                    matchId = matchId,
                    userId = loserId,
                    username = "LoserPlayer",
                    slot = "PLAYER_2",
                    joinedAt = System.currentTimeMillis(),
                    isReady = true,
                    uid = loserId,
                    entryFeeMinorUnits = 5500L,
                    status = "JOINED"
                )
            )
        )

        repository.setUserWallet(winnerId, UserWalletData(userId = winnerId, balance = 5000L, availableBalance = 5000L, winningBalance = 0L))
        repository.setUserWallet(loserId, UserWalletData(userId = loserId, balance = 2000L, availableBalance = 2000L, winningBalance = 0L))

        // Both players submitted proof
        val winnerResult = AdminResultItem(
            resultId = "res_duel_winner",
            matchId = matchId,
            matchNumber = "#001",
            userId = winnerId,
            roomCode = "12345678",
            prizeMinorUnits = 9900L,
            prizeTaka = 99.0,
            status = ResultStatus.PENDING
        )
        val loserResult = AdminResultItem(
            resultId = "res_duel_loser",
            matchId = matchId,
            matchNumber = "#001",
            userId = loserId,
            roomCode = "12345678",
            prizeMinorUnits = 9900L,
            prizeTaka = 99.0,
            status = ResultStatus.PENDING
        )
        repository.addResult(winnerResult)
        repository.addResult(loserResult)

        // Admin approves winner
        val approval = repository.approveResult(
            resultId = "res_duel_winner",
            submittedMatchNumber = "#001",
            submittedRoomCode = "12345678",
            adminSession = adminSession
        )
        assertTrue(approval.isSuccess)

        // 1. Winner result is APPROVED and wallet credited
        val approvedWinnerRes = repository.getResult("res_duel_winner")
        assertNotNull(approvedWinnerRes)
        assertEquals(ResultStatus.APPROVED, approvedWinnerRes!!.status)

        val winnerWallet = repository.getUserWallet(winnerId)
        assertNotNull(winnerWallet)
        assertEquals(5000L + 9900L, winnerWallet!!.balance)
        assertEquals(9900L, winnerWallet.winningBalance)

        // 2. Opponent result is marked LOST and proof cleared
        val opponentRes = repository.getResult("res_duel_loser")
        assertNotNull(opponentRes)
        assertEquals("Opponent result must be set to LOST", ResultStatus.LOST, opponentRes!!.status)
        assertTrue("Opponent proof screenshot must be cleared", opponentRes.proofScreenshotUrl.isBlank())

        // 3. Match players statuses updated
        val updatedPlayers = repository.getMatchPlayers(matchId)
        val pWinner = updatedPlayers.first { it.userId == winnerId }
        val pLoser = updatedPlayers.first { it.userId == loserId }
        assertEquals("WON", pWinner.status)
        assertEquals("LOST", pLoser.status)

        // 4. ZERO prize or credit for the opponent
        val loserWallet = repository.getUserWallet(loserId)
        assertNotNull(loserWallet)
        assertEquals("Loser wallet balance must NOT change", 2000L, loserWallet!!.balance)
        assertEquals("Loser winning balance must NOT change", 0L, loserWallet.winningBalance)
    }
}
