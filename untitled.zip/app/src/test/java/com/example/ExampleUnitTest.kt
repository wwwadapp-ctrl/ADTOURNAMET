package com.example

import com.example.core.model.AdminDepositItem
import com.example.core.model.AdminMatchItem
import com.example.core.model.MatchAutoHandler
import com.example.core.model.CreateMatchRequest
import com.example.core.model.DepositStatus
import com.example.core.model.MatchStatus
import com.example.core.model.PaymentNumberItem
import com.example.core.model.SuperAdminSession
import com.example.core.model.TournamentMath
import com.example.core.repository.FirebaseDepositsRepository
import com.example.core.repository.FirebaseSettingsRepository
import com.example.core.repository.FirebaseUsersRepository
import com.example.core.repository.InMemoryMatchesRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testDeleteMatchPermanently() = runBlocking {
    val repo = InMemoryMatchesRepository()
    val superAdminSession = SuperAdminSession(
      uid = "GuIxwtI4hLQIoKOOt3V2XKnFhiB2",
      identifier = "superadmin@example.com",
      isSuperAdminVerified = true
    )

    // Create a match
    val createResult = repo.createSingleMatch(
      CreateMatchRequest(
        gameType = "LUDO",
        matchNumber = "TEST-999",
        title = "Test Elimination Fixture",
        entryFeeTaka = 50,
        scheduledTimestamp = System.currentTimeMillis() + 3600000L
      ),
      superAdminSession
    )
    assertTrue("Match creation should succeed", createResult.isSuccess)
    val matchId = createResult.getOrThrow()

    // Verify it is present in flow
    val matchesBefore = repo.observeMatches().first()
    assertTrue(matchesBefore.any { it.matchId == matchId })

    // Permanently delete match
    val deleteResult = repo.deleteMatchPermanently(matchId, superAdminSession)
    assertTrue("Delete match should succeed", deleteResult.isSuccess)

    // Verify it has been permanently removed
    val matchesAfter = repo.observeMatches().first()
    assertFalse("Deleted match should no longer be present", matchesAfter.any { it.matchId == matchId })
  }

  @Test
  fun testRoomCodeInjectionAndStatusUpdate() = runBlocking {
    val repo = InMemoryMatchesRepository()
    val superAdminSession = SuperAdminSession(
      uid = "GuIxwtI4hLQIoKOOt3V2XKnFhiB2",
      identifier = "superadmin@example.com",
      isSuperAdminVerified = true
    )

    // Create match
    val createResult = repo.createSingleMatch(
      CreateMatchRequest(
        gameType = "LUDO",
        matchNumber = "TEST-100",
        title = "Room Code Test Match",
        entryFeeTaka = 50,
        scheduledTimestamp = System.currentTimeMillis() + 3600000L
      ),
      superAdminSession
    )
    assertTrue(createResult.isSuccess)
    val matchId = createResult.getOrThrow()

    // Transition to FULL status (simulating 2 players joined)
    val statusResult = repo.updateMatchStatus(matchId, MatchStatus.FULL, "2/2 joined", superAdminSession)
    assertTrue(statusResult.isSuccess)

    val matchFull = repo.observeMatches().first().first { it.matchId == matchId }
    assertTrue("FULL match with blank code should flag needsRoomCode", matchFull.needsRoomCode)

    // Admin injects game room code
    val codeResult = repo.setMatchGameCode(matchId, "982341", superAdminSession)
    assertTrue("Room code injection should succeed", codeResult.isSuccess)

    val matchWithCode = repo.observeMatches().first().first { it.matchId == matchId }
    assertEquals("982341", matchWithCode.gameCode)
    assertEquals(MatchStatus.CODE_ADDED, matchWithCode.status)
    assertFalse("Match with room code should no longer need room code", matchWithCode.needsRoomCode)
  }

  @Test
  fun testPaymentNumberManagement() = runBlocking {
    val settingsRepo = FirebaseSettingsRepository()
    val superAdminSession = SuperAdminSession(
      uid = "GuIxwtI4hLQIoKOOt3V2XKnFhiB2",
      identifier = "01700000000",
      isSuperAdminVerified = true
    )

    // Verify initial payment numbers exist
    val initialNumbers = settingsRepo.observePaymentNumbers().first()
    assertTrue("Should contain seeded payment numbers", initialNumbers.isNotEmpty())

    // Add a new Nagad Merchant payment number
    val newNumber = PaymentNumberItem(
      id = "test_nagad_merchant_01",
      method = "Nagad",
      number = "01855667788",
      type = "Merchant",
      isActive = true,
      instructions = "Merchant payment with tournament TrxID"
    )
    val saveResult = settingsRepo.savePaymentNumber(newNumber, superAdminSession)
    assertTrue("Saving payment number should succeed", saveResult.isSuccess)

    val numbersAfterAdd = settingsRepo.observePaymentNumbers().first()
    val addedItem = numbersAfterAdd.firstOrNull { it.id == "test_nagad_merchant_01" }
    assertNotNull("Added payment number should be present in flow", addedItem)
    assertEquals("01855667788", addedItem?.number)
    assertEquals("Merchant", addedItem?.type)
    assertTrue(addedItem?.isActive == true)

    // Toggle active status to inactive
    val toggleResult = settingsRepo.togglePaymentNumberActive("test_nagad_merchant_01", false, superAdminSession)
    assertTrue("Toggling payment number active should succeed", toggleResult.isSuccess)

    val numbersAfterToggle = settingsRepo.observePaymentNumbers().first()
    val toggledItem = numbersAfterToggle.firstOrNull { it.id == "test_nagad_merchant_01" }
    assertFalse("Payment number should now be inactive", toggledItem?.isActive ?: true)

    // Delete the payment number
    val deleteResult = settingsRepo.removePaymentNumber(
      id = "test_nagad_merchant_01",
      method = "Nagad",
      number = "01855667788",
      adminSession = superAdminSession
    )
    assertTrue("Deleting payment number should succeed", deleteResult.isSuccess)

    val numbersAfterDelete = settingsRepo.observePaymentNumbers().first()
    assertNull("Deleted payment number should no longer exist", numbersAfterDelete.firstOrNull { it.id == "test_nagad_merchant_01" })
  }

  @Test
  fun testUsersDirectoryAndBanUnban() = runBlocking {
    val usersRepo = FirebaseUsersRepository()
    val superAdminSession = SuperAdminSession(
      uid = "GuIxwtI4hLQIoKOOt3V2XKnFhiB2",
      identifier = "01700000000",
      isSuperAdminVerified = true
    )

    // Observe users list
    val users = usersRepo.observeUsers().first()
    assertTrue("Users list should not be empty", users.isNotEmpty())

    val targetUser = users.first { it.isActive }
    val targetUid = targetUser.uid

    // Ban the user
    val banReason = "Suspicious multi-accounting detected"
    val banResult = usersRepo.toggleUserBan(
      uid = targetUid,
      shouldBan = true,
      reason = banReason,
      adminSession = superAdminSession
    )
    assertTrue("Banning user should succeed", banResult.isSuccess)

    val usersAfterBan = usersRepo.observeUsers().first()
    val bannedUser = usersAfterBan.first { it.uid == targetUid }
    assertTrue("User should be flagged as banned", bannedUser.isBanned)
    assertEquals("BANNED", bannedUser.status)
    assertEquals(banReason, bannedUser.banReason)

    // Unban the user
    val unbanResult = usersRepo.toggleUserBan(
      uid = targetUid,
      shouldBan = false,
      reason = "Admin review cleared player",
      adminSession = superAdminSession
    )
    assertTrue("Unbanning user should succeed", unbanResult.isSuccess)

    val usersAfterUnban = usersRepo.observeUsers().first()
    val restoredUser = usersAfterUnban.first { it.uid == targetUid }
    assertFalse("User should no longer be banned", restoredUser.isBanned)
    assertEquals("ACTIVE", restoredUser.status)
    assertTrue(restoredUser.isActive)
  }

  @Test
  fun testDepositApprovalBalanceCalculation() = runBlocking {
    val depositsRepo = FirebaseDepositsRepository()
    val superAdminSession = SuperAdminSession(
      uid = "GuIxwtI4hLQIoKOOt3V2XKnFhiB2",
      identifier = "01700000000",
      isSuperAdminVerified = true
    )

    // Observe initial deposits
    val deposits = depositsRepo.observeDeposits().first()
    val pendingDeposit = deposits.first { it.status == DepositStatus.PENDING && it.userId == "usr_tanvir_9812" }
    val initialWallet = depositsRepo.getWallet(pendingDeposit.userId)
    assertNotNull("Target user wallet should exist", initialWallet)

    val initialBalance = initialWallet!!.balance
    val initialAvailable = initialWallet.availableBalance
    val initialDepositBalance = initialWallet.depositBalance
    val initialTotalDeposited = initialWallet.totalDeposited
    val depositAmountMinor = pendingDeposit.amountMinorUnits

    // Approve the pending deposit
    val approveResult = depositsRepo.approveDeposit(
      depositId = pendingDeposit.id,
      actualReceivedMinorUnits = pendingDeposit.amountMinorUnits,
      adminSession = superAdminSession
    )
    assertTrue("Deposit approval should succeed", approveResult.isSuccess)

    // Verify deposit status updated to APPROVED
    val updatedDeposits = depositsRepo.observeDeposits().first()
    val approvedItem = updatedDeposits.first { it.id == pendingDeposit.id }
    assertEquals(DepositStatus.APPROVED, approvedItem.status)
    assertTrue(approvedItem.isApproved)
    assertNotNull("Processed timestamp must be set", approvedItem.processedAt)
    assertEquals(superAdminSession.identifier, approvedItem.processedBy)

    // Verify wallet balances incremented directly by exact deposit amount in minor units
    val updatedWallet = depositsRepo.getWallet(pendingDeposit.userId)
    assertNotNull(updatedWallet)
    assertEquals(initialBalance + depositAmountMinor, updatedWallet!!.balance)
    assertEquals(initialAvailable + depositAmountMinor, updatedWallet.availableBalance)
    assertEquals(initialDepositBalance + depositAmountMinor, updatedWallet.depositBalance)
    assertEquals(initialTotalDeposited + depositAmountMinor, updatedWallet.totalDeposited)

    // Verify minor units calculation consistency via TournamentMath
    val expectedMinorUnits = TournamentMath.takaToMinorUnits(pendingDeposit.amountTaka)
    assertEquals(expectedMinorUnits, pendingDeposit.amountMinorUnits)

    // Verify cannot re-approve an already approved deposit
    val secondApproveResult = depositsRepo.approveDeposit(
      depositId = pendingDeposit.id,
      actualReceivedMinorUnits = pendingDeposit.amountMinorUnits,
      adminSession = superAdminSession
    )
    assertFalse("Re-approving an already approved deposit must fail", secondApproveResult.isSuccess)
  }

  @Test
  fun testDepositRejectionFlow() = runBlocking {
    val depositsRepo = FirebaseDepositsRepository()
    val superAdminSession = SuperAdminSession(
      uid = "GuIxwtI4hLQIoKOOt3V2XKnFhiB2",
      identifier = "01700000000",
      isSuperAdminVerified = true
    )

    val deposits = depositsRepo.observeDeposits().first()
    val pendingDeposit = deposits.first { it.status == DepositStatus.PENDING && it.userId == "usr_shakib_4412" }
    val initialWallet = depositsRepo.getWallet(pendingDeposit.userId)
    assertNotNull(initialWallet)
    val balanceBefore = initialWallet!!.balance

    // Reject with a reason
    val rejectionReason = "TrxID 4M2K91823B not found in Nagad merchant ledger"
    val rejectResult = depositsRepo.rejectDeposit(pendingDeposit.id, rejectionReason, superAdminSession)
    assertTrue("Deposit rejection should succeed", rejectResult.isSuccess)

    // Verify deposit status is REJECTED with reason recorded
    val updatedDeposits = depositsRepo.observeDeposits().first()
    val rejectedItem = updatedDeposits.first { it.id == pendingDeposit.id }
    assertEquals(DepositStatus.REJECTED, rejectedItem.status)
    assertTrue(rejectedItem.isRejected)
    assertEquals(rejectionReason, rejectedItem.rejectionReason)

    // Verify wallet balance was NOT altered
    val walletAfter = depositsRepo.getWallet(pendingDeposit.userId)
    assertEquals("Wallet balance must remain unchanged on rejection", balanceBefore, walletAfter!!.balance)
  }

  @Test
  fun testTutorialAndBannerSettings() = runBlocking {
    val settingsRepo = FirebaseSettingsRepository()
    val superAdminSession = SuperAdminSession(
      uid = "GuIxwtI4hLQIoKOOt3V2XKnFhiB2",
      identifier = "01700000000",
      isSuperAdminVerified = true
    )

    val depBanner = "https://cdn.example.com/deposit_banner.png"
    val depVideo = "https://youtube.com/watch?v=deposit456"
    val joinBanner = "https://cdn.example.com/join_banner.png"
    val joinVideo = "https://youtube.com/watch?v=join123"
    val submitBanner = "https://cdn.example.com/submit_banner.png"
    val submitVideo = "https://youtube.com/watch?v=submit789"
    val rulesBanner = "https://cdn.example.com/rules_banner.png"
    val rulesVideo = "https://youtube.com/watch?v=rules000"
    val heroBanner = "https://cdn.example.com/banner_3d_promo.png"

    // Save all 4 guide banners (image + video) and custom hero banner
    val saveResult = settingsRepo.saveTutorialAndBannerSettings(
      depositBannerImageUrl = depBanner,
      howToDepositVideoUrl = depVideo,
      matchJoinBannerImageUrl = joinBanner,
      howToJoinVideoUrl = joinVideo,
      resultSubmitBannerImageUrl = submitBanner,
      howToSubmitResultVideoUrl = submitVideo,
      rulesBannerImageUrl = rulesBanner,
      tournamentRulesVideoUrl = rulesVideo,
      customBannerImageUrl = heroBanner,
      adminSession = superAdminSession
    )
    assertTrue("Saving 4 guide banners (image + video) must succeed", saveResult.isSuccess)

    // Verify /appSettings reflects all 8 saved URLs + hero banner
    val settingsAfterSave = settingsRepo.observeAppSettings().first()
    assertEquals(depBanner, settingsAfterSave.depositBannerImageUrl)
    assertEquals(depVideo, settingsAfterSave.howToDepositVideoUrl)
    assertEquals(joinBanner, settingsAfterSave.matchJoinBannerImageUrl)
    assertEquals(joinVideo, settingsAfterSave.howToJoinVideoUrl)
    assertEquals(submitBanner, settingsAfterSave.resultSubmitBannerImageUrl)
    assertEquals(submitVideo, settingsAfterSave.howToSubmitResultVideoUrl)
    assertEquals(rulesBanner, settingsAfterSave.rulesBannerImageUrl)
    assertEquals(rulesVideo, settingsAfterSave.tournamentRulesVideoUrl)
    assertEquals(heroBanner, settingsAfterSave.customBannerImageUrl)

    // Test unauthorized access prevention
    val unverifiedSession = SuperAdminSession(
      uid = "unverified_user",
      identifier = "intruder",
      isSuperAdminVerified = false
    )
    val unauthorizedResult = settingsRepo.saveTutorialAndBannerSettings(
      depositBannerImageUrl = "https://malicious.com",
      howToDepositVideoUrl = "",
      matchJoinBannerImageUrl = "",
      howToJoinVideoUrl = "",
      resultSubmitBannerImageUrl = "",
      howToSubmitResultVideoUrl = "",
      rulesBannerImageUrl = "",
      tournamentRulesVideoUrl = "",
      customBannerImageUrl = "",
      adminSession = unverifiedSession
    )
    assertFalse("Unverified session must be blocked", unauthorizedResult.isSuccess)

    // Clear / Reset all 4 guide banners and hero banner
    val resetResult = settingsRepo.saveTutorialAndBannerSettings(
      depositBannerImageUrl = "",
      howToDepositVideoUrl = "",
      matchJoinBannerImageUrl = "",
      howToJoinVideoUrl = "",
      resultSubmitBannerImageUrl = "",
      howToSubmitResultVideoUrl = "",
      rulesBannerImageUrl = "",
      tournamentRulesVideoUrl = "",
      customBannerImageUrl = "",
      adminSession = superAdminSession
    )
    assertTrue("Clearing settings should succeed", resetResult.isSuccess)

    val settingsAfterReset = settingsRepo.observeAppSettings().first()
    assertEquals("", settingsAfterReset.depositBannerImageUrl)
    assertEquals("", settingsAfterReset.howToDepositVideoUrl)
    assertEquals("", settingsAfterReset.matchJoinBannerImageUrl)
    assertEquals("", settingsAfterReset.howToJoinVideoUrl)
    assertEquals("", settingsAfterReset.resultSubmitBannerImageUrl)
    assertEquals("", settingsAfterReset.howToSubmitResultVideoUrl)
    assertEquals("", settingsAfterReset.rulesBannerImageUrl)
    assertEquals("", settingsAfterReset.tournamentRulesVideoUrl)
    assertEquals("", settingsAfterReset.customBannerImageUrl)
  }

  @Test
  fun testMatchCancellationReasonValidationAndPersistence() = runBlocking {
    val repo = InMemoryMatchesRepository()
    val depositsRepo = FirebaseDepositsRepository()
    val superAdminSession = SuperAdminSession(
      uid = "GuIxwtI4hLQIoKOOt3V2XKnFhiB2",
      identifier = "superadmin@example.com",
      isSuperAdminVerified = true
    )

    // 1. Create and release a match
    val createResult = repo.createSingleMatch(
      CreateMatchRequest(
        gameType = "LUDO",
        matchNumber = "CANCEL-TEST-01",
        title = "Cancellation Reason Verification Match",
        entryFeeTaka = 50,
        scheduledTimestamp = System.currentTimeMillis() + 3600000L
      ),
      superAdminSession
    )
    assertTrue("Match creation should succeed", createResult.isSuccess)
    val matchId = createResult.getOrThrow()

    // Release match to AVAILABLE
    repo.releaseMatch(matchId, superAdminSession)
    val availableMatch = repo.observeMatches().first().first { it.matchId == matchId }
    assertEquals(MatchStatus.AVAILABLE, availableMatch.status)
    assertNull("New match should have null cancelReason", availableMatch.cancelReason)

    // Capture user wallet balance before cancellation test to verify zero wallet mutation
    val sampleUserId = "usr_tanvir_9812"
    val initialWallet = depositsRepo.getWallet(sampleUserId)
    assertNotNull("Sample player wallet should exist", initialWallet)
    val initialBalance = initialWallet!!.balance

    // 2. Cancel without reason is rejected
    val emptyReasonResult = repo.updateMatchStatus(matchId, MatchStatus.CANCELLED, "", superAdminSession)
    assertFalse("Cancelling with empty reason must fail", emptyReasonResult.isSuccess)
    assertTrue("Failure exception should mention cancellation reason is required",
      emptyReasonResult.exceptionOrNull()?.message?.contains("Cancellation reason is required") == true)

    // 3. Whitespace-only reason is rejected
    val whitespaceReasonResult = repo.updateMatchStatus(matchId, MatchStatus.CANCELLED, "    ", superAdminSession)
    assertFalse("Cancelling with whitespace-only reason must fail", whitespaceReasonResult.isSuccess)
    assertTrue("Failure exception should mention cancellation reason is required",
      whitespaceReasonResult.exceptionOrNull()?.message?.contains("Cancellation reason is required") == true)

    // Verify status was NOT changed to CANCELLED on rejected attempts
    val uncancelledMatch = repo.observeMatches().first().first { it.matchId == matchId }
    assertEquals("Status should remain AVAILABLE after failed cancellation attempts",
      MatchStatus.AVAILABLE, uncancelledMatch.status)
    assertNull("cancelReason should remain null", uncancelledMatch.cancelReason)

    // 4. Unauthorized Admin cannot cancel
    val unverifiedSession = SuperAdminSession(
      uid = "unverified_admin",
      identifier = "unauthorized@example.com",
      isSuperAdminVerified = false
    )
    val unauthorizedCancelResult = repo.updateMatchStatus(
      matchId,
      MatchStatus.CANCELLED,
      "Valid reason by unauthorized admin",
      unverifiedSession
    )
    assertFalse("Unauthorized admin cannot cancel match", unauthorizedCancelResult.isSuccess)

    // 5. Valid cancellation with surrounding whitespace -> trimmed reason and atomic state transition
    val rawReason = "  Server connectivity issue during scheduled slot. Full reschedule requested.  "
    val expectedTrimmedReason = "Server connectivity issue during scheduled slot. Full reschedule requested."

    val cancelResult = repo.updateMatchStatus(matchId, MatchStatus.CANCELLED, rawReason, superAdminSession)
    assertTrue("Valid cancellation must succeed", cancelResult.isSuccess)

    // 6. Verify matches/$matchId has status CANCELLED and receives trimmed cancelReason
    val cancelledMatch = repo.observeMatches().first().first { it.matchId == matchId }
    assertEquals(MatchStatus.CANCELLED, cancelledMatch.status)
    assertEquals(expectedTrimmedReason, cancelledMatch.cancelReason)
    assertTrue("updatedAt must be positive epoch timestamp", cancelledMatch.updatedAt > 0)

    // 7. Verify audit log receives the same trimmed cancellation reason and MATCH_CANCELLED action
    val lastAudit = repo.auditLogRecords.lastOrNull()
    assertNotNull("Audit log must be recorded", lastAudit)
    assertEquals("MATCH_CANCELLED", lastAudit?.get("action"))
    assertEquals(superAdminSession.identifier, lastAudit?.get("admin"))
    assertEquals(matchId, lastAudit?.get("referenceId"))
    assertEquals(expectedTrimmedReason, lastAudit?.get("reason"))

    // 8. Existing non-cancel status actions are not affected (can use empty/optional reason)
    val secondMatchResult = repo.createSingleMatch(
      CreateMatchRequest(
        gameType = "CARROM",
        matchNumber = "PAUSE-TEST-02",
        title = "Pause Test Fixture",
        entryFeeTaka = 30,
        scheduledTimestamp = System.currentTimeMillis() + 3600000L
      ),
      superAdminSession
    )
    val secondMatchId = secondMatchResult.getOrThrow()
    val pauseResult = repo.updateMatchStatus(secondMatchId, MatchStatus.PAUSED, "", superAdminSession)
    assertTrue("Non-cancel status update (PAUSED) does not require non-empty reason", pauseResult.isSuccess)
    val pausedMatch = repo.observeMatches().first().first { it.matchId == secondMatchId }
    assertEquals(MatchStatus.PAUSED, pausedMatch.status)

    // 9. Verify zero wallet mutation and zero refund transactions occurred
    val walletAfterCancel = depositsRepo.getWallet(sampleUserId)
    assertNotNull(walletAfterCancel)
    assertEquals("Wallet balance must be completely untouched by cancellation",
      initialBalance, walletAfterCancel!!.balance)
  }

  @Test
  fun testTournamentMathCommissionAndPrizeCalculations() {
    val testCases = listOf(
      Triple(35L, 350L, 6300L),
      Triple(55L, 550L, 9900L),
      Triple(75L, 750L, 13500L),
      Triple(95L, 950L, 17100L),
      Triple(115L, 1150L, 20700L)
    )

    for ((entryFeeTaka, expectedCommissionPerPlayerMinor, expectedPrizeMinor) in testCases) {
      val entryFeeMinor = TournamentMath.takaToMinorUnits(entryFeeTaka)
      val commissionPerPlayer = TournamentMath.calculateCommissionMinorUnits(entryFeeMinor)
      val totalCommission = commissionPerPlayer * TournamentMath.MAX_PLAYERS
      val prizeMinor = TournamentMath.calculatePrizeMinorUnits(entryFeeMinor)

      assertEquals("Commission per player for ৳$entryFeeTaka", expectedCommissionPerPlayerMinor, commissionPerPlayer)
      assertEquals("Total commission for ৳$entryFeeTaka (2 players)", expectedCommissionPerPlayerMinor * 2, totalCommission)
      assertEquals("Prize minor units for ৳$entryFeeTaka", expectedPrizeMinor, prizeMinor)
    }
  }

  @Test
  fun testMatchAutoHandlingAndRefundRules() {
    val baseTime = 1000000L
    val scheduledTime = baseTime

    // 1. AVAILABLE match at > 1 hour -> eligible for first cleanup
    val availableMatch = AdminMatchItem(
      matchId = "m_avail",
      matchNumber = "#001",
      title = "Test Match",
      gameType = "LUDO",
      entryFee = 35.0,
      prizePool = 63.0,
      status = MatchStatus.AVAILABLE,
      rawStatus = "AVAILABLE",
      gameCode = "",
      isCodeVisible = false,
      scheduledTime = scheduledTime,
      joinedPlayersCount = 0,
      scheduledAt = scheduledTime
    )
    val timeAfter1Hour = scheduledTime + MatchAutoHandler.ONE_HOUR_MS + 1000L
    assertTrue("AVAILABLE match > 1 hour must be eligible for cleanup",
      MatchAutoHandler.isEligibleForCleanup(availableMatch, timeAfter1Hour, hasPendingWinningProof = false))

    // 2. UPCOMING match at > 1 hour from scheduled time -> eligible
    val upcomingMatch = availableMatch.copy(matchId = "m_up", status = MatchStatus.UPCOMING, rawStatus = "UPCOMING")
    assertTrue("UPCOMING match > 1 hour must be eligible for cleanup",
      MatchAutoHandler.isEligibleForCleanup(upcomingMatch, timeAfter1Hour, hasPendingWinningProof = false))

    // 3. RUNNING match at > 1 hour -> NOT eligible for 1-hour deletion
    val runningMatch = availableMatch.copy(
      matchId = "m_run",
      status = MatchStatus.RUNNING,
      rawStatus = "RUNNING",
      startedAt = scheduledTime
    )
    assertFalse("RUNNING match must NOT be eligible for deletion at 1 hour",
      MatchAutoHandler.isEligibleForCleanup(runningMatch, timeAfter1Hour, hasPendingWinningProof = false))

    // 4. RESULT_SUBMITTED match at > 1 hour -> NOT eligible for 1-hour deletion
    val resultSubmittedMatch = availableMatch.copy(
      matchId = "m_res",
      status = MatchStatus.RESULT_SUBMITTED,
      rawStatus = "RESULT_SUBMITTED",
      updatedAt = scheduledTime
    )
    assertFalse("RESULT_SUBMITTED match must NOT be eligible for deletion at 1 hour",
      MatchAutoHandler.isEligibleForCleanup(resultSubmittedMatch, timeAfter1Hour, hasPendingWinningProof = false))

    // 5. COMPLETED match at > 1 hour -> NOT eligible for 1-hour deletion
    val completedMatch = availableMatch.copy(
      matchId = "m_comp",
      status = MatchStatus.COMPLETED,
      rawStatus = "COMPLETED",
      updatedAt = scheduledTime
    )
    assertFalse("COMPLETED match must NOT be eligible for deletion at 1 hour",
      MatchAutoHandler.isEligibleForCleanup(completedMatch, timeAfter1Hour, hasPendingWinningProof = false))

    // 6. RUNNING / RESULT_SUBMITTED / COMPLETED eligible only after correct 2-hour window
    val timeBefore2Hours = scheduledTime + MatchAutoHandler.TWO_HOURS_MS - 1000L
    val timeAfter2Hours = scheduledTime + MatchAutoHandler.TWO_HOURS_MS + 1000L

    assertFalse("RUNNING match must NOT be eligible before 2 hours",
      MatchAutoHandler.isEligibleForCleanup(runningMatch, timeBefore2Hours, hasPendingWinningProof = false))
    assertTrue("RUNNING match must be eligible after 2 hours",
      MatchAutoHandler.isEligibleForCleanup(runningMatch, timeAfter2Hours, hasPendingWinningProof = false))

    assertFalse("RESULT_SUBMITTED match must NOT be eligible before 2 hours",
      MatchAutoHandler.isEligibleForCleanup(resultSubmittedMatch, timeBefore2Hours, hasPendingWinningProof = false))
    assertTrue("RESULT_SUBMITTED match must be eligible after 2 hours",
      MatchAutoHandler.isEligibleForCleanup(resultSubmittedMatch, timeAfter2Hours, hasPendingWinningProof = false))

    assertFalse("COMPLETED match must NOT be eligible before 2 hours",
      MatchAutoHandler.isEligibleForCleanup(completedMatch, timeBefore2Hours, hasPendingWinningProof = false))
    assertTrue("COMPLETED match must be eligible after 2 hours",
      MatchAutoHandler.isEligibleForCleanup(completedMatch, timeAfter2Hours, hasPendingWinningProof = false))

    // 7. One-player expired match -> requires refund
    val onePlayerMatch = availableMatch.copy(joinedPlayersCount = 1)
    assertTrue("One-player expired match requires refund", MatchAutoHandler.requiresRefund(onePlayerMatch))

    // 8. Zero-player expired match -> no refund
    val zeroPlayerMatch = availableMatch.copy(joinedPlayersCount = 0)
    assertFalse("Zero-player expired match requires no refund", MatchAutoHandler.requiresRefund(zeroPlayerMatch))

    // 9. Re-running cleanup / refund tracker does not cause a second refund (idempotent)
    val tracker = MatchAutoHandler.IdempotentRefundTracker()
    var refundCount = 0
    val matchIdTest = "match_refund_test"
    val firstExecution = tracker.processRefundOnce(matchIdTest) { refundCount++ }
    val secondExecution = tracker.processRefundOnce(matchIdTest) { refundCount++ }

    assertTrue("First refund execution must succeed", firstExecution)
    assertFalse("Second refund execution must be blocked (idempotent)", secondExecution)
    assertEquals("Refund action must execute exactly once", 1, refundCount)
    assertTrue("Tracker must record match as refunded", tracker.isRefunded(matchIdTest))

    // 10. Pending Winning Proof is protected from premature deletion
    val matchWithPendingProof = availableMatch.copy(status = MatchStatus.AVAILABLE)
    assertFalse("Match with pending Winning Proof must be protected from cleanup even after 1 hour",
      MatchAutoHandler.isEligibleForCleanup(matchWithPendingProof, timeAfter1Hour, hasPendingWinningProof = true))
    assertFalse("Match with pending Winning Proof must be protected even after 2 hours",
      MatchAutoHandler.isEligibleForCleanup(matchWithPendingProof, timeAfter2Hours, hasPendingWinningProof = true))
  }

  @Test
  fun testAutoBatchMatchCreation() = runBlocking {
    val repo = InMemoryMatchesRepository()
    val superAdminSession = SuperAdminSession(
      uid = "GuIxwtI4hLQIoKOOt3V2XKnFhiB2",
      identifier = "superadmin@example.com",
      isSuperAdminVerified = true
    )

    val request = com.example.core.model.AutoBatchMatchRequest(
      quantity = 20,
      gameType = "LUDO",
      startingEntryFeeTaka = 35L,
      firstScheduledTimestamp = 1000000000L
    )

    val previews = TournamentMath.generateAutoBatchPreview(request)
    assertEquals(20, previews.size)
    assertEquals(35L, previews[0].entryFeeTaka)
    assertEquals(55L, previews[1].entryFeeTaka)
    assertEquals(415L, previews[19].entryFeeTaka) // 35 + 19 * 20 = 415

    // Verify 4 Ludo + 1 Carrom fixed repeating pattern (1=Ludo, 2=Ludo, 3=Ludo, 4=Ludo, 5=Carrom, ...)
    for (i in 0 until 20) {
      val expectedGame = if ((i + 1) % 5 == 0) "CARROM" else "LUDO"
      assertEquals("Match ${i + 1} gameType mismatch", expectedGame, previews[i].gameType)
    }

    val createResult = repo.createAutoBatchMatches(request, superAdminSession)
    assertTrue("Auto batch match creation should succeed", createResult.isSuccess)
    val createdIds = createResult.getOrThrow()
    assertEquals(20, createdIds.size)

    val matches = repo.observeMatches().first()
    assertEquals(20, matches.size)
    assertTrue(matches.all { it.status == MatchStatus.UPCOMING })
  }

  @Test
  fun testAutoBatchValidationAndPreviewEdgeCases() {
    fun parseStartTimeOrNull(timeStr: String): Long? {
      val clean = timeStr.trim().uppercase()
      if (clean.isBlank()) return null
      val timeOnly = clean.replace("AM", "").replace("PM", "").trim()
      val parts = timeOnly.split(":")
      if (parts.size != 2) return null
      val hour = parts[0].toIntOrNull() ?: return null
      val minute = parts[1].toIntOrNull() ?: return null

      if (hour !in 0..23 || minute !in 0..59) return null

      val calendar = java.util.Calendar.getInstance().apply {
        set(java.util.Calendar.HOUR_OF_DAY, hour)
        set(java.util.Calendar.MINUTE, minute)
        set(java.util.Calendar.SECOND, 0)
        set(java.util.Calendar.MILLISECOND, 0)
      }
      return calendar.timeInMillis
    }

    // 1-7. Time validation tests
    assertNotNull("10:00 should be valid", parseStartTimeOrNull("10:00"))
    assertNotNull("00:00 should be valid", parseStartTimeOrNull("00:00"))
    assertNotNull("23:59 should be valid", parseStartTimeOrNull("23:59"))
    assertNull("24:00 should be invalid", parseStartTimeOrNull("24:00"))
    assertNull("10:60 should be invalid", parseStartTimeOrNull("10:60"))
    assertNull("Malformed text should be invalid", parseStartTimeOrNull("invalid"))
    assertNull("Empty time should be invalid", parseStartTimeOrNull(""))

    // 8-10. Entry fee safety & limits
    val reqValid35 = com.example.core.model.AutoBatchMatchRequest(20, "LUDO", 35L, 1000000000L)
    val reqValid115 = com.example.core.model.AutoBatchMatchRequest(20, "LUDO", 115L, 1000000000L)
    val previews35 = TournamentMath.generateAutoBatchPreview(reqValid35)
    assertEquals(20, previews35.size)
    assertEquals(35L, previews35[0].entryFeeTaka)
    assertEquals(55L, previews35[1].entryFeeTaka)
    assertEquals(75L, previews35[2].entryFeeTaka)
    assertEquals(415L, previews35[19].entryFeeTaka)

    val previews115 = TournamentMath.generateAutoBatchPreview(reqValid115)
    assertEquals(115L, previews115[0].entryFeeTaka)

    // Excessively large fee should throw IllegalArgumentException safely
    assertThrows(IllegalArgumentException::class.java) {
      TournamentMath.generateAutoBatchPreview(
        com.example.core.model.AutoBatchMatchRequest(20, "LUDO", 999999L, 1000000000L)
      )
    }

    // Long overflow-risk calculation test (e.g. Long.MAX_VALUE quantity or starting fee)
    assertThrows(IllegalArgumentException::class.java) {
      TournamentMath.generateAutoBatchPreview(
        com.example.core.model.AutoBatchMatchRequest(Int.MAX_VALUE, "LUDO", Long.MAX_VALUE, 1000000000L)
      )
    }

    // 11-12. Quantity range validation
    assertThrows(IllegalArgumentException::class.java) {
      TournamentMath.generateAutoBatchPreview(
        com.example.core.model.AutoBatchMatchRequest(0, "LUDO", 35L, 1000000000L)
      )
    }
    assertThrows(IllegalArgumentException::class.java) {
      TournamentMath.generateAutoBatchPreview(
        com.example.core.model.AutoBatchMatchRequest(101, "LUDO", 35L, 1000000000L)
      )
    }
  }

  @Test
  fun testPersistentNotificationsDataLayer() = runBlocking {
    val repo = com.example.core.repository.FirebaseNotificationsRepository()
    val session = com.example.core.model.SuperAdminSession(
      uid = "admin_test_123",
      identifier = "admin@test.com",
      role = "Super Admin"
    )

    // Test sending ALL_USERS notification
    val res1 = repo.sendNotification(
      title = "System Update",
      message = "Platform is running smoothly.",
      targetType = com.example.core.model.NotificationTargetType.ALL_USERS,
      targetId = "ALL",
      adminSession = session
    )
    assertTrue("Sending ALL_USERS notification should succeed", res1.isSuccess)

    // Test sending SPECIFIC_USER notification
    val res2 = repo.sendNotification(
      title = "Private Message",
      message = "Hello user.",
      targetType = com.example.core.model.NotificationTargetType.SPECIFIC_USER,
      targetId = "usr_tanvir_9812",
      adminSession = session
    )
    assertTrue("Sending SPECIFIC_USER notification should succeed", res2.isSuccess)

    // Test sending MATCH_PARTICIPANTS notification
    val res3 = repo.sendNotification(
      title = "Match Code Ready",
      message = "Room code is 123456",
      targetType = com.example.core.model.NotificationTargetType.MATCH_PARTICIPANTS,
      targetId = "match_test_999",
      adminSession = session
    )
    assertTrue("Sending MATCH_PARTICIPANTS notification should succeed", res3.isSuccess)

    // Test validation failures
    val resFail = repo.sendNotification(
      title = "",
      message = "Bad notification",
      targetType = com.example.core.model.NotificationTargetType.ALL_USERS,
      targetId = "ALL",
      adminSession = session
    )
    assertTrue("Sending notification with empty title should fail", resFail.isFailure)

    // Observe notifications
    val notifications = repo.observeNotifications().first()
    assertTrue("Notifications list should contain items", notifications.size >= 3)
    val first = notifications.first()
    assertNotNull(first.id)
    assertEquals("admin_test_123", first.senderAdmin)
  }

  @Test
  fun testAutomaticRoomCodeNotificationBehavior() = runBlocking {
    val matchesRepo = com.example.core.repository.InMemoryMatchesRepository(
      listOf(
        com.example.core.model.AdminMatchItem(
          matchId = "match_auto_1",
          matchNumber = "1",
          title = "Match 1",
          gameType = "LUDO",
          entryFee = 10.0,
          prizePool = 100.0,
          status = com.example.core.model.MatchStatus.FULL,
          rawStatus = "FULL",
          gameCode = "",
          isCodeVisible = false,
          scheduledTime = 0L,
          joinedPlayersCount = 2
        ),
        com.example.core.model.AdminMatchItem(
          matchId = "match_auto_2",
          matchNumber = "2",
          title = "Match 2",
          gameType = "LUDO",
          entryFee = 10.0,
          prizePool = 100.0,
          status = com.example.core.model.MatchStatus.FULL,
          rawStatus = "FULL",
          gameCode = "",
          isCodeVisible = false,
          scheduledTime = 0L,
          joinedPlayersCount = 2
        )
      )
    )
    val notifRepo = com.example.core.repository.FirebaseNotificationsRepository()
    val session = com.example.core.model.SuperAdminSession(
      uid = "admin_auto_1",
      identifier = "admin@test.com",
      role = "Super Admin",
      isSuperAdminVerified = true
    )

    // Scenario 3: Missing participants creates no notification
    val resSet1 = matchesRepo.setMatchGameCode("match_auto_1", "CODE123", session)
    assertTrue("Setting game code with missing participants should succeed", resSet1.isSuccess)
    val notifs1 = notifRepo.observeNotifications().first()
    val match1Notifs = notifs1.filter { it.targetId == "match_auto_1" }
    assertEquals("Missing participants should create 0 notifications", 0, match1Notifs.size)

    // Scenario 1: Blank -> non-blank Room Code creates one notification when participants exist
    matchesRepo.emitPlayers("match_auto_2", listOf(
      com.example.core.model.MatchPlayerDetails(
        matchPlayerId = "p1",
        matchId = "match_auto_2",
        userId = "u1",
        username = "PlayerOne",
        slot = "PLAYER_1",
        joinedAt = 0L,
        isReady = true,
        uid = "u1",
        entryFeeMinorUnits = 1000L,
        status = "JOINED"
      )
    ))

    val resSet2 = matchesRepo.setMatchGameCode("match_auto_2", "CODE456", session)
    assertTrue("Setting game code with participants should succeed", resSet2.isSuccess)
    val notifs2 = notifRepo.observeNotifications().first()
    val match2Notifs = notifs2.filter { it.targetId == "match_auto_2" }
    assertEquals("Blank to non-blank with participants should create exactly 1 notification", 1, match2Notifs.size)
    assertEquals("Notification targetType should be MATCH_PARTICIPANTS", com.example.core.model.NotificationTargetType.MATCH_PARTICIPANTS.value, match2Notifs.first().targetType)

    // Scenario 2 & 5: Existing code -> different code (or repeated action) creates no new notification / no duplicates
    val countBefore = notifs2.size
    val resSet3 = matchesRepo.setMatchGameCode("match_auto_2", "CODE789", session)
    assertTrue("Updating existing non-blank game code should succeed", resSet3.isSuccess)
    val notifs3 = notifRepo.observeNotifications().first()
    assertEquals("Editing existing non-blank game code / repeated action should not create duplicate notifications", countBefore, notifs3.size)
  }

  @Test
  fun testDepositApprovalNotification() = runBlocking {
    val depositsRepo = com.example.core.repository.FirebaseDepositsRepository()
    val notifRepo = com.example.core.repository.FirebaseNotificationsRepository()
    val session = com.example.core.model.SuperAdminSession(
      uid = "admin_dep_1",
      identifier = "admin@test.com",
      role = "Super Admin",
      isSuperAdminVerified = true
    )

    val deposits = depositsRepo.observeDeposits().first()
    val pendingDeposit = deposits.first { it.status == com.example.core.model.DepositStatus.PENDING && it.userId == "usr_tanvir_9812" }

    val resApprove = depositsRepo.approveDeposit(pendingDeposit.id, pendingDeposit.amountMinorUnits, session)
    assertTrue("Approval should succeed", resApprove.isSuccess)

    val notifs = notifRepo.observeNotifications().first()
    val userNotifs = notifs.filter { it.targetId == pendingDeposit.userId && it.message.contains("approved") }
    assertTrue("Successful approval should create notification for deposit owner", userNotifs.isNotEmpty())
    assertEquals("Notification targetType should be SPECIFIC_USER", com.example.core.model.NotificationTargetType.SPECIFIC_USER.value, userNotifs.first().targetType)
    assertEquals("Target ID must be the real deposit owner UID", pendingDeposit.userId, userNotifs.first().targetId)
  }

  @Test
  fun testDepositRejectionNotification() = runBlocking {
    val depositsRepo = com.example.core.repository.FirebaseDepositsRepository()
    val notifRepo = com.example.core.repository.FirebaseNotificationsRepository()
    val session = com.example.core.model.SuperAdminSession(
      uid = "admin_dep_1",
      identifier = "admin@test.com",
      role = "Super Admin",
      isSuperAdminVerified = true
    )

    val deposits = depositsRepo.observeDeposits().first()
    val pendingDeposit = deposits.first { it.status == com.example.core.model.DepositStatus.PENDING && it.userId == "usr_shakib_4412" }

    val resReject = depositsRepo.rejectDeposit(pendingDeposit.id, "Invalid transaction ID", session)
    assertTrue("Rejection should succeed", resReject.isSuccess)

    val notifs = notifRepo.observeNotifications().first()
    val userNotifs = notifs.filter { it.targetId == pendingDeposit.userId && it.message.contains("rejected") }
    assertTrue("Successful rejection should create notification for deposit owner", userNotifs.isNotEmpty())
    assertEquals("Notification targetType should be SPECIFIC_USER", com.example.core.model.NotificationTargetType.SPECIFIC_USER.value, userNotifs.first().targetType)
    assertEquals("Target ID must be the real deposit owner UID", pendingDeposit.userId, userNotifs.first().targetId)
  }

  @Test
  fun testDepositFailureNoNotification() = runBlocking {
    val depositsRepo = com.example.core.repository.FirebaseDepositsRepository()
    val notifRepo = com.example.core.repository.FirebaseNotificationsRepository()
    val session = com.example.core.model.SuperAdminSession(
      uid = "admin_dep_1",
      identifier = "admin@test.com",
      role = "Super Admin",
      isSuperAdminVerified = true
    )

    val countBefore = notifRepo.observeNotifications().first().size
    val resFail = depositsRepo.approveDeposit("non_existent_deposit_id", 1000L, session)
    assertFalse("Failed approval should fail", resFail.isSuccess)
    val countAfter = notifRepo.observeNotifications().first().size
    assertEquals("Failed approval must create no notifications", countBefore, countAfter)
  }

  @Test
  fun testDepositDuplicatePrevention() = runBlocking {
    val depositsRepo = com.example.core.repository.FirebaseDepositsRepository()
    val notifRepo = com.example.core.repository.FirebaseNotificationsRepository()
    val session = com.example.core.model.SuperAdminSession(
      uid = "admin_dep_1",
      identifier = "admin@test.com",
      role = "Super Admin",
      isSuperAdminVerified = true
    )

    val deposits = depositsRepo.observeDeposits().first()
    val pendingDeposit = deposits.first { it.status == com.example.core.model.DepositStatus.PENDING }

    // First approval succeeds
    val res1 = depositsRepo.approveDeposit(pendingDeposit.id, pendingDeposit.amountMinorUnits, session)
    assertTrue(res1.isSuccess)
    val countAfterFirst = notifRepo.observeNotifications().first().size

    // Retry approval should fail and not create duplicate notification
    val res2 = depositsRepo.approveDeposit(pendingDeposit.id, pendingDeposit.amountMinorUnits, session)
    assertFalse(res2.isSuccess)
    val countAfterRetry = notifRepo.observeNotifications().first().size
    assertEquals("Retrying approval must not create duplicate notifications", countAfterFirst, countAfterRetry)
  }

  @Test
  fun testWithdrawalApprovalCompletesSuccessfully() = runBlocking {
    val withdrawalsRepo = com.example.core.repository.FirebaseWithdrawalsRepository()
    val notifRepo = com.example.core.repository.FirebaseNotificationsRepository()
    val session = com.example.core.model.SuperAdminSession(
      uid = "admin_w_1",
      identifier = "admin@test.com",
      role = "Super Admin",
      isSuperAdminVerified = true
    )

    val withdrawals = withdrawalsRepo.observeWithdrawals().first()
    val pendingWithdrawal = withdrawals.first { it.status == com.example.core.model.WithdrawalStatus.PENDING }

    val res = withdrawalsRepo.approveWithdrawal(pendingWithdrawal.withdrawalId, session)
    assertTrue("Withdrawal approval should succeed", res.isSuccess)

    // Verify withdrawal status becomes COMPLETED
    val updatedWithdrawal = withdrawalsRepo.getWithdrawal(pendingWithdrawal.withdrawalId)
    assertNotNull(updatedWithdrawal)
    assertEquals("Withdrawal status must become COMPLETED", com.example.core.model.WithdrawalStatus.COMPLETED, updatedWithdrawal!!.status)

    // Verify notification created
    val notifs = notifRepo.observeNotifications().first()
    val userNotifs = notifs.filter { it.targetId == pendingWithdrawal.userId && (it.message.contains("approved") || it.title.contains("Approved")) }
    assertTrue("Approval notification should be created for user", userNotifs.isNotEmpty())
    assertEquals("TargetType should be SPECIFIC_USER", com.example.core.model.NotificationTargetType.SPECIFIC_USER.value, userNotifs.first().targetType)
  }

  @Test
  fun testWithdrawalApprovalDoesNotIncreaseAvailableBalance() = runBlocking {
    val withdrawalsRepo = com.example.core.repository.FirebaseWithdrawalsRepository()
    val session = com.example.core.model.SuperAdminSession(
      uid = "admin_w_1",
      identifier = "admin@test.com",
      role = "Super Admin",
      isSuperAdminVerified = true
    )

    val withdrawals = withdrawalsRepo.observeWithdrawals().first()
    val pendingWithdrawal = withdrawals.first { it.status == com.example.core.model.WithdrawalStatus.PENDING }

    val walletBefore = withdrawalsRepo.getUserWallet(pendingWithdrawal.userId)
    assertNotNull("Wallet must exist before approval", walletBefore)
    val availBefore = walletBefore!!.availableBalance
    val pendingBefore = walletBefore.pendingBalance

    val res = withdrawalsRepo.approveWithdrawal(pendingWithdrawal.withdrawalId, session)
    assertTrue("Approval must succeed", res.isSuccess)

    val walletAfter = withdrawalsRepo.getUserWallet(pendingWithdrawal.userId)
    assertNotNull("Wallet must exist after approval", walletAfter)
    val availAfter = walletAfter!!.availableBalance
    val pendingAfter = walletAfter.pendingBalance

    assertEquals("Approve must NOT increase or change available balance", availBefore, availAfter)
    assertTrue("Pending balance should decrease after approval", pendingAfter < pendingBefore)
  }

  @Test
  fun testWithdrawalApprovalCannotBePerformedTwice() = runBlocking {
    val withdrawalsRepo = com.example.core.repository.FirebaseWithdrawalsRepository()
    val session = com.example.core.model.SuperAdminSession(
      uid = "admin_w_1",
      identifier = "admin@test.com",
      role = "Super Admin",
      isSuperAdminVerified = true
    )

    val withdrawals = withdrawalsRepo.observeWithdrawals().first()
    val pendingWithdrawal = withdrawals.first { it.status == com.example.core.model.WithdrawalStatus.PENDING }

    // First approval
    val res1 = withdrawalsRepo.approveWithdrawal(pendingWithdrawal.withdrawalId, session)
    assertTrue("First approval should succeed", res1.isSuccess)

    // Second approval must fail (idempotency guard)
    val res2 = withdrawalsRepo.approveWithdrawal(pendingWithdrawal.withdrawalId, session)
    assertFalse("Second approval must fail", res2.isSuccess)
  }

  @Test
  fun testWithdrawalApprovalAndNotification() = runBlocking {
    val withdrawalsRepo = com.example.core.repository.FirebaseWithdrawalsRepository()
    val notifRepo = com.example.core.repository.FirebaseNotificationsRepository()
    val session = com.example.core.model.SuperAdminSession(
      uid = "admin_w_1",
      identifier = "admin@test.com",
      role = "Super Admin",
      isSuperAdminVerified = true
    )

    val withdrawals = withdrawalsRepo.observeWithdrawals().first()
    val pendingWithdrawal = withdrawals.firstOrNull { it.status == com.example.core.model.WithdrawalStatus.PENDING }
    if (pendingWithdrawal != null) {
      val res = withdrawalsRepo.approveWithdrawal(pendingWithdrawal.withdrawalId, session)
      assertTrue("Withdrawal approval should succeed", res.isSuccess)

      val notifs = notifRepo.observeNotifications().first()
      val userNotifs = notifs.filter { it.targetId == pendingWithdrawal.userId && (it.message.contains("approved") || it.title.contains("Approved")) }
      assertTrue("Approval notification should be created for user", userNotifs.isNotEmpty())
      assertEquals("TargetType should be SPECIFIC_USER", com.example.core.model.NotificationTargetType.SPECIFIC_USER.value, userNotifs.first().targetType)
    }
  }

  @Test
  fun testWithdrawalRejectionAndRefundNotification() = runBlocking {
    val withdrawalsRepo = com.example.core.repository.FirebaseWithdrawalsRepository(initialWithdrawals = emptyList())
    val notifRepo = com.example.core.repository.FirebaseNotificationsRepository()
    val session = com.example.core.model.SuperAdminSession(
      uid = "admin_w_1",
      identifier = "admin@test.com",
      role = "Super Admin",
      isSuperAdminVerified = true
    )

    val withdrawals = withdrawalsRepo.observeWithdrawals().first()
    val pendingWithdrawal = withdrawals.firstOrNull { it.status == com.example.core.model.WithdrawalStatus.PENDING }
    if (pendingWithdrawal != null) {
      val res = withdrawalsRepo.rejectWithdrawal(pendingWithdrawal.withdrawalId, "Invalid details", session)
      assertTrue("Withdrawal rejection should succeed", res.isSuccess)

      val notifs = notifRepo.observeNotifications().first()
      val userNotifs = notifs.filter { it.targetId == pendingWithdrawal.userId && it.message.contains("rejected") }
      assertTrue("Rejection notification should be created for user", userNotifs.isNotEmpty())
      assertEquals("TargetType should be SPECIFIC_USER", com.example.core.model.NotificationTargetType.SPECIFIC_USER.value, userNotifs.first().targetType)
    }
  }

  @Test
  fun testWithdrawalMinorUnitsToBdtFormatting() = runBlocking {
    val minorUnits = 20000L
    val formatted = com.example.core.model.TournamentMath.formatTaka(minorUnits)
    assertEquals("৳200", formatted)

    // 1. Prove Firebase amount 20000 -> ৳200
    val withdrawalItem = com.example.core.model.AdminWithdrawalItem(
      withdrawalId = "wth_test_200",
      userId = "user_test_1",
      amount = 200.0,
      amountMinorUnits = minorUnits,
      method = "bKash",
      recipientNumber = "01711000000",
      status = com.example.core.model.WithdrawalStatus.PENDING
    )
    assertEquals("৳200", withdrawalItem.formattedAmountTaka)

    // 2. Prove rawAmountMinor remains 20000, not 2,000,000
    // Test parsing manually using the exact WithdrawalsRepository logic:
    val testAmountVal = 20000L
    val rawAmountMinor = testAmountVal // matching snapshot child.child("amount") mapping:
    assertEquals(20000L, rawAmountMinor)
    val amountInTaka = rawAmountMinor / 100L
    assertEquals(200L, amountInTaka)

    // Mock a user wallet with 20000 minor units (৳200) in pending balance and 10000 (৳100) available balance
    val userId = "user_test_99"
    val testWallet = com.example.core.model.UserWalletData(
      userId = userId,
      balance = 30000L,
      availableBalance = 10000L,
      pendingBalance = 20000L,
      totalWithdrawn = 0L,
      updatedAt = System.currentTimeMillis()
    )

    val adminSession = com.example.core.model.SuperAdminSession(
      uid = "admin_test",
      identifier = "admin@platform.com",
      role = "Super Admin",
      isSuperAdminVerified = true
    )

    // 3. Prove Approve uses 20000 minor units for a ৳200 withdrawal (deducting exactly 20000 from pendingBalance)
    val appWithdrawalsRepo = com.example.core.repository.FirebaseWithdrawalsRepository(
      initialWithdrawals = listOf(withdrawalItem.copy(userId = userId)),
      initialWallets = mapOf(userId to testWallet)
    )

    val approveRes = appWithdrawalsRepo.approveWithdrawal("wth_test_200", adminSession)
    assertTrue("Approval should succeed", approveRes.isSuccess)

    val updatedWalletPostApprove = appWithdrawalsRepo.getUserWallet(userId)
    assertNotNull(updatedWalletPostApprove)
    assertEquals("Pending balance should be reduced by exactly 20000 minor units", 0L, updatedWalletPostApprove!!.pendingBalance)
    assertEquals("Total withdrawn should be exactly 20000 minor units", 20000L, updatedWalletPostApprove.totalWithdrawn)

    // 4. Prove Reject refund uses 20000 minor units for a ৳200 withdrawal (refunds exactly 20000 minor units to availableBalance)
    val rejectWithdrawalsRepo = com.example.core.repository.FirebaseWithdrawalsRepository(
      initialWithdrawals = listOf(withdrawalItem.copy(userId = userId)),
      initialWallets = mapOf(userId to testWallet)
    )

    val rejectRes = rejectWithdrawalsRepo.rejectWithdrawal("wth_test_200", "Testing reject", adminSession)
    assertTrue("Rejection should succeed", rejectRes.isSuccess)

    val updatedWalletPostReject = rejectWithdrawalsRepo.getUserWallet(userId)
    assertNotNull(updatedWalletPostReject)

    // 5. Prove a rejected ৳200 withdrawal refunds exactly 20000 minor units to available balance
    assertEquals("Pending balance should be reduced to 0", 0L, updatedWalletPostReject!!.pendingBalance)
    assertEquals("Available balance should be refunded exactly 20000 minor units (10000 + 20000 = 30000)", 30000L, updatedWalletPostReject.availableBalance)

    // 6. Prove no double refund
    val duplicateRejectRes = rejectWithdrawalsRepo.rejectWithdrawal("wth_test_200", "Testing double reject", adminSession)
    assertTrue("Duplicate rejection should fail because status is no longer actionable", duplicateRejectRes.isFailure)
    
    val walletPostDuplicateReject = rejectWithdrawalsRepo.getUserWallet(userId)
    assertNotNull(walletPostDuplicateReject)
    assertEquals("Available balance should remain exactly 30000 minor units", 30000L, walletPostDuplicateReject!!.availableBalance)
  }

  @Test
  fun testValidBase64DataUriAccepted() {
    // 1x1 transparent PNG data URI
    val validPngDataUri = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=="
    assertTrue("Should be recognized as Base64 image", com.example.core.util.ScreenshotImageUtils.isBase64Image(validPngDataUri))

    val payload = com.example.core.util.ScreenshotImageUtils.extractBase64Payload(validPngDataUri)
    assertNotNull("Payload must be extracted", payload)
    assertEquals("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==", payload)

    val bytes = com.example.core.util.ScreenshotImageUtils.decodeBase64ToBytes(validPngDataUri)
    assertNotNull("Bytes should be decoded successfully", bytes)
    assertTrue("Decoded bytes should not be empty", bytes!!.isNotEmpty())

    // AdminResultItem mapping
    val resultItem = com.example.core.model.AdminResultItem(
      resultId = "res_101",
      matchId = "match_101",
      proofScreenshotUrl = validPngDataUri
    )
    assertEquals(validPngDataUri, resultItem.proofScreenshotUrl)
    assertEquals(validPngDataUri, resultItem.effectiveScreenshotUrl)
    assertTrue(resultItem.hasScreenshot)
  }

  @Test
  fun testMissingScreenshotHandledSafely() {
    val emptyResult = com.example.core.model.AdminResultItem(
      resultId = "res_102",
      proofScreenshotUrl = ""
    )
    assertFalse("Empty screenshot should report hasScreenshot as false", emptyResult.hasScreenshot)
    assertEquals("", emptyResult.effectiveScreenshotUrl)

    assertFalse("Blank should not be base64", com.example.core.util.ScreenshotImageUtils.isBase64Image(""))
    assertFalse("Null should not be base64", com.example.core.util.ScreenshotImageUtils.isBase64Image(null))
    assertNull("Extracting blank should return null", com.example.core.util.ScreenshotImageUtils.extractBase64Payload(""))
    assertNull("Extracting null should return null", com.example.core.util.ScreenshotImageUtils.extractBase64Payload(null))
    assertNull("Decoding blank should return null", com.example.core.util.ScreenshotImageUtils.decodeBase64ToBytes(""))
    assertNull("Decoding null should return null", com.example.core.util.ScreenshotImageUtils.decodeBase64ToBytes(null))
    assertNull("Bitmap decoding blank should return null", com.example.core.util.ScreenshotImageUtils.decodeBase64ToBitmap(""))
    assertNull("Bitmap decoding null should return null", com.example.core.util.ScreenshotImageUtils.decodeBase64ToBitmap(null))
  }

  @Test
  fun testInvalidScreenshotHandledSafely() {
    val invalidDataUri = "data:image/jpeg;base64,not-valid-base64-content!@#$%"
    // Must not throw an unhandled exception
    val bytes = com.example.core.util.ScreenshotImageUtils.decodeBase64ToBytes(invalidDataUri)
    // Even if malformed, decode safely returns null or invalid image bytes
    val bitmap = com.example.core.util.ScreenshotImageUtils.decodeBase64ToBitmap(invalidDataUri)
    assertNull("Corrupt base64 data must safely yield null bitmap without crashing", bitmap)

    val randomGarbage = "random_unformatted_string_that_is_not_an_image"
    val garbageBitmap = com.example.core.util.ScreenshotImageUtils.decodeBase64ToBitmap(randomGarbage)
    assertNull("Garbage string must yield null bitmap without crashing", garbageBitmap)
  }
}
