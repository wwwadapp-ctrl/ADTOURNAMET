package com.example

import com.example.core.model.AdminMatchItem
import com.example.core.model.CreateMatchRequest
import com.example.core.model.MatchStatus
import com.example.core.model.SuperAdminSession
import com.example.core.repository.InMemoryMatchesRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testDeleteMatchPermanently() = runBlocking {
    val repo = InMemoryMatchesRepository()
    val superAdminSession = SuperAdminSession(
      uid = "GuIxwtI4hLQIoKOOt3V2XKnFhiB2",
      identifier = "superadmin@example.com",
      isSuperAdminVerified = true
    )

    // Create a match
    val createResult = repo.createSingleMatch(
      CreateMatchRequest(
        gameType = "LUDO",
        matchNumber = "TEST-999",
        title = "Test Elimination Fixture",
        entryFeeTaka = 50,
        scheduledTimestamp = System.currentTimeMillis() + 3600000L
      ),
      superAdminSession
    )
    assertTrue("Match creation should succeed", createResult.isSuccess)
    val matchId = createResult.getOrThrow()

    // Verify it is present in flow
    val matchesBefore = repo.observeMatches().first()
    assertTrue(matchesBefore.any { it.matchId == matchId })

    // Permanently delete match
    val deleteResult = repo.deleteMatchPermanently(matchId, superAdminSession)
    assertTrue("Delete match should succeed", deleteResult.isSuccess)

    // Verify it has been permanently removed
    val matchesAfter = repo.observeMatches().first()
    assertFalse("Deleted match should no longer be present", matchesAfter.any { it.matchId == matchId })
  }
}
