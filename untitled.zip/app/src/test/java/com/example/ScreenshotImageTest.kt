package com.example

import com.example.core.model.AdminResultItem
import com.example.core.model.ResultStatus
import com.example.core.model.SuperAdminSession
import com.example.core.model.TournamentMath
import com.example.core.model.UserWalletData
import com.example.core.repository.FirebaseResultsRepository
import com.example.core.util.ScreenshotImageUtils
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ScreenshotImageTest {

    // Valid 1x1 transparent PNG data URI
    private val validPngDataUri = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=="

    private val adminSession = SuperAdminSession(
        uid = "admin_super_test",
        identifier = "Super Admin (Test)",
        isSuperAdminVerified = true
    )

    @Test
    fun testValidBase64DataUriDecodesToBitmap() {
        val bitmap = ScreenshotImageUtils.decodeBase64ToBitmap(validPngDataUri)
        assertNotNull("Bitmap must decode successfully from valid Base64 data URI", bitmap)
        assertEquals(1, bitmap!!.width)
        assertEquals(1, bitmap.height)
    }

    @Test
    fun testResultModelBindsProofScreenshotUrlCorrectly() {
        val result = AdminResultItem(
            resultId = "res_test_99",
            matchId = "match_test_99",
            matchNumber = "#42",
            userName = "TestPlayer",
            proofScreenshotUrl = validPngDataUri,
            status = ResultStatus.PENDING
        )

        assertEquals(validPngDataUri, result.proofScreenshotUrl)
        assertEquals(validPngDataUri, result.effectiveScreenshotUrl)
        assertTrue(result.hasScreenshot)
        assertTrue(result.isPending)
    }

    @Test
    fun testMissingScreenshotHandledSafely() {
        val emptyItem = AdminResultItem(resultId = "res_test_empty")
        assertFalse(emptyItem.hasScreenshot)
        assertEquals("", emptyItem.effectiveScreenshotUrl)

        assertNull(ScreenshotImageUtils.decodeBase64ToBitmap(""))
        assertNull(ScreenshotImageUtils.decodeBase64ToBitmap("   "))
        assertNull(ScreenshotImageUtils.decodeBase64ToBitmap(null))
    }

    @Test
    fun testInvalidScreenshotHandledSafely() {
        val malformedDataUri = "data:image/jpeg;base64,this_is_not_valid_base64_image_data_!!!"
        val bitmap = ScreenshotImageUtils.decodeBase64ToBitmap(malformedDataUri)
        assertNull("Corrupt Base64 data must return null bitmap without crashing", bitmap)

        val nonImageDataUri = "data:image/png;base64,SGVsbG8gV29ybGQ=" // "Hello World" in base64 (not a valid image)
        val textBitmap = ScreenshotImageUtils.decodeBase64ToBitmap(nonImageDataUri)
        assertNull("Non-image base64 payload must return null bitmap without crashing", textBitmap)
    }

    @Test
    fun testApproveWinningProofCreditsPrizeToWinnerWalletAvailableBalanceAndRemovesScreenshot() = runBlocking {
        val userId = "usr_winner_123"
        val prizeTaka = 500L
        val prizeMinor = TournamentMath.takaToMinorUnits(prizeTaka) // 50000

        val initialWallet = UserWalletData(
            userId = userId,
            balance = 10000L, // 100 Taka
            availableBalance = 10000L,
            winningBalance = 0L
        )

        val pendingResult = AdminResultItem(
            resultId = "res_proof_101",
            matchId = "mtc_match_101",
            matchNumber = "#101",
            userId = userId,
            userName = "Pro Gamer",
            roomCode = "778899",
            proofScreenshotUrl = validPngDataUri,
            screenshotUrl = validPngDataUri,
            prizeMinorUnits = prizeMinor,
            prizeTaka = prizeTaka.toDouble(),
            status = ResultStatus.PENDING
        )

        val repository = FirebaseResultsRepository(
            initialResults = listOf(pendingResult),
            initialWallets = mapOf(userId to initialWallet)
        )

        // Approve the result
        val approveResult = repository.approveResult(
            resultId = "res_proof_101",
            submittedMatchNumber = "#101",
            submittedRoomCode = "778899",
            adminSession = adminSession
        )

        assertTrue("Approval should succeed", approveResult.isSuccess)

        // Verify Winner Wallet Available Balance is credited with the prize amount
        val updatedWallet = repository.getUserWallet(userId)
        assertNotNull(updatedWallet)
        assertEquals("Available balance must be credited with prizeMinorUnits (10000 + 50000)", 60000L, updatedWallet!!.availableBalance)
        assertEquals("Winning balance must be credited with prizeMinorUnits (0 + 50000)", 50000L, updatedWallet.winningBalance)
        assertEquals("Total balance must reflect updated available balance", 60000L, updatedWallet.balance)

        // Verify proofScreenshotUrl is removed/nulled on the result
        val updatedResult = repository.getResult("res_proof_101")
        assertNotNull(updatedResult)
        assertEquals("Status must be APPROVED", ResultStatus.APPROVED, updatedResult!!.status)
        assertEquals("proofScreenshotUrl must be cleared/empty", "", updatedResult.proofScreenshotUrl)
        assertEquals("screenshotUrl must be cleared/empty", "", updatedResult.screenshotUrl)
        assertFalse("hasScreenshot must be false after approval cleanup", updatedResult.hasScreenshot)

        // Verify duplicate approval is prevented and does NOT double-credit prize
        val secondApprove = repository.approveResult(
            resultId = "res_proof_101",
            submittedMatchNumber = "#101",
            submittedRoomCode = "778899",
            adminSession = adminSession
        )

        assertTrue("Duplicate approval must fail", secondApprove.isFailure)
        val walletAfterDuplicate = repository.getUserWallet(userId)
        assertEquals("Wallet balance must NOT be double credited", 60000L, walletAfterDuplicate!!.availableBalance)
    }

    @Test
    fun testRejectWinningProofRemovesScreenshotAndDoesNotCreditWallet() = runBlocking {
        val userId = "usr_player_456"
        val prizeMinor = TournamentMath.takaToMinorUnits(300L) // 30000

        val initialWallet = UserWalletData(
            userId = userId,
            balance = 20000L,
            availableBalance = 20000L,
            winningBalance = 0L
        )

        val pendingResult = AdminResultItem(
            resultId = "res_proof_202",
            matchId = "mtc_match_202",
            matchNumber = "#202",
            userId = userId,
            userName = "Player Two",
            roomCode = "112233",
            proofScreenshotUrl = validPngDataUri,
            prizeMinorUnits = prizeMinor,
            prizeTaka = 300.0,
            status = ResultStatus.PENDING
        )

        val repository = FirebaseResultsRepository(
            initialResults = listOf(pendingResult),
            initialWallets = mapOf(userId to initialWallet)
        )

        // Reject the result
        val rejectResult = repository.rejectResult(
            resultId = "res_proof_202",
            reason = "Scoreboard screenshot does not match match room code.",
            adminSession = adminSession
        )

        assertTrue("Reject must succeed", rejectResult.isSuccess)

        // Verify Wallet balance is unchanged
        val updatedWallet = repository.getUserWallet(userId)
        assertNotNull(updatedWallet)
        assertEquals("Available balance must remain untouched", 20000L, updatedWallet!!.availableBalance)
        assertEquals("Winning balance must remain untouched", 0L, updatedWallet.winningBalance)

        // Verify proofScreenshotUrl is removed/nulled on rejection
        val updatedResult = repository.getResult("res_proof_202")
        assertNotNull(updatedResult)
        assertEquals("Status must be REJECTED", ResultStatus.REJECTED, updatedResult!!.status)
        assertEquals("proofScreenshotUrl must be cleared/empty", "", updatedResult.proofScreenshotUrl)
        assertFalse("hasScreenshot must be false after rejection cleanup", updatedResult.hasScreenshot)
    }
}
