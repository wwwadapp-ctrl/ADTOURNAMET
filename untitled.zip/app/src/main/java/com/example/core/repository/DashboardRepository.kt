package com.example.core.repository

import com.example.core.config.FirebaseAdminConfig
import com.example.core.model.ActionRequiredSummary
import com.example.core.model.AdminActivityLogItem
import com.example.core.model.DashboardOverviewStats
import com.example.core.model.DashboardUiState
import com.example.core.model.MatchLifecycleStatus
import com.example.core.model.TodayMatchItem
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Interface for Dashboard data access.
 * Enforces strictly read-only aggregate telemetry without mutation capabilities.
 */
interface DashboardRepository {
    fun streamDashboardState(): Flow<DashboardUiState>
    suspend fun refresh()
}

/**
 * Production Firebase Realtime Database implementation.
 * Queries the authoritative AD TOURNAMENT RTDB at:
 * https://adturnamet-default-rtdb.asia-southeast1.firebasedatabase.app
 */
class FirebaseDashboardRepository : DashboardRepository {
    private val database: FirebaseDatabase? = try {
        FirebaseDatabase.getInstance(FirebaseAdminConfig.RTDB_BASE_URL)
    } catch (e: Exception) {
        null
    }

    override fun streamDashboardState(): Flow<DashboardUiState> {
        val db = database ?: return flowOf(
            DashboardUiState.Success(
                overviewStats = DashboardOverviewStats(),
                todayMatches = emptyList(),
                actionRequired = ActionRequiredSummary(),
                recentActivity = emptyList()
            )
        )

        val usersFlow = callbackFlow {
            val ref = db.getReference(FirebaseAdminConfig.NODE_USERS)
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    launch(Dispatchers.IO) {
                        var totalUsers = 0L
                        var blockedUsers = 0L
                        for (child in snapshot.children) {
                            totalUsers++
                            val isBlocked = child.child("blocked").getValue(Boolean::class.java) == true ||
                                    child.child("isBlocked").getValue(Boolean::class.java) == true ||
                                    child.child("status").getValue(String::class.java)?.equals("BLOCKED", ignoreCase = true) == true
                            if (isBlocked) {
                                blockedUsers++
                            }
                        }
                        trySend(Pair(totalUsers, blockedUsers))
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    trySend(Pair(0L, 0L))
                }
            }
            ref.addValueEventListener(listener)
            awaitClose { ref.removeEventListener(listener) }
        }

        val matchesFlow = callbackFlow {
            val ref = db.getReference(FirebaseAdminConfig.NODE_MATCHES)
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    var totalMatches = 0L
                    var availableMatches = 0L
                    var runningMatches = 0L
                    var resultPending = 0L
                    var fullMatchesNeedingCode = 0L
                    val todayMatchesList = mutableListOf<TodayMatchItem>()
                    val todayStart = Calendar.getInstance().apply {
                        set(Calendar.HOUR_OF_DAY, 0)
                        set(Calendar.MINUTE, 0)
                        set(Calendar.SECOND, 0)
                        set(Calendar.MILLISECOND, 0)
                    }.timeInMillis
                    val todayEnd = todayStart + (24 * 60 * 60 * 1000)

                    for (child in snapshot.children) {
                        totalMatches++
                        val id = child.key ?: ""
                        val matchNumber = child.child("matchNumber").value?.toString()
                            ?: child.child("match_number").value?.toString()
                            ?: "#${id.takeLast(4).uppercase()}"
                        val rawGame = child.child("gameType").getValue(String::class.java)
                            ?: child.child("game").getValue(String::class.java)
                            ?: "Ludo"
                        val gameType = if (rawGame.contains("carrom", ignoreCase = true)) "Carrom" else "Ludo"
                        val entryFee = (child.child("entryFee").value as? Number)?.toLong()
                            ?: (child.child("entry_fee").value as? Number)?.toLong()
                            ?: 0L
                        val prize = (child.child("prize").value as? Number)?.toLong()
                            ?: (child.child("prizePool").value as? Number)?.toLong()
                            ?: (child.child("prize_pool").value as? Number)?.toLong()
                            ?: 0L
                        val rawStatus = child.child("status").getValue(String::class.java)
                        val status = MatchLifecycleStatus.fromString(rawStatus)
                        val gameCode = child.child("gameCode").value?.toString()
                            ?: child.child("code").value?.toString()
                            ?: ""
                        val joined = (child.child("joinedPlayers").value as? Number)?.toInt()
                            ?: (child.child("joined").value as? Number)?.toInt()
                            ?: (child.child("currentPlayers").value as? Number)?.toInt()
                            ?: if (status == MatchLifecycleStatus.FULL) 2 else if (status == MatchLifecycleStatus.AVAILABLE) 1 else 0
                        val maxPlayers = (child.child("maxPlayers").value as? Number)?.toInt() ?: 2
                        val scheduledTimestamp = (child.child("scheduledTimestamp").value as? Number)?.toLong()
                            ?: (child.child("timestamp").value as? Number)?.toLong()
                            ?: 0L
                        val scheduledTime = child.child("scheduledTime").value?.toString()
                            ?: if (scheduledTimestamp > 0L) {
                                SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(scheduledTimestamp))
                            } else {
                                "Today"
                            }

                        when (status) {
                            MatchLifecycleStatus.AVAILABLE -> availableMatches++
                            MatchLifecycleStatus.RUNNING, MatchLifecycleStatus.CODE_ADDED -> runningMatches++
                            MatchLifecycleStatus.RESULT_SUBMITTED -> resultPending++
                            else -> Unit
                        }

                        val needsCode = (status == MatchLifecycleStatus.FULL || joined >= maxPlayers) &&
                                gameCode.isBlank() &&
                                status != MatchLifecycleStatus.CODE_ADDED &&
                                status != MatchLifecycleStatus.RUNNING &&
                                status != MatchLifecycleStatus.COMPLETED
                        if (needsCode) {
                            fullMatchesNeedingCode++
                        }

                        // Determine if match is scheduled for today
                        val isToday = if (scheduledTimestamp > 0L) {
                            scheduledTimestamp in todayStart..todayEnd
                        } else {
                            scheduledTime.contains("Today", ignoreCase = true) || status != MatchLifecycleStatus.COMPLETED
                        }

                        if (isToday) {
                            todayMatchesList.add(
                                TodayMatchItem(
                                    id = id,
                                    matchNumber = matchNumber,
                                    gameType = gameType,
                                    entryFee = entryFee,
                                    prize = prize,
                                    scheduledTime = scheduledTime,
                                    scheduledTimestamp = scheduledTimestamp,
                                    status = status,
                                    joinedCount = joined,
                                    maxPlayers = maxPlayers,
                                    gameCode = gameCode
                                )
                            )
                        }
                    }

                    trySend(
                        Triple(
                            totalMatches,
                            Triple(availableMatches, runningMatches, Pair(resultPending, fullMatchesNeedingCode)),
                            todayMatchesList.sortedByDescending { it.scheduledTimestamp }
                        )
                    )
                }

                override fun onCancelled(error: DatabaseError) {
                    trySend(Triple(0L, Triple(0L, 0L, Pair(0L, 0L)), emptyList()))
                }
            }
            ref.addValueEventListener(listener)
            awaitClose { ref.removeEventListener(listener) }
        }

        val depositsFlow = callbackFlow {
            val ref = db.getReference(FirebaseAdminConfig.NODE_DEPOSITS)
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    var pendingCount = 0L
                    for (child in snapshot.children) {
                        val status = child.child("status").getValue(String::class.java)
                        if (status != null && status.equals("PENDING", ignoreCase = true)) {
                            pendingCount++
                        }
                    }
                    trySend(pendingCount)
                }

                override fun onCancelled(error: DatabaseError) {
                    trySend(0L)
                }
            }
            ref.addValueEventListener(listener)
            awaitClose { ref.removeEventListener(listener) }
        }

        val withdrawalsFlow = callbackFlow {
            val ref = db.getReference(FirebaseAdminConfig.NODE_WITHDRAWALS)
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    var pendingCount = 0L
                    for (child in snapshot.children) {
                        val status = child.child("status").getValue(String::class.java)
                        if (status != null && status.equals("PENDING", ignoreCase = true)) {
                            pendingCount++
                        }
                    }
                    trySend(pendingCount)
                }

                override fun onCancelled(error: DatabaseError) {
                    trySend(0L)
                }
            }
            ref.addValueEventListener(listener)
            awaitClose { ref.removeEventListener(listener) }
        }

        val resultsFlow = callbackFlow {
            val ref = db.getReference(FirebaseAdminConfig.NODE_RESULTS)
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    var pendingCount = 0L
                    for (child in snapshot.children) {
                        val directStatus = child.child("status").getValue(String::class.java)
                        if (directStatus != null) {
                            // Legacy flat structure: /results/{resultId}
                            if (directStatus.equals("SUBMITTED", ignoreCase = true) || directStatus.equals("PENDING", ignoreCase = true)) {
                                pendingCount++
                            }
                        } else {
                            // Nested structure: /results/{matchId}/{userId}
                            for (userChild in child.children) {
                                val nestedStatus = userChild.child("status").getValue(String::class.java)
                                if (nestedStatus != null && (nestedStatus.equals("SUBMITTED", ignoreCase = true) || nestedStatus.equals("PENDING", ignoreCase = true))) {
                                    pendingCount++
                                }
                            }
                        }
                    }
                    trySend(pendingCount)
                }

                override fun onCancelled(error: DatabaseError) {
                    trySend(0L)
                }
            }
            ref.addValueEventListener(listener)
            awaitClose { ref.removeEventListener(listener) }
        }

        val auditLogsFlow = callbackFlow {
            val ref = db.getReference(FirebaseAdminConfig.NODE_AUDIT_LOGS).limitToLast(20)
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val list = mutableListOf<AdminActivityLogItem>()
                    for (child in snapshot.children) {
                        val id = child.key ?: ""
                        val action = child.child("action").getValue(String::class.java) ?: "Admin Action"
                        val admin = child.child("admin").getValue(String::class.java) ?: "Super Admin"
                        val referenceId = child.child("referenceId").getValue(String::class.java)
                            ?: child.child("refId").getValue(String::class.java)
                            ?: "#${id.takeLast(6).uppercase()}"
                        val timestamp = (child.child("timestamp").value as? Number)?.toLong() ?: 0L
                        val time = child.child("time").value?.toString()
                            ?: if (timestamp > 0L) {
                                SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(timestamp))
                            } else {
                                "Recent"
                            }
                        list.add(
                            AdminActivityLogItem(
                                id = id,
                                action = action,
                                time = time,
                                timestamp = timestamp,
                                admin = admin,
                                referenceId = referenceId
                            )
                        )
                    }
                    trySend(list.sortedByDescending { it.timestamp })
                }

                override fun onCancelled(error: DatabaseError) {
                    trySend(emptyList())
                }
            }
            ref.addValueEventListener(listener)
            awaitClose { ref.removeEventListener(listener) }
        }

        return combine(
            usersFlow,
            matchesFlow,
            depositsFlow,
            withdrawalsFlow,
            resultsFlow
        ) { usersPair, matchesTriple, pendingDeposits, pendingWithdrawals, pendingResultsNode ->
            val (totalUsers, blockedUsers) = usersPair
            val (totalMatches, secondaryMatches, todayMatches) = matchesTriple
            val (availableMatches, runningMatches, matchResultAndNeedsCode) = secondaryMatches
            val (resultPendingFromMatches, fullMatchesNeedingCode) = matchResultAndNeedsCode
            val pendingResultsCount = if (pendingResultsNode > 0L) pendingResultsNode else resultPendingFromMatches

            val overviewStats = DashboardOverviewStats(
                totalUsers = totalUsers,
                totalMatches = totalMatches,
                pendingDeposits = pendingDeposits,
                pendingWithdrawals = pendingWithdrawals,
                availableMatches = availableMatches,
                runningMatches = runningMatches,
                resultPending = pendingResultsCount,
                blockedUsers = blockedUsers
            )
            val actionRequired = ActionRequiredSummary(
                pendingDepositsCount = pendingDeposits,
                pendingWithdrawalsCount = pendingWithdrawals,
                pendingResultsCount = pendingResultsCount,
                fullMatchesNeedingCodeCount = fullMatchesNeedingCode
            )
            Pair(overviewStats, Pair(todayMatches, actionRequired))
        }.combine(auditLogsFlow) { statsAndMatches, activityList ->
            val overviewStats = statsAndMatches.first
            val todayMatches = statsAndMatches.second.first
            val actionRequired = statsAndMatches.second.second
            DashboardUiState.Success(
                overviewStats = overviewStats,
                todayMatches = todayMatches,
                actionRequired = actionRequired,
                recentActivity = activityList
            )
        }
    }

    override suspend fun refresh() {
        // Realtime Database listeners automatically update live
    }
}

/**
 * In-memory test repository for Robolectric and Unit testing.
 */
class TestDashboardRepository : DashboardRepository {
    val stateFlow = MutableStateFlow<DashboardUiState>(DashboardUiState.Loading)

    override fun streamDashboardState(): Flow<DashboardUiState> = stateFlow

    override suspend fun refresh() {
        // No-op for testing
    }

    fun emitLoading() {
        stateFlow.value = DashboardUiState.Loading
    }

    fun emitSuccess(
        overviewStats: DashboardOverviewStats = DashboardOverviewStats(),
        todayMatches: List<TodayMatchItem> = emptyList(),
        actionRequired: ActionRequiredSummary = ActionRequiredSummary(),
        recentActivity: List<AdminActivityLogItem> = emptyList()
    ) {
        stateFlow.value = DashboardUiState.Success(
            overviewStats = overviewStats,
            todayMatches = todayMatches,
            actionRequired = actionRequired,
            recentActivity = recentActivity
        )
    }

    fun emitError(message: String) {
        stateFlow.value = DashboardUiState.Error(message)
    }
}
