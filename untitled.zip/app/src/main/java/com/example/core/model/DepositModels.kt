package com.example.core.model

/**
 * Lifecycle status of player deposit requests.
 */
enum class DepositStatus(val label: String) {
    PENDING("PENDING"),
    APPROVED("APPROVED"),
    REJECTED("REJECTED");

    val banglaLabel: String
        get() = when (this) {
            PENDING -> "অপেক্ষমাণ"
            APPROVED -> "অনুমোদিত"
            REJECTED -> "প্রত্যাখ্যাত"
        }

    companion object {
        fun fromString(raw: String?): DepositStatus {
            val normalized = raw?.trim()?.uppercase() ?: return PENDING
            return when {
                normalized.contains("APPROV") -> APPROVED
                normalized.contains("REJECT") -> REJECTED
                else -> PENDING
            }
        }
    }
}

/**
 * Domain entity representing a player deposit request submitted to the tournament platform.
 */
data class AdminDepositItem(
    val id: String = "",
    val userId: String = "",
    val userName: String = "",
    val userPhone: String = "",
    val amountTaka: Double = 0.0,
    val amountMinorUnits: Long = 0L,
    val transactionId: String = "",
    val paymentMethod: String = "bKash", // bKash, Nagad, Rocket
    val senderNumber: String = "",
    val receiverNumber: String = "",
    val status: DepositStatus = DepositStatus.PENDING,
    val createdAt: Long = 0L,
    val processedAt: Long? = null,
    val processedBy: String? = null,
    val rejectionReason: String? = null
) {
    val formattedAmount: String
        get() = TournamentMath.formatTakaAmount(amountTaka)

    val formattedMinorUnits: String
        get() = TournamentMath.formatTaka(amountMinorUnits)

    val isPending: Boolean
        get() = status == DepositStatus.PENDING

    val isApproved: Boolean
        get() = status == DepositStatus.APPROVED

    val isRejected: Boolean
        get() = status == DepositStatus.REJECTED
}

/**
 * Summary metrics for deposit queue management.
 */
data class DepositSummary(
    val pendingCount: Int = 0,
    val approvedCount: Int = 0,
    val rejectedCount: Int = 0,
    val totalPendingAmountTaka: Double = 0.0,
    val totalApprovedAmountTaka: Double = 0.0
)

/**
 * Wallet entity credited directly during deposit approval and updated during withdrawal settlement.
 * The Long minor-unit fields (in paisa) are authoritative.
 */
data class UserWalletData(
    val userId: String = "",
    val balance: Long = 0L,
    val availableBalance: Long = 0L,
    val depositBalance: Long = 0L,
    val winningBalance: Long = 0L,
    val pendingBalance: Long = 0L,
    val totalDeposited: Long = 0L,
    val totalWithdrawn: Long = 0L,
    val balanceDouble: Double = 0.0,
    val lockedBalanceDouble: Double = 0.0,
    val activeWithdrawals: Map<String, ActiveWithdrawalReservation> = emptyMap(),
    val updatedAt: Long = 0L
)
