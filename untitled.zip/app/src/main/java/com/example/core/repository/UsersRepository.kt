package com.example.core.repository

import com.example.core.config.FirebaseAdminConfig
import com.example.core.model.AdminUserItem
import com.example.core.model.SuperAdminSession
import com.example.core.model.TournamentMath
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.UUID

/**
 * Interface for observing registered users and managing player account governance (Ban/Unban).
 */
interface UsersRepository {
    fun observeUsers(): Flow<List<AdminUserItem>>
    suspend fun toggleUserBan(
        uid: String,
        shouldBan: Boolean,
        reason: String,
        adminSession: SuperAdminSession
    ): Result<Unit>
}

/**
 * Production Firebase Realtime Database implementation for /users and /auditLogs.
 */
class FirebaseUsersRepository : UsersRepository {
    private val database: FirebaseDatabase? = try {
        FirebaseDatabase.getInstance(FirebaseAdminConfig.RTDB_BASE_URL)
    } catch (e: Exception) {
        null
    }

    // Curated high-fidelity seed players for offline / initial development
    private val defaultSeedUsers = listOf(
        AdminUserItem(
            uid = "usr_tanvir_9812",
            name = "Tanvir Hasan",
            phone = "01712984561",
            email = "tanvir.esports@gmail.com",
            isBanned = false,
            status = "ACTIVE",
            balanceMinor = TournamentMath.takaToMinorUnits(750),
            depositBalanceMinor = TournamentMath.takaToMinorUnits(300),
            winningBalanceMinor = TournamentMath.takaToMinorUnits(450),
            matchesPlayed = 24,
            matchesWon = 18,
            joinedAt = System.currentTimeMillis() - (15L * 86400000L),
            deviceModel = "Samsung Galaxy S23 Ultra"
        ),
        AdminUserItem(
            uid = "usr_shakib_4412",
            name = "Shakib Rahman",
            phone = "01823490123",
            email = "shakib.gaming@yahoo.com",
            isBanned = false,
            status = "ACTIVE",
            balanceMinor = TournamentMath.takaToMinorUnits(1200),
            depositBalanceMinor = TournamentMath.takaToMinorUnits(500),
            winningBalanceMinor = TournamentMath.takaToMinorUnits(700),
            matchesPlayed = 42,
            matchesWon = 29,
            joinedAt = System.currentTimeMillis() - (28L * 86400000L),
            deviceModel = "Xiaomi Redmi Note 12 Pro"
        ),
        AdminUserItem(
            uid = "usr_mehedi_7731",
            name = "Mehedi Miraz",
            phone = "01944567890",
            email = "miraz.gamer99@gmail.com",
            isBanned = true,
            status = "BANNED",
            balanceMinor = TournamentMath.takaToMinorUnits(150),
            depositBalanceMinor = TournamentMath.takaToMinorUnits(150),
            winningBalanceMinor = 0L,
            matchesPlayed = 8,
            matchesWon = 2,
            joinedAt = System.currentTimeMillis() - (40L * 86400000L),
            banReason = "Suspicious duplicate app emulator usage during 1v1 match",
            bannedAt = System.currentTimeMillis() - (2L * 86400000L),
            deviceModel = "Realme GT Master Edition"
        ),
        AdminUserItem(
            uid = "usr_fahim_3321",
            name = "Fahim Ahmed",
            phone = "01678123456",
            email = "fahim.ludo.pro@outlook.com",
            isBanned = false,
            status = "ACTIVE",
            balanceMinor = TournamentMath.takaToMinorUnits(420),
            depositBalanceMinor = TournamentMath.takaToMinorUnits(100),
            winningBalanceMinor = TournamentMath.takaToMinorUnits(320),
            matchesPlayed = 19,
            matchesWon = 11,
            joinedAt = System.currentTimeMillis() - (10L * 86400000L),
            deviceModel = "OnePlus 11R 5G"
        ),
        AdminUserItem(
            uid = "usr_rakib_5589",
            name = "Rakib Hossain",
            phone = "01309876543",
            email = "rakib_bd@gmail.com",
            isBanned = false,
            status = "ACTIVE",
            balanceMinor = TournamentMath.takaToMinorUnits(2400),
            depositBalanceMinor = TournamentMath.takaToMinorUnits(1000),
            winningBalanceMinor = TournamentMath.takaToMinorUnits(1400),
            matchesPlayed = 65,
            matchesWon = 48,
            joinedAt = System.currentTimeMillis() - (60L * 86400000L),
            deviceModel = "Vivo V27 5G"
        )
    )

    private val localUsersState = MutableStateFlow(defaultSeedUsers)

    private fun verifySuperAdmin(adminSession: SuperAdminSession) {
        if (!adminSession.isSuperAdminVerified || adminSession.uid.isBlank()) {
            throw SecurityException("Unauthorized: User governance operations require verified Super Admin session.")
        }
    }

    override fun observeUsers(): Flow<List<AdminUserItem>> {
        val db = database ?: return localUsersState.asStateFlow()

        return callbackFlow {
            val ref = db.getReference(FirebaseAdminConfig.NODE_USERS)
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val parsedUsers = mutableListOf<AdminUserItem>()

                    for (child in snapshot.children) {
                        val uid = child.key ?: child.child("uid").value?.toString() ?: ""
                        if (uid.isBlank()) continue

                        val name = child.child("name").value?.toString()
                            ?: child.child("displayName").value?.toString()
                            ?: child.child("fullName").value?.toString()
                            ?: child.child("username").value?.toString()
                            ?: ""

                        val phone = child.child("phone").value?.toString()
                            ?: child.child("phoneNumber").value?.toString()
                            ?: child.child("mobile").value?.toString()
                            ?: ""

                        val email = child.child("email").value?.toString() ?: ""

                        val rawStatus = child.child("status").value?.toString()
                        val isBlockedFlag = child.child("blocked").getValue(Boolean::class.java) == true ||
                                child.child("isBlocked").getValue(Boolean::class.java) == true

                        val isBanned = isBlockedFlag || rawStatus?.equals("BANNED", ignoreCase = true) == true ||
                                rawStatus?.equals("BLOCKED", ignoreCase = true) == true

                        val status = if (isBanned) "BANNED" else "ACTIVE"

                        // Authoritative balance extraction (stored in minor units / paisa)
                        val balanceMinor = (child.child("balance").value as? Number)?.toLong()
                            ?: (child.child("walletBalance").value as? Number)?.toLong()
                            ?: 0L

                        val depositMinor = (child.child("depositBalance").value as? Number)?.toLong()
                            ?: (child.child("deposits").value as? Number)?.toLong()
                            ?: (balanceMinor / 2)

                        val winningMinor = (child.child("winningBalance").value as? Number)?.toLong()
                            ?: (child.child("winnings").value as? Number)?.toLong()
                            ?: maxOf(0L, balanceMinor - depositMinor)

                        val matchesCount = (child.child("matchesPlayed").value as? Number)?.toInt()
                            ?: (child.child("totalMatches").value as? Number)?.toInt()
                            ?: 0

                        val matchesWon = (child.child("matchesWon").value as? Number)?.toInt()
                            ?: 0

                        val joinedAt = (child.child("createdAt").value as? Number)?.toLong()
                            ?: (child.child("joinedAt").value as? Number)?.toLong()
                            ?: 0L

                        val banReason = child.child("banReason").value?.toString() ?: ""
                        val bannedAt = (child.child("bannedAt").value as? Number)?.toLong() ?: 0L
                        val device = child.child("deviceInfo").value?.toString()
                            ?: child.child("deviceModel").value?.toString()
                            ?: "Android Device"

                        parsedUsers.add(
                            AdminUserItem(
                                uid = uid,
                                name = name,
                                phone = phone,
                                email = email,
                                isBanned = isBanned,
                                status = status,
                                balanceMinor = balanceMinor,
                                depositBalanceMinor = depositMinor,
                                winningBalanceMinor = winningMinor,
                                matchesPlayed = matchesCount,
                                matchesWon = matchesWon,
                                joinedAt = joinedAt,
                                banReason = banReason,
                                bannedAt = bannedAt,
                                deviceModel = device
                            )
                        )
                    }

                    if (parsedUsers.isEmpty()) {
                        trySend(localUsersState.value)
                    } else {
                        localUsersState.value = parsedUsers
                        trySend(parsedUsers)
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    trySend(localUsersState.value)
                }
            }
            ref.addValueEventListener(listener)
            awaitClose { ref.removeEventListener(listener) }
        }
    }

    override suspend fun toggleUserBan(
        uid: String,
        shouldBan: Boolean,
        reason: String,
        adminSession: SuperAdminSession
    ): Result<Unit> = runCatching {
        verifySuperAdmin(adminSession)
        require(uid.isNotBlank()) { "Target User UID cannot be empty." }

        val now = System.currentTimeMillis()
        val logId = UUID.randomUUID().toString()
        val actionName = if (shouldBan) "USER_BANNED" else "USER_UNBANNED"
        val statusString = if (shouldBan) "BANNED" else "ACTIVE"

        val db = database
        if (db != null) {
            val updates = hashMapOf<String, Any?>(
                "${FirebaseAdminConfig.NODE_USERS}/$uid/status" to statusString,
                "${FirebaseAdminConfig.NODE_USERS}/$uid/isBlocked" to shouldBan,
                "${FirebaseAdminConfig.NODE_USERS}/$uid/blocked" to shouldBan,
                "${FirebaseAdminConfig.NODE_USERS}/$uid/banReason" to if (shouldBan) reason.ifBlank { "Violation of tournament policy" } else null,
                "${FirebaseAdminConfig.NODE_USERS}/$uid/bannedAt" to if (shouldBan) now else null,
                "${FirebaseAdminConfig.NODE_USERS}/$uid/updatedAt" to now,
                "${FirebaseAdminConfig.NODE_AUDIT_LOGS}/$logId" to hashMapOf(
                    "action" to actionName,
                    "admin" to adminSession.identifier,
                    "referenceId" to uid,
                    "timestamp" to now,
                    "reason" to if (shouldBan) "Account suspended by Super Admin: ${reason.ifBlank { "Policy enforcement" }}" else "Account unbanned and restored by Super Admin"
                )
            )
            db.reference.updateChildren(updates).await()
        }

        // Synchronize in-memory representation
        val currentList = localUsersState.value.toMutableList()
        val index = currentList.indexOfFirst { it.uid == uid }
        if (index >= 0) {
            val target = currentList[index]
            currentList[index] = target.copy(
                isBanned = shouldBan,
                status = statusString,
                banReason = if (shouldBan) reason.ifBlank { "Violation of tournament policy" } else "",
                bannedAt = if (shouldBan) now else 0L
            )
            localUsersState.value = currentList
        }
    }
}
