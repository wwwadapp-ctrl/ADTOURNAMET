package com.example.core.repository

import com.example.core.config.FirebaseAdminConfig
import com.example.core.model.AdminNotificationItem
import com.example.core.model.NotificationTargetType
import com.example.core.model.SuperAdminSession
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.UUID

/**
 * Interface for managing persistent notifications and broadcasting messages.
 */
interface NotificationsRepository {
    fun observeNotifications(): Flow<List<AdminNotificationItem>>
    suspend fun sendNotification(
        title: String,
        message: String,
        targetType: NotificationTargetType,
        targetId: String,
        adminSession: SuperAdminSession
    ): Result<String>
    suspend fun deleteNotification(notificationId: String, adminSession: SuperAdminSession): Result<Unit>
}

/**
 * Firebase Realtime Database repository for /notifications.
 */
class FirebaseNotificationsRepository(
    private val initialNotifications: List<AdminNotificationItem>? = null
) : NotificationsRepository {
    private val database: FirebaseDatabase? = try {
        FirebaseDatabase.getInstance(FirebaseAdminConfig.RTDB_BASE_URL)
    } catch (e: Exception) {
        null
    }

    companion object {
        private val sharedMemoryCache = MutableStateFlow<List<AdminNotificationItem>>(emptyList())
    }

    private val memoryCache = MutableStateFlow(initialNotifications ?: emptyList())

    override fun observeNotifications(): Flow<List<AdminNotificationItem>> {
        val db = database
        if (db == null) {
            if (initialNotifications != null && initialNotifications.isNotEmpty() && sharedMemoryCache.value.isEmpty()) {
                sharedMemoryCache.value = initialNotifications
            }
            return sharedMemoryCache
        }

        return callbackFlow {
            val ref = db.getReference(FirebaseAdminConfig.NODE_NOTIFICATIONS)
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val list = mutableListOf<AdminNotificationItem>()
                    for (child in snapshot.children) {
                        val id = child.child("id").value?.toString() ?: child.key ?: UUID.randomUUID().toString()
                        val title = child.child("title").value?.toString() ?: ""
                        val message = child.child("message").value?.toString() ?: ""
                        val timestamp = child.child("timestamp").value?.toString()?.toLongOrNull() ?: System.currentTimeMillis()
                        val targetType = child.child("targetType").value?.toString() ?: NotificationTargetType.ALL_USERS.value
                        val targetId = child.child("targetId").value?.toString() ?: "ALL"
                        val senderAdmin = child.child("senderAdmin").value?.toString() ?: ""

                        list.add(
                            AdminNotificationItem(
                                id = id,
                                title = title,
                                message = message,
                                timestamp = timestamp,
                                targetType = targetType,
                                targetId = targetId,
                                senderAdmin = senderAdmin
                            )
                        )
                    }
                    list.sortByDescending { it.timestamp }
                    memoryCache.value = list
                    trySend(list)
                }

                override fun onCancelled(error: DatabaseError) {
                    trySend(memoryCache.value)
                }
            }

            ref.addValueEventListener(listener)
            awaitClose { ref.removeEventListener(listener) }
        }
    }

    override suspend fun sendNotification(
        title: String,
        message: String,
        targetType: NotificationTargetType,
        targetId: String,
        adminSession: SuperAdminSession
    ): Result<String> {
        val cleanTitle = title.trim()
        val cleanMessage = message.trim()
        val cleanTargetId = targetId.trim()

        if (cleanTitle.isEmpty()) {
            return Result.failure(IllegalArgumentException("Notification title cannot be empty."))
        }
        if (cleanMessage.isEmpty()) {
            return Result.failure(IllegalArgumentException("Notification message cannot be empty."))
        }
        if (cleanTargetId.isEmpty()) {
            return Result.failure(IllegalArgumentException("Target identifier cannot be empty."))
        }

        val notificationId = "notif_" + UUID.randomUUID().toString().replace("-", "").take(16)
        val timestamp = System.currentTimeMillis()
        val senderAdmin = adminSession.uid.ifBlank { "super_admin" }

        val notificationItem = AdminNotificationItem(
            id = notificationId,
            title = cleanTitle,
            message = cleanMessage,
            timestamp = timestamp,
            targetType = targetType.value,
            targetId = cleanTargetId,
            senderAdmin = senderAdmin
        )

        val db = database
        if (db == null) {
            val updated = mutableListOf(notificationItem)
            updated.addAll(sharedMemoryCache.value)
            sharedMemoryCache.value = updated
            return Result.success(notificationId)
        }

        return try {
            val multiLocationUpdates = mutableMapOf<String, Any?>()

            // 1. Authoritative global notification record at /notifications/{notificationId}
            val globalRecord = mapOf(
                "id" to notificationItem.id,
                "notificationId" to notificationItem.id,
                "title" to notificationItem.title,
                "message" to notificationItem.message,
                "body" to notificationItem.message,
                "timestamp" to notificationItem.timestamp,
                "createdAt" to notificationItem.timestamp,
                "targetType" to notificationItem.targetType,
                "targetId" to notificationItem.targetId,
                "senderAdmin" to notificationItem.senderAdmin
            )
            multiLocationUpdates["${FirebaseAdminConfig.NODE_NOTIFICATIONS}/$notificationId"] = globalRecord

            // 2. User-specific notification inbox record at /userNotifications/{userId}/{notificationId}
            if (targetType == NotificationTargetType.SPECIFIC_USER && cleanTargetId.isNotBlank() && cleanTargetId != "ALL") {
                val userInboxRecord = mapOf(
                    "notificationId" to notificationId,
                    "id" to notificationId,
                    "userId" to cleanTargetId,
                    "title" to cleanTitle,
                    "body" to cleanMessage,
                    "message" to cleanMessage,
                    "targetScreen" to "NOTIFICATIONS",
                    "isRead" to false,
                    "createdAt" to timestamp,
                    "timestamp" to timestamp,
                    "type" to "SPECIFIC_USER",
                    "targetType" to targetType.value,
                    "targetId" to cleanTargetId,
                    "senderAdmin" to senderAdmin
                )
                multiLocationUpdates["${FirebaseAdminConfig.NODE_USER_NOTIFICATIONS}/$cleanTargetId/$notificationId"] = userInboxRecord
            }

            // 3. Immutable audit log record
            val auditPushKey = db.getReference(FirebaseAdminConfig.NODE_AUDIT_LOGS).push().key ?: UUID.randomUUID().toString()
            multiLocationUpdates["${FirebaseAdminConfig.NODE_AUDIT_LOGS}/$auditPushKey"] = mapOf(
                "action" to "SEND_NOTIFICATION",
                "notificationId" to notificationId,
                "targetType" to targetType.value,
                "targetId" to cleanTargetId,
                "adminUid" to senderAdmin,
                "timestamp" to timestamp
            )

            // Perform atomic multi-path update across /notifications, /userNotifications, and /auditLogs
            db.reference.updateChildren(multiLocationUpdates).await()

            Result.success(notificationId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun deleteNotification(notificationId: String, adminSession: SuperAdminSession): Result<Unit> {
        if (notificationId.isBlank()) {
            return Result.failure(IllegalArgumentException("Invalid notification ID."))
        }
        val db = database
        if (db == null) {
            memoryCache.value = memoryCache.value.filter { it.id != notificationId }
            return Result.success(Unit)
        }

        return try {
            db.getReference(FirebaseAdminConfig.NODE_NOTIFICATIONS).child(notificationId).removeValue().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
