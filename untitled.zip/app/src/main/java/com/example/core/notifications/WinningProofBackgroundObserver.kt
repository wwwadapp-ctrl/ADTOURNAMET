package com.example.core.notifications

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import com.example.core.repository.FirebaseResultsRepository
import com.example.core.repository.ResultsRepository
import kotlinx.coroutines.flow.collectLatest

@Composable
fun WinningProofBackgroundObserver(
    repository: ResultsRepository = FirebaseResultsRepository()
) {
    val context = LocalContext.current

    // Android 13+ (API 33) requires runtime permission for notifications.
    // If not granted, we skip background notification observation safely to prevent crashes.
    val hasNotificationPermission = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
        androidx.core.content.ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.POST_NOTIFICATIONS
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
    } else {
        true
    }

    LaunchedEffect(Unit) {
        if (!hasNotificationPermission) return@LaunchedEffect

        try {
            repository.observeResults().collectLatest { results ->
                val pendingProofs = results.filter { it.isPending }
                for (proof in pendingProofs) {
                    WinningProofNotificationHelper.showWinningProofNotification(context, proof)
                }
            }
        } catch (e: Exception) {
            // Silently catch and log issues with background observation
            android.util.Log.e("WinningProofObserver", "Background observation failed: ${e.message}")
        }
    }
}
