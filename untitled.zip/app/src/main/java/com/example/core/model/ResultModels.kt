package com.example.core.model

/**
 * Lifecycle status of player result submissions.
 */
enum class ResultStatus(val label: String) {
    PENDING("PENDING"),
    APPROVED("APPROVED"),
    REJECTED("REJECTED"),
    CONFLICT("CONFLICT");

    val banglaLabel: String
        get() = when (this) {
            PENDING -> "পর্যালোচনা বাকি"
            APPROVED -> "অনুমোদিত"
            REJECTED -> "প্রত্যাখ্যাত"
            CONFLICT -> "দ্বন্দ্বে আছে"
        }

    companion object {
        fun fromString(raw: String?): ResultStatus {
            val normalized = raw?.trim()?.uppercase() ?: return PENDING
            return when {
                normalized.contains("APPROV") || normalized.contains("SETTLED") || normalized.contains("COMPLET") -> APPROVED
                normalized.contains("REJECT") -> REJECTED
                normalized.contains("CONFLICT") -> CONFLICT
                else -> PENDING
            }
        }
    }
}

/**
 * Domain entity for Admin Result / Winning Screenshot items matching the User App result schema.
 * Reads from authoritative nodes: /results and /userResults/{userId}/{resultId}.
 */
data class AdminResultItem(
    val resultId: String = "",
    val matchId: String = "",
    val matchNumber: String = "",
    val gameType: String = "LUDO", // "LUDO" or "CARROM"
    val userId: String = "",
    val userName: String = "",
    val userPhone: String = "",
    val roomCode: String = "",
    val proofScreenshotUrl: String = "",
    val screenshotUrl: String = proofScreenshotUrl,
    val prizeMinorUnits: Long = 0L,
    val prizeTaka: Long = 0L,
    val status: ResultStatus = ResultStatus.PENDING,
    val rawStatus: String = "",
    val createdAt: Long = 0L,
    val processedAt: Long? = null,
    val processedBy: String? = null,
    val rejectionReason: String? = null,
    val settlementTransactionId: String = "",
    val isNested: Boolean = false
) {
    val isPending: Boolean
        get() = status == ResultStatus.PENDING

    val isApproved: Boolean
        get() = status == ResultStatus.APPROVED

    val isRejected: Boolean
        get() = status == ResultStatus.REJECTED

    val formattedPrize: String
        get() = if (prizeMinorUnits > 0L) {
            TournamentMath.formatTaka(prizeMinorUnits)
        } else {
            TournamentMath.formatTakaAmount(prizeTaka)
        }

    val hasScreenshot: Boolean
        get() = proofScreenshotUrl.isNotBlank() || screenshotUrl.isNotBlank()

    val effectiveScreenshotUrl: String
        get() = proofScreenshotUrl.ifBlank { screenshotUrl }
}
