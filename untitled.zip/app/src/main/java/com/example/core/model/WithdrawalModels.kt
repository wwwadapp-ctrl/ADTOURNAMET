package com.example.core.model

/**
 * Lifecycle status of player withdrawal requests.
 */
enum class WithdrawalStatus(val label: String) {
    REQUESTED("REQUESTED"),
    PENDING("PENDING"),
    COMPLETED("COMPLETED"),
    REJECTED("REJECTED");

    val banglaLabel: String
        get() = when (this) {
            REQUESTED, PENDING -> "অপেক্ষমাণ"
            COMPLETED -> "সম্পন্ন"
            REJECTED -> "প্রত্যাখ্যাত"
        }

    companion object {
        fun fromString(raw: String?): WithdrawalStatus {
            val normalized = raw?.trim()?.uppercase() ?: return REQUESTED
            return when {
                normalized.contains("COMPLET") || normalized.contains("APPROV") -> COMPLETED
                normalized.contains("REJECT") -> REJECTED
                normalized.contains("PENDING") -> PENDING
                else -> REQUESTED
            }
        }
    }
}

/**
 * Domain entity representing a player withdrawal request submitted to the platform.
 * Reads existing User App withdrawal schema:
 * /withdrawals/{withdrawalId} & /userWithdrawals/{userId}/{withdrawalId}
 */
data class AdminWithdrawalItem(
    val withdrawalId: String = "",
    val userId: String = "",
    val amount: Double = 0.0,
    val amountMinorUnits: Long = 0L,
    val method: String = "bKash", // bKash, Nagad, Rocket
    val recipientNumber: String = "",
    val status: WithdrawalStatus = WithdrawalStatus.REQUESTED,
    val createdAt: Long = 0L,
    val processedAt: Long? = null,
    val rejectionReason: String? = null,
    val adminUid: String? = null,
    val transactionId: String = ""
) {
    val isActionable: Boolean
        get() = status == WithdrawalStatus.REQUESTED || status == WithdrawalStatus.PENDING

    val isCompleted: Boolean
        get() = status == WithdrawalStatus.COMPLETED

    val isRejected: Boolean
        get() = status == WithdrawalStatus.REJECTED

    val formattedAmountTaka: String
        get() = if (amountMinorUnits > 0L) {
            TournamentMath.formatTaka(amountMinorUnits)
        } else {
            TournamentMath.formatTakaAmount(amount)
        }
}

/**
 * Active withdrawal reservation stored inside player's wallet:
 * /wallets/{userId}/activeWithdrawals/{withdrawalId}
 */
data class ActiveWithdrawalReservation(
    val withdrawalId: String = "",
    val amountMinorUnits: Long = 0L,
    val status: String = "REQUESTED",
    val transactionId: String = "",
    val createdAt: Long = 0L
)
