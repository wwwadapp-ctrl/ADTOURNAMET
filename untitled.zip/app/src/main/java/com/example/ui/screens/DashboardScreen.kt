package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.PlaylistAdd
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.AssignmentTurnedIn
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.core.config.FirebaseAdminConfig
import com.example.core.model.ActionRequiredSummary
import com.example.core.model.AdminActivityLogItem
import com.example.core.model.DashboardOverviewStats
import com.example.core.model.DashboardUiState
import com.example.core.model.MatchLifecycleStatus
import com.example.core.model.TodayMatchItem
import com.example.navigation.AdminSection
import com.example.ui.components.AdminCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.SuperAdminBadge
import com.example.ui.theme.CyanLight
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.NavyBorder
import com.example.ui.theme.NavyBorderLight
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyDeepest
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavySurfaceElevated
import com.example.ui.theme.StatusLive
import com.example.ui.theme.StatusPending
import com.example.ui.theme.StatusRejected
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun DashboardScreen(
    onNavigateToSection: (AdminSection) -> Unit,
    modifier: Modifier = Modifier,
    viewModel: DashboardViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("dashboard_screen")
    ) {
        // Top Header
        SectionHeader(
            title = "Dashboard",
            subtitle = "AD TOURNAMENT authoritative administrative overview",
            badgeText = "SUPER ADMIN CONSOLE",
            icon = AdminSection.DASHBOARD.icon
        )

        // Super Admin Authority Hero Card
        AdminCard(
            borderColor = GoldPrimary.copy(alpha = 0.6f),
            backgroundColor = NavySurface
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0x22FFC837)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = "Super Admin Authority",
                                tint = GoldPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "AD TOURNAMENT ADMIN",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            )
                            Text(
                                text = "Authoritative Realtime Database Console",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = TextSecondary
                                )
                            )
                        }
                    }
                    SuperAdminBadge()
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(NavySurfaceElevated)
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(StatusLive)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "${FirebaseAdminConfig.FIREBASE_PROJECT_ID} • ${FirebaseAdminConfig.RTDB_REGION}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = CyanSecondary,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                    }

                    Text(
                        text = "LIVE TELEMETRY",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = GoldLight,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        when (val state = uiState) {
            is DashboardUiState.Loading -> {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(280.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(NavySurface)
                        .border(1.dp, NavyBorder, RoundedCornerShape(14.dp))
                        .testTag("dashboard_loading"),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(
                            color = GoldPrimary,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Syncing authoritative RTDB telemetry...",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = TextSecondary,
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }
                }
            }

            is DashboardUiState.Error -> {
                AdminCard(
                    borderColor = StatusRejected.copy(alpha = 0.5f),
                    backgroundColor = NavySurface
                ) {
                    Column(
                        modifier = Modifier
                            .padding(20.dp)
                            .testTag("dashboard_error"),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Error",
                            tint = StatusRejected,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = state.message,
                            style = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { viewModel.refresh() },
                            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = "Retry", tint = NavyDeepest)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Retry Sync", color = NavyDeepest, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            is DashboardUiState.Success -> {
                // 1. OVERVIEW STATS (Primary)
                DashboardPrimaryStatsSection(stats = state.overviewStats)

                Spacer(modifier = Modifier.height(12.dp))

                // 2. OVERVIEW STATS (Secondary)
                DashboardSecondaryStatsSection(stats = state.overviewStats)

                Spacer(modifier = Modifier.height(16.dp))

                // 3. ACTION REQUIRED
                DashboardActionRequiredSection(
                    actionRequired = state.actionRequired,
                    onNavigateToSection = onNavigateToSection
                )

                Spacer(modifier = Modifier.height(16.dp))

                // 4. QUICK ACTIONS
                DashboardQuickActionsSection(onNavigateToSection = onNavigateToSection)

                Spacer(modifier = Modifier.height(16.dp))

                // 5. TODAY'S MATCHES
                DashboardTodayMatchesSection(
                    matches = state.todayMatches,
                    onViewAllMatches = { onNavigateToSection(AdminSection.MATCHES) }
                )

                Spacer(modifier = Modifier.height(16.dp))

                // 6. RECENT ADMIN ACTIVITY
                DashboardRecentActivitySection(
                    activityList = state.recentActivity,
                    onViewAllLogs = { onNavigateToSection(AdminSection.AUDIT_LOGS) }
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun DashboardPrimaryStatsSection(stats: DashboardOverviewStats) {
    Text(
        text = "OVERVIEW STATISTICS",
        style = MaterialTheme.typography.labelSmall.copy(
            color = GoldPrimary,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.2.sp
        ),
        modifier = Modifier.padding(bottom = 8.dp)
    )

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        PrimaryStatCard(
            title = "Total Users",
            value = stats.totalUsers.toString(),
            icon = Icons.Default.People,
            accentColor = CyanSecondary,
            testTag = "stat_total_users",
            modifier = Modifier.weight(1f)
        )
        PrimaryStatCard(
            title = "Total Matches",
            value = stats.totalMatches.toString(),
            icon = Icons.Default.SportsEsports,
            accentColor = GoldPrimary,
            testTag = "stat_total_matches",
            modifier = Modifier.weight(1f)
        )
    }

    Spacer(modifier = Modifier.height(10.dp))

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        PrimaryStatCard(
            title = "Pending Deposits",
            value = stats.pendingDeposits.toString(),
            icon = Icons.Default.Payments,
            accentColor = if (stats.pendingDeposits > 0L) StatusPending else TextSecondary,
            testTag = "stat_pending_deposits",
            modifier = Modifier.weight(1f)
        )
        PrimaryStatCard(
            title = "Pending Withdrawals",
            value = stats.pendingWithdrawals.toString(),
            icon = Icons.Default.History,
            accentColor = if (stats.pendingWithdrawals > 0L) StatusRejected else TextSecondary,
            testTag = "stat_pending_withdrawals",
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun PrimaryStatCard(
    title: String,
    value: String,
    icon: ImageVector,
    accentColor: Color,
    testTag: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(NavySurface)
            .border(1.dp, NavyBorder, RoundedCornerShape(12.dp))
            .padding(14.dp)
            .testTag(testTag)
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = TextSecondary,
                        fontWeight = FontWeight.Medium
                    )
                )
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(accentColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = accentColor,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = value,
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            )
        }
    }
}

@Composable
private fun DashboardSecondaryStatsSection(stats: DashboardOverviewStats) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        SecondaryStatChip(
            label = "Available",
            count = stats.availableMatches,
            icon = Icons.Default.ConfirmationNumber,
            color = CyanLight,
            testTag = "stat_available_matches"
        )
        SecondaryStatChip(
            label = "Running",
            count = stats.runningMatches,
            icon = Icons.AutoMirrored.Filled.TrendingUp,
            color = StatusLive,
            testTag = "stat_running_matches"
        )
        SecondaryStatChip(
            label = "Result Pending",
            count = stats.resultPending,
            icon = Icons.Default.HourglassTop,
            color = StatusPending,
            testTag = "stat_result_pending"
        )
        SecondaryStatChip(
            label = "Blocked Users",
            count = stats.blockedUsers,
            icon = Icons.Default.Block,
            color = StatusRejected,
            testTag = "stat_blocked_users"
        )
    }
}

@Composable
private fun SecondaryStatChip(
    label: String,
    count: Long,
    icon: ImageVector,
    color: Color,
    testTag: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(NavySurfaceElevated)
            .border(1.dp, NavyBorderLight, RoundedCornerShape(20.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .testTag(testTag)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = color,
            modifier = Modifier.size(14.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = "$label: ",
            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
        )
        Text(
            text = count.toString(),
            style = MaterialTheme.typography.bodySmall.copy(
                fontWeight = FontWeight.Bold,
                color = color
            )
        )
    }
}

@Composable
private fun DashboardActionRequiredSection(
    actionRequired: ActionRequiredSummary,
    onNavigateToSection: (AdminSection) -> Unit
) {
    Column {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "ACTION REQUIRED",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = GoldPrimary,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    )
                )
                if (actionRequired.hasPendingActions) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(StatusPending.copy(alpha = 0.2f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "${actionRequired.totalPendingActions} PENDING",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = StatusPending,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (!actionRequired.hasPendingActions) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(NavySurface)
                    .border(1.dp, NavyBorder, RoundedCornerShape(12.dp))
                    .padding(16.dp)
                    .testTag("action_required_empty"),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "No Pending Actions",
                        tint = StatusLive,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "No pending actions requiring attention",
                        style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                    )
                }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (actionRequired.pendingDepositsCount > 0L) {
                    ActionRequiredRow(
                        title = "Deposits Awaiting Approval",
                        count = actionRequired.pendingDepositsCount,
                        urgencyColor = StatusPending,
                        testTag = "action_deposits_pending",
                        onActionClick = { onNavigateToSection(AdminSection.DEPOSITS) }
                    )
                }
                if (actionRequired.pendingWithdrawalsCount > 0L) {
                    ActionRequiredRow(
                        title = "Withdrawals Awaiting Review",
                        count = actionRequired.pendingWithdrawalsCount,
                        urgencyColor = StatusRejected,
                        testTag = "action_withdrawals_pending",
                        onActionClick = { onNavigateToSection(AdminSection.WITHDRAWALS) }
                    )
                }
                if (actionRequired.pendingResultsCount > 0L) {
                    ActionRequiredRow(
                        title = "Results Awaiting Verification",
                        count = actionRequired.pendingResultsCount,
                        urgencyColor = CyanSecondary,
                        testTag = "action_results_pending",
                        onActionClick = { onNavigateToSection(AdminSection.RESULTS) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ActionRequiredRow(
    title: String,
    count: Long,
    urgencyColor: Color,
    testTag: String,
    onActionClick: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(NavySurface)
            .border(1.dp, urgencyColor.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
            .clickable(onClick = onActionClick)
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag(testTag)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(urgencyColor)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary
                )
            )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = count.toString(),
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = urgencyColor
                )
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "View",
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = GoldLight
                )
            )
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = "View",
                tint = GoldLight,
                modifier = Modifier.size(14.dp)
            )
        }
    }
}

@Composable
private fun DashboardQuickActionsSection(onNavigateToSection: (AdminSection) -> Unit) {
    Column {
        Text(
            text = "QUICK ACTIONS",
            style = MaterialTheme.typography.labelSmall.copy(
                color = GoldPrimary,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp
            ),
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            QuickActionButton(
                label = "CREATE MATCH",
                icon = Icons.Default.AddCircleOutline,
                accentColor = GoldPrimary,
                testTag = "quick_action_create_match",
                modifier = Modifier.weight(1f),
                onClick = { onNavigateToSection(AdminSection.MATCHES) }
            )
            QuickActionButton(
                label = "BULK MATCHES",
                icon = Icons.AutoMirrored.Filled.PlaylistAdd,
                accentColor = CyanSecondary,
                testTag = "quick_action_create_bulk_matches",
                modifier = Modifier.weight(1f),
                onClick = { onNavigateToSection(AdminSection.MATCHES) }
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            QuickActionButton(
                label = "RESULTS",
                icon = Icons.Default.AssignmentTurnedIn,
                accentColor = CyanLight,
                testTag = "quick_action_results",
                modifier = Modifier.weight(1f),
                onClick = { onNavigateToSection(AdminSection.RESULTS) }
            )
            QuickActionButton(
                label = "DEPOSITS",
                icon = Icons.Default.Payments,
                accentColor = GoldLight,
                testTag = "quick_action_deposits",
                modifier = Modifier.weight(1f),
                onClick = { onNavigateToSection(AdminSection.DEPOSITS) }
            )
            QuickActionButton(
                label = "WITHDRAWALS",
                icon = Icons.Default.History,
                accentColor = StatusRejected,
                testTag = "quick_action_withdrawals",
                modifier = Modifier.weight(1f),
                onClick = { onNavigateToSection(AdminSection.WITHDRAWALS) }
            )
            QuickActionButton(
                label = "USERS",
                icon = Icons.Default.People,
                accentColor = TextSecondary,
                testTag = "quick_action_users",
                modifier = Modifier.weight(1f),
                onClick = { onNavigateToSection(AdminSection.USERS) }
            )
        }
    }
}

@Composable
private fun QuickActionButton(
    label: String,
    icon: ImageVector,
    accentColor: Color,
    testTag: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(NavySurface)
            .border(1.dp, NavyBorder, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp, horizontal = 8.dp)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = accentColor,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    fontSize = 10.sp
                ),
                maxLines = 1
            )
        }
    }
}

@Composable
private fun DashboardTodayMatchesSection(
    matches: List<TodayMatchItem>,
    onViewAllMatches: () -> Unit
) {
    Column {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "TODAY'S MATCHES",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = GoldPrimary,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                )
            )
            Text(
                text = "View All",
                style = MaterialTheme.typography.labelMedium.copy(
                    color = CyanSecondary,
                    fontWeight = FontWeight.SemiBold
                ),
                modifier = Modifier
                    .clickable(onClick = onViewAllMatches)
                    .padding(4.dp)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (matches.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(NavySurface)
                    .border(1.dp, NavyBorder, RoundedCornerShape(12.dp))
                    .padding(20.dp)
                    .testTag("matches_empty_state"),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.SportsEsports,
                        contentDescription = "No Matches",
                        tint = TextMuted,
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "No matches scheduled for today",
                        style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                    )
                }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                matches.take(5).forEach { match ->
                    TodayMatchCard(match = match)
                }
            }
        }
    }
}

@Composable
private fun TodayMatchCard(match: TodayMatchItem) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(NavySurface)
            .border(1.dp, NavyBorder, RoundedCornerShape(12.dp))
            .padding(14.dp)
            .testTag("match_item_${match.id}")
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = match.matchNumber,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = GoldPrimary
                        )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(NavySurfaceElevated)
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = match.gameType,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                        )
                    }
                }

                MatchLifecycleBadge(status = match.status)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Column {
                        Text("Entry Fee", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
                        Text("৳${match.entryFee}", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = TextPrimary))
                    }
                    Column {
                        Text("Prize", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
                        Text("৳${match.prize}", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = GoldLight))
                    }
                    Column {
                        Text("Joined", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
                        Text(match.joinedFraction, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = CyanLight))
                    }
                }

                Text(
                    text = match.scheduledTime,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = TextSecondary,
                        fontWeight = FontWeight.Medium
                    )
                )
            }
        }
    }
}

@Composable
private fun MatchLifecycleBadge(status: MatchLifecycleStatus) {
    val (bgColor, textColor) = when (status) {
        MatchLifecycleStatus.AVAILABLE -> Pair(CyanSecondary.copy(alpha = 0.2f), CyanLight)
        MatchLifecycleStatus.FULL -> Pair(GoldPrimary.copy(alpha = 0.2f), GoldLight)
        MatchLifecycleStatus.CODE_ADDED -> Pair(Color(0x33A855F7), Color(0xFFC084FC))
        MatchLifecycleStatus.RUNNING -> Pair(StatusLive.copy(alpha = 0.2f), StatusLive)
        MatchLifecycleStatus.RESULT_SUBMITTED -> Pair(StatusPending.copy(alpha = 0.2f), StatusPending)
        MatchLifecycleStatus.COMPLETED -> Pair(NavyBorder, TextMuted)
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(bgColor)
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .testTag("status_badge_${status.name}")
    ) {
        Text(
            text = status.label,
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = textColor,
                fontSize = 10.sp
            )
        )
    }
}

@Composable
private fun DashboardRecentActivitySection(
    activityList: List<AdminActivityLogItem>,
    onViewAllLogs: () -> Unit
) {
    Column {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "RECENT ADMIN ACTIVITY",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = GoldPrimary,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                )
            )
            Text(
                text = "View All",
                style = MaterialTheme.typography.labelMedium.copy(
                    color = CyanSecondary,
                    fontWeight = FontWeight.SemiBold
                ),
                modifier = Modifier
                    .clickable(onClick = onViewAllLogs)
                    .padding(4.dp)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (activityList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(NavySurface)
                    .border(1.dp, NavyBorder, RoundedCornerShape(12.dp))
                    .padding(20.dp)
                    .testTag("activity_empty_state"),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = "No Activity",
                        tint = TextMuted,
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "No recent activity",
                        style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                    )
                }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                activityList.take(5).forEach { item ->
                    ActivityItemRow(item = item)
                }
            }
        }
    }
}

@Composable
private fun ActivityItemRow(item: AdminActivityLogItem) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(NavySurface)
            .border(1.dp, NavyBorder, RoundedCornerShape(10.dp))
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .testTag("activity_item_${item.id}")
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(GoldPrimary)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = item.action,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                    )
                )
                Text(
                    text = "${item.admin} • ${item.referenceId}",
                    style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                )
            }
        }

        Text(
            text = item.time,
            style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
        )
    }
}
