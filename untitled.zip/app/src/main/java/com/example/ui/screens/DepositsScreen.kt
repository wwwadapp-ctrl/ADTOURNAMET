package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.navigation.AdminSection
import com.example.ui.components.SectionHeader
import com.example.ui.components.SectionShellHeroCard
import com.example.ui.components.SecurityLockNotice
import com.example.ui.components.StructuralQueueCard

@Composable
fun DepositsScreen(
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        SectionHeader(
            title = AdminSection.DEPOSITS.title,
            subtitle = AdminSection.DEPOSITS.subtitle,
            icon = AdminSection.DEPOSITS.icon
        )

        SectionShellHeroCard(
            section = AdminSection.DEPOSITS,
            statusText = "BKASH / NAGAD / ROCKET LEDGER"
        )

        SecurityLockNotice(
            title = "Authoritative Deposit Verification",
            description = "Manual and gateway deposits are verified against transaction TrxID. Balance updates are executed authoritatively on the backend."
        )

        StructuralQueueCard(
            title = "Deposit Verification Queue",
            items = listOf(
                "TrxID: 9X7B88210A (bKash ৳500)" to "Pending Review",
                "TrxID: 4M2K91823B (Nagad ৳1,000)" to "Pending Review",
                "TrxID: 7L5N11029C (Rocket ৳300)" to "Pending Review"
            ),
            badgeLabel = "GATEWAY INGESTION"
        )

        Spacer(modifier = Modifier.height(20.dp))
    }
}
