package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.navigation.AdminSection
import com.example.ui.components.SectionHeader
import com.example.ui.components.SectionShellHeroCard
import com.example.ui.components.SecurityLockNotice
import com.example.ui.components.StructuralQueueCard

@Composable
fun UsersScreen(
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        SectionHeader(
            title = AdminSection.USERS.title,
            subtitle = AdminSection.USERS.subtitle,
            icon = AdminSection.USERS.icon
        )

        SectionShellHeroCard(
            section = AdminSection.USERS,
            statusText = "PLAYER DIRECTORY & GOVERNANCE"
        )

        SecurityLockNotice(
            title = "Strict User Governance & Anti-Fraud",
            description = "Player account suspension, hardware device ban, and KYC compliance are audited here. Player balances remain strictly managed by authoritative rules."
        )

        StructuralQueueCard(
            title = "User Directory & Access Status",
            items = listOf(
                "Active Registered Accounts" to "Synced via /users",
                "Flagged Accounts (Suspicious Activity)" to "0 Accounts Flagged",
                "Blocked Accounts (Policy Enforcement)" to "Guarded via /admins"
            ),
            badgeLabel = "ROSTER SUMMARY"
        )

        Spacer(modifier = Modifier.height(20.dp))
    }
}
