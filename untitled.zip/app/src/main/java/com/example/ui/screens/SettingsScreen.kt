package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.core.config.FirebaseAdminConfig
import com.example.navigation.AdminSection
import com.example.ui.components.SectionHeader
import com.example.ui.components.SectionShellHeroCard
import com.example.ui.components.SecurityLockNotice
import com.example.ui.components.StructuralQueueCard

@Composable
fun SettingsScreen(
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        SectionHeader(
            title = AdminSection.SETTINGS.title,
            subtitle = AdminSection.SETTINGS.subtitle,
            icon = AdminSection.SETTINGS.icon
        )

        SectionShellHeroCard(
            section = AdminSection.SETTINGS,
            statusText = "ENVIRONMENT & INTEGRATIONS"
        )

        SecurityLockNotice(
            title = "Firebase Production Configuration",
            description = "The Admin app is directly bound to the production Firebase Project '${FirebaseAdminConfig.FIREBASE_PROJECT_ID}' in region '${FirebaseAdminConfig.RTDB_REGION}'."
        )

        StructuralQueueCard(
            title = "Connected Infrastructure",
            items = listOf(
                "Firebase Project ID" to FirebaseAdminConfig.FIREBASE_PROJECT_ID,
                "RTDB Instance URL" to FirebaseAdminConfig.RTDB_BASE_URL.take(35) + "...",
                "Database Region" to FirebaseAdminConfig.RTDB_REGION,
                "Super Admin UID" to FirebaseAdminConfig.FALLBACK_SUPER_ADMIN_UID.take(12) + "...",
                "Client Wallet Mutations" to "STRICTLY DISABLED (Backend Only)"
            ),
            badgeLabel = "SYSTEM ARCHITECTURE"
        )

        Spacer(modifier = Modifier.height(20.dp))
    }
}
