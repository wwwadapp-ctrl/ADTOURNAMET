package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.navigation.AdminSection
import com.example.ui.components.SectionHeader
import com.example.ui.components.SectionShellHeroCard
import com.example.ui.components.SecurityLockNotice
import com.example.ui.components.StructuralQueueCard

@Composable
fun NotificationsScreen(
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        SectionHeader(
            title = AdminSection.NOTIFICATIONS.title,
            subtitle = AdminSection.NOTIFICATIONS.subtitle,
            icon = AdminSection.NOTIFICATIONS.icon
        )

        SectionShellHeroCard(
            section = AdminSection.NOTIFICATIONS,
            statusText = "FCM BROADCAST HUB"
        )

        SecurityLockNotice(
            title = "Platform-Wide Push Broadcasts",
            description = "Send tournament commencement alerts, maintenance warnings, and payout notifications directly to user devices using Firebase Cloud Messaging."
        )

        StructuralQueueCard(
            title = "Scheduled & Recent Broadcasts",
            items = listOf(
                "Weekend Ludo 1v1 Championship Announcement" to "Sent to All Players",
                "Scheduled Maintenance Warning (02:00 AM)" to "Ready in Queue",
                "Instant Room Code Broadcast Alert" to "Automated Trigger"
            ),
            badgeLabel = "BROADCAST PIPELINE"
        )

        Spacer(modifier = Modifier.height(20.dp))
    }
}
