package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.rememberAsyncImagePainter
import com.example.core.model.AdminResultItem
import com.example.core.model.ResultStatus
import com.example.core.model.TournamentMath
import com.example.navigation.AdminSection
import com.example.ui.components.SectionHeader
import com.example.ui.components.ScreenshotUnavailablePlaceholder
import com.example.ui.components.WinningProofImageView
import com.example.ui.components.ZoomableWinningProofImageView

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResultsScreen(
    viewModel: ResultsViewModel = androidx.lifecycle.viewmodel.compose.viewModel(),
    initialFocusResultId: String? = null,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val processingIds by viewModel.processingResultIds.collectAsStateWithLifecycle()
    val feedbackMessage by viewModel.feedbackMessage.collectAsStateWithLifecycle()
    val errorMessage by viewModel.errorMessage.collectAsStateWithLifecycle()

    val isDetailsOpen by viewModel.isDetailsModalOpen.collectAsStateWithLifecycle()
    val selectedResult by viewModel.selectedResultForDetails.collectAsStateWithLifecycle()

    val isFullImageOpen by viewModel.isFullImageModalOpen.collectAsStateWithLifecycle()
    val fullImageUrl by viewModel.selectedResultForFullImage.collectAsStateWithLifecycle()

    val isApproveConfirmOpen by viewModel.isApproveConfirmOpen.collectAsStateWithLifecycle()
    val isRejectConfirmOpen by viewModel.isRejectConfirmOpen.collectAsStateWithLifecycle()
    val rejectReasonInput by viewModel.rejectReasonInput.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(initialFocusResultId) {
        if (!initialFocusResultId.isNullOrBlank()) {
            viewModel.setPendingFocusResultId(initialFocusResultId)
        }
    }

    LaunchedEffect(uiState) {
        viewModel.checkAndFocusResult()
    }

    LaunchedEffect(feedbackMessage, errorMessage) {
        feedbackMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.dismissFeedback()
        }
        errorMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.dismissFeedback()
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                SectionHeader(
                    title = AdminSection.RESULTS.title,
                    subtitle = AdminSection.RESULTS.subtitle,
                    icon = AdminSection.RESULTS.icon
                )
                Spacer(modifier = Modifier.height(12.dp))

                // Search Bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = viewModel::onSearchQueryChanged,
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Search by Match #, Room Code, Player...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                    trailingIcon = {
                        if (searchQuery.isNotBlank()) {
                            IconButton(onClick = { viewModel.onSearchQueryChanged("") }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear Search")
                            }
                        }
                    },
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Tabs Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    when (val state = uiState) {
                        is ResultsUiState.Success -> {
                            FilterTabButton(
                                title = "PENDING",
                                count = state.pendingCount,
                                isSelected = selectedTab == "PENDING",
                                onClick = { viewModel.onTabChanged("PENDING") },
                                modifier = Modifier.weight(1f)
                            )
                            FilterTabButton(
                                title = "APPROVED",
                                count = state.approvedCount,
                                isSelected = selectedTab == "APPROVED",
                                onClick = { viewModel.onTabChanged("APPROVED") },
                                modifier = Modifier.weight(1f)
                            )
                            FilterTabButton(
                                title = "REJECTED",
                                count = state.rejectedCount,
                                isSelected = selectedTab == "REJECTED",
                                onClick = { viewModel.onTabChanged("REJECTED") },
                                modifier = Modifier.weight(1f)
                            )
                            FilterTabButton(
                                title = "ALL",
                                count = state.allResults.size,
                                isSelected = selectedTab == "ALL",
                                onClick = { viewModel.onTabChanged("ALL") },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        else -> {
                            FilterTabButton(
                                title = "PENDING",
                                count = 0,
                                isSelected = selectedTab == "PENDING",
                                onClick = { viewModel.onTabChanged("PENDING") },
                                modifier = Modifier.weight(1f)
                            )
                            FilterTabButton(
                                title = "ALL",
                                count = 0,
                                isSelected = selectedTab == "ALL",
                                onClick = { viewModel.onTabChanged("ALL") },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (val state = uiState) {
                is ResultsUiState.Loading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
                is ResultsUiState.Error -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(text = state.message, color = MaterialTheme.colorScheme.error)
                    }
                }
                is ResultsUiState.Success -> {
                    if (state.filteredResults.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    Icons.Default.DoneAll,
                                    contentDescription = null,
                                    modifier = Modifier.size(64.dp),
                                    tint = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "No result submissions found for '$selectedTab'",
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingHorizontal16Vertical12(),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(state.filteredResults, key = { it.resultId }) { result ->
                                ResultItemCard(
                                    result = result,
                                    isProcessing = processingIds.contains(result.resultId),
                                    onInspectClick = { viewModel.openDetailsModal(result) },
                                    onImageClick = { url -> viewModel.openFullImageModal(url) },
                                    onApproveClick = { viewModel.openApproveConfirm(result) },
                                    onRejectClick = { viewModel.openRejectConfirm(result) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Details / Approval Review Modal
    if (isDetailsOpen && selectedResult != null) {
        val res = selectedResult!!
        ResultDetailsModal(
            result = res,
            isProcessing = processingIds.contains(res.resultId),
            onDismiss = viewModel::closeDetailsModal,
            onImageClick = { url -> viewModel.openFullImageModal(url) },
            onApprove = { viewModel.openApproveConfirm(res) },
            onReject = { viewModel.openRejectConfirm(res) }
        )
    }

    // Full Screen Image Viewer Dialog
    if (isFullImageOpen && !fullImageUrl.isNullOrBlank()) {
        Dialog(
            onDismissRequest = viewModel::closeFullImageModal,
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.95f)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Winning Proof Full View",
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        IconButton(onClick = viewModel::closeFullImageModal) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        ZoomableWinningProofImageView(
                            screenshotDataOrUrl = fullImageUrl!!,
                            modifier = Modifier.fillMaxSize(),
                            contentDescription = "Full Size Winning Screenshot Proof"
                        )
                    }

                    Button(
                        onClick = viewModel::closeFullImageModal,
                        modifier = Modifier.padding(vertical = 16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text("Close Full Screen")
                    }
                }
            }
        }
    }

    // Approve Confirmation Dialog
    if (isApproveConfirmOpen && selectedResult != null) {
        val res = selectedResult!!
        AlertDialog(
            onDismissRequest = viewModel::closeApproveConfirm,
            title = { Text("Approve Match Result & Credit Prize?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    val displayName = res.userName.ifBlank { res.userId.ifBlank { "Player" } }
                    val displaySub = res.userPhone.ifBlank { res.userId }
                    Text("Match Number: ${res.matchNumber} (${res.gameType})")
                    Text("Winner: $displayName${if (displaySub.isNotBlank() && displaySub != displayName) " ($displaySub)" else if (displaySub.isNotBlank()) " ($displaySub)" else ""}")
                    Text("Prize Payout: ${res.formattedPrize}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Approving this result will atomically credit the winner's wallet and mark the match completed.")
                }
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.approveResult(res) },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text("Confirm & Credit")
                }
            },
            dismissButton = {
                TextButton(onClick = viewModel::closeApproveConfirm) {
                    Text("Cancel")
                }
            }
        )
    }

    // Reject Confirmation Dialog
    if (isRejectConfirmOpen && selectedResult != null) {
        val res = selectedResult!!
        AlertDialog(
            onDismissRequest = viewModel::closeRejectConfirm,
            title = { Text("Reject Result Submission") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Rejecting result for match ${res.matchNumber} submitted by ${res.userName}.")
                    OutlinedTextField(
                        value = rejectReasonInput,
                        onValueChange = viewModel::onRejectReasonChanged,
                        label = { Text("Rejection Reason *") },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("e.g. Invalid room code or forged screenshot") },
                        maxLines = 3
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.rejectResult(res, rejectReasonInput) },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    enabled = rejectReasonInput.isNotBlank()
                ) {
                    Text("Confirm Rejection")
                }
            },
            dismissButton = {
                TextButton(onClick = viewModel::closeRejectConfirm) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun PaddingHorizontal16Vertical12(): PaddingValues = PaddingValues(horizontal = 16.dp, vertical = 12.dp)

@Composable
fun FilterTabButton(
    title: String,
    count: Int,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
    val contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant

    Surface(
        onClick = onClick,
        modifier = modifier.height(36.dp),
        shape = RoundedCornerShape(18.dp),
        color = containerColor
    ) {
        Box(
            modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = contentColor,
                    maxLines = 1
                )
                if (count > 0) {
                    Spacer(modifier = Modifier.width(4.dp))
                    Surface(
                        shape = CircleShape,
                        color = if (isSelected) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.25f) else MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = count.toString(),
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            color = contentColor
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ResultItemCard(
    result: AdminResultItem,
    isProcessing: Boolean,
    onInspectClick: () -> Unit,
    onImageClick: (String) -> Unit,
    onApproveClick: () -> Unit,
    onRejectClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onInspectClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header Row: Match #, Game Type, Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (result.gameType == "CARROM") MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.primaryContainer
                    ) {
                        Text(
                            text = result.gameType,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            color = if (result.gameType == "CARROM") MaterialTheme.colorScheme.onTertiaryContainer else MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                    Text(
                        text = "Match ${result.matchNumber}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                StatusBadge(status = result.status)
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

            // Details Grid: Player, Room Code, Prize
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    val displayName = result.userName.ifBlank { result.userId.ifBlank { "Player" } }
                    val displaySub = result.userPhone.ifBlank { result.userId }
                    Text("PLAYER", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                    Text(text = displayName, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                    if (displaySub.isNotBlank()) {
                        Text(text = displaySub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text("SUBMITTED ROOM CODE", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                    Text(
                        text = result.roomCode.ifBlank { "N/A" },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                    Text("WINNING PRIZE", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                    Text(
                        text = result.formattedPrize,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.tertiary
                    )
                }
            }

            // Screenshot Preview & Action Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val screenshotData = result.effectiveScreenshotUrl
                if (screenshotData.isNotBlank()) {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            .clickable { onImageClick(screenshotData) }
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Image, contentDescription = "Screenshot", tint = MaterialTheme.colorScheme.primary)
                        Text("Tap to view Screenshot", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                    }
                } else {
                    Text("Screenshot unavailable", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                }

                if (result.isPending) {
                    if (isProcessing) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp))
                    } else {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = onRejectClick,
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Reject")
                            }
                            Button(
                                onClick = onApproveClick,
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                            ) {
                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Approve")
                            }
                        }
                    }
                } else {
                    TextButton(onClick = onInspectClick) {
                        Text("Inspect Details")
                    }
                }
            }
        }
    }
}

@Composable
fun ResultDetailsModal(
    result: AdminResultItem,
    isProcessing: Boolean,
    onDismiss: () -> Unit,
    onImageClick: (String) -> Unit,
    onApprove: () -> Unit,
    onReject: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .fillMaxHeight(0.92f),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Modal Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Result Verification Review",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                // Scrollable Content
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    val displayName = result.userName.ifBlank { result.userId.ifBlank { "N/A" } }
                    val displaySub = result.userPhone.ifBlank { result.userId }
                    DetailRow(label = "Match", value = "${result.gameType} — Match ${result.matchNumber}")
                    DetailRow(label = "Player Name", value = displayName)
                    if (displaySub.isNotBlank()) {
                        DetailRow(label = "Player Phone / ID", value = displaySub)
                    }
                    DetailRow(label = "Submitted Room Code", value = result.roomCode.ifBlank { "N/A" }, isHighlight = true)
                    DetailRow(label = "Prize Payout", value = result.formattedPrize, isHighlight = true)
                    DetailRow(label = "Status", value = result.status.name)

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Winning Screenshot Proof:",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    val screenshotData = result.effectiveScreenshotUrl
                    if (screenshotData.isNotBlank()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 220.dp, max = 340.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { onImageClick(screenshotData) },
                            contentAlignment = Alignment.Center
                        ) {
                            WinningProofImageView(
                                screenshotDataOrUrl = screenshotData,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Fit,
                                contentDescription = "Winning Screenshot Proof"
                            )
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color.Black.copy(alpha = 0.65f),
                                modifier = Modifier
                                    .padding(8.dp)
                                    .align(Alignment.BottomEnd)
                            ) {
                                Text(
                                    "Tap to Zoom / Full Screen",
                                    color = Color.White,
                                    style = MaterialTheme.typography.labelSmall,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    } else {
                        ScreenshotUnavailablePlaceholder(modifier = Modifier.fillMaxWidth())
                    }
                }

                // Sticky Bottom Action Buttons if pending
                if (result.isPending) {
                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = onReject,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                        ) {
                            Text("Reject Result")
                        }
                        Button(
                            onClick = onApprove,
                            modifier = Modifier.weight(1f),
                            enabled = !isProcessing
                        ) {
                            if (isProcessing) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = MaterialTheme.colorScheme.onPrimary)
                            } else {
                                Text("Approve & Pay")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DetailRow(label: String, value: String, isHighlight: Boolean = false) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = if (isHighlight) FontWeight.Bold else FontWeight.SemiBold,
            color = if (isHighlight) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
fun StatusBadge(status: ResultStatus) {
    val (bg, fg) = when (status) {
        ResultStatus.APPROVED -> MaterialTheme.colorScheme.primaryContainer to MaterialTheme.colorScheme.onPrimaryContainer
        ResultStatus.REJECTED -> MaterialTheme.colorScheme.errorContainer to MaterialTheme.colorScheme.onErrorContainer
        ResultStatus.CONFLICT -> MaterialTheme.colorScheme.tertiaryContainer to MaterialTheme.colorScheme.onTertiaryContainer
        ResultStatus.LOST -> MaterialTheme.colorScheme.surfaceVariant to MaterialTheme.colorScheme.onSurfaceVariant
        ResultStatus.PENDING -> MaterialTheme.colorScheme.secondaryContainer to MaterialTheme.colorScheme.onSecondaryContainer
    }

    Surface(
        shape = RoundedCornerShape(8.dp),
        color = bg
    ) {
        Text(
            text = status.name,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            color = fg
        )
    }
}
