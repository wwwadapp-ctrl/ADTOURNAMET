package com.example.ui.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.model.DashboardUiState
import com.example.core.repository.DashboardRepository
import com.example.core.repository.FirebaseDashboardRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * ViewModel for the Super Admin Dashboard.
 * Exposes real-time aggregate telemetry streams from the authoritative Firebase RTDB.
 */
class DashboardViewModel(
    private val repository: DashboardRepository = defaultRepository
) : ViewModel() {
    val uiState: StateFlow<DashboardUiState> = repository.streamDashboardState()
        .catch { emit(DashboardUiState.Error("Connectivity error: ${it.message}")) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = DashboardUiState.Loading
        )

    fun refresh() {
        viewModelScope.launch {
            repository.refresh()
        }
    }

    companion object {
        var defaultRepository: DashboardRepository = FirebaseDashboardRepository()

        fun resetForTesting(testRepository: DashboardRepository) {
            defaultRepository = testRepository
        }
    }
}
