package com.example.core.security

/**
 * Result of authentication input validation.
 */
data class ValidationResult(
  val isValid: Boolean,
  val errorMessage: String? = null,
)

/**
 * Comprehensive client and server-side validation rules for authentication.
 * Ensures inputs strictly conform to AD Tournament security requirements:
 * - Clean mobile number (10 digits, valid prefixes)
 * - Secure password policy (min 6 characters, max 64, not whitespace)
 * - Proper name format (2-50 characters, letters/spaces only)
 * - 6-digit numeric OTP code
 */
object AuthValidator {

  private val VALID_BANGLADESH_PREFIXES = setOf("013", "014", "015", "016", "017", "018", "019")
  const val ERROR_INVALID_MOBILE = "Enter a valid 11-digit Bangladeshi mobile number starting with 013–019."

  /**
   * Validates an 11-digit Bangladeshi mobile number.
   * Accepted format: 01XXXXXXXXX
   * Valid prefixes: 013, 014, 015, 016, 017, 018, 019
   */
  fun validateMobileNumber(phone: String): ValidationResult {
    if (phone.isEmpty()) {
      return ValidationResult(false, "Mobile number cannot be empty")
    }
    if (phone.length != 11 || !phone.all { it.isDigit() }) {
      return ValidationResult(false, ERROR_INVALID_MOBILE)
    }
    val prefix = phone.take(3)
    if (prefix !in VALID_BANGLADESH_PREFIXES) {
      return ValidationResult(false, ERROR_INVALID_MOBILE)
    }
    return ValidationResult(true)
  }

  /**
   * Normalizes an 11-digit Bangladeshi mobile number (e.g. "01635003779")
   * to a 10-digit clean mobile number (e.g. "1635003779") for internal Firebase
   * phoneIndex and email mapping. Never alters user-facing UI values.
   */
  fun normalizeMobileNumber(phone: String): String {
    val digits = phone.filter { it.isDigit() }
    return if (digits.length == 11 && digits.startsWith("0")) {
      digits.substring(1)
    } else {
      digits
    }
  }

  /**
   * Validates password strength and length.
   * Requirement: minimum 6 characters, maximum 64 characters, not purely whitespace.
   */
  fun validatePassword(password: String): ValidationResult {
    return when {
      password.isEmpty() -> ValidationResult(false, "Password cannot be empty")
      password.length < 6 -> ValidationResult(false, "Password must be at least 6 characters")
      password.length > 64 -> ValidationResult(false, "Password must not exceed 64 characters")
      password.all { it.isWhitespace() } -> ValidationResult(false, "Password cannot consist only of whitespace")
      else -> ValidationResult(true)
    }
  }

  /**
   * Validates user full name.
   * Requirement: 2 to 50 characters, letters and spaces only.
   */
  fun validateFullName(name: String): ValidationResult {
    val trimmed = name.trim()
    return when {
      trimmed.isEmpty() -> ValidationResult(false, "Full name cannot be empty")
      trimmed.length < 2 -> ValidationResult(false, "Full name must be at least 2 characters")
      trimmed.length > 50 -> ValidationResult(false, "Full name cannot exceed 50 characters")
      !trimmed.all { it.isLetter() || it.isWhitespace() || it == '.' || it == '-' } ->
        ValidationResult(false, "Full name can only contain letters, spaces, dots, or hyphens")
      else -> ValidationResult(true)
    }
  }

  /**
   * Validates confirm password matches initial password.
   */
  fun validateConfirmPassword(password: String, confirm: String): ValidationResult {
    return when {
      confirm.isEmpty() -> ValidationResult(false, "Please confirm your password")
      password != confirm -> ValidationResult(false, "Passwords do not match")
      else -> ValidationResult(true)
    }
  }

  /**
   * Validates a 6-digit OTP code.
   */
  fun validateOtp(otp: String): ValidationResult {
    val clean = otp.filter { it.isDigit() }
    return when {
      clean.isEmpty() -> ValidationResult(false, "Please enter the 6-digit OTP")
      clean.length != 6 -> ValidationResult(false, "OTP must be exactly 6 digits")
      else -> ValidationResult(true)
    }
  }
}
