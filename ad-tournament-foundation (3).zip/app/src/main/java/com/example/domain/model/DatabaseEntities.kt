package com.example.domain.model

import com.google.firebase.database.IgnoreExtraProperties

/**
 * Account status state representation
 */
enum class AccountStatus {
  ACTIVE,
  BLOCKED
}

/**
 * 1. Approved Node: "users"
 * Phase 2 Profile Specification:
 * - userId
 * - fullName
 * - mobileNumber
 * - profilePhoto
 * - accountStatus
 * - joinDate
 * - totalMatches
 * - wins
 * - losses
 * - totalWinnings
 */
@IgnoreExtraProperties
data class UserEntity(
  val uid: String = "",
  val name: String = "",
  val mobileNumber: String = "",
  val joinDate: Long = 0L,
  val status: String = AccountStatus.ACTIVE.name,
  val profilePhotoUrl: String? = null,
  val userId: String = uid,
  val fullName: String = name,
  val profilePhoto: String = profilePhotoUrl ?: "",
  val accountStatus: String = status,
  val totalMatches: Int = 0,
  val wins: Int = 0,
  val losses: Int = 0,
  val totalWinnings: Double = 0.0,
  val role: String = "PLAYER", // PLAYER, ADMIN
  val walletBalance: Double = 0.0,
  val lastActiveAt: Long = 0L,
  // Saved payment profile for withdrawals (Strictly enforced: users cannot introduce arbitrary numbers on withdrawal)
  val savedBkashNumber: String = "",
  val savedNagadNumber: String = "",
  // Backward compatibility fields for serialization and view mapping:
  val displayName: String = name.ifEmpty { fullName },
  val phoneNumber: String = mobileNumber,
  val avatarUrl: String = profilePhotoUrl ?: profilePhoto,
  val isBlocked: Boolean = status.equals(AccountStatus.BLOCKED.name, ignoreCase = true) ||
      accountStatus.equals(AccountStatus.BLOCKED.name, ignoreCase = true),
  val createdAt: Long = joinDate,
) {
  val effectiveName: String get() = name.ifEmpty { fullName.ifEmpty { displayName.ifEmpty { "Player" } } }
  val effectiveMobile: String get() = mobileNumber.ifEmpty { phoneNumber }
  val effectivePhoto: String get() = profilePhotoUrl ?: profilePhoto.ifEmpty { avatarUrl }
  val isAccountBlocked: Boolean get() = isBlocked ||
      status.equals(AccountStatus.BLOCKED.name, ignoreCase = true) ||
      accountStatus.equals(AccountStatus.BLOCKED.name, ignoreCase = true)
}

/**
 * 2. Approved Node: "wallets"
 * SECURITY NOTICE: Read-only on the client side.
 * Clients MUST NEVER mutate balance directly. All transactions and balances
 * are calculated and verified server-side.
 *
 * Phase 3 Specification:
 * - wallets/{uid}
 * - availableBalance, pendingBalance, totalDeposited, totalWithdrawn, totalWinnings, updatedAt
 * - All monetary values stored as Long integer minor units (poisha / cents: 1 BDT = 100 minor units)
 *   to guarantee deterministic non-floating-point financial accounting.
 */
@IgnoreExtraProperties
data class WalletEntity(
  val uid: String = "",
  val availableBalance: Long = 0L,
  val pendingBalance: Long = 0L,
  val totalDeposited: Long = 0L,
  val totalWithdrawn: Long = 0L,
  val totalWinnings: Long = 0L,
  val updatedAt: Long = 0L,
  // Backward compatibility fields for views
  val walletId: String = uid,
  val userId: String = uid,
  val balance: Double = availableBalance / 100.0,
  val winningBalance: Double = totalWinnings / 100.0,
  val lockedBalance: Double = pendingBalance / 100.0,
  val bonusBalance: Double = 0.0,
) {
  val availableAmount: Double get() = availableBalance / 100.0
  val pendingAmount: Double get() = pendingBalance / 100.0
  val totalDepositedAmount: Double get() = totalDeposited / 100.0
  val totalWithdrawnAmount: Double get() = totalWithdrawn / 100.0
  val totalWinningsAmount: Double get() = totalWinnings / 100.0
}

/**
 * 3. Approved Node: "transactions"
 * Phase 3 Specification:
 * - transactions/{transactionId}
 * - Required fields: transactionId, uid, amount, type, status, beforeBalance, afterBalance, source, referenceId, description, createdAt, processedAt
 * - Monetary values in integer minor units (Long)
 */
enum class TransactionType {
  DEPOSIT,
  WITHDRAW,
  WITHDRAW_HOLD,
  WITHDRAW_RELEASE,
  MATCH_ENTRY,
  MATCH_REFUND,
  MATCH_PRIZE,
  ADMIN_CREDIT,
  ADMIN_DEBIT,
  COMMISSION,
  // Backward compatibility aliases
  WITHDRAWAL,
  MATCH_ENTRY_FEE,
  MATCH_PRIZE_CREDIT,
  REFUND,
  ADMIN_ADJUSTMENT
}

enum class TransactionStatus {
  PENDING,
  COMPLETED,
  FAILED,
  CANCELLED
}

@IgnoreExtraProperties
data class TransactionEntity(
  val transactionId: String = "",
  val uid: String = "",
  val amount: Long = 0L, // In minor units (1 ৳ = 100 units)
  val type: String = TransactionType.DEPOSIT.name,
  val status: String = TransactionStatus.PENDING.name,
  val beforeBalance: Long = 0L,
  val afterBalance: Long = 0L,
  val source: String = "APP",
  val referenceId: String = "",
  val description: String = "",
  val createdAt: Long = 0L,
  val processedAt: Long = 0L,
  // Backward compatibility getters / fields
  val walletId: String = uid,
  val userId: String = uid,
) {
  val amountInCurrency: Double get() = amount / 100.0
  val beforeBalanceInCurrency: Double get() = beforeBalance / 100.0
  val afterBalanceInCurrency: Double get() = afterBalance / 100.0
}

/**
 * 4. Approved Node: "matches"
 */
enum class GameType {
  LUDO,
  CARROM
}

enum class MatchStatus {
  AVAILABLE,
  FULL,
  CODE_ADDED,
  RUNNING,
  RESULT_SUBMITTED,
  COMPLETED,
  PAUSED,
  DISABLED,
  CANCELLED,
  UPCOMING // Alias for available scheduled
}

@IgnoreExtraProperties
data class MatchEntity(
  val matchId: String = "",
  val matchNumber: String = "",
  val title: String = "",
  val gameType: String = GameType.LUDO.name,
  val entryFee: Double = 0.0,
  val prizePool: Double = 0.0,
  val status: String = MatchStatus.AVAILABLE.name,
  val gameCode: String = "", // Set by Super Admin from external game
  val isCodeVisible: Boolean = false, // Visible only to joined players after being added
  val scheduledTime: Long = 0L,
  val maxPlayers: Int = 2,
  val joinedPlayersCount: Int = 0,
  val winnerUserId: String = "",
  val createdByAdminId: String = "",
  val createdAt: Long = 0L,
  // Phase 4 explicit properties:
  val entryFeeMinorUnits: Long = 0L,
  val prizeMinorUnits: Long = 0L,
  val scheduledAt: Long = 0L,
  val updatedAt: Long = 0L,
  val startedAt: Long? = null,
) {
  val effectiveEntryFeeMinorUnits: Long
    get() = if (entryFeeMinorUnits > 0L) entryFeeMinorUnits else (entryFee * 100).toLong()

  val effectivePrizeMinorUnits: Long
    get() = if (prizeMinorUnits > 0L) prizeMinorUnits else (prizePool * 100).toLong()

  val effectiveScheduledAt: Long
    get() = if (scheduledAt > 0L) scheduledAt else scheduledTime

  val effectiveUpdatedAt: Long
    get() = if (updatedAt > 0L) updatedAt else createdAt

  val displayEntryFee: Double
    get() = if (entryFee > 0.0) entryFee else effectiveEntryFeeMinorUnits / 100.0

  val displayPrizePool: Double
    get() = if (prizePool > 0.0) prizePool else effectivePrizeMinorUnits / 100.0
}

/**
 * 5. Approved Node: "matchPlayers"
 */
enum class PlayerSlot {
  PLAYER_1,
  PLAYER_2
}

@IgnoreExtraProperties
data class MatchPlayerEntity(
  val matchPlayerId: String = "",
  val matchId: String = "",
  val userId: String = "",
  val username: String = "",
  val slot: String = PlayerSlot.PLAYER_1.name,
  val joinedAt: Long = 0L,
  val isReady: Boolean = false,
  val uid: String = userId,
  val entryFeeMinorUnits: Long = 0L,
  val status: String = "JOINED",
) {
  val effectiveUid: String get() = uid.ifEmpty { userId }
}

/**
 * 6. Approved Node: "results"
 */
enum class ResultStatus {
  PENDING_REVIEW,
  APPROVED,
  REJECTED
}

@IgnoreExtraProperties
data class ResultEntity(
  val resultId: String = "",
  val matchId: String = "",
  val submittedByUserId: String = "",
  val claimedWinnerUserId: String = "",
  val proofScreenshotUrl: String = "",
  val status: String = ResultStatus.PENDING_REVIEW.name,
  val reviewNotes: String = "",
  val reviewedByAdminId: String = "",
  val submittedAt: Long = 0L,
  val reviewedAt: Long = 0L,
)

/**
 * 7. Approved Node: "deposits"
 * Phase 3 Specification:
 * - deposits/{depositId}
 * - Required fields: depositId, uid, amount, method, senderNumber, trxId, screenshotUrl, status, createdAt, processedAt
 * - Note: amount stored in integer minor units (Long)
 */
enum class DepositStatus {
  SUBMITTED,
  PENDING,
  APPROVED,
  REJECTED,
  VERIFYING
}

@IgnoreExtraProperties
data class DepositEntity(
  val depositId: String = "",
  val uid: String = "",
  val amount: Long = 0L, // In minor units (1 BDT = 100 minor units)
  val method: String = "BKASH", // BKASH, NAGAD
  val senderNumber: String = "",
  val trxId: String = "",
  val screenshotUrl: String = "",
  val status: String = DepositStatus.SUBMITTED.name,
  val createdAt: Long = 0L,
  val processedAt: Long = 0L,
  val rejectionReason: String = "",
  val adminUid: String = "",
  // Backward compatibility fields
  val userId: String = uid,
  val paymentMethod: String = method,
  val transactionReference: String = trxId,
  val screenshotProofUrl: String = screenshotUrl,
  val approvedAt: Long = processedAt,
) {
  val amountInCurrency: Double get() = amount / 100.0
}

/**
 * 8. Approved Node: "withdrawals"
 * Phase 3 Specification:
 * - withdrawals/{withdrawalId}
 * - Required fields: withdrawalId, uid, amount, method, recipientNumber, status, createdAt, processedAt
 * - Note: amount stored in integer minor units (Long)
 */
enum class WithdrawalStatus {
  REQUESTED,
  PENDING,
  APPROVED,
  REJECTED,
  PROCESSING,
  COMPLETED
}

@IgnoreExtraProperties
data class WithdrawalEntity(
  val withdrawalId: String = "",
  val uid: String = "",
  val amount: Long = 0L, // In minor units (1 BDT = 100 minor units)
  val method: String = "BKASH", // BKASH, NAGAD
  val recipientNumber: String = "",
  val status: String = WithdrawalStatus.REQUESTED.name,
  val createdAt: Long = 0L,
  val processedAt: Long = 0L,
  val rejectionReason: String = "",
  val adminUid: String = "",
  // Backward compatibility fields
  val userId: String = uid,
  val paymentMethod: String = method,
  val paymentDetails: String = recipientNumber,
  val requestedAt: Long = createdAt,
) {
  val amountInCurrency: Double get() = amount / 100.0
}

/**
 * 9. Approved Node: "notifications"
 */
@IgnoreExtraProperties
data class NotificationEntity(
  val notificationId: String = "",
  val userId: String = "",
  val title: String = "",
  val body: String = "",
  val targetScreen: String = "",
  val isRead: Boolean = false,
  val createdAt: Long = 0L,
)

/**
 * 10. Approved Node: "adminUsers"
 */
@IgnoreExtraProperties
data class AdminUserEntity(
  val adminId: String = "",
  val userId: String = "",
  val email: String = "",
  val role: String = "MODERATOR", // SUPER_ADMIN, MODERATOR
  val permissions: List<String> = emptyList(),
  val isActive: Boolean = true,
  val createdAt: Long = 0L,
)

/**
 * 11. Approved Node: "auditLogs"
 * Phase 3 Specification:
 * - auditLogs/{logId}
 * - Required fields: logId, action, adminUid, targetUid, beforeState, afterState, timestamp, ipAddress
 */
@IgnoreExtraProperties
data class AuditLogEntity(
  val logId: String = "",
  val action: String = "",
  val adminUid: String = "",
  val targetUid: String = "",
  val beforeState: String = "",
  val afterState: String = "",
  val timestamp: Long = 0L,
  val ipAddress: String = "",
  // Backward compatibility fields
  val performedByUserId: String = adminUid,
  val targetEntityId: String = targetUid,
  val targetEntityType: String = "",
  val details: String = "$beforeState -> $afterState",
)

/**
 * 12. Approved Node: "appSettings"
 * Phase 3 Specification:
 * - appSettings/finance
 * - minDeposit (in minor units: default 5000 = 50 BDT), maxDeposit (default 2500000 = 25,000 BDT)
 * - minWithdraw (in minor units: default 10000 = 100 BDT), maxWithdraw (default 1000000 = 10,000 BDT)
 * - depositFeePercent (0%), withdrawFeePercent (default 0%)
 * - commissionRate (default 10%)
 * - bkashNumber, nagadNumber, depositInstructions
 */
@IgnoreExtraProperties
data class FinanceSettingsEntity(
  val minDeposit: Long = 5000L, // 50 BDT in minor units
  val maxDeposit: Long = 2500000L, // 25,000 BDT
  val minWithdraw: Long = 10000L, // 100 BDT in minor units
  val maxWithdraw: Long = 1000000L, // 10,000 BDT
  val depositFeePercent: Double = 0.0,
  val withdrawFeePercent: Double = 0.0,
  val commissionRate: Double = 10.0,
  val bkashNumber: String = "01700000000",
  val nagadNumber: String = "01800000000",
  val depositInstructions: String = "Send Money (Personal) to the official bKash/Nagad number, then submit your transaction ID and proof.",
) {
  val minDepositAmount: Double get() = minDeposit / 100.0
  val maxDepositAmount: Double get() = maxDeposit / 100.0
  val minWithdrawAmount: Double get() = minWithdraw / 100.0
  val maxWithdrawAmount: Double get() = maxWithdraw / 100.0
}

@IgnoreExtraProperties
data class AppSettingsEntity(
  val minDepositAmount: Double = 50.0,
  val minWithdrawalAmount: Double = 100.0,
  val platformCommissionPercent: Double = 10.0,
  val maintenanceMode: Boolean = false,
  val supportWhatsappNumber: String = "",
  val supportTelegramUrl: String = "",
  val appVersionCode: Int = 1,
  val finance: FinanceSettingsEntity = FinanceSettingsEntity(),
)
