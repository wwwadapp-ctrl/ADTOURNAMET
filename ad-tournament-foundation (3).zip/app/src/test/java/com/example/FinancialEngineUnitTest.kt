package com.example

import com.example.core.finance.FinancialEngine
import com.example.domain.model.DepositEntity
import com.example.domain.model.DepositStatus
import com.example.domain.model.MatchEntity
import com.example.domain.model.MatchPlayerEntity
import com.example.domain.model.MatchStatus
import com.example.domain.model.PlayerSlot
import com.example.domain.model.TransactionEntity
import com.example.domain.model.TransactionStatus
import com.example.domain.model.TransactionType
import com.example.domain.model.UserEntity
import com.example.domain.model.WalletEntity
import com.example.domain.model.WithdrawalEntity
import com.example.domain.model.WithdrawalStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

/**
 * Unit tests verifying the AD TOURNAMENT Phase 3 Financial Engine:
 * - Tiered commission rules (Entry fee <= ৳100 -> ৳10; <= ৳200 -> ৳20; > ৳200 -> ৳40)
 * - 2-Player prize pool math: (entry fee * 2) - commission
 * - Strict integer minor-unit accounting (1 ৳ = 100 minor units)
 * - Non-negative prize bounds and non-positive entry fee protection
 * - Idempotency and atomic mutation safety
 */
class FinancialEngineUnitTest {

  // 1. ৳50 entry -> totalPool ৳100 -> commission ৳10 -> prize ৳90
  @Test
  fun testCommissionAndPrize_50Bdt() {
    val entryFee = 50_00L // 5,000 minor units = ৳50
    val commission = FinancialEngine.calculateCommission(entryFee)
    assertEquals(10_00L, commission) // ৳10

    val prizeCalc = FinancialEngine.calculateMatchPrize(entryFee)
    assertEquals(100_00L, prizeCalc.totalPool) // ৳100
    assertEquals(10_00L, prizeCalc.commissionAmount) // ৳10
    assertEquals(90_00L, prizeCalc.winnerPrize) // ৳90
  }

  // 2. ৳100 entry boundary -> commission ৳10 -> prize ৳190
  @Test
  fun testCommission_100Bdt_Boundary() {
    val entryFee = 100_00L // 10,000 minor units = ৳100
    val commission = FinancialEngine.calculateCommission(entryFee)
    assertEquals(10_00L, commission) // ৳10

    val prizeCalc = FinancialEngine.calculateMatchPrize(entryFee)
    assertEquals(200_00L, prizeCalc.totalPool) // ৳200
    assertEquals(10_00L, prizeCalc.commissionAmount) // ৳10
    assertEquals(190_00L, prizeCalc.winnerPrize) // ৳190
  }

  // 3. ৳101 entry boundary -> commission ৳20 -> prize ৳182
  @Test
  fun testCommission_101Bdt_Boundary() {
    val entryFee = 101_00L // 10,100 minor units = ৳101
    val commission = FinancialEngine.calculateCommission(entryFee)
    assertEquals(20_00L, commission) // ৳20

    val prizeCalc = FinancialEngine.calculateMatchPrize(entryFee)
    assertEquals(202_00L, prizeCalc.totalPool) // ৳202
    assertEquals(20_00L, prizeCalc.commissionAmount) // ৳20
    assertEquals(182_00L, prizeCalc.winnerPrize) // ৳182
  }

  // 4. ৳150 entry -> commission ৳20 -> prize ৳280
  @Test
  fun testCommissionAndPrize_150Bdt() {
    val entryFee = 150_00L // 15,000 minor units = ৳150
    val commission = FinancialEngine.calculateCommission(entryFee)
    assertEquals(20_00L, commission) // ৳20

    val prizeCalc = FinancialEngine.calculateMatchPrize(entryFee)
    assertEquals(300_00L, prizeCalc.totalPool) // ৳300
    assertEquals(20_00L, prizeCalc.commissionAmount) // ৳20
    assertEquals(280_00L, prizeCalc.winnerPrize) // ৳280
  }

  // 5. ৳200 entry boundary -> commission ৳20 -> prize ৳380
  @Test
  fun testCommission_200Bdt_Boundary() {
    val entryFee = 200_00L // 20,000 minor units = ৳200
    val commission = FinancialEngine.calculateCommission(entryFee)
    assertEquals(20_00L, commission) // ৳20

    val prizeCalc = FinancialEngine.calculateMatchPrize(entryFee)
    assertEquals(400_00L, prizeCalc.totalPool) // ৳400
    assertEquals(20_00L, prizeCalc.commissionAmount) // ৳20
    assertEquals(380_00L, prizeCalc.winnerPrize) // ৳380
  }

  // 6. ৳201 entry boundary -> commission ৳40 -> prize ৳362
  @Test
  fun testCommission_201Bdt_Boundary() {
    val entryFee = 201_00L // 20,100 minor units = ৳201
    val commission = FinancialEngine.calculateCommission(entryFee)
    assertEquals(40_00L, commission) // ৳40

    val prizeCalc = FinancialEngine.calculateMatchPrize(entryFee)
    assertEquals(402_00L, prizeCalc.totalPool) // ৳402
    assertEquals(40_00L, prizeCalc.commissionAmount) // ৳40
    assertEquals(362_00L, prizeCalc.winnerPrize) // ৳362
  }

  // 7. ৳250 entry -> commission ৳40 -> prize ৳460
  @Test
  fun testCommissionAndPrize_250Bdt() {
    val entryFee = 250_00L // 25,000 minor units = ৳250
    val commission = FinancialEngine.calculateCommission(entryFee)
    assertEquals(40_00L, commission) // ৳40

    val prizeCalc = FinancialEngine.calculateMatchPrize(entryFee)
    assertEquals(500_00L, prizeCalc.totalPool) // ৳500
    assertEquals(40_00L, prizeCalc.commissionAmount) // ৳40
    assertEquals(460_00L, prizeCalc.winnerPrize) // ৳460
  }

  // 8. ৳300 entry -> commission ৳40 -> prize ৳560
  @Test
  fun testCommissionAndPrize_300Bdt() {
    val entryFee = 300_00L // 30,000 minor units = ৳300
    val commission = FinancialEngine.calculateCommission(entryFee)
    assertEquals(40_00L, commission) // ৳40

    val prizeCalc = FinancialEngine.calculateMatchPrize(entryFee)
    assertEquals(600_00L, prizeCalc.totalPool) // ৳600
    assertEquals(40_00L, prizeCalc.commissionAmount) // ৳40
    assertEquals(560_00L, prizeCalc.winnerPrize) // ৳560
  }

  // 9. Invalid/non-positive entry fee validation
  @Test
  fun testInvalidNonPositiveEntryFee() {
    try {
      FinancialEngine.calculateCommission(0L)
      fail("Should have thrown IllegalArgumentException for zero entry fee")
    } catch (e: IllegalArgumentException) {
      assertNotNull(e.message)
    }

    try {
      FinancialEngine.calculateCommission(-1000L)
      fail("Should have thrown IllegalArgumentException for negative entry fee")
    } catch (e: IllegalArgumentException) {
      assertNotNull(e.message)
    }

    try {
      FinancialEngine.calculateMatchPrize(0L)
      fail("Should have thrown IllegalArgumentException for zero entry fee in match prize")
    } catch (e: IllegalArgumentException) {
      assertNotNull(e.message)
    }

    try {
      FinancialEngine.calculateMatchPrize(-5000L)
      fail("Should have thrown IllegalArgumentException for negative entry fee in match prize")
    } catch (e: IllegalArgumentException) {
      assertNotNull(e.message)
    }
  }

  // 10. Prize cannot become negative
  @Test
  fun testPrizeCannotBecomeNegative() {
    // 2 players with very small fee (e.g. 100 minor units = ৳1, total pool = 200 minor units, commission = 1000)
    // Prize pool should clamp safely to 0 rather than negative
    val prizeCalc = FinancialEngine.calculateMatchPrize(100L)
    assertTrue("Prize must never be negative", prizeCalc.winnerPrize >= 0L)
    assertEquals(0L, prizeCalc.winnerPrize)
  }

  // 11. Integer minor-unit precision check
  @Test
  fun testIntegerMinorUnitPrecision() {
    val oddEntryFee = 77_77L // ৳77.77
    val prizeCalc = FinancialEngine.calculateMatchPrize(oddEntryFee)
    assertEquals(155_54L, prizeCalc.totalPool)
    assertEquals(10_00L, prizeCalc.commissionAmount)
    assertEquals(145_54L, prizeCalc.winnerPrize)
    assertEquals(prizeCalc.totalPool - prizeCalc.commissionAmount, prizeCalc.winnerPrize)
  }

  // 12. Deposit approval idempotency check
  @Test
  fun testDepositApproval_Idempotency() {
    val initialWallet = WalletEntity(
      uid = "user_test_123",
      availableBalance = 5000L,
      totalDeposited = 5000L,
    )
    val deposit = DepositEntity(
      depositId = "dep_test_001",
      uid = "user_test_123",
      amount = 10000L,
      method = "BKASH",
      trxId = "TRX123456",
      status = DepositStatus.SUBMITTED.name,
    )

    // First run: Should succeed and credit wallet
    val firstResult = FinancialEngine.processDepositApproval(
      currentWallet = initialWallet,
      deposit = deposit,
      existingTransactions = emptyList(),
    )
    assertTrue(firstResult is FinancialEngine.MutationResult.Success)
    val success1 = firstResult as FinancialEngine.MutationResult.Success
    assertEquals(15000L, success1.wallet.availableBalance)
    assertEquals(15000L, success1.wallet.totalDeposited)

    // Second run with existing transaction: Must be idempotent
    val existingTransactions = listOf(success1.transaction)
    val secondResult = FinancialEngine.processDepositApproval(
      currentWallet = success1.wallet,
      deposit = deposit,
      existingTransactions = existingTransactions,
    )
    assertTrue(secondResult is FinancialEngine.MutationResult.Success)
    val success2 = secondResult as FinancialEngine.MutationResult.Success
    assertTrue("Should indicate already processed", success2.isAlreadyProcessed)
    assertEquals("Wallet balance must remain unchanged", 15000L, success2.wallet.availableBalance)
  }

  // 13. Withdrawal hold: Insufficient balance & idempotency
  @Test
  fun testWithdrawalHold_InsufficientBalanceAndIdempotency() {
    val lowBalanceWallet = WalletEntity(
      uid = "user_test_123",
      availableBalance = 5000L, // ৳50
      pendingBalance = 0L,
    )
    val withdrawal = WithdrawalEntity(
      withdrawalId = "wth_test_001",
      uid = "user_test_123",
      amount = 10000L, // ৳100 (exceeds ৳50 available)
      method = "NAGAD",
      recipientNumber = "01700000000",
      status = WithdrawalStatus.REQUESTED.name,
    )

    val failResult = FinancialEngine.processWithdrawalHold(
      currentWallet = lowBalanceWallet,
      withdrawal = withdrawal,
    )
    assertTrue("Must fail on insufficient balance", failResult is FinancialEngine.MutationResult.Failure)

    // Wallet with sufficient balance
    val fundedWallet = WalletEntity(
      uid = "user_test_123",
      availableBalance = 20000L, // ৳200
      pendingBalance = 0L,
    )
    val holdResult = FinancialEngine.processWithdrawalHold(
      currentWallet = fundedWallet,
      withdrawal = withdrawal,
    )
    assertTrue(holdResult is FinancialEngine.MutationResult.Success)
    val holdSuccess = holdResult as FinancialEngine.MutationResult.Success
    assertEquals(10000L, holdSuccess.wallet.availableBalance) // Deducted from available
    assertEquals(10000L, holdSuccess.wallet.pendingBalance) // Held in escrow

    // Repeat hold: Idempotent
    val repeatHoldResult = FinancialEngine.processWithdrawalHold(
      currentWallet = holdSuccess.wallet,
      withdrawal = withdrawal,
      existingTransactions = listOf(holdSuccess.transaction),
    )
    assertTrue(repeatHoldResult is FinancialEngine.MutationResult.Success)
    assertTrue((repeatHoldResult as FinancialEngine.MutationResult.Success).isAlreadyProcessed)
  }

  // ==========================================
  // PHASE 4 TESTS: MATCH JOIN & LIFECYCLE
  // ==========================================

  // 1. First player can join an AVAILABLE match, count=1, status remains AVAILABLE, wallet deducted, MATCH_ENTRY created
  @Test
  fun testMatchJoin_FirstPlayer_AvailableAndSlot1() {
    val scheduledTime = System.currentTimeMillis() + 3600_000L
    val match = MatchEntity(
      matchId = "match_p4_1",
      entryFeeMinorUnits = 50_00L, // ৳50
      maxPlayers = 2,
      joinedPlayersCount = 0,
      status = MatchStatus.AVAILABLE.name,
      scheduledAt = scheduledTime,
    )
    val user = UserEntity(
      uid = "player_1",
      userId = "player_1",
      phoneNumber = "01700000001",
      isBlocked = false,
    )
    val wallet = WalletEntity(
      uid = "player_1",
      availableBalance = 150_00L, // ৳150
      pendingBalance = 0L,
    )

    val result = FinancialEngine.processMatchJoin(
      match = match,
      user = user,
      currentWallet = wallet,
      existingPlayers = emptyList(),
      currentTime = scheduledTime - 1800_000L,
    )

    assertTrue("First player join must succeed", result is FinancialEngine.MatchJoinResult.Success)
    val success = result as FinancialEngine.MatchJoinResult.Success

    // Player details
    assertEquals("player_1", success.matchPlayer.uid)
    assertEquals(PlayerSlot.PLAYER_1.name, success.matchPlayer.slot)
    assertEquals(50_00L, success.matchPlayer.entryFeeMinorUnits)

    // Match details
    assertEquals(1, success.match.joinedPlayersCount)
    assertEquals(MatchStatus.AVAILABLE.name, success.match.status)

    // Wallet balance
    assertEquals(100_00L, success.wallet.availableBalance) // ৳150 - ৳50 = ৳100
    assertEquals(50_00L, success.wallet.pendingBalance) // Held in pending escrow

    // Transaction
    assertEquals(TransactionType.MATCH_ENTRY.name, success.transaction.type)
    assertEquals(50_00L, success.transaction.amount)
    assertEquals(150_00L, success.transaction.beforeBalance)
    assertEquals(100_00L, success.transaction.afterBalance)
    assertEquals("MATCH_ENTRY_match_p4_1_player_1", success.transaction.referenceId)
    assertFalse(success.isAlreadyProcessed)
  }

  // 2. Second player can join, count=2, status becomes FULL
  @Test
  fun testMatchJoin_SecondPlayer_BecomesFull() {
    val scheduledTime = System.currentTimeMillis() + 3600_000L
    val match = MatchEntity(
      matchId = "match_p4_2",
      entryFeeMinorUnits = 50_00L,
      maxPlayers = 2,
      joinedPlayersCount = 1,
      status = MatchStatus.AVAILABLE.name,
      scheduledAt = scheduledTime,
    )
    val existingPlayer1 = MatchPlayerEntity(
      matchPlayerId = "mp_1",
      matchId = "match_p4_2",
      uid = "player_1",
      slot = PlayerSlot.PLAYER_1.name,
      entryFeeMinorUnits = 50_00L,
    )
    val user2 = UserEntity(
      uid = "player_2",
      userId = "player_2",
      phoneNumber = "01700000002",
      isBlocked = false,
    )
    val wallet2 = WalletEntity(
      uid = "player_2",
      availableBalance = 80_00L, // ৳80
      pendingBalance = 0L,
    )

    val result = FinancialEngine.processMatchJoin(
      match = match,
      user = user2,
      currentWallet = wallet2,
      existingPlayers = listOf(existingPlayer1),
      currentTime = scheduledTime - 1800_000L,
    )

    assertTrue("Second player join must succeed", result is FinancialEngine.MatchJoinResult.Success)
    val success = result as FinancialEngine.MatchJoinResult.Success

    assertEquals("player_2", success.matchPlayer.uid)
    assertEquals(PlayerSlot.PLAYER_2.name, success.matchPlayer.slot)
    assertEquals(2, success.match.joinedPlayersCount)
    assertEquals(MatchStatus.FULL.name, success.match.status)
    assertEquals(30_00L, success.wallet.availableBalance)
    assertEquals(50_00L, success.wallet.pendingBalance)
  }

  // 3. Third player is rejected when match is full
  @Test
  fun testMatchJoin_ThirdPlayer_Rejected() {
    val scheduledTime = System.currentTimeMillis() + 3600_000L
    val match = MatchEntity(
      matchId = "match_p4_3",
      entryFeeMinorUnits = 50_00L,
      maxPlayers = 2,
      joinedPlayersCount = 2,
      status = MatchStatus.FULL.name,
      scheduledAt = scheduledTime,
    )
    val existingPlayers = listOf(
      MatchPlayerEntity(matchPlayerId = "mp_1", matchId = "match_p4_3", uid = "player_1", slot = PlayerSlot.PLAYER_1.name),
      MatchPlayerEntity(matchPlayerId = "mp_2", matchId = "match_p4_3", uid = "player_2", slot = PlayerSlot.PLAYER_2.name),
    )
    val user3 = UserEntity(uid = "player_3", isBlocked = false)
    val wallet3 = WalletEntity(uid = "player_3", availableBalance = 100_00L)

    val result = FinancialEngine.processMatchJoin(
      match = match,
      user = user3,
      currentWallet = wallet3,
      existingPlayers = existingPlayers,
      currentTime = scheduledTime - 1800_000L,
    )

    assertTrue(result is FinancialEngine.MatchJoinResult.Failure)
    val failure = result as FinancialEngine.MatchJoinResult.Failure
    assertEquals("ERR_MATCH_FULL", failure.errorCode)
  }

  // 4. Same user cannot join the same match twice
  @Test
  fun testMatchJoin_SameUserTwice_Rejected() {
    val scheduledTime = System.currentTimeMillis() + 3600_000L
    val match = MatchEntity(
      matchId = "match_p4_4",
      entryFeeMinorUnits = 50_00L,
      maxPlayers = 2,
      joinedPlayersCount = 1,
      status = MatchStatus.AVAILABLE.name,
      scheduledAt = scheduledTime,
    )
    val existingPlayer1 = MatchPlayerEntity(
      matchPlayerId = "mp_1",
      matchId = "match_p4_4",
      uid = "player_1",
      slot = PlayerSlot.PLAYER_1.name,
      entryFeeMinorUnits = 50_00L,
    )
    val user1 = UserEntity(uid = "player_1", isBlocked = false)
    val wallet1 = WalletEntity(uid = "player_1", availableBalance = 200_00L)

    val result = FinancialEngine.processMatchJoin(
      match = match,
      user = user1,
      currentWallet = wallet1,
      existingPlayers = listOf(existingPlayer1),
      currentTime = scheduledTime - 1800_000L,
    )

    assertTrue(result is FinancialEngine.MatchJoinResult.Failure)
    assertEquals("ERR_ALREADY_JOINED", (result as FinancialEngine.MatchJoinResult.Failure).errorCode)
  }

  // 5. Same user can join two different matches
  @Test
  fun testMatchJoin_SameUserDifferentMatches_Allowed() {
    val scheduledTime = System.currentTimeMillis() + 3600_000L
    val matchA = MatchEntity(
      matchId = "match_A",
      entryFeeMinorUnits = 30_00L,
      maxPlayers = 2,
      status = MatchStatus.AVAILABLE.name,
      scheduledAt = scheduledTime,
    )
    val matchB = MatchEntity(
      matchId = "match_B",
      entryFeeMinorUnits = 40_00L,
      maxPlayers = 2,
      status = MatchStatus.AVAILABLE.name,
      scheduledAt = scheduledTime,
    )
    val user = UserEntity(uid = "player_multi", isBlocked = false)
    val initialWallet = WalletEntity(uid = "player_multi", availableBalance = 100_00L)

    // Join Match A
    val resA = FinancialEngine.processMatchJoin(
      match = matchA,
      user = user,
      currentWallet = initialWallet,
      existingPlayers = emptyList(),
      currentTime = scheduledTime - 1000L,
    )
    assertTrue(resA is FinancialEngine.MatchJoinResult.Success)
    val walletAfterA = (resA as FinancialEngine.MatchJoinResult.Success).wallet
    assertEquals(70_00L, walletAfterA.availableBalance)
    assertEquals(30_00L, walletAfterA.pendingBalance)

    // Join Match B with updated wallet
    val resB = FinancialEngine.processMatchJoin(
      match = matchB,
      user = user,
      currentWallet = walletAfterA,
      existingPlayers = emptyList(),
      currentTime = scheduledTime - 1000L,
    )
    assertTrue(resB is FinancialEngine.MatchJoinResult.Success)
    val walletAfterB = (resB as FinancialEngine.MatchJoinResult.Success).wallet
    assertEquals(30_00L, walletAfterB.availableBalance)
    assertEquals(70_00L, walletAfterB.pendingBalance)
  }

  // 6. Blocked user cannot join
  @Test
  fun testMatchJoin_BlockedUser_Rejected() {
    val match = MatchEntity(
      matchId = "match_p4_blocked",
      entryFeeMinorUnits = 50_00L,
      status = MatchStatus.AVAILABLE.name,
      scheduledAt = System.currentTimeMillis() + 3600_000L,
    )
    val blockedUser = UserEntity(uid = "blocked_user", isBlocked = true)
    val wallet = WalletEntity(uid = "blocked_user", availableBalance = 500_00L)

    val result = FinancialEngine.processMatchJoin(
      match = match,
      user = blockedUser,
      currentWallet = wallet,
      existingPlayers = emptyList(),
    )

    assertTrue(result is FinancialEngine.MatchJoinResult.Failure)
    assertEquals("ERR_BLOCKED_USER", (result as FinancialEngine.MatchJoinResult.Failure).errorCode)
  }

  // 7. Insufficient balance rejects join
  @Test
  fun testMatchJoin_InsufficientBalance_Rejected() {
    val match = MatchEntity(
      matchId = "match_p4_poor",
      entryFeeMinorUnits = 100_00L, // ৳100
      status = MatchStatus.AVAILABLE.name,
      scheduledAt = System.currentTimeMillis() + 3600_000L,
    )
    val user = UserEntity(uid = "user_poor", isBlocked = false)
    val lowWallet = WalletEntity(uid = "user_poor", availableBalance = 40_00L) // Only ৳40

    val result = FinancialEngine.processMatchJoin(
      match = match,
      user = user,
      currentWallet = lowWallet,
      existingPlayers = emptyList(),
    )

    assertTrue(result is FinancialEngine.MatchJoinResult.Failure)
    assertEquals("ERR_INSUFFICIENT_BALANCE", (result as FinancialEngine.MatchJoinResult.Failure).errorCode)
  }

  // 8. Join after scheduledAt rejects
  @Test
  fun testMatchJoin_AfterCutoff_Rejected() {
    val scheduledTime = 1_000_000L
    val match = MatchEntity(
      matchId = "match_p4_late",
      entryFeeMinorUnits = 50_00L,
      status = MatchStatus.AVAILABLE.name,
      scheduledAt = scheduledTime,
    )
    val user = UserEntity(uid = "user_late", isBlocked = false)
    val wallet = WalletEntity(uid = "user_late", availableBalance = 200_00L)

    val result = FinancialEngine.processMatchJoin(
      match = match,
      user = user,
      currentWallet = wallet,
      existingPlayers = emptyList(),
      currentTime = scheduledTime + 1L, // 1 ms late
    )

    assertTrue(result is FinancialEngine.MatchJoinResult.Failure)
    assertEquals("ERR_CUTOFF_PASSED", (result as FinancialEngine.MatchJoinResult.Failure).errorCode)
  }

  // 9. Retry with existing transaction is idempotent and does not double-deduct
  @Test
  fun testMatchJoin_IdempotentRetry_NoDoubleDeduct() {
    val scheduledTime = System.currentTimeMillis() + 3600_000L
    val match = MatchEntity(
      matchId = "match_p4_retry",
      entryFeeMinorUnits = 50_00L,
      status = MatchStatus.AVAILABLE.name,
      scheduledAt = scheduledTime,
    )
    val user = UserEntity(uid = "user_retry", isBlocked = false)
    val wallet = WalletEntity(uid = "user_retry", availableBalance = 100_00L, pendingBalance = 50_00L)

    val existingPlayer = MatchPlayerEntity(
      matchPlayerId = "mp_retry",
      matchId = "match_p4_retry",
      uid = "user_retry",
      userId = "user_retry",
      slot = PlayerSlot.PLAYER_1.name,
      entryFeeMinorUnits = 50_00L,
    )

    val existingTxn = TransactionEntity(
      transactionId = "TXN_ENTRY_1",
      uid = "user_retry",
      amount = 50_00L,
      type = TransactionType.MATCH_ENTRY.name,
      status = TransactionStatus.COMPLETED.name,
      referenceId = "MATCH_ENTRY_match_p4_retry_user_retry",
    )

    // A: Retrying when BOTH player registration and transaction exist -> Success(isAlreadyProcessed = true), NO second deduction
    val result = FinancialEngine.processMatchJoin(
      match = match,
      user = user,
      currentWallet = wallet,
      existingPlayers = listOf(existingPlayer),
      existingTransactions = listOf(existingTxn),
    )

    assertTrue(result is FinancialEngine.MatchJoinResult.Success)
    val success = result as FinancialEngine.MatchJoinResult.Success
    assertTrue("Should be marked as already processed", success.isAlreadyProcessed)
    assertEquals(100_00L, success.wallet.availableBalance) // Unchanged
    assertEquals(50_00L, success.wallet.pendingBalance) // Unchanged

    // D: Orphaned transaction without player registration -> Safe Failure (ERR_DUPLICATE_TXN), NO second deduction
    val orphanResult = FinancialEngine.processMatchJoin(
      match = match,
      user = user,
      currentWallet = wallet,
      existingPlayers = emptyList(), // Missing player
      existingTransactions = listOf(existingTxn),
    )
    assertTrue(orphanResult is FinancialEngine.MatchJoinResult.Failure)
    val orphanFailure = orphanResult as FinancialEngine.MatchJoinResult.Failure
    assertEquals("ERR_DUPLICATE_TXN", orphanFailure.errorCode)
    assertEquals(100_00L, wallet.availableBalance) // Unchanged
  }

  // 10. Super Admin can set game code; non-admin is rejected
  @Test
  fun testGameCode_AdminAuthorization() {
    val match = MatchEntity(
      matchId = "match_code_1",
      status = MatchStatus.FULL.name,
      gameCode = "",
    )
    val superAdmin = UserEntity(uid = "admin_super", role = "SUPER_ADMIN")
    val regularAdmin = UserEntity(uid = "admin_reg", role = "ADMIN")
    val regularUser = UserEntity(uid = "user_normal", role = "USER")

    // Super Admin sets code
    val resSuper = FinancialEngine.processAdminSetGameCode(
      match = match,
      adminUser = superAdmin,
      gameCode = "LUDO_9988",
    )
    assertTrue(resSuper is FinancialEngine.AdminMatchResult.Success)
    val updatedMatch = (resSuper as FinancialEngine.AdminMatchResult.Success).updatedMatch
    assertEquals("LUDO_9988", updatedMatch.gameCode)
    assertTrue(updatedMatch.isCodeVisible)
    assertEquals(MatchStatus.CODE_ADDED.name, updatedMatch.status)

    // Admin sets code
    val resAdmin = FinancialEngine.processAdminSetGameCode(
      match = match,
      adminUser = regularAdmin,
      gameCode = "LUDO_1122",
    )
    assertTrue(resAdmin is FinancialEngine.AdminMatchResult.Success)

    // Regular user is rejected
    val resUser = FinancialEngine.processAdminSetGameCode(
      match = match,
      adminUser = regularUser,
      gameCode = "HACK_CODE",
    )
    assertTrue(resUser is FinancialEngine.AdminMatchResult.Failure)
    assertEquals("ERR_UNAUTHORIZED", (resUser as FinancialEngine.AdminMatchResult.Failure).errorCode)
  }

  // 11. Room code privacy: permitted only to joined players and admins
  @Test
  fun testGameCode_PrivacyAccessControl() {
    val match = MatchEntity(
      matchId = "match_private",
      status = MatchStatus.CODE_ADDED.name,
      gameCode = "SECRET_ROOM_42",
      isCodeVisible = true,
    )

    // Joined player can see code
    val joinedView = FinancialEngine.getPermittedGameRoomCode(
      match = match,
      userId = "joined_user",
      isJoined = true,
      isAdmin = false,
    )
    assertEquals("SECRET_ROOM_42", joinedView)

    // Non-joined user cannot see code
    val nonJoinedView = FinancialEngine.getPermittedGameRoomCode(
      match = match,
      userId = "stranger",
      isJoined = false,
      isAdmin = false,
    )
    assertNull("Non-joined user must not see room code", nonJoinedView)

    // Admin can see code
    val adminView = FinancialEngine.getPermittedGameRoomCode(
      match = match,
      userId = "admin_uid",
      isJoined = false,
      isAdmin = true,
    )
    assertEquals("SECRET_ROOM_42", adminView)
  }

  // 12. RUNNING transition: Admin can start match, records startedAt & updatedAt; non-admin rejected
  @Test
  fun testMatchRunning_AdminAuthorizationAndTimestamps() {
    val now = 1_700_000_000_000L
    val matchCoded = MatchEntity(
      matchId = "match_to_run",
      status = MatchStatus.CODE_ADDED.name,
      gameCode = "ROOM_888",
      startedAt = null,
      updatedAt = now - 10_000L,
    )
    val admin = UserEntity(uid = "admin_super", role = "SUPER_ADMIN")
    val regularUser = UserEntity(uid = "user_normal", role = "USER")

    // Admin starts match
    val runResult = FinancialEngine.processAdminSetMatchRunning(
      match = matchCoded,
      adminUser = admin,
      currentTime = now,
    )
    assertTrue("Admin can start coded match", runResult is FinancialEngine.AdminMatchResult.Success)
    val runningMatch = (runResult as FinancialEngine.AdminMatchResult.Success).updatedMatch
    assertEquals(MatchStatus.RUNNING.name, runningMatch.status)
    assertEquals(now, runningMatch.startedAt)
    assertEquals(now, runningMatch.updatedAt)

    // Re-running does not overwrite startedAt
    val nextTime = now + 50_000L
    val rerunMatch = runningMatch.copy(status = MatchStatus.CODE_ADDED.name)
    val rerunResult = FinancialEngine.processAdminSetMatchRunning(
      match = rerunMatch,
      adminUser = admin,
      currentTime = nextTime,
    )
    assertTrue(rerunResult is FinancialEngine.AdminMatchResult.Success)
    assertEquals(now, (rerunResult as FinancialEngine.AdminMatchResult.Success).updatedMatch.startedAt)
    assertEquals(nextTime, (rerunResult as FinancialEngine.AdminMatchResult.Success).updatedMatch.updatedAt)

    // Unauthorized user rejected
    val userResult = FinancialEngine.processAdminSetMatchRunning(
      match = matchCoded,
      adminUser = regularUser,
      currentTime = now,
    )
    assertTrue(userResult is FinancialEngine.AdminMatchResult.Failure)
    assertEquals("ERR_UNAUTHORIZED", (userResult as FinancialEngine.AdminMatchResult.Failure).errorCode)
  }

  // 13. Admin secondary mutations: PAUSE, DISABLE, CANCEL
  @Test
  fun testAdminSecondaryMutations_PauseDisableCancel() {
    val now = 1_700_000_000_000L
    val match = MatchEntity(
      matchId = "match_lifecycle",
      status = MatchStatus.AVAILABLE.name,
      updatedAt = now - 1000L,
    )
    val admin = UserEntity(uid = "admin_super", role = "SUPER_ADMIN")
    val normalUser = UserEntity(uid = "normal_user", role = "USER")

    // PAUSE
    val pauseRes = FinancialEngine.processAdminPauseMatch(match, admin, "Weather maintenance", now)
    assertTrue(pauseRes is FinancialEngine.AdminMatchResult.Success)
    val pausedMatch = (pauseRes as FinancialEngine.AdminMatchResult.Success).updatedMatch
    assertEquals(MatchStatus.PAUSED.name, pausedMatch.status)
    assertEquals(now, pausedMatch.updatedAt)

    // DISABLE
    val disableRes = FinancialEngine.processAdminDisableMatch(match, admin, "Rule update", now + 100L)
    assertTrue(disableRes is FinancialEngine.AdminMatchResult.Success)
    val disabledMatch = (disableRes as FinancialEngine.AdminMatchResult.Success).updatedMatch
    assertEquals(MatchStatus.DISABLED.name, disabledMatch.status)
    assertEquals(now + 100L, disabledMatch.updatedAt)

    // CANCEL
    val cancelRes = FinancialEngine.processAdminCancelMatch(match, admin, "Lobby expired", now + 200L)
    assertTrue(cancelRes is FinancialEngine.AdminMatchResult.Success)
    val cancelledMatch = (cancelRes as FinancialEngine.AdminMatchResult.Success).updatedMatch
    assertEquals(MatchStatus.CANCELLED.name, cancelledMatch.status)
    assertEquals(now + 200L, cancelledMatch.updatedAt)

    // Cannot pause or cancel an already CANCELLED match
    val repeatCancel = FinancialEngine.processAdminCancelMatch(cancelledMatch, admin, "Again", now + 300L)
    assertTrue(repeatCancel is FinancialEngine.AdminMatchResult.Failure)
    assertEquals("ERR_INVALID_TRANSITION", (repeatCancel as FinancialEngine.AdminMatchResult.Failure).errorCode)

    // Non-admin authorization check
    val unauthPause = FinancialEngine.processAdminPauseMatch(match, normalUser, "Hack", now)
    assertTrue(unauthPause is FinancialEngine.AdminMatchResult.Failure)
    assertEquals("ERR_UNAUTHORIZED", (unauthPause as FinancialEngine.AdminMatchResult.Failure).errorCode)
  }
}
