package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.core.error.Resource
import com.example.core.security.AuthValidator
import com.example.core.security.PasswordSecurity
import com.example.core.security.SessionManager
import com.example.data.repository.FirebaseAuthRepository
import com.example.domain.model.AccountStatus
import com.example.domain.model.UserEntity
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class AuthFoundationUnitTest {

  private lateinit var context: Context
  private lateinit var sessionManager: SessionManager
  private lateinit var authRepository: FirebaseAuthRepository

  @Before
  fun setup() {
    context = ApplicationProvider.getApplicationContext()
    sessionManager = SessionManager(context)
    sessionManager.clearSession()
    authRepository = FirebaseAuthRepository(sessionManager)
  }

  // =========================================================================
  // 1. MOBILE NUMBER FORMAT & VALIDATION (11 DIGITS, PREFIXES 013 - 019)
  // =========================================================================

  @Test
  fun testMobileValidation_ValidPrefixes_013to019() {
    val validNumbers = listOf(
      "01312345678", // Grameenphone / Skitto
      "01412345678", // Banglalink
      "01512345678", // Teletalk
      "01635003779", // Airtel (User example)
      "01712345678", // Grameenphone
      "01812345678", // Robi
      "01912345678", // Banglalink
    )
    for (num in validNumbers) {
      val res = AuthValidator.validateMobileNumber(num)
      assertTrue("Expected $num to be valid, error: ${res.errorMessage}", res.isValid)
      assertNull("Error message should be null for valid number $num", res.errorMessage)
      assertTrue("PasswordSecurity.isValidMobileNumber should also accept $num", PasswordSecurity.isValidMobileNumber(num))
    }
  }

  @Test
  fun testMobileValidation_Reject10DigitNumbers() {
    val tenDigitNumbers = listOf(
      "1635003779", // Missing leading 0
      "9985003779", // Old format
      "9876543210", // 10-digit Indian format
    )
    for (num in tenDigitNumbers) {
      val res = AuthValidator.validateMobileNumber(num)
      assertFalse("Expected 10-digit number $num to be rejected", res.isValid)
      assertEquals(AuthValidator.ERROR_INVALID_MOBILE, res.errorMessage)
    }
  }

  @Test
  fun testMobileValidation_RejectInvalidLengths() {
    val invalidLengths = listOf(
      "",             // Empty
      "017",          // Too short
      "017123456",    // 9 digits
      "0171234567",   // 10 digits
      "017123456789", // 12 digits
      "0171234567890",// 13 digits
    )
    for (num in invalidLengths) {
      val res = AuthValidator.validateMobileNumber(num)
      assertFalse("Expected length ${num.length} for '$num' to be rejected", res.isValid)
    }
  }

  @Test
  fun testMobileValidation_RejectInvalidPrefixes() {
    val invalidPrefixes = listOf(
      "01012345678", // 010 invalid
      "01112345678", // 011 invalid (Citycell legacy inactive)
      "01212345678", // 012 invalid
      "02012345678", // 020 invalid
      "12345678901", // Starts with 12
      "09912345678", // Starts with 099
    )
    for (num in invalidPrefixes) {
      val res = AuthValidator.validateMobileNumber(num)
      assertFalse("Expected invalid prefix in '$num' to be rejected", res.isValid)
      assertEquals(AuthValidator.ERROR_INVALID_MOBILE, res.errorMessage)
    }
  }

  @Test
  fun testMobileValidation_RejectNonDigits() {
    val nonDigitInputs = listOf(
      "0171234567a",
      "018-1234567",
      "+8801712345",
      "017 1234567",
      "019abcdefgh",
    )
    for (input in nonDigitInputs) {
      val res = AuthValidator.validateMobileNumber(input)
      assertFalse("Expected non-digit input '$input' to be rejected", res.isValid)
    }
  }

  // =========================================================================
  // 2. NORMALIZATION TESTS (11-DIGIT USER INPUT -> 10-DIGIT INTERNAL)
  // =========================================================================

  @Test
  fun testMobileNormalization_StripsLeadingZero() {
    assertEquals("1635003779", AuthValidator.normalizeMobileNumber("01635003779"))
    assertEquals("1712345678", AuthValidator.normalizeMobileNumber("01712345678"))
    assertEquals("1812345678", AuthValidator.normalizeMobileNumber("01812345678"))
    assertEquals("1312345678", AuthValidator.normalizeMobileNumber("01312345678"))
    assertEquals("1412345678", AuthValidator.normalizeMobileNumber("01412345678"))
    assertEquals("1512345678", AuthValidator.normalizeMobileNumber("01512345678"))
    assertEquals("1912345678", AuthValidator.normalizeMobileNumber("01912345678"))
  }

  @Test
  fun testMobileNormalization_AlreadyNormalized() {
    // If already 10 digits without leading zero, keep as is
    assertEquals("1635003779", AuthValidator.normalizeMobileNumber("1635003779"))
  }

  @Test
  fun testMobileNormalization_EmailGeneration() {
    val clean = AuthValidator.normalizeMobileNumber("01635003779")
    val email = "user_$clean@adtournament.local"
    assertEquals("user_1635003779@adtournament.local", email)
  }

  // =========================================================================
  // 3. REGISTRATION VALIDATION (FULL NAME, PASSWORD, CONFIRM PASSWORD)
  // =========================================================================

  @Test
  fun testRegistrationInputValidation() {
    // Password validation tests
    val emptyPass = AuthValidator.validatePassword("")
    assertFalse(emptyPass.isValid)

    val shortPass = AuthValidator.validatePassword("12345")
    assertFalse(shortPass.isValid)

    val validPass = AuthValidator.validatePassword("password123")
    assertTrue(validPass.isValid)

    // Name validation tests
    val emptyName = AuthValidator.validateFullName("")
    assertFalse(emptyName.isValid)

    val invalidName = AuthValidator.validateFullName("User123!")
    assertFalse(invalidName.isValid)

    val validName = AuthValidator.validateFullName("Tanvir Ahmed")
    assertTrue(validName.isValid)

    // Confirm password validation
    val mismatch = AuthValidator.validateConfirmPassword("pass123", "pass456")
    assertFalse(mismatch.isValid)

    val match = AuthValidator.validateConfirmPassword("pass123", "pass123")
    assertTrue(match.isValid)
  }

  // =========================================================================
  // 4. DUPLICATE MOBILE & REGISTRATION HANDLING
  // =========================================================================

  @Test
  fun testDuplicateMobilePrevention() = runBlocking {
    val phone = "01635003779"

    // Simulate registration call with valid 11-digit mobile
    val reg1 = authRepository.registerUser("Tanvir Ahmed", phone, "secretPass12")
    assertTrue("Initial registration succeeds or returns structured resource", reg1 is Resource.Success || reg1 is Resource.Error)

    val duplicatePhoneValidation = AuthValidator.validateMobileNumber(phone)
    assertTrue(duplicatePhoneValidation.isValid)
  }

  // =========================================================================
  // 5. LOGIN INPUT VALIDATION
  // =========================================================================

  @Test
  fun testLoginInputValidation() = runBlocking {
    // Malformed mobile numbers rejected immediately
    val invalidPhoneResult1 = authRepository.loginWithPhone("12345", "validPassword123")
    assertTrue(invalidPhoneResult1 is Resource.Error)

    val invalidPhoneResult2 = authRepository.loginWithPhone("1635003779", "validPassword123") // 10 digits
    assertTrue(invalidPhoneResult2 is Resource.Error)

    // Empty/short password rejected immediately
    val invalidPassResult = authRepository.loginWithPhone("01712345678", "123")
    assertTrue(invalidPassResult is Resource.Error)
  }

  // =========================================================================
  // 6. LOGOUT TERMINATION
  // =========================================================================

  @Test
  fun testLogoutTerminatesSession() = runBlocking {
    val activeUser = UserEntity(
      uid = "USER-TEST-1",
      name = "Active Player",
      mobileNumber = "01712345678",
      joinDate = System.currentTimeMillis(),
      status = AccountStatus.ACTIVE.name,
      profilePhotoUrl = null,
    )
    sessionManager.saveSession(activeUser)
    assertTrue("Session user is logged in", sessionManager.isUserLoggedIn())

    // Trigger Sign Out
    val signOutResult = authRepository.signOut()
    assertTrue(signOutResult is Resource.Success)
    assertFalse("Session is cleared after logout", sessionManager.isUserLoggedIn())
    assertNull("Session user is null after logout", sessionManager.getSessionUser())
  }

  // =========================================================================
  // 7. SESSION RESTORATION
  // =========================================================================

  @Test
  fun testSessionRestoration() {
    val activeUser = UserEntity(
      uid = "USER-ACTIVE-44",
      name = "Tournament Champ",
      mobileNumber = "01812345678",
      joinDate = 1715000000000L,
      status = AccountStatus.ACTIVE.name,
      profilePhotoUrl = "https://example.com/avatar.png",
    )
    sessionManager.saveSession(activeUser)

    val restoredUser = sessionManager.getSessionUser()
    assertNotNull(restoredUser)
    assertEquals("USER-ACTIVE-44", restoredUser?.uid)
    assertEquals("Tournament Champ", restoredUser?.name)
    assertEquals("01812345678", restoredUser?.mobileNumber)
    assertEquals(AccountStatus.ACTIVE.name, restoredUser?.status)
    assertFalse(restoredUser?.isAccountBlocked ?: true)
  }

  // =========================================================================
  // 8. BLOCKED-USER HANDLING
  // =========================================================================

  @Test
  fun testBlockedUserDeniedAccess() {
    val blockedUser = UserEntity(
      uid = "USER-BLOCKED-99",
      name = "Suspended Player",
      mobileNumber = "01912345678",
      joinDate = System.currentTimeMillis(),
      status = AccountStatus.BLOCKED.name,
      accountStatus = AccountStatus.BLOCKED.name,
      isBlocked = true,
    )
    // SessionManager must reject saving or restoring blocked users
    sessionManager.saveSession(blockedUser)
    assertFalse("Blocked user must never be recognized as logged in", sessionManager.isUserLoggedIn())
    assertNull("Blocked user session must be null", sessionManager.getSessionUser())
    assertTrue("User entity correctly marks account as blocked", blockedUser.isAccountBlocked)
  }

  // =========================================================================
  // 9. PROFILE CREATION SCHEMA ENFORCEMENT
  // =========================================================================

  @Test
  fun testProfileEntityConformsToSpecification() {
    val now = System.currentTimeMillis()
    val userProfile = UserEntity(
      uid = "UID-7890",
      name = "Tanvir Ahmed",
      mobileNumber = "01635003779",
      joinDate = now,
      status = AccountStatus.ACTIVE.name,
      profilePhotoUrl = null,
    )

    // Conformance with Phase 1 approved profile fields
    assertEquals("UID-7890", userProfile.uid)
    assertEquals("Tanvir Ahmed", userProfile.name)
    assertEquals("01635003779", userProfile.mobileNumber)
    assertEquals(now, userProfile.joinDate)
    assertEquals(AccountStatus.ACTIVE.name, userProfile.status)
    assertNull(userProfile.profilePhotoUrl)

    // Security compliance checks: Password, passwordHash, and OTP are never members of UserEntity
    val userFields = UserEntity::class.java.declaredFields.map { it.name }
    assertFalse("Plaintext password field must not exist in user profile", userFields.contains("password"))
    assertFalse("Password hash field must not exist in user profile", userFields.contains("passwordHash"))
    assertFalse("OTP field must not exist in user profile", userFields.contains("otp"))
    assertFalse("Salt field must not exist in user profile", userFields.contains("salt"))
  }
}
