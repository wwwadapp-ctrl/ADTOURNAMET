package com.example.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.error.Resource
import com.example.domain.model.AppSettingsEntity
import com.example.domain.model.GameType
import com.example.domain.model.MatchEntity
import com.example.domain.model.MatchStatus
import com.example.domain.repository.MatchRepository
import com.example.domain.repository.SettingsRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class MatchFilterTab(val label: String) {
  AVAILABLE("Available"),
  MY_JOINED("My Joined"),
  UPCOMING("Upcoming"),
  HISTORY("History"),
}

data class HomeUiState(
  val isLoading: Boolean = true,
  val selectedTab: MatchFilterTab = MatchFilterTab.AVAILABLE,
  val selectedGameFilter: GameType? = null,
  val matchesList: List<MatchEntity> = emptyList(),
  val filteredMatches: List<MatchEntity> = emptyList(),
  val errorMessage: String? = null,
  val joinedMatchIds: Set<String> = emptySet(),
  val myJoinedMatches: List<MatchEntity> = emptyList(),
  val appSettings: AppSettingsEntity = AppSettingsEntity(),
)

class HomeViewModel(
  private val matchRepository: MatchRepository,
  private val currentUserId: String,
  private val settingsRepository: SettingsRepository? = null,
) : ViewModel() {

  private val _uiState = MutableStateFlow(HomeUiState())
  val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

  val appSettings: StateFlow<AppSettingsEntity?> = (settingsRepository?.getAppSettings()
    ?: flowOf(Resource.Success(AppSettingsEntity())))
    .map { res ->
      if (res is Resource.Success) res.data else AppSettingsEntity()
    }
    .stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue = AppSettingsEntity()
    )

  private var fetchJob: Job? = null

  init {
    loadMatchesForCurrentTab()
    observeJoinedMatches()
    observeAppSettings()
  }

  private fun observeAppSettings() {
    if (settingsRepository == null) return
    viewModelScope.launch {
      settingsRepository.getAppSettings().collect { res ->
        if (res is Resource.Success) {
          _uiState.value = _uiState.value.copy(appSettings = res.data)
        }
      }
    }
  }

  private fun observeJoinedMatches() {
    viewModelScope.launch {
      matchRepository.getMyJoinedMatches(currentUserId).collect { res ->
        if (res is Resource.Success) {
          val joinedMatches = res.data
          val joinedIds = joinedMatches.map { it.matchId }.toSet()
          _uiState.value = _uiState.value.copy(
            joinedMatchIds = joinedIds,
            myJoinedMatches = joinedMatches,
          )
          if (_uiState.value.selectedTab == MatchFilterTab.AVAILABLE) {
            val updated = mergeAvailableWithJoined(_uiState.value.matchesList, joinedMatches)
            _uiState.value = _uiState.value.copy(
              matchesList = updated,
              filteredMatches = filterMatches(updated, _uiState.value.selectedGameFilter),
            )
          }
        }
      }
    }
  }

  fun setTab(tab: MatchFilterTab) {
    if (_uiState.value.selectedTab == tab) return
    _uiState.value = _uiState.value.copy(selectedTab = tab)
    loadMatchesForCurrentTab()
  }

  fun setGameFilter(gameType: GameType?) {
    _uiState.value = _uiState.value.copy(
      selectedGameFilter = gameType,
      filteredMatches = filterMatches(_uiState.value.matchesList, gameType),
    )
  }

  fun refresh() {
    loadMatchesForCurrentTab()
  }

  fun loadMatchesForCurrentTab() {
    fetchJob?.cancel()
    fetchJob = viewModelScope.launch {
      _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
      val flow = when (_uiState.value.selectedTab) {
        MatchFilterTab.AVAILABLE -> matchRepository.getAvailableMatches(30)
        MatchFilterTab.MY_JOINED -> matchRepository.getMyJoinedMatches(currentUserId)
        MatchFilterTab.UPCOMING -> matchRepository.getUpcomingMatches(30)
        MatchFilterTab.HISTORY -> matchRepository.getMatchHistory(currentUserId, 30)
      }
      flow.collect { resource ->
        when (resource) {
          is Resource.Loading -> {
            _uiState.value = _uiState.value.copy(isLoading = true)
          }
          is Resource.Success -> {
            val rawMatches = resource.data
            val matches = if (_uiState.value.selectedTab == MatchFilterTab.AVAILABLE) {
              mergeAvailableWithJoined(rawMatches, _uiState.value.myJoinedMatches)
            } else {
              rawMatches
            }
            _uiState.value = _uiState.value.copy(
              isLoading = false,
              matchesList = matches,
              filteredMatches = filterMatches(matches, _uiState.value.selectedGameFilter),
              errorMessage = null,
            )
          }
          is Resource.Error -> {
            _uiState.value = _uiState.value.copy(
              isLoading = false,
              errorMessage = resource.error.userMessage,
            )
          }
          is Resource.Idle -> Unit
        }
      }
    }
  }

  private fun mergeAvailableWithJoined(
    availableMatches: List<MatchEntity>,
    joinedMatches: List<MatchEntity>,
  ): List<MatchEntity> {
    if (joinedMatches.isEmpty()) return availableMatches
    val activeJoined = joinedMatches.filter { match ->
      match.status in setOf(
        MatchStatus.AVAILABLE.name,
        MatchStatus.FULL.name,
        MatchStatus.CODE_ADDED.name,
        MatchStatus.RUNNING.name,
      )
    }
    val existingIds = availableMatches.map { it.matchId }.toSet()
    val missingJoined = activeJoined.filter { !existingIds.contains(it.matchId) }
    return availableMatches + missingJoined
  }

  private fun filterMatches(matches: List<MatchEntity>, filter: GameType?): List<MatchEntity> {
    if (filter == null) return matches
    return matches.filter { it.gameType.equals(filter.name, ignoreCase = true) }
  }

  class Factory(
    private val matchRepository: MatchRepository,
    private val currentUserId: String,
    private val settingsRepository: SettingsRepository? = null,
  ) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
      return HomeViewModel(matchRepository, currentUserId, settingsRepository) as T
    }
  }
}
