package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Midnight Esports Background Tokens
val MidnightBgTop = Color(0xFF070B14)
val MidnightBgBottom = Color(0xFF0D1527)
val MidnightNavyCard = Color(0xFF131E3A)
val MidnightNavyBorder = Color(0xFF1F2E4D)
val GoldBorderSubtle = Color(0x26FFB800) // 15% opacity

// Gradients
val MidnightBackgroundGradient = Brush.verticalGradient(
  listOf(MidnightBgTop, MidnightBgBottom)
)

// Electric Amber & Gold CTA Tokens
val ElectricAmberStart = Color(0xFFFFB800)
val ElectricAmberEnd = Color(0xFFFF9100)
val ElectricAmberGradient = Brush.horizontalGradient(
  listOf(ElectricAmberStart, ElectricAmberEnd)
)
val ElectricAmberVerticalGradient = Brush.verticalGradient(
  listOf(ElectricAmberStart, ElectricAmberEnd)
)

// Neon Status Chips
val NeonEmerald = Color(0xFF00E676)
val NeonEmeraldGlow = Color(0x3300E676)
val NeonCyan = Color(0xFF00F2FE)
val NeonCyanGlow = Color(0x3300F2FE)

// Primary App Theme Colors
val DeepNavyBg = Color(0xFF070B14)
val NavyDark = Color(0xFF070B14)
val NavySurface = Color(0xFF0A1122)
val NavyCard = Color(0xFF131E3A)
val NavyCardBorder = Color(0xFF1F2E4D)

val Slate950 = Color(0xFF070B14)
val Slate900 = Color(0xFF0D1527)
val Slate850 = Color(0xFF131E3A)
val Slate800 = Color(0xFF1F2E4D)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate500 = Color(0xFF64748B)
val Slate400 = Color(0xFF94A3B8)
val Slate300 = Color(0xFFCBD5E1)
val Slate200 = Color(0xFFE2E8F0)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)

val Gold400 = Color(0xFFFFB800)
val Gold500 = Color(0xFFFF9100)
val Amber400 = Color(0xFFFFB800)
val Amber500 = Color(0xFFFF9100)
val Amber600 = Color(0xFFD97706)
val Amber700 = Color(0xFFB45309)
val Amber900 = Color(0xFF78350F)

val Indigo950 = Color(0xFF0F0E2A)
val Indigo900 = Color(0xFF1E1B4B)
val Indigo600 = Color(0xFF4F46E5)
val Indigo500 = Color(0xFF6366F1)
val Indigo400 = Color(0xFF818CF8)

val Purple600 = Color(0xFF7C3AED)
val Purple500 = Color(0xFF8B5CF6)
val Purple400 = Color(0xFFA78BFA)
val Blue600 = Color(0xFF2563EB)
val Blue500 = Color(0xFF3B82F6)

val Cyan300 = Color(0xFF67E8F9)
val Cyan400 = Color(0xFF00F2FE)
val Cyan500 = Color(0xFF06B6D4)
val Cyan600 = Color(0xFF0891B2)

val Emerald300 = Color(0xFF6EE7B7)
val Emerald400 = Color(0xFF00E676)
val Emerald500 = Color(0xFF00E676)
val Emerald600 = Color(0xFF059669)
val Emerald900 = Color(0xFF064E3B)

val Rose400 = Color(0xFFFB7185)
val Rose500 = Color(0xFFF43F5E)
val Rose600 = Color(0xFFE11D48)
val Rose900 = Color(0xFF4C0519)

val CardBorder = Color(0xFF1F2E4D)
val GoldGlow = Color(0x33FFB800)
val CyanGlow = Color(0x3300F2FE)
val PurpleGlow = Color(0x338B5CF6)

