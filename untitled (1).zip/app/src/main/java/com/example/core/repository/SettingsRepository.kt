package com.example.core.repository

import com.example.core.config.FirebaseAdminConfig
import com.example.core.model.AppSettingsData
import com.example.core.model.PaymentNumberItem
import com.example.core.model.SuperAdminSession
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.tasks.await
import java.util.UUID

/**
 * Interface for tournament app settings and bKash / Nagad payment number management.
 */
interface SettingsRepository {
    fun observeAppSettings(): Flow<AppSettingsData>
    fun observePaymentNumbers(): Flow<List<PaymentNumberItem>>
    suspend fun savePaymentNumber(item: PaymentNumberItem, adminSession: SuperAdminSession): Result<Unit>
    suspend fun removePaymentNumber(id: String, method: String, number: String, adminSession: SuperAdminSession): Result<Unit>
    suspend fun togglePaymentNumberActive(id: String, isActive: Boolean, adminSession: SuperAdminSession): Result<Unit>
}

/**
 * Production Firebase Realtime Database implementation writing to /appSettings and /auditLogs.
 */
class FirebaseSettingsRepository : SettingsRepository {
    private val database: FirebaseDatabase? = try {
        FirebaseDatabase.getInstance(FirebaseAdminConfig.RTDB_BASE_URL)
    } catch (e: Exception) {
        null
    }

    // Default authoritative seed numbers for offline / initial development
    private val defaultSeedNumbers = listOf(
        PaymentNumberItem(
            id = "seed_bkash_personal",
            method = "bKash",
            number = "01712345678",
            type = "Personal",
            isActive = true,
            instructions = "Send Money (Personal) with User UID / TrxID note",
            updatedAt = System.currentTimeMillis() - 86400000L,
            updatedBy = "Super Admin"
        ),
        PaymentNumberItem(
            id = "seed_nagad_agent",
            method = "Nagad",
            number = "01887654321",
            type = "Agent",
            isActive = true,
            instructions = "Cash Out (Agent) via mobile operator",
            updatedAt = System.currentTimeMillis() - 43200000L,
            updatedBy = "Super Admin"
        ),
        PaymentNumberItem(
            id = "seed_bkash_merchant",
            method = "bKash",
            number = "01990011223",
            type = "Merchant",
            isActive = false,
            instructions = "Make Payment with tournament reference",
            updatedAt = System.currentTimeMillis() - 10000000L,
            updatedBy = "Super Admin"
        )
    )

    private val localInMemoryState = MutableStateFlow(defaultSeedNumbers)

    private fun verifySuperAdmin(adminSession: SuperAdminSession) {
        if (!adminSession.isSuperAdminVerified || adminSession.uid.isBlank()) {
            throw SecurityException("Unauthorized: Settings operations require verified Super Admin session.")
        }
    }

    override fun observeAppSettings(): Flow<AppSettingsData> {
        val db = database ?: return flowOf(
            AppSettingsData(
                bkashNumber = "01712345678",
                bkashType = "Personal",
                nagadNumber = "01887654321",
                nagadType = "Agent",
                paymentNumbers = defaultSeedNumbers
            )
        )

        return callbackFlow {
            val ref = db.getReference(FirebaseAdminConfig.NODE_APP_SETTINGS)
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val bkash = snapshot.child("bkashNumber").value?.toString() ?: ""
                    val bkashType = snapshot.child("bkashType").value?.toString() ?: "Personal"
                    val nagad = snapshot.child("nagadNumber").value?.toString() ?: ""
                    val nagadType = snapshot.child("nagadType").value?.toString() ?: "Personal"
                    val isDepActive = snapshot.child("isDepositActive").getValue(Boolean::class.java) ?: true
                    val isWthActive = snapshot.child("isWithdrawActive").getValue(Boolean::class.java) ?: true
                    val minDep = (snapshot.child("minDepositTaka").value as? Number)?.toLong() ?: 50L
                    val minWth = (snapshot.child("minWithdrawTaka").value as? Number)?.toLong() ?: 100L
                    val banner = snapshot.child("noticeBanner").value?.toString() ?: ""
                    val updated = (snapshot.child("updatedAt").value as? Number)?.toLong() ?: 0L

                    val numbersList = mutableListOf<PaymentNumberItem>()
                    val numbersNode = snapshot.child("paymentNumbers")
                    for (child in numbersNode.children) {
                        val id = child.key ?: child.child("id").value?.toString() ?: UUID.randomUUID().toString()
                        val method = child.child("method").value?.toString() ?: "bKash"
                        val number = child.child("number").value?.toString() ?: ""
                        val type = child.child("type").value?.toString() ?: "Personal"
                        val isActive = child.child("isActive").getValue(Boolean::class.java) ?: true
                        val instructions = child.child("instructions").value?.toString() ?: ""
                        val ts = (child.child("updatedAt").value as? Number)?.toLong() ?: 0L
                        val by = child.child("updatedBy").value?.toString() ?: ""

                        if (number.isNotBlank()) {
                            numbersList.add(
                                PaymentNumberItem(
                                    id = id,
                                    method = method,
                                    number = number,
                                    type = type,
                                    isActive = isActive,
                                    instructions = instructions,
                                    updatedAt = ts,
                                    updatedBy = by
                                )
                            )
                        }
                    }

                    // If empty in remote, supplement with fallback seed list
                    val finalNumbers = if (numbersList.isEmpty()) defaultSeedNumbers else numbersList

                    trySend(
                        AppSettingsData(
                            bkashNumber = if (bkash.isNotBlank()) bkash else finalNumbers.firstOrNull { it.method.equals("bKash", true) && it.isActive }?.number ?: "",
                            bkashType = if (bkash.isNotBlank()) bkashType else finalNumbers.firstOrNull { it.method.equals("bKash", true) && it.isActive }?.type ?: "Personal",
                            nagadNumber = if (nagad.isNotBlank()) nagad else finalNumbers.firstOrNull { it.method.equals("Nagad", true) && it.isActive }?.number ?: "",
                            nagadType = if (nagad.isNotBlank()) nagadType else finalNumbers.firstOrNull { it.method.equals("Nagad", true) && it.isActive }?.type ?: "Agent",
                            paymentNumbers = finalNumbers,
                            isDepositActive = isDepActive,
                            isWithdrawActive = isWthActive,
                            minDepositTaka = minDep,
                            minWithdrawTaka = minWth,
                            noticeBanner = banner,
                            updatedAt = updated
                        )
                    )
                }

                override fun onCancelled(error: DatabaseError) {
                    trySend(
                        AppSettingsData(
                            bkashNumber = "01712345678",
                            bkashType = "Personal",
                            nagadNumber = "01887654321",
                            nagadType = "Agent",
                            paymentNumbers = defaultSeedNumbers
                        )
                    )
                }
            }
            ref.addValueEventListener(listener)
            awaitClose { ref.removeEventListener(listener) }
        }
    }

    override fun observePaymentNumbers(): Flow<List<PaymentNumberItem>> {
        val db = database ?: return localInMemoryState.asStateFlow()

        return callbackFlow {
            val ref = db.getReference(FirebaseAdminConfig.NODE_APP_SETTINGS).child("paymentNumbers")
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val numbersList = mutableListOf<PaymentNumberItem>()
                    for (child in snapshot.children) {
                        val id = child.key ?: child.child("id").value?.toString() ?: ""
                        val method = child.child("method").value?.toString() ?: "bKash"
                        val number = child.child("number").value?.toString() ?: ""
                        val type = child.child("type").value?.toString() ?: "Personal"
                        val isActive = child.child("isActive").getValue(Boolean::class.java) ?: true
                        val instructions = child.child("instructions").value?.toString() ?: ""
                        val ts = (child.child("updatedAt").value as? Number)?.toLong() ?: 0L
                        val by = child.child("updatedBy").value?.toString() ?: ""

                        if (number.isNotBlank()) {
                            numbersList.add(
                                PaymentNumberItem(
                                    id = id,
                                    method = method,
                                    number = number,
                                    type = type,
                                    isActive = isActive,
                                    instructions = instructions,
                                    updatedAt = ts,
                                    updatedBy = by
                                )
                            )
                        }
                    }

                    if (numbersList.isEmpty()) {
                        trySend(localInMemoryState.value)
                    } else {
                        localInMemoryState.value = numbersList
                        trySend(numbersList)
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    trySend(localInMemoryState.value)
                }
            }
            ref.addValueEventListener(listener)
            awaitClose { ref.removeEventListener(listener) }
        }
    }

    override suspend fun savePaymentNumber(
        item: PaymentNumberItem,
        adminSession: SuperAdminSession
    ): Result<Unit> = runCatching {
        verifySuperAdmin(adminSession)
        val cleanNumber = item.number.trim().replace(" ", "").replace("-", "")
        require(cleanNumber.length in 11..14) { "Please enter a valid 11-digit Bangladesh phone number (e.g. 017XXXXXXXX)." }

        val id = if (item.id.isNotBlank()) item.id else "pay_${item.method.lowercase()}_${UUID.randomUUID().toString().take(6)}"
        val now = System.currentTimeMillis()
        val logId = UUID.randomUUID().toString()

        val updatedItem = item.copy(
            id = id,
            number = cleanNumber,
            updatedAt = now,
            updatedBy = adminSession.identifier
        )

        val db = database
        if (db != null) {
            val updates = hashMapOf<String, Any?>(
                "${FirebaseAdminConfig.NODE_APP_SETTINGS}/paymentNumbers/$id" to hashMapOf(
                    "id" to id,
                    "method" to updatedItem.method,
                    "number" to updatedItem.number,
                    "type" to updatedItem.type,
                    "isActive" to updatedItem.isActive,
                    "instructions" to updatedItem.instructions,
                    "updatedAt" to now,
                    "updatedBy" to adminSession.identifier
                ),
                "${FirebaseAdminConfig.NODE_APP_SETTINGS}/updatedAt" to now,
                "${FirebaseAdminConfig.NODE_AUDIT_LOGS}/$logId" to hashMapOf(
                    "action" to "PAYMENT_NUMBER_CONFIGURED",
                    "admin" to adminSession.identifier,
                    "referenceId" to id,
                    "timestamp" to now,
                    "reason" to "Configured ${updatedItem.method} (${updatedItem.type}) number $cleanNumber"
                )
            )

            // Direct sync of top-level keys for User App convenience
            if (updatedItem.method.equals("bKash", true) && updatedItem.isActive) {
                updates["${FirebaseAdminConfig.NODE_APP_SETTINGS}/bkashNumber"] = cleanNumber
                updates["${FirebaseAdminConfig.NODE_APP_SETTINGS}/bkashType"] = updatedItem.type
            } else if (updatedItem.method.equals("Nagad", true) && updatedItem.isActive) {
                updates["${FirebaseAdminConfig.NODE_APP_SETTINGS}/nagadNumber"] = cleanNumber
                updates["${FirebaseAdminConfig.NODE_APP_SETTINGS}/nagadType"] = updatedItem.type
            }

            db.reference.updateChildren(updates).await()
        }

        // Local state update for instant UI feedback
        val current = localInMemoryState.value.toMutableList()
        val index = current.indexOfFirst { it.id == id }
        if (index >= 0) {
            current[index] = updatedItem
        } else {
            current.add(0, updatedItem)
        }
        localInMemoryState.value = current
    }

    override suspend fun removePaymentNumber(
        id: String,
        method: String,
        number: String,
        adminSession: SuperAdminSession
    ): Result<Unit> = runCatching {
        verifySuperAdmin(adminSession)
        val now = System.currentTimeMillis()
        val logId = UUID.randomUUID().toString()

        val db = database
        if (db != null) {
            val updates = hashMapOf<String, Any?>(
                "${FirebaseAdminConfig.NODE_APP_SETTINGS}/paymentNumbers/$id" to null,
                "${FirebaseAdminConfig.NODE_APP_SETTINGS}/updatedAt" to now,
                "${FirebaseAdminConfig.NODE_AUDIT_LOGS}/$logId" to hashMapOf(
                    "action" to "PAYMENT_NUMBER_REMOVED",
                    "admin" to adminSession.identifier,
                    "referenceId" to id,
                    "timestamp" to now,
                    "reason" to "Removed $method payment number $number"
                )
            )
            db.reference.updateChildren(updates).await()
        }

        localInMemoryState.value = localInMemoryState.value.filter { it.id != id }
    }

    override suspend fun togglePaymentNumberActive(
        id: String,
        isActive: Boolean,
        adminSession: SuperAdminSession
    ): Result<Unit> = runCatching {
        verifySuperAdmin(adminSession)
        val target = localInMemoryState.value.find { it.id == id }
        if (target != null) {
            savePaymentNumber(target.copy(isActive = isActive), adminSession).getOrThrow()
        }
    }
}
