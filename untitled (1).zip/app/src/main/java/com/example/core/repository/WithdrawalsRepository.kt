package com.example.core.repository

import com.example.core.config.FirebaseAdminConfig
import com.example.core.model.ActiveWithdrawalReservation
import com.example.core.model.AdminWithdrawalItem
import com.example.core.model.SuperAdminSession
import com.example.core.model.TournamentMath
import com.example.core.model.UserWalletData
import com.example.core.model.WithdrawalStatus
import com.example.core.model.NotificationTargetType
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.MutableData
import com.google.firebase.database.Transaction
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.tasks.await
import java.util.UUID
import kotlin.coroutines.resume

/**
 * Interface defining real-time withdrawal observation and authoritative Super Admin settlement operations.
 */
interface WithdrawalsRepository {
    fun observeWithdrawals(): Flow<List<AdminWithdrawalItem>>
    suspend fun getWithdrawal(withdrawalId: String): AdminWithdrawalItem?
    suspend fun getUserWallet(userId: String): UserWalletData?
    suspend fun approveWithdrawal(withdrawalId: String, adminSession: SuperAdminSession): Result<Unit>
    suspend fun rejectWithdrawal(withdrawalId: String, reason: String, adminSession: SuperAdminSession): Result<Unit>
}

/**
 * Result data holder for wallet transaction settlement.
 */
data class WalletSettlementResult(
    val success: Boolean,
    val isAlreadySettled: Boolean = false,
    val errorMessage: String? = null,
    val settledAmountMinorUnits: Long = 0L,
    val newAvailableBalance: Long = 0L,
    val newPendingBalance: Long = 0L,
    val newTotalWithdrawn: Long = 0L
)

/**
 * Authoritative Firebase Realtime Database implementation for Withdrawal Settlement.
 * Enforces runTransaction on /wallets/{userId}, matching activeWithdrawals reservation verification,
 * atomic multi-path status transitions, idempotency, and audit logging.
 */
class FirebaseWithdrawalsRepository : WithdrawalsRepository {
    private val database: FirebaseDatabase? = try {
        FirebaseDatabase.getInstance(FirebaseAdminConfig.RTDB_BASE_URL)
    } catch (e: Exception) {
        null
    }

    private val localWithdrawalsState = MutableStateFlow<List<AdminWithdrawalItem>>(emptyList())

    private fun verifySuperAdmin(adminSession: SuperAdminSession) {
        if (!adminSession.isSuperAdminVerified || adminSession.uid.isBlank()) {
            throw SecurityException("Unauthorized: Withdrawal settlement operations require verified Super Admin authorization.")
        }
    }

    override fun observeWithdrawals(): Flow<List<AdminWithdrawalItem>> {
        val db = database ?: return localWithdrawalsState.asStateFlow()

        return callbackFlow {
            val ref = db.getReference(FirebaseAdminConfig.NODE_WITHDRAWALS)
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val parsedList = mutableListOf<AdminWithdrawalItem>()
                    for (child in snapshot.children) {
                        try {
                            val withdrawalId = child.key ?: child.child("withdrawalId").value?.toString() ?: continue
                            val userId = child.child("userId").value?.toString()
                                ?: child.child("uid").value?.toString()
                                ?: ""

                            val rawAmount = (child.child("amount").value as? Number)?.toLong() ?: 0L
                            val rawAmountMinor = (child.child("amountMinorUnits").value as? Number)?.toLong()
                                ?: if (rawAmount > 0L) TournamentMath.takaToMinorUnits(rawAmount) else 0L

                            val amountInTaka = if (rawAmount > 0L) rawAmount else rawAmountMinor / 100L

                            val method = child.child("method").value?.toString()
                                ?: child.child("paymentMethod").value?.toString()
                                ?: "bKash"

                            val recipientNumber = child.child("recipientNumber").value?.toString()
                                ?: child.child("receiverNumber").value?.toString()
                                ?: child.child("accountNumber").value?.toString()
                                ?: ""

                            val statusStr = child.child("status").value?.toString()
                            val status = WithdrawalStatus.fromString(statusStr)

                            val createdAt = (child.child("createdAt").value as? Number)?.toLong()
                                ?: (child.child("timestamp").value as? Number)?.toLong()
                                ?: 0L

                            val processedAt = (child.child("processedAt").value as? Number)?.toLong()
                            val rejectionReason = child.child("rejectionReason").value?.toString()
                            val adminUid = child.child("adminUid").value?.toString()
                                ?: child.child("processedBy").value?.toString()

                            val transactionId = child.child("transactionId").value?.toString()
                                ?: child.child("trxId").value?.toString()
                                ?: ""

                            parsedList.add(
                                AdminWithdrawalItem(
                                    withdrawalId = withdrawalId,
                                    userId = userId,
                                    amount = amountInTaka,
                                    amountMinorUnits = rawAmountMinor,
                                    method = method,
                                    recipientNumber = recipientNumber,
                                    status = status,
                                    createdAt = createdAt,
                                    processedAt = processedAt,
                                    rejectionReason = rejectionReason,
                                    adminUid = adminUid,
                                    transactionId = transactionId
                                )
                            )
                        } catch (_: Exception) {
                        }
                    }

                    // Sort newest requests first
                    parsedList.sortByDescending { it.createdAt }
                    localWithdrawalsState.value = parsedList
                    trySend(parsedList)
                }

                override fun onCancelled(error: DatabaseError) {
                    trySend(localWithdrawalsState.value)
                }
            }

            ref.addValueEventListener(listener)
            awaitClose { ref.removeEventListener(listener) }
        }
    }

    override suspend fun getWithdrawal(withdrawalId: String): AdminWithdrawalItem? {
        val db = database ?: return localWithdrawalsState.value.find { it.withdrawalId == withdrawalId }
        return try {
            val snap = db.getReference(FirebaseAdminConfig.NODE_WITHDRAWALS).child(withdrawalId).get().await()
            if (!snap.exists()) return null

            val userId = snap.child("userId").value?.toString()
                ?: snap.child("uid").value?.toString()
                ?: ""

            val rawAmount = (snap.child("amount").value as? Number)?.toLong() ?: 0L
            val rawAmountMinor = (snap.child("amountMinorUnits").value as? Number)?.toLong()
                ?: if (rawAmount > 0L) TournamentMath.takaToMinorUnits(rawAmount) else 0L

            val amountInTaka = if (rawAmount > 0L) rawAmount else rawAmountMinor / 100L

            val method = snap.child("method").value?.toString()
                ?: snap.child("paymentMethod").value?.toString()
                ?: "bKash"

            val recipientNumber = snap.child("recipientNumber").value?.toString()
                ?: snap.child("receiverNumber").value?.toString()
                ?: ""

            val statusStr = snap.child("status").value?.toString()
            val status = WithdrawalStatus.fromString(statusStr)

            val createdAt = (snap.child("createdAt").value as? Number)?.toLong() ?: 0L
            val processedAt = (snap.child("processedAt").value as? Number)?.toLong()
            val rejectionReason = snap.child("rejectionReason").value?.toString()
            val adminUid = snap.child("adminUid").value?.toString()
                ?: snap.child("processedBy").value?.toString()
            val transactionId = snap.child("transactionId").value?.toString() ?: ""

            AdminWithdrawalItem(
                withdrawalId = withdrawalId,
                userId = userId,
                amount = amountInTaka,
                amountMinorUnits = rawAmountMinor,
                method = method,
                recipientNumber = recipientNumber,
                status = status,
                createdAt = createdAt,
                processedAt = processedAt,
                rejectionReason = rejectionReason,
                adminUid = adminUid,
                transactionId = transactionId
            )
        } catch (_: Exception) {
            localWithdrawalsState.value.find { it.withdrawalId == withdrawalId }
        }
    }

    override suspend fun getUserWallet(userId: String): UserWalletData? {
        val db = database ?: return null
        return try {
            val snap = db.getReference(FirebaseAdminConfig.NODE_WALLETS).child(userId).get().await()
            if (!snap.exists()) return null

            val bal = (snap.child("balance").value as? Number)?.toLong() ?: 0L
            val avail = (snap.child("availableBalance").value as? Number)?.toLong() ?: bal
            val dep = (snap.child("depositBalance").value as? Number)?.toLong() ?: 0L
            val win = (snap.child("winningBalance").value as? Number)?.toLong() ?: 0L
            val pending = (snap.child("pendingBalance").value as? Number)?.toLong() ?: 0L
            val totalDeposited = (snap.child("totalDeposited").value as? Number)?.toLong() ?: 0L
            val totalWithdrawn = (snap.child("totalWithdrawn").value as? Number)?.toLong() ?: 0L
            val balDouble = (snap.child("balance").value as? Number)?.toDouble() ?: (avail / 100.0)
            val lockedDouble = (snap.child("lockedBalance").value as? Number)?.toDouble() ?: (pending / 100.0)
            val updated = (snap.child("updatedAt").value as? Number)?.toLong() ?: 0L

            val reservations = mutableMapOf<String, ActiveWithdrawalReservation>()
            val activeSnap = snap.child("activeWithdrawals")
            for (child in activeSnap.children) {
                val wid = child.key ?: continue
                val amtMinor = (child.child("amountMinorUnits").value as? Number)?.toLong()
                    ?: (child.child("amount").value as? Number)?.toLong()?.let { TournamentMath.takaToMinorUnits(it) }
                    ?: 0L
                val stat = child.child("status").value?.toString() ?: "REQUESTED"
                val trx = child.child("transactionId").value?.toString() ?: ""
                val created = (child.child("createdAt").value as? Number)?.toLong() ?: 0L
                reservations[wid] = ActiveWithdrawalReservation(
                    withdrawalId = wid,
                    amountMinorUnits = amtMinor,
                    status = stat,
                    transactionId = trx,
                    createdAt = created
                )
            }

            UserWalletData(
                userId = userId,
                balance = bal,
                availableBalance = avail,
                depositBalance = dep,
                winningBalance = win,
                pendingBalance = pending,
                totalDeposited = totalDeposited,
                totalWithdrawn = totalWithdrawn,
                balanceDouble = balDouble,
                lockedBalanceDouble = lockedDouble,
                activeWithdrawals = reservations,
                updatedAt = updated
            )
        } catch (_: Exception) {
            null
        }
    }

    override suspend fun approveWithdrawal(
        withdrawalId: String,
        adminSession: SuperAdminSession
    ): Result<Unit> {
        return try {
            verifySuperAdmin(adminSession)

            // Step 1: Fetch and verify withdrawal record
            val withdrawal = getWithdrawal(withdrawalId)
                ?: return Result.failure(IllegalArgumentException("Withdrawal with ID '$withdrawalId' does not exist."))

            if (!withdrawal.isActionable) {
                return Result.failure(IllegalStateException("Withdrawal is already in '${withdrawal.status}' status and cannot be approved."))
            }

            if (withdrawal.userId.isBlank()) {
                return Result.failure(IllegalArgumentException("Withdrawal is missing valid userId."))
            }

            val requiredAmountMinor = if (withdrawal.amountMinorUnits > 0L) {
                withdrawal.amountMinorUnits
            } else {
                TournamentMath.takaToMinorUnits(withdrawal.amount)
            }

            if (requiredAmountMinor <= 0L) {
                return Result.failure(IllegalArgumentException("Withdrawal amount must be strictly greater than 0."))
            }

            val db = database ?: return Result.failure(IllegalStateException("Firebase Realtime Database instance unavailable."))

            // Step 2: Atomic wallet settlement via runTransaction on /wallets/{userId}
            val walletRef = db.getReference(FirebaseAdminConfig.NODE_WALLETS).child(withdrawal.userId)
            val settlementResult = executeWalletApprovalTransaction(
                walletRef = walletRef,
                withdrawalId = withdrawalId,
                requiredAmountMinor = requiredAmountMinor
            )

            if (!settlementResult.success) {
                return Result.failure(IllegalStateException(settlementResult.errorMessage ?: "Wallet settlement failed."))
            }

            // Step 3: Write metadata, status, ledger, and audit updates
            val now = System.currentTimeMillis()
            val finalTrxId = if (withdrawal.transactionId.isNotBlank()) {
                withdrawal.transactionId
            } else {
                "WTRX-${UUID.randomUUID().toString().take(8).uppercase()}"
            }
            val logId = "AUDIT-${UUID.randomUUID().toString().take(8).uppercase()}"
            val amountTaka = requiredAmountMinor / 100L

            val updates = hashMapOf<String, Any?>(
                // 1. Update /withdrawals/{withdrawalId}
                "${FirebaseAdminConfig.NODE_WITHDRAWALS}/$withdrawalId/status" to WithdrawalStatus.COMPLETED.name,
                "${FirebaseAdminConfig.NODE_WITHDRAWALS}/$withdrawalId/processedAt" to now,
                "${FirebaseAdminConfig.NODE_WITHDRAWALS}/$withdrawalId/adminUid" to adminSession.uid,
                "${FirebaseAdminConfig.NODE_WITHDRAWALS}/$withdrawalId/processedBy" to adminSession.identifier,
                "${FirebaseAdminConfig.NODE_WITHDRAWALS}/$withdrawalId/transactionId" to finalTrxId,
                "${FirebaseAdminConfig.NODE_WITHDRAWALS}/$withdrawalId/updatedAt" to now,

                // 2. Update /userWithdrawals/{userId}/{withdrawalId}
                "${FirebaseAdminConfig.NODE_USER_WITHDRAWALS}/${withdrawal.userId}/$withdrawalId/status" to WithdrawalStatus.COMPLETED.name,
                "${FirebaseAdminConfig.NODE_USER_WITHDRAWALS}/${withdrawal.userId}/$withdrawalId/processedAt" to now,
                "${FirebaseAdminConfig.NODE_USER_WITHDRAWALS}/${withdrawal.userId}/$withdrawalId/transactionId" to finalTrxId,
                "${FirebaseAdminConfig.NODE_USER_WITHDRAWALS}/${withdrawal.userId}/$withdrawalId/updatedAt" to now,

                // 3. Write /transactions/{finalTrxId}
                "${FirebaseAdminConfig.NODE_TRANSACTIONS}/$finalTrxId" to hashMapOf(
                    "transactionId" to finalTrxId,
                    "withdrawalId" to withdrawalId,
                    "userId" to withdrawal.userId,
                    "amount" to amountTaka,
                    "amountMinorUnits" to requiredAmountMinor,
                    "type" to "WITHDRAW",
                    "direction" to "DEBIT",
                    "status" to "COMPLETED",
                    "paymentMethod" to withdrawal.method,
                    "recipientNumber" to withdrawal.recipientNumber,
                    "timestamp" to now,
                    "processedBy" to adminSession.identifier,
                    "description" to "Withdrawal of ৳$amountTaka approved and disbursed via ${withdrawal.method}"
                ),

                // 4. Write /userTransactions/{userId}/{finalTrxId}
                "${FirebaseAdminConfig.NODE_USER_TRANSACTIONS}/${withdrawal.userId}/$finalTrxId" to hashMapOf(
                    "transactionId" to finalTrxId,
                    "withdrawalId" to withdrawalId,
                    "amount" to amountTaka,
                    "amountMinorUnits" to requiredAmountMinor,
                    "type" to "WITHDRAW",
                    "direction" to "DEBIT",
                    "status" to "COMPLETED",
                    "paymentMethod" to withdrawal.method,
                    "recipientNumber" to withdrawal.recipientNumber,
                    "timestamp" to now,
                    "description" to "Withdrawal payout of ৳$amountTaka disbursed to ${withdrawal.recipientNumber}"
                ),

                // 5. Write /auditLogs/{logId}
                "${FirebaseAdminConfig.NODE_AUDIT_LOGS}/$logId" to hashMapOf(
                    "action" to "WITHDRAWAL_APPROVED",
                    "admin" to adminSession.identifier,
                    "referenceId" to withdrawalId,
                    "timestamp" to now,
                    "reason" to "Super Admin approved withdrawal payout of ৳$amountTaka to ${withdrawal.recipientNumber} (${withdrawal.method})",
                    "amount" to amountTaka,
                    "amountMinorUnits" to requiredAmountMinor,
                    "userId" to withdrawal.userId,
                    "transactionId" to finalTrxId
                )
            )

            try {
                db.reference.updateChildren(updates).await()
            } catch (e: Exception) {
                // Two-phase failure recovery: the wallet reservation was already consumed.
                // Do NOT rollback or refund wallet. Log the error and return failure indicating status update failure.
                return Result.failure(
                    IllegalStateException(
                        "Wallet reservation successfully consumed, but status/ledger update failed: ${e.localizedMessage}. Do NOT re-approve."
                    )
                )
            }

            sendWithdrawalNotification(
                userId = withdrawal.userId,
                title = "Withdrawal Approved / পেমেন্ট অনুমোদিত",
                message = "Your withdrawal request of ৳$amountTaka has been approved and disbursed.",
                adminSession = adminSession
            )

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun rejectWithdrawal(
        withdrawalId: String,
        reason: String,
        adminSession: SuperAdminSession
    ): Result<Unit> {
        return try {
            verifySuperAdmin(adminSession)

            val trimmedReason = reason.trim()
            if (trimmedReason.isBlank()) {
                return Result.failure(IllegalArgumentException("Rejection reason cannot be blank. An explanatory audit reason is required."))
            }

            // Step 1: Fetch and verify withdrawal record
            val withdrawal = getWithdrawal(withdrawalId)
                ?: return Result.failure(IllegalArgumentException("Withdrawal with ID '$withdrawalId' does not exist."))

            if (!withdrawal.isActionable) {
                return Result.failure(IllegalStateException("Withdrawal is already in '${withdrawal.status}' status and cannot be rejected."))
            }

            if (withdrawal.userId.isBlank()) {
                return Result.failure(IllegalArgumentException("Withdrawal is missing valid userId."))
            }

            val requiredAmountMinor = if (withdrawal.amountMinorUnits > 0L) {
                withdrawal.amountMinorUnits
            } else {
                TournamentMath.takaToMinorUnits(withdrawal.amount)
            }

            if (requiredAmountMinor <= 0L) {
                return Result.failure(IllegalArgumentException("Withdrawal amount must be strictly greater than 0."))
            }

            val db = database ?: return Result.failure(IllegalStateException("Firebase Realtime Database instance unavailable."))

            // Step 2: Atomic wallet reservation release via runTransaction on /wallets/{userId}
            val walletRef = db.getReference(FirebaseAdminConfig.NODE_WALLETS).child(withdrawal.userId)
            val settlementResult = executeWalletRejectionTransaction(
                walletRef = walletRef,
                withdrawalId = withdrawalId,
                requiredAmountMinor = requiredAmountMinor
            )

            if (!settlementResult.success) {
                return Result.failure(IllegalStateException(settlementResult.errorMessage ?: "Wallet release failed."))
            }

            // Step 3: Write metadata, status, ledger, and audit updates
            val now = System.currentTimeMillis()
            val finalTrxId = if (withdrawal.transactionId.isNotBlank()) {
                withdrawal.transactionId
            } else {
                "WREL-${UUID.randomUUID().toString().take(8).uppercase()}"
            }
            val logId = "AUDIT-${UUID.randomUUID().toString().take(8).uppercase()}"
            val amountTaka = requiredAmountMinor / 100L

            val updates = hashMapOf<String, Any?>(
                // 1. Update /withdrawals/{withdrawalId}
                "${FirebaseAdminConfig.NODE_WITHDRAWALS}/$withdrawalId/status" to WithdrawalStatus.REJECTED.name,
                "${FirebaseAdminConfig.NODE_WITHDRAWALS}/$withdrawalId/rejectionReason" to trimmedReason,
                "${FirebaseAdminConfig.NODE_WITHDRAWALS}/$withdrawalId/processedAt" to now,
                "${FirebaseAdminConfig.NODE_WITHDRAWALS}/$withdrawalId/adminUid" to adminSession.uid,
                "${FirebaseAdminConfig.NODE_WITHDRAWALS}/$withdrawalId/processedBy" to adminSession.identifier,
                "${FirebaseAdminConfig.NODE_WITHDRAWALS}/$withdrawalId/transactionId" to finalTrxId,
                "${FirebaseAdminConfig.NODE_WITHDRAWALS}/$withdrawalId/updatedAt" to now,

                // 2. Update /userWithdrawals/{userId}/{withdrawalId}
                "${FirebaseAdminConfig.NODE_USER_WITHDRAWALS}/${withdrawal.userId}/$withdrawalId/status" to WithdrawalStatus.REJECTED.name,
                "${FirebaseAdminConfig.NODE_USER_WITHDRAWALS}/${withdrawal.userId}/$withdrawalId/rejectionReason" to trimmedReason,
                "${FirebaseAdminConfig.NODE_USER_WITHDRAWALS}/${withdrawal.userId}/$withdrawalId/processedAt" to now,
                "${FirebaseAdminConfig.NODE_USER_WITHDRAWALS}/${withdrawal.userId}/$withdrawalId/transactionId" to finalTrxId,
                "${FirebaseAdminConfig.NODE_USER_WITHDRAWALS}/${withdrawal.userId}/$withdrawalId/updatedAt" to now,

                // 3. Write /transactions/{finalTrxId}
                "${FirebaseAdminConfig.NODE_TRANSACTIONS}/$finalTrxId" to hashMapOf(
                    "transactionId" to finalTrxId,
                    "withdrawalId" to withdrawalId,
                    "userId" to withdrawal.userId,
                    "amount" to amountTaka,
                    "amountMinorUnits" to requiredAmountMinor,
                    "type" to "WITHDRAW_RELEASE",
                    "direction" to "CREDIT",
                    "status" to "COMPLETED",
                    "paymentMethod" to withdrawal.method,
                    "recipientNumber" to withdrawal.recipientNumber,
                    "timestamp" to now,
                    "processedBy" to adminSession.identifier,
                    "rejectionReason" to trimmedReason,
                    "description" to "Withdrawal hold of ৳$amountTaka released back to available balance. Reason: $trimmedReason"
                ),

                // 4. Write /userTransactions/{userId}/{finalTrxId}
                "${FirebaseAdminConfig.NODE_USER_TRANSACTIONS}/${withdrawal.userId}/$finalTrxId" to hashMapOf(
                    "transactionId" to finalTrxId,
                    "withdrawalId" to withdrawalId,
                    "amount" to amountTaka,
                    "amountMinorUnits" to requiredAmountMinor,
                    "type" to "WITHDRAW_RELEASE",
                    "direction" to "CREDIT",
                    "status" to "COMPLETED",
                    "paymentMethod" to withdrawal.method,
                    "recipientNumber" to withdrawal.recipientNumber,
                    "timestamp" to now,
                    "rejectionReason" to trimmedReason,
                    "description" to "Withdrawal hold of ৳$amountTaka refunded to available balance. Reason: $trimmedReason"
                ),

                // 5. Write /auditLogs/{logId}
                "${FirebaseAdminConfig.NODE_AUDIT_LOGS}/$logId" to hashMapOf(
                    "action" to "WITHDRAWAL_REJECTED",
                    "admin" to adminSession.identifier,
                    "referenceId" to withdrawalId,
                    "timestamp" to now,
                    "reason" to "Super Admin rejected withdrawal of ৳$amountTaka. Reason: $trimmedReason",
                    "amount" to amountTaka,
                    "amountMinorUnits" to requiredAmountMinor,
                    "userId" to withdrawal.userId,
                    "rejectionReason" to trimmedReason,
                    "transactionId" to finalTrxId
                )
            )

            try {
                db.reference.updateChildren(updates).await()
            } catch (e: Exception) {
                // Two-phase failure recovery: the wallet reservation was already released.
                return Result.failure(
                    IllegalStateException(
                        "Wallet reservation successfully released, but status/ledger update failed: ${e.localizedMessage}. Do NOT re-reject."
                    )
                )
            }

            sendWithdrawalNotification(
                userId = withdrawal.userId,
                title = "Withdrawal Rejected / পেমেন্ট বাতিল",
                message = "Your withdrawal request of ৳$amountTaka has been rejected. Reason: $trimmedReason",
                adminSession = adminSession
            )

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private suspend fun executeWalletApprovalTransaction(
        walletRef: com.google.firebase.database.DatabaseReference,
        withdrawalId: String,
        requiredAmountMinor: Long
    ): WalletSettlementResult = suspendCancellableCoroutine { continuation ->
        walletRef.runTransaction(object : Transaction.Handler {
            var failureMessage: String? = null
            var resultHolder: WalletSettlementResult? = null

            override fun doTransaction(currentData: MutableData): Transaction.Result {
                if (currentData.value == null) {
                    failureMessage = "Wallet record does not exist."
                    return Transaction.abort()
                }

                // 1. Verify activeWithdrawals/{withdrawalId} exists or fallback to verifying pending balance
                val reservationNode = currentData.child("activeWithdrawals").child(withdrawalId)
                val hasReservation = reservationNode.value != null

                val resAmountMinor = if (hasReservation) {
                    (reservationNode.child("amountMinorUnits").value as? Number)?.toLong()
                        ?: (reservationNode.child("amount").value as? Number)?.toLong()?.let { TournamentMath.takaToMinorUnits(it) }
                        ?: requiredAmountMinor
                } else {
                    requiredAmountMinor
                }

                if (hasReservation && resAmountMinor != requiredAmountMinor) {
                    failureMessage = "Reservation amount mismatch: expected $requiredAmountMinor minor units but found $resAmountMinor in wallet reservation."
                    return Transaction.abort()
                }

                // 3. Read current wallet balances
                val currentPending = (currentData.child("pendingBalance").value as? Number)?.toLong() ?: 0L
                val currentAvail = (currentData.child("availableBalance").value as? Number)?.toLong()
                    ?: (currentData.child("balance").value as? Number)?.toLong()
                    ?: 0L
                val currentTotalWithdrawn = (currentData.child("totalWithdrawn").value as? Number)?.toLong() ?: 0L

                // 4. Require pendingBalance >= amountMinorUnits (or allow fallback if pending is at least required)
                if (currentPending < requiredAmountMinor) {
                    failureMessage = "Insufficient pendingBalance in wallet: has $currentPending, required $requiredAmountMinor."
                    return Transaction.abort()
                }

                // 5. Calculate new balances
                val newPending = currentPending - requiredAmountMinor
                val newTotalWithdrawn = currentTotalWithdrawn + requiredAmountMinor

                // 6. Available balance remains unchanged
                // 7. Synchronize Double representation fields: balance and lockedBalance
                val syncBalanceDouble = currentAvail / 100.0
                val syncLockedBalanceDouble = newPending / 100.0

                currentData.child("pendingBalance").value = newPending
                currentData.child("totalWithdrawn").value = newTotalWithdrawn
                currentData.child("balance").value = syncBalanceDouble
                currentData.child("lockedBalance").value = syncLockedBalanceDouble
                currentData.child("updatedAt").value = System.currentTimeMillis()

                // 8. Remove activeWithdrawals/{withdrawalId} if present
                if (hasReservation) {
                    reservationNode.value = null
                }

                resultHolder = WalletSettlementResult(
                    success = true,
                    settledAmountMinorUnits = requiredAmountMinor,
                    newAvailableBalance = currentAvail,
                    newPendingBalance = newPending,
                    newTotalWithdrawn = newTotalWithdrawn
                )

                return Transaction.success(currentData)
            }

            override fun onComplete(
                error: DatabaseError?,
                committed: Boolean,
                currentData: DataSnapshot?
            ) {
                if (committed && error == null) {
                    val res = resultHolder ?: WalletSettlementResult(success = true)
                    continuation.resume(res)
                } else {
                    val err = error?.message ?: failureMessage ?: "Transaction aborted or conflicted."
                    continuation.resume(
                        WalletSettlementResult(
                            success = false,
                            errorMessage = err
                        )
                    )
                }
            }
        })
    }

    private suspend fun executeWalletRejectionTransaction(
        walletRef: com.google.firebase.database.DatabaseReference,
        withdrawalId: String,
        requiredAmountMinor: Long
    ): WalletSettlementResult = suspendCancellableCoroutine { continuation ->
        walletRef.runTransaction(object : Transaction.Handler {
            var failureMessage: String? = null
            var resultHolder: WalletSettlementResult? = null

            override fun doTransaction(currentData: MutableData): Transaction.Result {
                if (currentData.value == null) {
                    failureMessage = "Wallet record does not exist."
                    return Transaction.abort()
                }

                // 1. Verify activeWithdrawals/{withdrawalId} exists or fallback to verifying pending balance
                val reservationNode = currentData.child("activeWithdrawals").child(withdrawalId)
                val hasReservation = reservationNode.value != null

                val resAmountMinor = if (hasReservation) {
                    (reservationNode.child("amountMinorUnits").value as? Number)?.toLong()
                        ?: (reservationNode.child("amount").value as? Number)?.toLong()?.let { TournamentMath.takaToMinorUnits(it) }
                        ?: requiredAmountMinor
                } else {
                    requiredAmountMinor
                }

                if (hasReservation && resAmountMinor != requiredAmountMinor) {
                    failureMessage = "Reservation amount mismatch: expected $requiredAmountMinor minor units but found $resAmountMinor in wallet reservation."
                    return Transaction.abort()
                }

                // 3. Read current wallet balances
                val currentPending = (currentData.child("pendingBalance").value as? Number)?.toLong() ?: 0L
                val currentAvail = (currentData.child("availableBalance").value as? Number)?.toLong()
                    ?: (currentData.child("balance").value as? Number)?.toLong()
                    ?: 0L
                val currentTotalWithdrawn = (currentData.child("totalWithdrawn").value as? Number)?.toLong() ?: 0L

                // 4. Require pendingBalance >= requiredAmountMinor
                if (currentPending < requiredAmountMinor) {
                    failureMessage = "Insufficient pendingBalance in wallet: has $currentPending, required $requiredAmountMinor."
                    return Transaction.abort()
                }

                // 5. Calculate new balances (release back to availableBalance)
                val newAvail = currentAvail + requiredAmountMinor
                val newPending = currentPending - requiredAmountMinor

                // 6. totalWithdrawn unchanged
                // 7. Synchronize Double fields: balance and lockedBalance
                val syncBalanceDouble = newAvail / 100.0
                val syncLockedBalanceDouble = newPending / 100.0

                currentData.child("availableBalance").value = newAvail
                currentData.child("pendingBalance").value = newPending
                currentData.child("balance").value = syncBalanceDouble
                currentData.child("lockedBalance").value = syncLockedBalanceDouble
                currentData.child("updatedAt").value = System.currentTimeMillis()

                // 8. Remove activeWithdrawals/{withdrawalId} if present
                if (hasReservation) {
                    reservationNode.value = null
                }

                resultHolder = WalletSettlementResult(
                    success = true,
                    settledAmountMinorUnits = requiredAmountMinor,
                    newAvailableBalance = newAvail,
                    newPendingBalance = newPending,
                    newTotalWithdrawn = currentTotalWithdrawn
                )

                return Transaction.success(currentData)
            }

            override fun onComplete(
                error: DatabaseError?,
                committed: Boolean,
                currentData: DataSnapshot?
            ) {
                if (committed && error == null) {
                    val res = resultHolder ?: WalletSettlementResult(success = true)
                    continuation.resume(res)
                } else {
                    val err = error?.message ?: failureMessage ?: "Transaction aborted or conflicted."
                    continuation.resume(
                        WalletSettlementResult(
                            success = false,
                            errorMessage = err
                        )
                    )
                }
            }
        })
    }

    private suspend fun sendWithdrawalNotification(
        userId: String,
        title: String,
        message: String,
        adminSession: SuperAdminSession
    ) {
        try {
            val notifRepo = FirebaseNotificationsRepository()
            val result = notifRepo.sendNotification(
                title = title,
                message = message,
                targetType = NotificationTargetType.SPECIFIC_USER,
                targetId = userId,
                adminSession = adminSession
            )
            if (result.isFailure) {
                android.util.Log.e("WithdrawalsRepository", "Failed to send withdrawal notification: ${result.exceptionOrNull()?.message}", result.exceptionOrNull())
            }
        } catch (e: Exception) {
            android.util.Log.e("WithdrawalsRepository", "Exception sending withdrawal notification", e)
        }
    }
}
