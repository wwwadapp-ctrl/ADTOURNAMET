package com.example.core.repository

import com.example.core.config.FirebaseAdminConfig
import com.example.core.model.AdminMatchItem
import com.example.core.model.AutoBatchMatchRequest
import com.example.core.model.BulkMatchRequest
import com.example.core.model.CreateMatchRequest
import com.example.core.model.MatchPlayerDetails
import com.example.core.model.MatchStatus
import com.example.core.model.NotificationTargetType
import com.example.core.model.SuperAdminSession
import com.example.core.model.TournamentMath
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.tasks.await
import java.util.UUID

/**
 * Interface defining real-time match data observation and Super Admin match operations.
 */
interface MatchesRepository {
    fun observeMatches(): Flow<List<AdminMatchItem>>
    fun observeMatchPlayers(matchId: String): Flow<List<MatchPlayerDetails>>
    suspend fun setMatchGameCode(matchId: String, gameCode: String, adminSession: SuperAdminSession): Result<Unit>
    suspend fun releaseMatch(matchId: String, adminSession: SuperAdminSession): Result<Unit>
    suspend fun updateMatchStatus(matchId: String, newStatus: MatchStatus, reason: String, adminSession: SuperAdminSession): Result<Unit>
    suspend fun createSingleMatch(request: CreateMatchRequest, adminSession: SuperAdminSession): Result<String>
    suspend fun createBulkMatches(request: BulkMatchRequest, adminSession: SuperAdminSession): Result<List<String>>
    suspend fun createAutoBatchMatches(request: AutoBatchMatchRequest, adminSession: SuperAdminSession): Result<List<String>>
    suspend fun deleteMatchPermanently(matchId: String, adminSession: SuperAdminSession): Result<Unit>
}

/**
 * Authoritative Firebase Realtime Database implementation for Matches Management.
 * Communicates with the established /matches, /matchPlayers, and /auditLogs nodes.
 */
class FirebaseMatchesRepository : MatchesRepository {
    private val database: FirebaseDatabase? = try {
        FirebaseDatabase.getInstance(FirebaseAdminConfig.RTDB_BASE_URL)
    } catch (e: Exception) {
        null
    }

    private fun verifySuperAdmin(adminSession: SuperAdminSession) {
        if (!adminSession.isSuperAdminVerified || adminSession.uid.isBlank()) {
            throw SecurityException("Unauthorized: Match operations require verified Super Admin authorization.")
        }
    }

    override fun observeMatches(): Flow<List<AdminMatchItem>> {
        val db = database ?: return flowOf(emptyList())
        return callbackFlow {
            val ref = db.getReference(FirebaseAdminConfig.NODE_MATCHES)
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val matches = mutableListOf<AdminMatchItem>()
                    for (child in snapshot.children) {
                        try {
                            val id = child.key ?: continue
                            val matchNumber = child.child("matchNumber").value?.toString()
                                ?: child.child("match_number").value?.toString()
                                ?: "#${id.takeLast(4).uppercase()}"
                            val title = child.child("title").value?.toString()
                                ?: "Tournament 1v1 $matchNumber"
                            val rawGame = child.child("gameType").value?.toString()
                                ?: child.child("game").value?.toString()
                                ?: "LUDO"
                            val canonicalGame = if (rawGame.contains("carrom", ignoreCase = true)) "CARROM" else "LUDO"
                            val rawEntryFee = (child.child("entryFee").value as? Number)?.toDouble()
                                ?: (child.child("entry_fee").value as? Number)?.toDouble()
                                ?: 0.0
                            val rawPrizePool = (child.child("prizePool").value as? Number)?.toDouble()
                                ?: (child.child("prize_pool").value as? Number)?.toDouble()
                                ?: (child.child("prize").value as? Number)?.toDouble()
                                ?: 0.0
                            
                            val entryFee = rawEntryFee / 100.0
                            val prizePool = rawPrizePool / 100.0
                            val rawStatus = child.child("status").value?.toString() ?: ""
                            val status = MatchStatus.fromString(rawStatus)
                            val gameCode = child.child("gameCode").value?.toString()
                                ?: child.child("code").value?.toString()
                                ?: ""
                            val isCodeVisible = child.child("isCodeVisible").getValue(Boolean::class.java)
                                ?: (gameCode.isNotBlank())
                            val scheduledTime = (child.child("scheduledTime").value as? Number)?.toLong() ?: 0L
                            val maxPlayers = (child.child("maxPlayers").value as? Number)?.toInt() ?: TournamentMath.MAX_PLAYERS
                            val joinedCount = (child.child("joinedPlayersCount").value as? Number)?.toInt()
                                ?: (child.child("joinedPlayers").value as? Number)?.toInt()
                                ?: (child.child("joined").value as? Number)?.toInt()
                                ?: (child.child("currentPlayers").value as? Number)?.toInt()
                                ?: 0
                            val winnerUserId = child.child("winnerUserId").value?.toString() ?: ""
                            val createdByAdminId = child.child("createdByAdminId").value?.toString() ?: ""
                            val createdAt = (child.child("createdAt").value as? Number)?.toLong() ?: 0L
                            val entryFeeMinorUnits = (child.child("entryFeeMinorUnits").value as? Number)?.toLong()
                                ?: rawEntryFee.toLong()
                            val prizeMinorUnits = (child.child("prizeMinorUnits").value as? Number)?.toLong()
                                ?: rawPrizePool.toLong()
                            val scheduledAt = (child.child("scheduledAt").value as? Number)?.toLong()
                                ?: (child.child("scheduledTimestamp").value as? Number)?.toLong()
                                ?: scheduledTime
                            val updatedAt = (child.child("updatedAt").value as? Number)?.toLong() ?: 0L
                            val startedAt = (child.child("startedAt").value as? Number)?.toLong()
                            val cancelReason = child.child("cancelReason").value?.toString()

                            matches.add(
                                AdminMatchItem(
                                    matchId = id,
                                    matchNumber = matchNumber,
                                    title = title,
                                    gameType = canonicalGame,
                                    entryFee = entryFee,
                                    prizePool = prizePool,
                                    status = status,
                                    rawStatus = rawStatus,
                                    gameCode = gameCode,
                                    isCodeVisible = isCodeVisible,
                                    scheduledTime = scheduledTime,
                                    maxPlayers = maxPlayers,
                                    joinedPlayersCount = joinedCount,
                                    winnerUserId = winnerUserId,
                                    createdByAdminId = createdByAdminId,
                                    createdAt = createdAt,
                                    entryFeeMinorUnits = entryFeeMinorUnits,
                                    prizeMinorUnits = prizeMinorUnits,
                                    scheduledAt = scheduledAt,
                                    updatedAt = updatedAt,
                                    startedAt = startedAt,
                                    cancelReason = cancelReason
                                )
                            )
                        } catch (_: Exception) {
                            // Safely skip malformed items
                        }
                    }
                    val sorted = matches.sortedByDescending { if (it.scheduledAt > 0) it.scheduledAt else it.createdAt }
                    trySend(sorted)
                }

                override fun onCancelled(error: DatabaseError) {
                    close(error.toException())
                }
            }
            ref.addValueEventListener(listener)
            awaitClose { ref.removeEventListener(listener) }
        }
    }

    override fun observeMatchPlayers(matchId: String): Flow<List<MatchPlayerDetails>> {
        val db = database ?: return flowOf(emptyList())
        return callbackFlow {
            val ref = db.getReference(FirebaseAdminConfig.NODE_MATCH_PLAYERS).child(matchId)
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val players = mutableListOf<MatchPlayerDetails>()
                    for (child in snapshot.children) {
                        try {
                            val id = child.key ?: continue
                            val matchPlayerId = child.child("matchPlayerId").value?.toString() ?: id
                            val userId = child.child("userId").value?.toString()
                                ?: child.child("uid").value?.toString() ?: id
                            val username = child.child("username").value?.toString() ?: "Player"
                            val slot = child.child("slot").value?.toString() ?: "PLAYER_1"
                            val joinedAt = (child.child("joinedAt").value as? Number)?.toLong() ?: 0L
                            val isReady = child.child("isReady").getValue(Boolean::class.java) ?: true
                            val uid = child.child("uid").value?.toString() ?: userId
                            val entryFeeMinorUnits = (child.child("entryFeeMinorUnits").value as? Number)?.toLong() ?: 0L
                            val status = child.child("status").value?.toString() ?: "JOINED"

                            players.add(
                                MatchPlayerDetails(
                                    matchPlayerId = matchPlayerId,
                                    matchId = matchId,
                                    userId = userId,
                                    username = username,
                                    slot = slot,
                                    joinedAt = joinedAt,
                                    isReady = isReady,
                                    uid = uid,
                                    entryFeeMinorUnits = entryFeeMinorUnits,
                                    status = status
                                )
                            )
                        } catch (_: Exception) {
                            // Gracefully ignore individual parse errors
                        }
                    }
                    trySend(players)
                }

                override fun onCancelled(error: DatabaseError) {
                    close(error.toException())
                }
            }
            ref.addValueEventListener(listener)
            awaitClose { ref.removeEventListener(listener) }
        }
    }

    override suspend fun setMatchGameCode(
        matchId: String,
        gameCode: String,
        adminSession: SuperAdminSession
    ): Result<Unit> = runCatching {
        verifySuperAdmin(adminSession)
        val cleanCode = gameCode.trim()
        require(cleanCode.isNotBlank()) { "Game room code cannot be empty." }
        val db = database ?: throw IllegalStateException("Firebase RTDB instance is unavailable.")

        val matchSnapshot = db.reference.child(FirebaseAdminConfig.NODE_MATCHES).child(matchId).get().await()
        val oldGameCode = matchSnapshot.child("gameCode").value?.toString() ?: ""
        val wasBlank = oldGameCode.isBlank()

        val now = System.currentTimeMillis()
        val logId = UUID.randomUUID().toString()

        val updates = hashMapOf<String, Any?>(
            "${FirebaseAdminConfig.NODE_MATCHES}/$matchId/gameCode" to cleanCode,
            "${FirebaseAdminConfig.NODE_MATCHES}/$matchId/isCodeVisible" to true,
            "${FirebaseAdminConfig.NODE_MATCHES}/$matchId/status" to MatchStatus.CODE_ADDED.name,
            "${FirebaseAdminConfig.NODE_MATCHES}/$matchId/updatedAt" to now,
            "${FirebaseAdminConfig.NODE_AUDIT_LOGS}/$logId" to hashMapOf(
                "action" to "MATCH_CODE_ADDED",
                "admin" to adminSession.identifier,
                "referenceId" to matchId,
                "timestamp" to now,
                "reason" to "Game room code configured by Super Admin"
            )
        )
        db.reference.updateChildren(updates).await()

        if (wasBlank) {
            try {
                val playersSnapshot = db.reference.child(FirebaseAdminConfig.NODE_MATCH_PLAYERS).child(matchId).get().await()
                if (playersSnapshot.exists() && playersSnapshot.childrenCount > 0) {
                    val notifRepo = FirebaseNotificationsRepository()
                    notifRepo.sendNotification(
                        title = "Game Room Code Available! / রুম কোড যোগ করা হয়েছে",
                        message = "Room code for your match has been published. Open match details to view.",
                        targetType = NotificationTargetType.MATCH_PARTICIPANTS,
                        targetId = matchId,
                        adminSession = adminSession
                    )
                }
            } catch (_: Exception) {}
        }
    }

    override suspend fun releaseMatch(
        matchId: String,
        adminSession: SuperAdminSession
    ): Result<Unit> = runCatching {
        verifySuperAdmin(adminSession)
        val db = database ?: throw IllegalStateException("Firebase RTDB instance is unavailable.")
        
        // Fetch current match snapshot to ensure status is UPCOMING
        val matchSnapshot = db.reference.child(FirebaseAdminConfig.NODE_MATCHES).child(matchId).get().await()
        if (!matchSnapshot.exists()) {
            throw IllegalArgumentException("Match $matchId does not exist.")
        }
        val currentStatus = matchSnapshot.child("status").value?.toString() ?: ""
        val parsedStatus = MatchStatus.fromString(currentStatus)
        if (parsedStatus != MatchStatus.UPCOMING) {
            throw IllegalStateException("Cannot release match in $currentStatus state. Only UPCOMING matches can be released.")
        }

        val now = System.currentTimeMillis()
        val logId = UUID.randomUUID().toString()
        val updates = hashMapOf<String, Any?>(
            "${FirebaseAdminConfig.NODE_MATCHES}/$matchId/status" to MatchStatus.AVAILABLE.name,
            "${FirebaseAdminConfig.NODE_MATCHES}/$matchId/updatedAt" to now,
            "${FirebaseAdminConfig.NODE_AUDIT_LOGS}/$logId" to hashMapOf(
                "action" to "MATCH_RELEASED",
                "admin" to adminSession.identifier,
                "referenceId" to matchId,
                "timestamp" to now,
                "reason" to "Match released to AVAILABLE by Super Admin"
            )
        )
        db.reference.updateChildren(updates).await()
    }

    override suspend fun updateMatchStatus(
        matchId: String,
        newStatus: MatchStatus,
        reason: String,
        adminSession: SuperAdminSession
    ): Result<Unit> = runCatching {
        verifySuperAdmin(adminSession)
        val trimmedReason = reason.trim()
        if (newStatus == MatchStatus.CANCELLED) {
            require(trimmedReason.isNotBlank()) { "Cancellation reason is required." }
        }

        val db = database ?: throw IllegalStateException("Firebase RTDB instance is unavailable.")
        val now = System.currentTimeMillis()
        val logId = UUID.randomUUID().toString()
        val actionName = when (newStatus) {
            MatchStatus.PAUSED -> "MATCH_PAUSED"
            MatchStatus.DISABLED -> "MATCH_DISABLED"
            MatchStatus.CANCELLED -> "MATCH_CANCELLED"
            else -> "MATCH_STATUS_UPDATED"
        }

        val finalAuditReason = if (newStatus == MatchStatus.CANCELLED) {
            trimmedReason
        } else {
            trimmedReason.ifEmpty { "Status updated to ${newStatus.label}" }
        }

        // NOTE: For CANCELLED matches, client-side wallet refunds are STRICTLY FORBIDDEN.
        // Wallet adjustments require an authoritative backend or Cloud Function trigger.
        val updates = hashMapOf<String, Any?>(
            "${FirebaseAdminConfig.NODE_MATCHES}/$matchId/status" to newStatus.name,
            "${FirebaseAdminConfig.NODE_MATCHES}/$matchId/updatedAt" to now,
            "${FirebaseAdminConfig.NODE_AUDIT_LOGS}/$logId" to hashMapOf(
                "action" to actionName,
                "admin" to adminSession.identifier,
                "referenceId" to matchId,
                "timestamp" to now,
                "reason" to finalAuditReason
            )
        )

        if (newStatus == MatchStatus.CANCELLED) {
            updates["${FirebaseAdminConfig.NODE_MATCHES}/$matchId/cancelReason"] = trimmedReason
        }

        db.reference.updateChildren(updates).await()
    }

    override suspend fun deleteMatchPermanently(
        matchId: String,
        adminSession: SuperAdminSession
    ): Result<Unit> = runCatching {
        verifySuperAdmin(adminSession)
        val db = database ?: throw IllegalStateException("Firebase RTDB instance is unavailable.")
        val now = System.currentTimeMillis()
        val logId = UUID.randomUUID().toString()

        // Permanently remove match from /matches/{matchId}
        db.reference.child(FirebaseAdminConfig.NODE_MATCHES).child(matchId).removeValue().await()

        // Also clean up match players node for this fixture
        try {
            db.reference.child(FirebaseAdminConfig.NODE_MATCH_PLAYERS).child(matchId).removeValue().await()
        } catch (_: Exception) {
            // non-fatal if node empty
        }

        // Record immutable audit log
        val auditPayload = hashMapOf<String, Any?>(
            "action" to "MATCH_DELETED_PERMANENTLY",
            "admin" to adminSession.identifier,
            "referenceId" to matchId,
            "timestamp" to now,
            "reason" to "Match permanently deleted by Super Admin"
        )
        db.reference.child(FirebaseAdminConfig.NODE_AUDIT_LOGS).child(logId).setValue(auditPayload).await()
    }

    override suspend fun createSingleMatch(
        request: CreateMatchRequest,
        adminSession: SuperAdminSession
    ): Result<String> = runCatching {
        verifySuperAdmin(adminSession)
        val cleanNumber = request.matchNumber.trim()
        require(cleanNumber.isNotBlank()) { "Match number cannot be empty." }
        require(request.entryFeeTaka >= 0) { "Entry fee cannot be negative." }
        require(request.scheduledTimestamp > 0) { "Valid scheduled timestamp is required." }
        require(request.maxPlayers == TournamentMath.MAX_PLAYERS) { "Max players must strictly be 2." }

        val db = database ?: throw IllegalStateException("Firebase RTDB instance is unavailable.")
        val matchId = db.getReference(FirebaseAdminConfig.NODE_MATCHES).push().key ?: UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val entryFeeMinorUnits = TournamentMath.takaToMinorUnits(request.entryFeeTaka)
        val prizeMinorUnits = TournamentMath.calculatePrizeMinorUnits(entryFeeMinorUnits)
        val prizeTaka = TournamentMath.minorUnitsToTakaDouble(prizeMinorUnits)
        val initialStatus = MatchStatus.UPCOMING.name

        val matchPayload = hashMapOf<String, Any?>(
            "matchId" to matchId,
            "matchNumber" to cleanNumber,
            "title" to request.title.trim().ifEmpty { "${request.gameType.uppercase()} 1v1 $cleanNumber" },
            "gameType" to request.gameType.uppercase(),
            "entryFee" to entryFeeMinorUnits,
            "prizePool" to prizeMinorUnits,
            "status" to initialStatus,
            "gameCode" to "",
            "isCodeVisible" to false,
            "scheduledTime" to request.scheduledTimestamp,
            "maxPlayers" to TournamentMath.MAX_PLAYERS,
            "joinedPlayersCount" to 0,
            "winnerUserId" to "",
            "createdByAdminId" to adminSession.uid,
            "createdAt" to now,
            "entryFeeMinorUnits" to entryFeeMinorUnits,
            "prizeMinorUnits" to prizeMinorUnits,
            "scheduledAt" to request.scheduledTimestamp,
            "updatedAt" to now,
            "startedAt" to null
        )

        val logId = UUID.randomUUID().toString()
        val updates = hashMapOf<String, Any?>(
            "${FirebaseAdminConfig.NODE_MATCHES}/$matchId" to matchPayload,
            "${FirebaseAdminConfig.NODE_AUDIT_LOGS}/$logId" to hashMapOf(
                "action" to "MATCH_CREATED",
                "admin" to adminSession.identifier,
                "referenceId" to matchId,
                "timestamp" to now,
                "reason" to "Single match $cleanNumber created by Super Admin"
            )
        )
        db.reference.updateChildren(updates).await()
        matchId
    }

    override suspend fun createBulkMatches(
        request: BulkMatchRequest,
        adminSession: SuperAdminSession
    ): Result<List<String>> = runCatching {
        verifySuperAdmin(adminSession)
        require(request.quantity in 1..100) { "Quantity must be between 1 and 100." }
        require(request.entryFeeTaka >= 0) { "Entry fee cannot be negative." }
        require(request.maxPlayers == TournamentMath.MAX_PLAYERS) { "Max players must strictly be 2." }

        val db = database ?: throw IllegalStateException("Firebase RTDB instance is unavailable.")
        val previewItems = TournamentMath.generateBulkPreview(request)
        val now = System.currentTimeMillis()
        val createdIds = mutableListOf<String>()
        val updates = hashMapOf<String, Any?>()

        for (item in previewItems) {
            val matchId = db.getReference(FirebaseAdminConfig.NODE_MATCHES).push().key ?: UUID.randomUUID().toString()
            createdIds.add(matchId)
            val entryFeeMinorUnits = TournamentMath.takaToMinorUnits(item.entryFeeTaka)
            val prizeMinorUnits = TournamentMath.takaToMinorUnits(item.prizeTaka)
            val initialStatus = MatchStatus.UPCOMING.name

            val matchPayload = hashMapOf<String, Any?>(
                "matchId" to matchId,
                "matchNumber" to item.matchNumber,
                "title" to item.title,
                "gameType" to item.gameType,
                "entryFee" to entryFeeMinorUnits,
                "prizePool" to prizeMinorUnits,
                "status" to initialStatus,
                "gameCode" to "",
                "isCodeVisible" to false,
                "scheduledTime" to item.scheduledTimestamp,
                "maxPlayers" to TournamentMath.MAX_PLAYERS,
                "joinedPlayersCount" to 0,
                "winnerUserId" to "",
                "createdByAdminId" to adminSession.uid,
                "createdAt" to now,
                "entryFeeMinorUnits" to entryFeeMinorUnits,
                "prizeMinorUnits" to prizeMinorUnits,
                "scheduledAt" to item.scheduledTimestamp,
                "updatedAt" to now,
                "startedAt" to null
            )
            updates["${FirebaseAdminConfig.NODE_MATCHES}/$matchId"] = matchPayload
        }

        val logId = UUID.randomUUID().toString()
        updates["${FirebaseAdminConfig.NODE_AUDIT_LOGS}/$logId"] = hashMapOf(
            "action" to "MATCH_BULK_CREATED",
            "admin" to adminSession.identifier,
            "referenceId" to createdIds.joinToString(",").take(100),
            "timestamp" to now,
            "reason" to "Bulk created ${request.quantity} matches starting from ${request.startingNumber}"
        )

        db.reference.updateChildren(updates).await()
        createdIds
    }

    override suspend fun createAutoBatchMatches(
        request: AutoBatchMatchRequest,
        adminSession: SuperAdminSession
    ): Result<List<String>> = runCatching {
        verifySuperAdmin(adminSession)
        require(request.quantity in 1..100) { "Quantity must be between 1 and 100." }
        require(request.startingEntryFeeTaka >= 0) { "Starting entry fee cannot be negative." }
        require(request.maxPlayers == TournamentMath.MAX_PLAYERS) { "Max players must strictly be 2." }

        val db = database ?: throw IllegalStateException("Firebase RTDB instance is unavailable.")
        val previewItems = TournamentMath.generateAutoBatchPreview(request)
        val now = System.currentTimeMillis()
        val createdIds = mutableListOf<String>()
        val updates = hashMapOf<String, Any?>()

        for (item in previewItems) {
            val matchId = db.getReference(FirebaseAdminConfig.NODE_MATCHES).push().key ?: UUID.randomUUID().toString()
            createdIds.add(matchId)
            val entryFeeMinorUnits = TournamentMath.takaToMinorUnits(item.entryFeeTaka)
            val prizeMinorUnits = TournamentMath.takaToMinorUnits(item.prizeTaka)
            val initialStatus = MatchStatus.UPCOMING.name

            val matchPayload = hashMapOf<String, Any?>(
                "matchId" to matchId,
                "matchNumber" to item.matchNumber,
                "title" to item.title,
                "gameType" to item.gameType,
                "entryFee" to entryFeeMinorUnits,
                "prizePool" to prizeMinorUnits,
                "status" to initialStatus,
                "gameCode" to "",
                "isCodeVisible" to false,
                "scheduledTime" to item.scheduledTimestamp,
                "maxPlayers" to TournamentMath.MAX_PLAYERS,
                "joinedPlayersCount" to 0,
                "winnerUserId" to "",
                "createdByAdminId" to adminSession.uid,
                "createdAt" to now,
                "entryFeeMinorUnits" to entryFeeMinorUnits,
                "prizeMinorUnits" to prizeMinorUnits,
                "scheduledAt" to item.scheduledTimestamp,
                "updatedAt" to now,
                "startedAt" to null
            )
            updates["${FirebaseAdminConfig.NODE_MATCHES}/$matchId"] = matchPayload
        }

        val logId = UUID.randomUUID().toString()
        updates["${FirebaseAdminConfig.NODE_AUDIT_LOGS}/$logId"] = hashMapOf(
            "action" to "MATCH_AUTO_BATCH_CREATED",
            "admin" to adminSession.identifier,
            "referenceId" to createdIds.joinToString(",").take(100),
            "timestamp" to now,
            "reason" to "Auto batch created ${request.quantity} matches starting at fee ৳${request.startingEntryFeeTaka}"
        )

        db.reference.updateChildren(updates).await()
        createdIds
    }
}

/**
 * In-memory test repository for fast, deterministic Robolectric and JVM unit tests.
 */
class InMemoryMatchesRepository(
    initialMatches: List<AdminMatchItem> = emptyList()
) : MatchesRepository {
    private val _matchesFlow = MutableStateFlow(initialMatches)
    private val _playersMap = mutableMapOf<String, MutableStateFlow<List<MatchPlayerDetails>>>()
    val auditLogRecords = mutableListOf<Map<String, Any?>>()

    fun emitMatches(matches: List<AdminMatchItem>) {
        _matchesFlow.value = matches
    }

    fun emitPlayers(matchId: String, players: List<MatchPlayerDetails>) {
        val flow = _playersMap.getOrPut(matchId) { MutableStateFlow(emptyList()) }
        flow.value = players
    }

    override fun observeMatches(): Flow<List<AdminMatchItem>> = _matchesFlow.asStateFlow()

    override fun observeMatchPlayers(matchId: String): Flow<List<MatchPlayerDetails>> {
        return _playersMap.getOrPut(matchId) { MutableStateFlow(emptyList()) }.asStateFlow()
    }

    override suspend fun setMatchGameCode(
        matchId: String,
        gameCode: String,
        adminSession: SuperAdminSession
    ): Result<Unit> = runCatching {
        if (!adminSession.isSuperAdminVerified) {
            throw SecurityException("Unauthorized: Super Admin authorization required.")
        }
        val cleanCode = gameCode.trim()
        require(cleanCode.isNotBlank()) { "Game room code cannot be empty." }

        val current = _matchesFlow.value
        val targetMatch = current.firstOrNull { it.matchId == matchId }
        val oldCode = targetMatch?.gameCode ?: ""
        val wasBlank = oldCode.isBlank()

        val updated = current.map {
            if (it.matchId == matchId) {
                it.copy(
                    gameCode = cleanCode,
                    isCodeVisible = true,
                    status = MatchStatus.CODE_ADDED,
                    updatedAt = System.currentTimeMillis()
                )
            } else it
        }
        _matchesFlow.value = updated
        auditLogRecords.add(
            mapOf(
                "action" to "MATCH_CODE_ADDED",
                "admin" to adminSession.identifier,
                "referenceId" to matchId,
                "timestamp" to System.currentTimeMillis()
            )
        )

        if (wasBlank) {
            try {
                val players = _playersMap[matchId]?.value ?: emptyList()
                if (players.isNotEmpty()) {
                    val notifRepo = FirebaseNotificationsRepository()
                    notifRepo.sendNotification(
                        title = "Game Room Code Available! / রুম কোড যোগ করা হয়েছে",
                        message = "Room code for your match has been published. Open match details to view.",
                        targetType = NotificationTargetType.MATCH_PARTICIPANTS,
                        targetId = matchId,
                        adminSession = adminSession
                    )
                }
            } catch (_: Exception) {}
        }
    }

    override suspend fun releaseMatch(
        matchId: String,
        adminSession: SuperAdminSession
    ): Result<Unit> = runCatching {
        if (!adminSession.isSuperAdminVerified) {
            throw SecurityException("Unauthorized: Super Admin authorization required.")
        }
        val current = _matchesFlow.value
        val targetMatch = current.firstOrNull { it.matchId == matchId }
            ?: throw IllegalArgumentException("Match $matchId does not exist.")
        if (targetMatch.status != MatchStatus.UPCOMING) {
            throw IllegalStateException("Cannot release match in ${targetMatch.status} state. Only UPCOMING matches can be released.")
        }
        val updated = current.map {
            if (it.matchId == matchId) {
                it.copy(
                    status = MatchStatus.AVAILABLE,
                    rawStatus = "AVAILABLE",
                    updatedAt = System.currentTimeMillis()
                )
            } else it
        }
        _matchesFlow.value = updated
        auditLogRecords.add(
            mapOf(
                "action" to "MATCH_RELEASED",
                "admin" to adminSession.identifier,
                "referenceId" to matchId,
                "timestamp" to System.currentTimeMillis(),
                "reason" to "Match released to AVAILABLE by Super Admin"
            )
        )
    }

    override suspend fun updateMatchStatus(
        matchId: String,
        newStatus: MatchStatus,
        reason: String,
        adminSession: SuperAdminSession
    ): Result<Unit> = runCatching {
        if (!adminSession.isSuperAdminVerified) {
            throw SecurityException("Unauthorized: Super Admin authorization required.")
        }
        val trimmedReason = reason.trim()
        if (newStatus == MatchStatus.CANCELLED) {
            require(trimmedReason.isNotBlank()) { "Cancellation reason is required." }
        }

        val current = _matchesFlow.value
        val updated = current.map {
            if (it.matchId == matchId) {
                it.copy(
                    status = newStatus,
                    updatedAt = System.currentTimeMillis(),
                    cancelReason = if (newStatus == MatchStatus.CANCELLED) trimmedReason else it.cancelReason
                )
            } else it
        }
        _matchesFlow.value = updated
        auditLogRecords.add(
            mapOf(
                "action" to if (newStatus == MatchStatus.CANCELLED) "MATCH_CANCELLED" else "MATCH_${newStatus.name}",
                "admin" to adminSession.identifier,
                "referenceId" to matchId,
                "timestamp" to System.currentTimeMillis(),
                "reason" to if (newStatus == MatchStatus.CANCELLED) trimmedReason else trimmedReason.ifEmpty { "Status updated to ${newStatus.label}" }
            )
        )
    }

    override suspend fun createSingleMatch(
        request: CreateMatchRequest,
        adminSession: SuperAdminSession
    ): Result<String> = runCatching {
        if (!adminSession.isSuperAdminVerified) {
            throw SecurityException("Unauthorized: Super Admin authorization required.")
        }
        val cleanNumber = request.matchNumber.trim()
        require(cleanNumber.isNotBlank()) { "Match number cannot be empty." }
        require(request.entryFeeTaka >= 0) { "Entry fee cannot be negative." }
        require(request.maxPlayers == TournamentMath.MAX_PLAYERS) { "Max players must strictly be 2." }

        val matchId = "match_${System.currentTimeMillis()}"
        val entryFeeMinorUnits = TournamentMath.takaToMinorUnits(request.entryFeeTaka)
        val prizeMinorUnits = TournamentMath.calculatePrizeMinorUnits(entryFeeMinorUnits)
        val prizeTaka = TournamentMath.minorUnitsToTaka(prizeMinorUnits)

        val newMatch = AdminMatchItem(
            matchId = matchId,
            matchNumber = cleanNumber,
            title = request.title.trim().ifEmpty { "${request.gameType.uppercase()} 1v1 $cleanNumber" },
            gameType = request.gameType.uppercase(),
            entryFee = request.entryFeeTaka.toDouble(),
            prizePool = prizeTaka.toDouble(),
            status = MatchStatus.UPCOMING,
            rawStatus = "UPCOMING",
            gameCode = "",
            isCodeVisible = false,
            scheduledTime = request.scheduledTimestamp,
            maxPlayers = TournamentMath.MAX_PLAYERS,
            joinedPlayersCount = 0,
            entryFeeMinorUnits = entryFeeMinorUnits,
            prizeMinorUnits = prizeMinorUnits,
            scheduledAt = request.scheduledTimestamp,
            createdAt = System.currentTimeMillis()
        )
        _matchesFlow.value = listOf(newMatch) + _matchesFlow.value
        auditLogRecords.add(
            mapOf(
                "action" to "MATCH_CREATED",
                "admin" to adminSession.identifier,
                "referenceId" to matchId
            )
        )
        matchId
    }

    override suspend fun createBulkMatches(
        request: BulkMatchRequest,
        adminSession: SuperAdminSession
    ): Result<List<String>> = runCatching {
        if (!adminSession.isSuperAdminVerified) {
            throw SecurityException("Unauthorized: Super Admin authorization required.")
        }
        require(request.quantity in 1..100) { "Quantity must be between 1 and 100." }
        require(request.entryFeeTaka >= 0) { "Entry fee cannot be negative." }

        val previews = TournamentMath.generateBulkPreview(request)
        val createdIds = mutableListOf<String>()
        val newMatches = mutableListOf<AdminMatchItem>()

        previews.forEachIndexed { idx, item ->
            val matchId = "bulk_${System.currentTimeMillis()}_$idx"
            createdIds.add(matchId)
            val entryFeeMinorUnits = TournamentMath.takaToMinorUnits(item.entryFeeTaka)
            val prizeMinorUnits = TournamentMath.takaToMinorUnits(item.prizeTaka)
            newMatches.add(
                AdminMatchItem(
                    matchId = matchId,
                    matchNumber = item.matchNumber,
                    title = item.title,
                    gameType = item.gameType,
                    entryFee = item.entryFeeTaka.toDouble(),
                    prizePool = item.prizeTaka.toDouble(),
                    status = MatchStatus.UPCOMING,
                    rawStatus = "UPCOMING",
                    gameCode = "",
                    isCodeVisible = false,
                    scheduledTime = item.scheduledTimestamp,
                    maxPlayers = TournamentMath.MAX_PLAYERS,
                    joinedPlayersCount = 0,
                    entryFeeMinorUnits = entryFeeMinorUnits,
                    prizeMinorUnits = prizeMinorUnits,
                    scheduledAt = item.scheduledTimestamp,
                    createdAt = System.currentTimeMillis()
                )
            )
        }
        _matchesFlow.value = newMatches + _matchesFlow.value
        auditLogRecords.add(
            mapOf(
                "action" to "MATCH_BULK_CREATED",
                "admin" to adminSession.identifier,
                "referenceId" to createdIds.joinToString(",")
            )
        )
        createdIds
    }

    override suspend fun createAutoBatchMatches(
        request: AutoBatchMatchRequest,
        adminSession: SuperAdminSession
    ): Result<List<String>> = runCatching {
        if (!adminSession.isSuperAdminVerified) {
            throw SecurityException("Unauthorized: Super Admin authorization required.")
        }
        require(request.quantity in 1..100) { "Quantity must be between 1 and 100." }
        require(request.startingEntryFeeTaka >= 0) { "Starting entry fee cannot be negative." }

        val previews = TournamentMath.generateAutoBatchPreview(request)
        val createdIds = mutableListOf<String>()
        val newMatches = mutableListOf<AdminMatchItem>()

        previews.forEachIndexed { idx, item ->
            val matchId = "autobatch_${System.currentTimeMillis()}_$idx"
            createdIds.add(matchId)
            val entryFeeMinorUnits = TournamentMath.takaToMinorUnits(item.entryFeeTaka)
            val prizeMinorUnits = TournamentMath.takaToMinorUnits(item.prizeTaka)
            newMatches.add(
                AdminMatchItem(
                    matchId = matchId,
                    matchNumber = item.matchNumber,
                    title = item.title,
                    gameType = item.gameType,
                    entryFee = item.entryFeeTaka.toDouble(),
                    prizePool = item.prizeTaka.toDouble(),
                    status = MatchStatus.UPCOMING,
                    rawStatus = "UPCOMING",
                    gameCode = "",
                    isCodeVisible = false,
                    scheduledTime = item.scheduledTimestamp,
                    maxPlayers = TournamentMath.MAX_PLAYERS,
                    joinedPlayersCount = 0,
                    entryFeeMinorUnits = entryFeeMinorUnits,
                    prizeMinorUnits = prizeMinorUnits,
                    scheduledAt = item.scheduledTimestamp,
                    createdAt = System.currentTimeMillis()
                )
            )
        }
        _matchesFlow.value = newMatches + _matchesFlow.value
        auditLogRecords.add(
            mapOf(
                "action" to "MATCH_AUTO_BATCH_CREATED",
                "admin" to adminSession.identifier,
                "referenceId" to createdIds.joinToString(",")
            )
        )
        createdIds
    }

    override suspend fun deleteMatchPermanently(
        matchId: String,
        adminSession: SuperAdminSession
    ): Result<Unit> = runCatching {
        if (!adminSession.isSuperAdminVerified) {
            throw SecurityException("Unauthorized: Super Admin authorization required.")
        }
        _matchesFlow.value = _matchesFlow.value.filter { it.matchId != matchId }
        auditLogRecords.add(
            mapOf(
                "action" to "MATCH_DELETED_PERMANENTLY",
                "admin" to adminSession.identifier,
                "referenceId" to matchId
            )
        )
    }
}
