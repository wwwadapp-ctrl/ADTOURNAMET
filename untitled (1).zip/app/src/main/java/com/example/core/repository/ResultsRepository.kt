package com.example.core.repository

import com.example.core.config.FirebaseAdminConfig
import com.example.core.model.AdminResultItem
import com.example.core.model.NotificationTargetType
import com.example.core.model.ResultStatus
import com.example.core.model.SuperAdminSession
import com.example.core.model.TournamentMath
import com.example.core.model.UserWalletData
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.MutableData
import com.google.firebase.database.Transaction
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.tasks.await
import kotlin.coroutines.resume

data class ResultApprovalResult(
    val success: Boolean,
    val alreadySettled: Boolean = false,
    val errorMessage: String? = null
)

object ResultPrizeResolver {
    /**
     * Resolves authoritative prize in minor units from match data with fallbacks.
     * 1. Prefers authoritative minor-unit field: prizeMinorUnits
     * 2. Safely falls back to authoritative prize field present in match model (prizePool / prize)
     * 3. Falls back to entry fee under existing TournamentMath
     * 4. Falls back to result record prize if available
     */
    fun resolvePrizeMinorUnits(
        matchPrizeMinorUnits: Long? = null,
        matchPrizePoolTaka: Double? = null,
        matchEntryFeeMinorUnits: Long? = null,
        matchEntryFeeTaka: Double? = null,
        resultPrizeMinorUnits: Long? = null,
        resultPrizePoolTaka: Double? = null
    ): Long {
        if (matchPrizeMinorUnits != null && matchPrizeMinorUnits > 0L) {
            return matchPrizeMinorUnits
        }

        if (matchPrizePoolTaka != null && matchPrizePoolTaka > 0.0) {
            return matchPrizePoolTaka.toLong()
        }

        if (matchEntryFeeMinorUnits != null && matchEntryFeeMinorUnits > 0L) {
            val calculated = TournamentMath.calculatePrizeMinorUnits(matchEntryFeeMinorUnits)
            if (calculated > 0L) return calculated
        }

        if (matchEntryFeeTaka != null && matchEntryFeeTaka > 0.0) {
            val entryFeeMinor = matchEntryFeeTaka.toLong()
            val calculated = TournamentMath.calculatePrizeMinorUnits(entryFeeMinor)
            if (calculated > 0L) return calculated
        }

        if (resultPrizeMinorUnits != null && resultPrizeMinorUnits > 0L) {
            return resultPrizeMinorUnits
        }

        if (resultPrizePoolTaka != null && resultPrizePoolTaka > 0.0) {
            return resultPrizePoolTaka.toLong()
        }

        return 0L
    }

    fun resolveFromSnapshots(
        matchSnapshot: DataSnapshot?,
        resultSnapshot: DataSnapshot? = null
    ): Long {
        val matchPrizeMinor = (matchSnapshot?.child("prizeMinorUnits")?.value as? Number)?.toLong()
            ?: matchSnapshot?.child("prizeMinorUnits")?.value?.toString()?.toLongOrNull()
            ?: (matchSnapshot?.child("prize_minor_units")?.value as? Number)?.toLong()
            ?: matchSnapshot?.child("prize_minor_units")?.value?.toString()?.toLongOrNull()
        val matchPrizePool = (matchSnapshot?.child("prizePool")?.value as? Number)?.toDouble()
            ?: matchSnapshot?.child("prizePool")?.value?.toString()?.toDoubleOrNull()
            ?: (matchSnapshot?.child("prize_pool")?.value as? Number)?.toDouble()
            ?: matchSnapshot?.child("prize_pool")?.value?.toString()?.toDoubleOrNull()
            ?: (matchSnapshot?.child("prize")?.value as? Number)?.toDouble()
            ?: matchSnapshot?.child("prize")?.value?.toString()?.toDoubleOrNull()
            ?: (matchSnapshot?.child("winningPrize")?.value as? Number)?.toDouble()
            ?: matchSnapshot?.child("winningPrize")?.value?.toString()?.toDoubleOrNull()
            ?: (matchSnapshot?.child("amount")?.value as? Number)?.toDouble()
            ?: matchSnapshot?.child("amount")?.value?.toString()?.toDoubleOrNull()
        val matchEntryFeeMinor = (matchSnapshot?.child("entryFeeMinorUnits")?.value as? Number)?.toLong()
            ?: matchSnapshot?.child("entryFeeMinorUnits")?.value?.toString()?.toLongOrNull()
            ?: (matchSnapshot?.child("entry_fee_minor_units")?.value as? Number)?.toLong()
            ?: matchSnapshot?.child("entry_fee_minor_units")?.value?.toString()?.toLongOrNull()
        val matchEntryFee = (matchSnapshot?.child("entryFee")?.value as? Number)?.toDouble()
            ?: matchSnapshot?.child("entryFee")?.value?.toString()?.toDoubleOrNull()
            ?: (matchSnapshot?.child("entry_fee")?.value as? Number)?.toDouble()
            ?: matchSnapshot?.child("entry_fee")?.value?.toString()?.toDoubleOrNull()

        val resultPrizeMinor = (resultSnapshot?.child("prizeMinorUnits")?.value as? Number)?.toLong()
            ?: resultSnapshot?.child("prizeMinorUnits")?.value?.toString()?.toLongOrNull()
            ?: (resultSnapshot?.child("amountMinorUnits")?.value as? Number)?.toLong()
            ?: resultSnapshot?.child("amountMinorUnits")?.value?.toString()?.toLongOrNull()
        val resultPrizeTaka = (resultSnapshot?.child("prizePool")?.value as? Number)?.toDouble()
            ?: resultSnapshot?.child("prizePool")?.value?.toString()?.toDoubleOrNull()
            ?: (resultSnapshot?.child("prize")?.value as? Number)?.toDouble()
            ?: resultSnapshot?.child("prize")?.value?.toString()?.toDoubleOrNull()
            ?: (resultSnapshot?.child("amount")?.value as? Number)?.toDouble()
            ?: resultSnapshot?.child("amount")?.value?.toString()?.toDoubleOrNull()
            ?: (resultSnapshot?.child("prizeTaka")?.value as? Number)?.toDouble()
            ?: resultSnapshot?.child("prizeTaka")?.value?.toString()?.toDoubleOrNull()

        return resolvePrizeMinorUnits(
            matchPrizeMinorUnits = matchPrizeMinor,
            matchPrizePoolTaka = matchPrizePool,
            matchEntryFeeMinorUnits = matchEntryFeeMinor,
            matchEntryFeeTaka = matchEntryFee,
            resultPrizeMinorUnits = resultPrizeMinor,
            resultPrizePoolTaka = resultPrizeTaka
        )
    }
}

interface ResultsRepository {
    fun observeResults(): Flow<List<AdminResultItem>>
    suspend fun getResult(resultId: String): AdminResultItem?
    suspend fun approveResult(
        resultId: String,
        submittedMatchNumber: String,
        submittedRoomCode: String,
        adminSession: SuperAdminSession
    ): Result<Unit>
    suspend fun rejectResult(
        resultId: String,
        reason: String,
        adminSession: SuperAdminSession
    ): Result<Unit>
}

class FirebaseResultsRepository(
    initialResults: List<AdminResultItem>? = null,
    initialWallets: Map<String, UserWalletData>? = null,
    initialMatches: Map<String, com.example.core.model.AdminMatchItem>? = null
) : ResultsRepository {
    companion object {
        val defaultSeedResults = listOf(
            AdminResultItem(
                resultId = "res_seed_001",
                matchId = "mtc_seed_001",
                matchNumber = "#101",
                gameType = "LUDO",
                userId = "usr_tanvir_9812",
                userName = "Tanvir Hasan",
                userPhone = "01712984561",
                roomCode = "7829104",
                proofScreenshotUrl = "data:image/jpeg;base64,/9j/4AAQSkZJRg==",
                screenshotUrl = "data:image/jpeg;base64,/9j/4AAQSkZJRg==",
                prizeMinorUnits = TournamentMath.takaToMinorUnits(750),
                prizeTaka = 750.0,
                status = ResultStatus.PENDING,
                rawStatus = "PENDING",
                createdAt = System.currentTimeMillis() - 1800000L
            ),
            AdminResultItem(
                resultId = "res_seed_002",
                matchId = "mtc_seed_002",
                matchNumber = "#102",
                gameType = "CARROM",
                userId = "usr_shakib_4412",
                userName = "Shakib Rahman",
                userPhone = "01823490123",
                roomCode = "5512903",
                proofScreenshotUrl = "data:image/jpeg;base64,/9j/4AAQSkZJRg==",
                screenshotUrl = "data:image/jpeg;base64,/9j/4AAQSkZJRg==",
                prizeMinorUnits = TournamentMath.takaToMinorUnits(1200),
                prizeTaka = 1200.0,
                status = ResultStatus.APPROVED,
                rawStatus = "APPROVED",
                createdAt = System.currentTimeMillis() - 7200000L,
                processedAt = System.currentTimeMillis() - 3600000L
            )
        )

        val defaultSeedWallets = mapOf(
            "usr_tanvir_9812" to UserWalletData(
                userId = "usr_tanvir_9812",
                balance = TournamentMath.takaToMinorUnits(1200),
                availableBalance = TournamentMath.takaToMinorUnits(700),
                depositBalance = TournamentMath.takaToMinorUnits(500),
                winningBalance = TournamentMath.takaToMinorUnits(700),
                pendingBalance = TournamentMath.takaToMinorUnits(500),
                totalDeposited = TournamentMath.takaToMinorUnits(2000),
                totalWithdrawn = 0L,
                balanceDouble = 1200.0,
                lockedBalanceDouble = 500.0,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    private val database: FirebaseDatabase? = try {
        FirebaseDatabase.getInstance(FirebaseAdminConfig.RTDB_BASE_URL)
    } catch (e: Exception) {
        null
    }

    private val _matchesMap = (initialMatches ?: emptyMap()).toMutableMap()
    private val _resultsMap = (initialResults ?: defaultSeedResults).map { res ->
        if (res.prizeMinorUnits <= 0L && res.matchId.isNotBlank() && _matchesMap.containsKey(res.matchId)) {
            val match = _matchesMap[res.matchId]!!
            val resolvedMinor = ResultPrizeResolver.resolvePrizeMinorUnits(
                matchPrizeMinorUnits = match.prizeMinorUnits,
                matchPrizePoolTaka = match.prizePool,
                matchEntryFeeMinorUnits = match.entryFeeMinorUnits,
                matchEntryFeeTaka = match.entryFee,
                resultPrizeMinorUnits = res.prizeMinorUnits,
                resultPrizePoolTaka = res.prizeTaka.toDouble()
            )
            res.copy(
                prizeMinorUnits = resolvedMinor,
                prizeTaka = TournamentMath.minorUnitsToTakaDouble(resolvedMinor)
            )
        } else {
            res
        }
    }.associateBy { it.resultId }.toMutableMap()
    private val _walletsMap = (initialWallets ?: defaultSeedWallets).toMutableMap()
    private val _creditedResultIds = mutableSetOf<String>()
    private val _localResultsState = MutableStateFlow(_resultsMap.values.toList())

    fun getUserWallet(userId: String): UserWalletData? {
        return _walletsMap[userId]
    }

    fun setMatch(match: com.example.core.model.AdminMatchItem) {
        _matchesMap[match.matchId] = match
    }

    fun addResult(item: AdminResultItem) {
        val resolvedMinor = if (item.prizeMinorUnits <= 0L && item.matchId.isNotBlank() && _matchesMap.containsKey(item.matchId)) {
            val match = _matchesMap[item.matchId]!!
            ResultPrizeResolver.resolvePrizeMinorUnits(
                matchPrizeMinorUnits = match.prizeMinorUnits,
                matchPrizePoolTaka = match.prizePool,
                matchEntryFeeMinorUnits = match.entryFeeMinorUnits,
                matchEntryFeeTaka = match.entryFee,
                resultPrizeMinorUnits = item.prizeMinorUnits,
                resultPrizePoolTaka = item.prizeTaka.toDouble()
            )
        } else {
            item.prizeMinorUnits
        }
        val resolvedItem = item.copy(
            prizeMinorUnits = resolvedMinor,
            prizeTaka = TournamentMath.minorUnitsToTakaDouble(resolvedMinor)
        )
        _resultsMap[item.resultId] = resolvedItem
        _localResultsState.value = _resultsMap.values.toList()
    }

    private fun verifySuperAdmin(adminSession: SuperAdminSession) {
        if (!adminSession.isSuperAdminVerified || adminSession.uid.isBlank()) {
            throw SecurityException("Unauthorized: Result settlement requires verified Super Admin authorization.")
        }
    }

    override fun observeResults(): Flow<List<AdminResultItem>> {
        val db = database ?: return _localResultsState.asStateFlow()

        val resultsFlow = callbackFlow {
            val ref = db.getReference(FirebaseAdminConfig.NODE_RESULTS)
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    trySend(snapshot)
                }
                override fun onCancelled(error: DatabaseError) {
                    close(error.toException())
                }
            }
            ref.addValueEventListener(listener)
            awaitClose { ref.removeEventListener(listener) }
        }

        val matchesFlow = callbackFlow {
            val ref = db.getReference(FirebaseAdminConfig.NODE_MATCHES)
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    trySend(snapshot)
                }
                override fun onCancelled(error: DatabaseError) {
                    trySend(null)
                }
            }
            ref.addValueEventListener(listener)
            awaitClose { ref.removeEventListener(listener) }
        }

        return combine(resultsFlow, matchesFlow) { resultsSnap, matchesSnap ->
            val list = mutableListOf<AdminResultItem>()
            for (matchGroup in resultsSnap.children) {
                // Ensure this is a match node (has result objects as children)
                if (!matchGroup.hasChildren()) continue
                
                val matchIdFromKey = matchGroup.key ?: continue
                val matchSnap = if (matchesSnap != null && matchesSnap.hasChild(matchIdFromKey)) {
                    matchesSnap.child(matchIdFromKey)
                } else null

                for (child in matchGroup.children) {
                    // Ensure this is a result object (has fields), not a primitive leaf
                    if (!child.hasChildren()) continue

                    try {
                        val userIdFromKey = child.key ?: continue
                        val resultId = "$matchIdFromKey/$userIdFromKey"

                        val matchId = child.child("matchId").value?.toString()
                            ?: child.child("match_id").value?.toString()
                            ?: matchIdFromKey

                        val matchNumber = child.child("matchNumber").value?.toString()
                            ?: child.child("match_number").value?.toString()
                            ?: matchSnap?.child("matchNumber")?.value?.toString()
                            ?: matchSnap?.child("match_number")?.value?.toString() ?: "#001"
                        
                        val rawGame = child.child("gameType").value?.toString()
                            ?: child.child("game").value?.toString()
                            ?: matchSnap?.child("gameType")?.value?.toString()
                            ?: matchSnap?.child("game")?.value?.toString() ?: "LUDO"
                        val gameType = if (rawGame.contains("carrom", ignoreCase = true)) "CARROM" else "LUDO"

                        val userId = child.child("claimedWinnerUserId").value?.toString()
                            ?: child.child("submittedByUserId").value?.toString()
                            ?: child.child("userId").value?.toString()
                            ?: child.child("winnerUserId").value?.toString()
                            ?: child.child("uid").value?.toString()
                            ?: child.child("submitterId").value?.toString()
                            ?: child.child("playerUid").value?.toString()
                            ?: userIdFromKey

                        val winnerUserId = child.child("claimedWinnerUserId").value?.toString()
                            ?: child.child("submittedByUserId").value?.toString()
                            ?: child.child("winnerUserId").value?.toString()
                            ?: userId

                        var userName = child.child("userName").value?.toString()
                            ?: child.child("name").value?.toString()
                            ?: child.child("username").value?.toString()
                            ?: child.child("displayName").value?.toString()
                            ?: child.child("fullName").value?.toString() ?: ""
                        
                        if (userName.isBlank() || userName.equals("Player", ignoreCase = true)) {
                            userName = userId.ifBlank { "Player" }
                        }

                        val userPhone = child.child("userPhone").value?.toString()
                            ?: child.child("phone").value?.toString()
                            ?: child.child("mobile").value?.toString()
                            ?: child.child("contact").value?.toString() ?: ""

                        val reviewNotes = child.child("reviewNotes").value?.toString() ?: ""
                        var roomCode = child.child("roomCode").value?.toString()
                            ?: child.child("code").value?.toString()
                            ?: child.child("gameCode").value?.toString()

                        if (roomCode.isNullOrBlank() && reviewNotes.isNotBlank()) {
                            val regex = Regex("""রুমকোড:\s*([0-9]+)""", RegexOption.IGNORE_CASE)
                            val match = regex.find(reviewNotes)
                            roomCode = match?.groupValues?.get(1)
                        }

                        val authoritativeGameCode = matchSnap?.child("gameCode")?.value?.toString()
                            ?: matchSnap?.child("code")?.value?.toString() ?: ""
                        
                        val proofScreenshotUrl = child.child("proofScreenshotUrl").value?.toString()
                            ?: child.child("screenshotUrl").value?.toString()
                            ?: child.child("screenshot").value?.toString()
                            ?: child.child("imageUrl").value?.toString()
                            ?: child.child("proofUrl").value?.toString() ?: ""
                        val screenshotUrl = proofScreenshotUrl

                        val prizeMinor = ResultPrizeResolver.resolveFromSnapshots(matchSnap, child)
                        val prizeTaka = TournamentMath.minorUnitsToTakaDouble(prizeMinor)

                        val rawStatus = child.child("status").value?.toString() ?: "PENDING"
                        val status = ResultStatus.fromString(rawStatus)
                        val createdAt = (child.child("createdAt").value as? Number)?.toLong()
                            ?: (child.child("timestamp").value as? Number)?.toLong() ?: System.currentTimeMillis()
                        val processedAt = (child.child("processedAt").value as? Number)?.toLong()
                        val processedBy = child.child("processedBy").value?.toString()
                        val rejectionReason = child.child("rejectionReason").value?.toString()
                            ?: child.child("reason").value?.toString()
                        val settlementTransactionId = child.child("settlementTransactionId").value?.toString()
                            ?: child.child("transactionId").value?.toString() ?: ""

                        list.add(
                            AdminResultItem(
                                resultId = resultId,
                                matchId = matchId,
                                matchNumber = matchNumber,
                                gameType = gameType,
                                userId = userId,
                                winnerUserId = winnerUserId,
                                userName = userName,
                                userPhone = userPhone,
                                roomCode = (roomCode ?: "").ifBlank { authoritativeGameCode }.ifBlank { "N/A" },
                                reviewNotes = reviewNotes,
                                proofScreenshotUrl = proofScreenshotUrl,
                                screenshotUrl = proofScreenshotUrl,
                                prizeMinorUnits = prizeMinor,
                                prizeTaka = prizeTaka,
                                status = status,
                                rawStatus = rawStatus,
                                createdAt = createdAt,
                                processedAt = processedAt,
                                processedBy = processedBy,
                                rejectionReason = rejectionReason,
                                settlementTransactionId = settlementTransactionId
                            )
                        )
                    } catch (e: Exception) {
                        // Skip malformed nodes gracefully
                    }
                }
            }
            list.sortedByDescending { it.createdAt }
        }
    }

    override suspend fun getResult(resultId: String): AdminResultItem? {
        val db = database
        if (db == null) {
            val item = _resultsMap[resultId] ?: return null
            if (item.prizeMinorUnits <= 0L && item.matchId.isNotBlank() && _matchesMap.containsKey(item.matchId)) {
                val match = _matchesMap[item.matchId]!!
                val resolvedMinor = ResultPrizeResolver.resolvePrizeMinorUnits(
                    matchPrizeMinorUnits = match.prizeMinorUnits,
                    matchPrizePoolTaka = match.prizePool,
                    matchEntryFeeMinorUnits = match.entryFeeMinorUnits,
                    matchEntryFeeTaka = match.entryFee,
                    resultPrizeMinorUnits = item.prizeMinorUnits,
                    resultPrizePoolTaka = item.prizeTaka.toDouble()
                )
                val updated = item.copy(
                    prizeMinorUnits = resolvedMinor,
                    prizeTaka = TournamentMath.minorUnitsToTakaDouble(resolvedMinor)
                )
                _resultsMap[resultId] = updated
                return updated
            }
            return item
        }
        return try {
            val ref = db.getReference(FirebaseAdminConfig.NODE_RESULTS).child(resultId)
            val child = ref.get().await()
            if (child.exists()) {
                resolveResultData(db, resultId, child)
            } else {
                // If resultId is not matchId/userId but just userId, we might need a search, 
                // but usually the app passes the full resultId.
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    private suspend fun resolveResultData(
        db: FirebaseDatabase,
        resultId: String,
        child: DataSnapshot
    ): AdminResultItem {
        val parts = resultId.split("/")
        val matchIdFromPath = if (parts.size > 1) parts[0] else ""
        val userIdFromPath = if (parts.size > 1) parts[1] else resultId

        val matchId = child.child("matchId").value?.toString()
            ?: child.child("match_id").value?.toString()
            ?: matchIdFromPath

        val matchNumber = child.child("matchNumber").value?.toString()
            ?: child.child("match_number").value?.toString() ?: "#001"
        val rawGame = child.child("gameType").value?.toString()
            ?: child.child("game").value?.toString() ?: "LUDO"
        val gameType = if (rawGame.contains("carrom", ignoreCase = true)) "CARROM" else "LUDO"
        
        var userId = child.child("claimedWinnerUserId").value?.toString()
            ?: child.child("submittedByUserId").value?.toString()
            ?: child.child("userId").value?.toString()
            ?: child.child("winnerUserId").value?.toString()
            ?: child.child("uid").value?.toString()
            ?: child.child("submitterId").value?.toString()
            ?: child.child("playerUid").value?.toString()
            ?: userIdFromPath

        val winnerUserId = child.child("claimedWinnerUserId").value?.toString()
            ?: child.child("submittedByUserId").value?.toString()
            ?: child.child("winnerUserId").value?.toString()
            ?: userId

        var userName = child.child("userName").value?.toString()
            ?: child.child("name").value?.toString()
            ?: child.child("username").value?.toString()
            ?: child.child("displayName").value?.toString()
            ?: child.child("fullName").value?.toString() ?: ""
        
        if (userName.isBlank() || userName.equals("Player", ignoreCase = true)) {
            userName = userId.ifBlank { "Player" }
        }

        var userPhone = child.child("userPhone").value?.toString()
            ?: child.child("phone").value?.toString()
            ?: child.child("mobile").value?.toString()
            ?: child.child("contact").value?.toString() ?: ""

        val reviewNotes = child.child("reviewNotes").value?.toString() ?: ""
        var roomCode = child.child("roomCode").value?.toString()
            ?: child.child("code").value?.toString()
            ?: child.child("gameCode").value?.toString()

        if (roomCode.isNullOrBlank() && reviewNotes.isNotBlank()) {
            val regex = Regex("""রুমকোড:\s*([0-9]+)""", RegexOption.IGNORE_CASE)
            val match = regex.find(reviewNotes)
            roomCode = match?.groupValues?.get(1)
        }

        if (roomCode.isNullOrBlank()) {
            roomCode = ""
        }

        val proofScreenshotUrl = child.child("proofScreenshotUrl").value?.toString()
            ?: child.child("screenshotUrl").value?.toString()
            ?: child.child("screenshot").value?.toString()
            ?: child.child("imageUrl").value?.toString()
            ?: child.child("proofUrl").value?.toString() ?: ""
        val screenshotUrl = proofScreenshotUrl

        var matchSnap: DataSnapshot? = null
        if (matchId.isNotBlank()) {
            try {
                val snap = db.getReference(FirebaseAdminConfig.NODE_MATCHES).child(matchId).get().await()
                if (snap.exists()) {
                    matchSnap = snap
                    if (userId.isBlank()) {
                        userId = matchSnap.child("winnerUserId").value?.toString()
                            ?: matchSnap.child("winnerId").value?.toString()
                            ?: matchSnap.child("userId").value?.toString() ?: ""
                    }
                }
            } catch (e: Exception) {}
        }

        val authoritativeGameCode = matchSnap?.child("gameCode")?.value?.toString()
            ?: matchSnap?.child("code")?.value?.toString() ?: ""

        val prizeMinor = ResultPrizeResolver.resolveFromSnapshots(matchSnap, child)

        // Deep resolution from /matchPlayers if userId is still missing
        if (userId.isBlank() && matchId.isNotBlank()) {
            try {
                val playersSnap = db.getReference(FirebaseAdminConfig.NODE_MATCH_PLAYERS).child(matchId).get().await()
                    if (playersSnap.exists()) {
                        var firstPlayerId = ""
                        var firstPlayerName = ""
                        var firstPlayerPhone = ""
                        for (playerChild in playersSnap.children) {
                            val pId = playerChild.key ?: continue
                            val pUserId = playerChild.child("userId").value?.toString()
                                ?: playerChild.child("uid").value?.toString() ?: pId
                            val pName = playerChild.child("username").value?.toString()
                                ?: playerChild.child("name").value?.toString() ?: ""
                            val pPhone = playerChild.child("phone").value?.toString()
                                ?: playerChild.child("mobile").value?.toString() ?: ""
                            val isWinnerFlag = playerChild.child("isWinner").getValue(Boolean::class.java)
                                ?: playerChild.child("winner").getValue(Boolean::class.java)
                                ?: (playerChild.child("status").value?.toString().equals("WON", ignoreCase = true))

                            if (firstPlayerId.isBlank()) {
                                firstPlayerId = pUserId
                                firstPlayerName = pName
                                firstPlayerPhone = pPhone
                            }
                            if (isWinnerFlag) {
                                userId = pUserId
                                if (userName.isBlank() || userName.equals("Player", ignoreCase = true)) {
                                    if (pName.isNotBlank()) userName = pName
                                }
                                if (userPhone.isBlank() && pPhone.isNotBlank()) {
                                    userPhone = pPhone
                                }
                                break
                            }
                        }
                        if (userId.isBlank() && firstPlayerId.isNotBlank()) {
                            userId = firstPlayerId
                            if (userName.isBlank() || userName.equals("Player", ignoreCase = true)) {
                                if (firstPlayerName.isNotBlank()) userName = firstPlayerName
                            }
                            if (userPhone.isBlank() && firstPlayerPhone.isNotBlank()) {
                                userPhone = firstPlayerPhone
                            }
                        }
                    }
            } catch (e: Exception) {}
        }

        if (userId.isNotBlank() && (userName.isBlank() || userName.equals("Player", ignoreCase = true))) {
            try {
                val userSnap = db.getReference(FirebaseAdminConfig.NODE_USERS).child(userId).get().await()
                if (userSnap.exists()) {
                    val uName = userSnap.child("name").value?.toString()
                        ?: userSnap.child("username").value?.toString()
                        ?: userSnap.child("fullName").value?.toString() ?: ""
                    val uPhone = userSnap.child("phone").value?.toString()
                        ?: userSnap.child("mobile").value?.toString() ?: ""
                    if (uName.isNotBlank()) userName = uName
                    if (userPhone.isBlank() && uPhone.isNotBlank()) userPhone = uPhone
                }
            } catch (e: Exception) {}
        }

        if (userName.isBlank() || userName.equals("Player", ignoreCase = true)) {
            userName = userId.ifBlank { "Player" }
        }

        val prizeTaka = TournamentMath.minorUnitsToTakaDouble(prizeMinor)
        val rawStatus = child.child("status").value?.toString() ?: "PENDING"
        val status = ResultStatus.fromString(rawStatus)
        val createdAt = (child.child("createdAt").value as? Number)?.toLong()
            ?: (child.child("timestamp").value as? Number)?.toLong() ?: System.currentTimeMillis()
        val processedAt = (child.child("processedAt").value as? Number)?.toLong()
        val processedBy = child.child("processedBy").value?.toString()
        val rejectionReason = child.child("rejectionReason").value?.toString()
            ?: child.child("reason").value?.toString()
        val settlementTransactionId = child.child("settlementTransactionId").value?.toString()
            ?: child.child("transactionId").value?.toString() ?: ""

        return AdminResultItem(
            resultId = resultId,
            matchId = matchId,
            matchNumber = matchNumber,
            gameType = gameType,
            userId = userId,
            winnerUserId = winnerUserId,
            userName = userName,
            userPhone = userPhone,
            roomCode = (roomCode ?: "").ifBlank { authoritativeGameCode }.ifBlank { "N/A" },
            proofScreenshotUrl = proofScreenshotUrl,
            screenshotUrl = proofScreenshotUrl,
            prizeMinorUnits = prizeMinor,
            prizeTaka = prizeTaka,
            status = status,
            rawStatus = rawStatus,
            createdAt = createdAt,
            processedAt = processedAt,
            processedBy = processedBy,
            rejectionReason = rejectionReason,
            settlementTransactionId = settlementTransactionId,
            reviewNotes = reviewNotes
        )
    }

    override suspend fun approveResult(
        resultId: String,
        submittedMatchNumber: String,
        submittedRoomCode: String,
        adminSession: SuperAdminSession
    ): Result<Unit> = runCatching {
        verifySuperAdmin(adminSession)
        val db = database

        if (db == null) {
            // In-memory offline/test execution path
            val resultItem = getResult(resultId)
                ?: throw IllegalArgumentException("Result submission '$resultId' does not exist.")

            if (resultItem.status == ResultStatus.APPROVED) {
                throw IllegalStateException("Result '$resultId' has already been approved and settled.")
            }
            if (resultItem.status == ResultStatus.REJECTED) {
                throw IllegalStateException("Result '$resultId' was rejected and cannot be approved.")
            }

            val userId = resultItem.userId
            require(userId.isNotBlank()) { "Winner User ID is missing from result submission." }

            if (_creditedResultIds.contains(resultId)) {
                throw IllegalStateException("Result '$resultId' has already been approved or settled concurrently.")
            }

            val prizeMinor = if (resultItem.prizeMinorUnits > 0L) {
                resultItem.prizeMinorUnits
            } else if (resultItem.matchId.isNotBlank() && _matchesMap.containsKey(resultItem.matchId)) {
                val match = _matchesMap[resultItem.matchId]!!
                ResultPrizeResolver.resolvePrizeMinorUnits(
                    matchPrizeMinorUnits = match.prizeMinorUnits,
                    matchPrizePoolTaka = match.prizePool,
                    matchEntryFeeMinorUnits = match.entryFeeMinorUnits,
                    matchEntryFeeTaka = match.entryFee,
                    resultPrizeMinorUnits = resultItem.prizeMinorUnits,
                    resultPrizePoolTaka = resultItem.prizeTaka.toDouble()
                )
            } else {
                resultItem.prizeMinorUnits
            }
            require(prizeMinor > 0L) { "Cannot approve result: Prize amount is ৳0." }
            val now = System.currentTimeMillis()
            val deterministicTrxId = "WIN_$resultId"
            val prizeTaka = TournamentMath.minorUnitsToTakaDouble(prizeMinor)

            val currentWallet = _walletsMap[userId] ?: UserWalletData(userId = userId)
            val updatedWallet = currentWallet.copy(
                balance = currentWallet.balance + prizeMinor,
                availableBalance = currentWallet.availableBalance + prizeMinor,
                winningBalance = currentWallet.winningBalance + prizeMinor,
                balanceDouble = (currentWallet.balance + prizeMinor) / 100.0,
                updatedAt = now
            )
            _walletsMap[userId] = updatedWallet
            _creditedResultIds.add(resultId)

            // Update result item (mark approved and remove proofScreenshotUrl)
            val approvedItem = resultItem.copy(
                status = ResultStatus.APPROVED,
                rawStatus = ResultStatus.APPROVED.name,
                prizeMinorUnits = prizeMinor,
                prizeTaka = prizeTaka,
                proofScreenshotUrl = "",
                screenshotUrl = "",
                processedAt = now,
                processedBy = adminSession.identifier,
                settlementTransactionId = deterministicTrxId
            )
            _resultsMap[resultId] = approvedItem
            _localResultsState.value = _resultsMap.values.toList()

            sendResultNotification(
                userId = userId,
                title = "Match Winning Prize Credited! / ম্যাচ বিজয়ী পুরস্কার যোগ হয়েছে",
                message = "Congratulations! You won match ${resultItem.matchNumber}. Prize of ৳$prizeTaka has been credited to your wallet balance.",
                adminSession = adminSession
            )

            return@runCatching
        }

        // Production Firebase Realtime Database path
        val resultItem = getResult(resultId)
            ?: throw IllegalArgumentException("Result submission '$resultId' does not exist.")

        if (resultItem.status == ResultStatus.APPROVED) {
            throw IllegalStateException("Result '$resultId' has already been approved and settled.")
        }
        if (resultItem.status == ResultStatus.REJECTED) {
            throw IllegalStateException("Result '$resultId' was rejected and cannot be approved.")
        }

        val matchId = resultItem.matchId
        require(matchId.isNotBlank()) { "Result submission is not linked to any match ID." }

        // Fetch authoritative match details from /matches/{matchId}
        val matchSnapshot = db.getReference(FirebaseAdminConfig.NODE_MATCHES).child(matchId).get().await()
        if (!matchSnapshot.exists()) {
            throw IllegalArgumentException("Linked match ID '$matchId' does not exist in the system.")
        }

        val canonicalMatchNumber = matchSnapshot.child("matchNumber").value?.toString()
            ?: matchSnapshot.child("match_number").value?.toString() ?: resultItem.matchNumber
        val authoritativeGameCode = matchSnapshot.child("gameCode").value?.toString()
            ?: matchSnapshot.child("code").value?.toString()
            ?: matchSnapshot.child("game_code").value?.toString() ?: ""
        val authoritativePrizeMinor = ResultPrizeResolver.resolveFromSnapshots(matchSnapshot).let { resolved ->
            if (resolved > 0L) resolved else resultItem.prizeMinorUnits
        }
        // Allow approval even if prize is 0 (manual correction or free matches) as per user request
        // require(authoritativePrizeMinor > 0L) { "Cannot approve result: Prize amount is ৳0." }

        // Strict correspondence check
        val cleanSubmittedMatchNum = submittedMatchNumber.trim().lowercase()
        val cleanCanonicalMatchNum = canonicalMatchNumber.trim().lowercase()
        require(cleanSubmittedMatchNum == cleanCanonicalMatchNum || resultItem.matchNumber.trim().lowercase() == cleanCanonicalMatchNum) {
            "Match verification mismatch: Submitted Match Number ($submittedMatchNumber) does not correspond to system Match Number ($canonicalMatchNumber)."
        }

        val cleanSubmittedRoomCode = submittedRoomCode.trim()
        val cleanAuthoritativeRoomCode = authoritativeGameCode.trim()
        if (cleanAuthoritativeRoomCode.isNotBlank()) {
            require(cleanSubmittedRoomCode.equals(cleanAuthoritativeRoomCode, ignoreCase = true) || cleanSubmittedRoomCode.equals(resultItem.roomCode.trim(), ignoreCase = true)) {
                "Room Code verification mismatch: Submitted Room Code ($submittedRoomCode) does not correspond to authoritative system Room Code."
            }
        }

        val userId = resultItem.userId
        require(userId.isNotBlank()) { "Winner User ID is missing from result submission." }

        val now = System.currentTimeMillis()
        val deterministicTrxId = "WIN_$resultId"
        val deterministicLogId = "AUDIT_WIN_$resultId"
        val prizeTaka = TournamentMath.minorUnitsToTakaDouble(authoritativePrizeMinor)

        // Step 1: Authoritative atomic status lock on /results/{resultId}
        val resultRef = db.getReference(FirebaseAdminConfig.NODE_RESULTS).child(resultId)
        val lockResult = executeResultApprovalLockTransaction(
            resultRef = resultRef,
            adminSession = adminSession,
            settlementTrxId = deterministicTrxId,
            authoritativePrizeMinor = authoritativePrizeMinor,
            now = now
        )

        if (!lockResult.success) {
            if (lockResult.alreadySettled) {
                throw IllegalStateException("Result '$resultId' has already been approved or settled concurrently.")
            }
            throw IllegalStateException(lockResult.errorMessage ?: "Failed to lock result status for approval.")
        }

        // Step 2: Atomic wallet prize credit via runTransaction on /wallets/{userId}
        val walletRef = db.getReference(FirebaseAdminConfig.NODE_WALLETS).child(userId)
        val walletCreditResult = executeWalletPrizeCreditTransaction(
            walletRef = walletRef,
            resultId = resultId,
            prizeMinorUnits = authoritativePrizeMinor,
            now = now
        )

        if (!walletCreditResult.success) {
            throw IllegalStateException(walletCreditResult.errorMessage ?: "Wallet prize credit transaction failed.")
        }

        // Step 3: Write secondary mirrored nodes, match winner updates, ledger transaction, audit logs, and nullify proofScreenshotUrl
        val userResultsNodeKey = "userResults"
        val updates = mutableMapOf<String, Any?>(
            // User result mirror update
            "$userResultsNodeKey/$userId/$resultId/status" to ResultStatus.APPROVED.name,
            "$userResultsNodeKey/$userId/$resultId/processedAt" to now,
            "$userResultsNodeKey/$userId/$resultId/processedBy" to adminSession.identifier,
            "$userResultsNodeKey/$userId/$resultId/settlementTransactionId" to deterministicTrxId,
            "$userResultsNodeKey/$userId/$resultId/proofScreenshotUrl" to null,
            "$userResultsNodeKey/$userId/$resultId/screenshotUrl" to null,

            // Root result screenshot removal
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/proofScreenshotUrl" to null,
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/screenshotUrl" to null,

            // Update match winner & status in /matches/{matchId}
            "${FirebaseAdminConfig.NODE_MATCHES}/$matchId/winnerUserId" to userId,
            "${FirebaseAdminConfig.NODE_MATCHES}/$matchId/status" to "COMPLETED",
            "${FirebaseAdminConfig.NODE_MATCHES}/$matchId/updatedAt" to now,

            // Profile consistency update in /users/{userId}
            "${FirebaseAdminConfig.NODE_USERS}/$userId/balance" to walletCreditResult.newBalance,
            "${FirebaseAdminConfig.NODE_USERS}/$userId/winningBalance" to walletCreditResult.newWinningBalance,
            "${FirebaseAdminConfig.NODE_USERS}/$userId/updatedAt" to now,

            // Global ledger record in /transactions/{deterministicTrxId}
            "${FirebaseAdminConfig.NODE_TRANSACTIONS}/$deterministicTrxId" to mapOf(
                "transactionId" to deterministicTrxId,
                "resultId" to resultId,
                "matchId" to matchId,
                "userId" to userId,
                "amount" to prizeTaka,
                "amountMinorUnits" to authoritativePrizeMinor,
                "type" to "PRIZE_WIN",
                "direction" to "CREDIT",
                "status" to "COMPLETED",
                "timestamp" to now,
                "processedBy" to adminSession.identifier,
                "description" to "Prize winning payout of ৳$prizeTaka credited for match $canonicalMatchNumber"
            ),

            // User ledger mirror in /userTransactions/{userId}/{deterministicTrxId}
            "${FirebaseAdminConfig.NODE_USER_TRANSACTIONS}/$userId/$deterministicTrxId" to mapOf(
                "transactionId" to deterministicTrxId,
                "resultId" to resultId,
                "matchId" to matchId,
                "amount" to prizeTaka,
                "amountMinorUnits" to authoritativePrizeMinor,
                "type" to "PRIZE_WIN",
                "direction" to "CREDIT",
                "status" to "COMPLETED",
                "timestamp" to now,
                "description" to "Won match $canonicalMatchNumber — Prize credited: ৳$prizeTaka"
            ),

            // Immutable audit log entry in /auditLogs/{deterministicLogId}
            "${FirebaseAdminConfig.NODE_AUDIT_LOGS}/$deterministicLogId" to mapOf(
                "action" to "MATCH_RESULT_APPROVED",
                "admin" to adminSession.identifier,
                "referenceId" to resultId,
                "matchId" to matchId,
                "timestamp" to now,
                "reason" to "Super Admin approved result for match $canonicalMatchNumber. Credited prize of ৳$prizeTaka to winner $userId",
                "amount" to prizeTaka,
                "amountMinorUnits" to authoritativePrizeMinor,
                "userId" to userId,
                "transactionId" to deterministicTrxId
            )
        )

        db.reference.updateChildren(updates).await()

        // Step 4: Idempotent screenshot cleanup after primary financial & status settlement (never rolls back approval)
        try {
            db.getReference(FirebaseAdminConfig.NODE_RESULTS).child(resultId).child("proofScreenshotUrl").removeValue().await()
            db.getReference(FirebaseAdminConfig.NODE_RESULTS).child(resultId).child("screenshotUrl").removeValue().await()
            if (userId.isNotBlank()) {
                db.getReference(userResultsNodeKey).child(userId).child(resultId).child("proofScreenshotUrl").removeValue().await()
                db.getReference(userResultsNodeKey).child(userId).child(resultId).child("screenshotUrl").removeValue().await()
            }
        } catch (e: Exception) {
            // Screenshot cleanup failure must never fail the successful financial settlement
        }

        // Step 5: Send notification to winner
        sendResultNotification(
            userId = userId,
            title = "Match Winning Prize Credited! / ম্যাচ বিজয়ী পুরস্কার যোগ হয়েছে",
            message = "Congratulations! You won match $canonicalMatchNumber. Prize of ৳$prizeTaka has been credited to your wallet balance.",
            adminSession = adminSession
        )
    }

    override suspend fun rejectResult(
        resultId: String,
        reason: String,
        adminSession: SuperAdminSession
    ): Result<Unit> = runCatching {
        verifySuperAdmin(adminSession)
        val trimmedReason = reason.trim()
        require(trimmedReason.isNotBlank()) { "Rejection reason is required." }

        val db = database

        if (db == null) {
            // In-memory offline/test execution path
            val resultItem = getResult(resultId)
                ?: throw IllegalArgumentException("Result submission '$resultId' does not exist.")

            if (resultItem.status == ResultStatus.APPROVED) {
                throw IllegalStateException("Result '$resultId' is already approved and settled.")
            }
            if (resultItem.status == ResultStatus.REJECTED) {
                throw IllegalStateException("Result '$resultId' is already rejected.")
            }

            val now = System.currentTimeMillis()
            val userId = resultItem.userId

            val rejectedItem = resultItem.copy(
                status = ResultStatus.REJECTED,
                rawStatus = ResultStatus.REJECTED.name,
                proofScreenshotUrl = "",
                screenshotUrl = "",
                rejectionReason = trimmedReason,
                processedAt = now,
                processedBy = adminSession.identifier
            )
            _resultsMap[resultId] = rejectedItem
            _localResultsState.value = _resultsMap.values.toList()

            if (userId.isNotBlank()) {
                sendResultNotification(
                    userId = userId,
                    title = "Result Submission Rejected / রেজাল্ট বাতিল করা হয়েছে",
                    message = "Your result submission for match ${resultItem.matchNumber} was rejected. Reason: $trimmedReason",
                    adminSession = adminSession
                )
            }

            return@runCatching
        }

        // Production Firebase Realtime Database path
        val resultItem = getResult(resultId)
            ?: throw IllegalArgumentException("Result submission '$resultId' does not exist.")

        if (resultItem.status == ResultStatus.APPROVED) {
            throw IllegalStateException("Result '$resultId' is already approved and settled.")
        }
        if (resultItem.status == ResultStatus.REJECTED) {
            throw IllegalStateException("Result '$resultId' is already rejected.")
        }

        val now = System.currentTimeMillis()
        val userId = resultItem.userId
        val deterministicLogId = "AUDIT_REJ_RES_$resultId"
        val userResultsNodeKey = "userResults"

        val updates = mutableMapOf<String, Any?>(
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/status" to ResultStatus.REJECTED.name,
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/rejectionReason" to trimmedReason,
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/proofScreenshotUrl" to null,
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/screenshotUrl" to null,
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/processedAt" to now,
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/processedBy" to adminSession.identifier,
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/updatedAt" to now,

            "${FirebaseAdminConfig.NODE_AUDIT_LOGS}/$deterministicLogId" to mapOf(
                "action" to "MATCH_RESULT_REJECTED",
                "admin" to adminSession.identifier,
                "referenceId" to resultId,
                "timestamp" to now,
                "reason" to "Super Admin rejected result submission: $trimmedReason"
            )
        )

        if (userId.isNotBlank()) {
            updates["$userResultsNodeKey/$userId/$resultId/status"] = ResultStatus.REJECTED.name
            updates["$userResultsNodeKey/$userId/$resultId/rejectionReason"] = trimmedReason
            updates["$userResultsNodeKey/$userId/$resultId/proofScreenshotUrl"] = null
            updates["$userResultsNodeKey/$userId/$resultId/screenshotUrl"] = null
        }

        db.reference.updateChildren(updates).await()

        // Idempotent screenshot cleanup after rejection (never rolls back rejection)
        try {
            db.getReference(FirebaseAdminConfig.NODE_RESULTS).child(resultId).child("proofScreenshotUrl").removeValue().await()
            db.getReference(FirebaseAdminConfig.NODE_RESULTS).child(resultId).child("screenshotUrl").removeValue().await()
            if (userId.isNotBlank()) {
                db.getReference(userResultsNodeKey).child(userId).child(resultId).child("proofScreenshotUrl").removeValue().await()
                db.getReference(userResultsNodeKey).child(userId).child(resultId).child("screenshotUrl").removeValue().await()
            }
        } catch (e: Exception) {
            // Screenshot cleanup failure must never fail the rejection operation
        }

        // Send notification
        if (userId.isNotBlank()) {
            sendResultNotification(
                userId = userId,
                title = "Result Submission Rejected / রেজাল্ট বাতিল করা হয়েছে",
                message = "Your result submission for match ${resultItem.matchNumber} was rejected. Reason: $trimmedReason",
                adminSession = adminSession
            )
        }
    }

    private suspend fun sendResultNotification(
        userId: String,
        title: String,
        message: String,
        adminSession: SuperAdminSession
    ) {
        try {
            val notifRepo = FirebaseNotificationsRepository()
            notifRepo.sendNotification(
                title = title,
                message = message,
                targetType = NotificationTargetType.SPECIFIC_USER,
                targetId = userId,
                adminSession = adminSession
            )
        } catch (e: Exception) {
            // Non-critical notification failure must never block financial operations
        }
    }

    private suspend fun executeResultApprovalLockTransaction(
        resultRef: DatabaseReference,
        adminSession: SuperAdminSession,
        settlementTrxId: String,
        authoritativePrizeMinor: Long,
        now: Long
    ): ResultApprovalResult = suspendCancellableCoroutine { continuation ->
        resultRef.runTransaction(object : Transaction.Handler {
            var failureMessage: String? = null
            var wasAlreadySettled = false

            override fun doTransaction(currentData: MutableData): Transaction.Result {
                if (currentData.value == null) {
                    failureMessage = "Result submission record does not exist on database."
                    return Transaction.abort()
                }

                val currentStatusStr = currentData.child("status").value?.toString()
                val currentStatus = ResultStatus.fromString(currentStatusStr)

                if (currentStatus == ResultStatus.APPROVED) {
                    wasAlreadySettled = true
                    failureMessage = "Result is already APPROVED and settled."
                    return Transaction.abort()
                }

                if (currentStatus == ResultStatus.REJECTED) {
                    wasAlreadySettled = true
                    failureMessage = "Result is ALREADY REJECTED."
                    return Transaction.abort()
                }

                currentData.child("status").value = ResultStatus.APPROVED.name
                currentData.child("processedAt").value = now
                currentData.child("processedBy").value = adminSession.identifier
                currentData.child("updatedAt").value = now
                currentData.child("settlementTransactionId").value = settlementTrxId
                currentData.child("settledPrizeMinorUnits").value = authoritativePrizeMinor

                return Transaction.success(currentData)
            }

            override fun onComplete(
                error: DatabaseError?,
                committed: Boolean,
                currentData: DataSnapshot?
            ) {
                if (committed && error == null) {
                    continuation.resume(ResultApprovalResult(success = true))
                } else {
                    continuation.resume(
                        ResultApprovalResult(
                            success = false,
                            alreadySettled = wasAlreadySettled,
                            errorMessage = error?.message ?: failureMessage ?: "Result approval lock transaction aborted."
                        )
                    )
                }
            }
        })
    }

    private suspend fun executeWalletPrizeCreditTransaction(
        walletRef: DatabaseReference,
        resultId: String,
        prizeMinorUnits: Long,
        now: Long
    ): WalletPrizeCreditResult = suspendCancellableCoroutine { continuation ->
        walletRef.runTransaction(object : Transaction.Handler {
            var failureMessage: String? = null
            var creditResult: WalletPrizeCreditResult? = null

            override fun doTransaction(currentData: MutableData): Transaction.Result {
                // Idempotency check: verify if this resultId was already credited to the wallet
                val creditedResultsNode = currentData.child("creditedResults")
                if (creditedResultsNode.hasChild(resultId)) {
                    creditResult = WalletPrizeCreditResult(
                        success = true,
                        alreadySettled = true,
                        newBalance = (currentData.child("balance").value as? Number)?.toLong() ?: 0L,
                        newWinningBalance = (currentData.child("winningBalance").value as? Number)?.toLong() ?: 0L
                    )
                    return Transaction.abort()
                }

                val currentBalance = (currentData.child("balance").value as? Number)?.toLong() ?: 0L
                val currentAvailable = (currentData.child("availableBalance").value as? Number)?.toLong() ?: currentBalance
                val currentWinning = (currentData.child("winningBalance").value as? Number)?.toLong() ?: 0L
                val currentPending = (currentData.child("pendingBalance").value as? Number)?.toLong() ?: 0L

                val newAvailable = currentAvailable + prizeMinorUnits
                val newWinning = currentWinning + prizeMinorUnits
                val newBalance = newAvailable + currentPending

                currentData.child("balance").value = newBalance
                currentData.child("availableBalance").value = newAvailable
                currentData.child("winningBalance").value = newWinning
                currentData.child("balanceDouble").value = newBalance / 100.0
                currentData.child("updatedAt").value = now

                // Mark resultId as settled inside wallet
                currentData.child("creditedResults").child(resultId).value = mapOf(
                    "resultId" to resultId,
                    "prizeMinorUnits" to prizeMinorUnits,
                    "creditedAt" to now
                )

                creditResult = WalletPrizeCreditResult(
                    success = true,
                    alreadySettled = false,
                    newBalance = newBalance,
                    newWinningBalance = newWinning
                )

                return Transaction.success(currentData)
            }

            override fun onComplete(
                error: DatabaseError?,
                committed: Boolean,
                currentData: DataSnapshot?
            ) {
                if (committed && error == null) {
                    continuation.resume(creditResult ?: WalletPrizeCreditResult(success = true))
                } else {
                    continuation.resume(
                        creditResult ?: WalletPrizeCreditResult(
                            success = false,
                            errorMessage = error?.message ?: failureMessage ?: "Wallet prize credit transaction failed."
                        )
                    )
                }
            }
        })
    }
}

data class WalletPrizeCreditResult(
    val success: Boolean,
    val alreadySettled: Boolean = false,
    val newBalance: Long = 0L,
    val newWinningBalance: Long = 0L,
    val errorMessage: String? = null
)
