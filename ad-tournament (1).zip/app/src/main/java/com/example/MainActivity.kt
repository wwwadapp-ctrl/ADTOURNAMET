package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.compose.rememberNavController
import com.example.core.network.NetworkStatus
import com.example.ui.components.NetworkStatusBar
import com.example.ui.navigation.AppNavigation
import com.example.ui.theme.AdTournamentTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    val app = application as TournamentApplication
    val container = app.container

    setContent {
      AdTournamentTheme(darkTheme = true) {
        val navController = rememberNavController()
        val networkStatus by container.networkMonitor.status.collectAsState(initial = NetworkStatus.Available)

        Scaffold(
          modifier = Modifier.fillMaxSize(),
          topBar = {
            NetworkStatusBar(networkStatus = networkStatus)
          },
        ) { innerPadding ->
          Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            AppNavigation(
              navController = navController,
              container = container,
            )
          }
        }
      }
    }
  }
}
