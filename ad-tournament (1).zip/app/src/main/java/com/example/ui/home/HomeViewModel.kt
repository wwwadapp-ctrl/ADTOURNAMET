package com.example.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.error.Resource
import com.example.domain.model.GameType
import com.example.domain.model.MatchEntity
import com.example.domain.repository.MatchRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class HomeUiState(
  val isLoading: Boolean = true,
  val allMatches: List<MatchEntity> = emptyList(),
  val filteredMatches: List<MatchEntity> = emptyList(),
  val selectedGameFilter: GameType? = null,
  val errorMessage: String? = null,
  val joinedMatchIds: Set<String> = emptySet(),
)

class HomeViewModel(
  private val matchRepository: MatchRepository,
) : ViewModel() {

  private val _uiState = MutableStateFlow(HomeUiState())
  val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

  init {
    loadMatches()
  }

  fun loadMatches() {
    viewModelScope.launch {
      matchRepository.getAvailableMatches().collect { resource ->
        when (resource) {
          is Resource.Loading -> {
            _uiState.value = _uiState.value.copy(isLoading = true)
          }
          is Resource.Success -> {
            val matches = resource.data
            _uiState.value = _uiState.value.copy(
              isLoading = false,
              allMatches = matches,
              filteredMatches = filterMatches(matches, _uiState.value.selectedGameFilter),
              errorMessage = null,
            )
          }
          is Resource.Error -> {
            _uiState.value = _uiState.value.copy(
              isLoading = false,
              errorMessage = resource.error.message,
            )
          }
          is Resource.Idle -> Unit
        }
      }
    }
  }

  fun setGameFilter(gameType: GameType?) {
    _uiState.value = _uiState.value.copy(
      selectedGameFilter = gameType,
      filteredMatches = filterMatches(_uiState.value.allMatches, gameType),
    )
  }

  private fun filterMatches(matches: List<MatchEntity>, filter: GameType?): List<MatchEntity> {
    if (filter == null) return matches
    return matches.filter { it.gameType.equals(filter.name, ignoreCase = true) }
  }

  class Factory(private val matchRepository: MatchRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
      return HomeViewModel(matchRepository) as T
    }
  }
}
