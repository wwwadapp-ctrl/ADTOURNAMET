package com.example.ui.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.GameType
import com.example.domain.model.MatchEntity
import com.example.domain.model.UserEntity
import com.example.ui.components.EmptyState
import com.example.ui.components.ErrorState
import com.example.ui.components.LoadingState
import com.example.ui.components.MatchCard
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
  viewModel: HomeViewModel,
  currentUser: UserEntity?,
  walletBalance: Long,
  onMatchClick: (String) -> Unit,
  onWalletClick: () -> Unit,
  onProfileClick: () -> Unit,
  onAdminClick: () -> Unit,
) {
  val uiState by viewModel.uiState.collectAsState()

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
              color = Gold500.copy(alpha = 0.2f),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.size(36.dp),
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  imageVector = Icons.Default.EmojiEvents,
                  contentDescription = null,
                  tint = Gold400,
                  modifier = Modifier.size(20.dp),
                )
              }
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "AD TOURNAMENT",
                style = MaterialTheme.typography.titleMedium.copy(
                  fontWeight = FontWeight.Black,
                  letterSpacing = 1.sp,
                ),
                color = Color.White,
              )
              Text(
                text = "Esports Battles",
                style = MaterialTheme.typography.labelSmall,
                color = Gold400,
              )
            }
          }
        },
        actions = {
          Surface(
            color = Slate850,
            shape = RoundedCornerShape(20.dp),
            border = BorderStroke(1.dp, Gold500.copy(alpha = 0.5f)),
            modifier = Modifier
              .clickable { onWalletClick() }
              .padding(end = 8.dp)
              .testTag("home_wallet_chip"),
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(
                imageVector = Icons.Default.AccountBalanceWallet,
                contentDescription = "Wallet",
                tint = Gold400,
                modifier = Modifier.size(16.dp),
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "৳ ${"%.0f".format(walletBalance / 100.0)}",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = Color.White,
              )
            }
          }

          if (currentUser?.role?.equals("ADMIN", ignoreCase = true) == true ||
              currentUser?.role?.equals("SUPER_ADMIN", ignoreCase = true) == true) {
            IconButton(onClick = onAdminClick, modifier = Modifier.testTag("admin_nav_button")) {
              Icon(Icons.Default.AdminPanelSettings, contentDescription = "Admin", tint = Cyan400)
            }
          }

          IconButton(onClick = onProfileClick, modifier = Modifier.testTag("profile_nav_button")) {
            Icon(Icons.Default.AccountCircle, contentDescription = "Profile", tint = Slate300)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = NavySurface,
        ),
      )
    },
    containerColor = DeepNavyBg,
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding),
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        FilterChip(
          selected = uiState.selectedGameFilter == null,
          onClick = { viewModel.setGameFilter(null) },
          label = { Text("All Matches") },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = Gold500,
            selectedLabelColor = Slate950,
            containerColor = Slate900,
            labelColor = Slate300,
          ),
        )
        FilterChip(
          selected = uiState.selectedGameFilter == GameType.LUDO,
          onClick = { viewModel.setGameFilter(GameType.LUDO) },
          label = { Text("Ludo 1v1") },
          leadingIcon = {
            Icon(Icons.Default.Casino, contentDescription = null, modifier = Modifier.size(16.dp))
          },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = Indigo600,
            selectedLabelColor = Color.White,
            containerColor = Slate900,
            labelColor = Slate300,
          ),
        )
        FilterChip(
          selected = uiState.selectedGameFilter == GameType.CARROM,
          onClick = { viewModel.setGameFilter(GameType.CARROM) },
          label = { Text("Carrom 1v1") },
          leadingIcon = {
            Icon(Icons.Default.Album, contentDescription = null, modifier = Modifier.size(16.dp))
          },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = Cyan600,
            selectedLabelColor = Color.White,
            containerColor = Slate900,
            labelColor = Slate300,
          ),
        )
      }

      when {
        uiState.isLoading -> {
          LoadingState(message = "Fetching active matches...")
        }
        uiState.errorMessage != null -> {
          ErrorState(
            message = uiState.errorMessage ?: "Failed to load matches",
            onRetry = { viewModel.loadMatches() },
          )
        }
        uiState.filteredMatches.isEmpty() -> {
          EmptyState(
            title = "No Matches Available",
            description = "No 1v1 battles currently scheduled for this filter. Check back soon or pull to refresh.",
            actionButtonText = "Refresh",
            onActionClick = { viewModel.loadMatches() },
          )
        }
        else -> {
          LazyColumn(
            modifier = Modifier
              .fillMaxSize()
              .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 24.dp, top = 6.dp),
          ) {
            items(uiState.filteredMatches, key = { it.matchId }) { match ->
              MatchCard(
                match = match,
                onCardClick = { onMatchClick(match.matchId) },
                onJoinClick = { onMatchClick(match.matchId) },
                onViewCodeClick = { onMatchClick(match.matchId) },
                onSubmitProofClick = { onMatchClick(match.matchId) },
                isJoined = uiState.joinedMatchIds.contains(match.matchId),
              )
            }
          }
        }
      }
    }
  }
}
