package com.example.ui.wallet

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.TournamentButton
import com.example.ui.components.TournamentButtonVariant
import com.example.ui.components.TournamentCard
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WalletScreen(
  viewModel: WalletViewModel,
  onNavigateBack: () -> Unit,
  onNavigateToDeposit: () -> Unit,
  onNavigateToWithdraw: () -> Unit,
  onNavigateToTransactions: () -> Unit,
) {
  val uiState by viewModel.uiState.collectAsState()
  val wallet = uiState.wallet

  val availableBalance = wallet?.availableBalance ?: 0L
  val pendingBalance = wallet?.pendingBalance ?: 0L
  val totalDeposited = wallet?.totalDeposited ?: 0L
  val totalWithdrawn = wallet?.totalWithdrawn ?: 0L
  val totalWinnings = wallet?.totalWinnings ?: 0L

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Text(
            text = "Tournament Wallet",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = Color.White,
          )
        },
        navigationIcon = {
          IconButton(onClick = onNavigateBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = NavySurface),
      )
    },
    containerColor = DeepNavyBg,
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
    ) {
      TournamentCard(
        modifier = Modifier.fillMaxWidth(),
        backgroundColor = NavyCard,
        borderColor = Gold500.copy(alpha = 0.4f),
      ) {
        Text(
          text = "AVAILABLE BALANCE",
          style = MaterialTheme.typography.labelMedium,
          color = Gold400,
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = "৳ ${"%.2f".format(availableBalance / 100.0)}",
          style = MaterialTheme.typography.displayMedium.copy(fontWeight = FontWeight.Black),
          color = Color.White,
        )

        if (pendingBalance > 0L) {
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "Pending in Escrow / Withdrawal: ৳ ${"%.2f".format(pendingBalance / 100.0)}",
            style = MaterialTheme.typography.bodySmall,
            color = Slate400,
          )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          TournamentButton(
            text = "DEPOSIT",
            onClick = onNavigateToDeposit,
            leadingIcon = {
              Icon(Icons.Default.AddCircle, contentDescription = null, tint = Slate950, modifier = Modifier.size(18.dp))
            },
            modifier = Modifier.weight(1f),
            testTag = "wallet_deposit_button",
          )
          TournamentButton(
            text = "WITHDRAW",
            onClick = onNavigateToWithdraw,
            variant = TournamentButtonVariant.OUTLINED,
            leadingIcon = {
              Icon(Icons.Default.ArrowUpward, contentDescription = null, tint = Gold500, modifier = Modifier.size(18.dp))
            },
            modifier = Modifier.weight(1f),
            testTag = "wallet_withdraw_button",
          )
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        TournamentCard(
          modifier = Modifier.weight(1f),
          backgroundColor = Slate900,
          borderColor = NavyCardBorder,
        ) {
          Text(text = "TOTAL WINNINGS", style = MaterialTheme.typography.labelSmall, color = Slate400)
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "৳ ${"%.0f".format(totalWinnings / 100.0)}",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = Emerald400,
          )
        }
        TournamentCard(
          modifier = Modifier.weight(1f),
          backgroundColor = Slate900,
          borderColor = NavyCardBorder,
        ) {
          Text(text = "TOTAL DEPOSITED", style = MaterialTheme.typography.labelSmall, color = Slate400)
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "৳ ${"%.0f".format(totalDeposited / 100.0)}",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = Cyan400,
          )
        }
      }

      Spacer(modifier = Modifier.height(24.dp))

      TournamentCard(
        modifier = Modifier.fillMaxWidth(),
        backgroundColor = NavyCard,
        borderColor = NavyCardBorder,
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = "Recent Transactions",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = Color.White,
          )
          TextButton(onClick = onNavigateToTransactions) {
            Text(text = "See All", color = Gold400, style = MaterialTheme.typography.labelMedium)
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (uiState.transactions.isEmpty()) {
          Text(
            text = "No recent transactions found.",
            style = MaterialTheme.typography.bodyMedium,
            color = Slate400,
            modifier = Modifier.padding(vertical = 12.dp),
          )
        } else {
          uiState.transactions.take(5).forEach { txn ->
            val isCredit = txn.type.contains("PRIZE") || txn.type.contains("DEPOSIT") || txn.type.contains("REFUND") || txn.type.contains("CREDIT")
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = txn.description.ifBlank { txn.type },
                  style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                  color = Color.White,
                )
                Text(
                  text = txn.referenceId.ifBlank { txn.source },
                  style = MaterialTheme.typography.labelSmall,
                  color = Slate400,
                )
              }
              Text(
                text = "${if (isCredit) "+ " else "- "}৳ ${"%.0f".format(txn.amount / 100.0)}",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = if (isCredit) Emerald400 else Rose400,
              )
            }
            HorizontalDivider(color = Slate800, thickness = 0.5.dp)
          }
        }
      }
    }
  }
}
