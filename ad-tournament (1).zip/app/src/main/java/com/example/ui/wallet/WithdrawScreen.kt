package com.example.ui.wallet

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.ui.components.TournamentButton
import com.example.ui.components.TournamentCard
import com.example.ui.components.TournamentTextField
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WithdrawScreen(
  viewModel: WalletViewModel,
  onNavigateBack: () -> Unit,
) {
  val uiState by viewModel.uiState.collectAsState()
  val availableBalance = uiState.wallet?.availableBalance ?: 0L

  var selectedMethod by remember { mutableStateOf("BKASH") }
  var amountInput by remember { mutableStateOf("100") }
  var recipientNumber by remember { mutableStateOf("") }
  var clientError by remember { mutableStateOf<String?>(null) }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Text(
            text = "Withdraw Winnings",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = Color.White,
          )
        },
        navigationIcon = {
          IconButton(onClick = onNavigateBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = NavySurface),
      )
    },
    containerColor = DeepNavyBg,
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
    ) {
      if (uiState.withdrawalSubmitted) {
        TournamentCard(
          modifier = Modifier.fillMaxWidth(),
          backgroundColor = Slate900,
          borderColor = Emerald500,
        ) {
          Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = null,
            tint = Emerald400,
            modifier = Modifier.size(48.dp),
          )
          Spacer(modifier = Modifier.height(12.dp))
          Text(
            text = "Withdrawal Requested",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = Color.White,
          )
          Text(
            text = uiState.successMessage ?: "Your withdrawal request is being processed. It will be sent via $selectedMethod within 1-2 hours.",
            style = MaterialTheme.typography.bodyMedium,
            color = Slate300,
            modifier = Modifier.padding(top = 4.dp, bottom = 16.dp),
          )
          TournamentButton(
            text = "BACK TO WALLET",
            onClick = {
              viewModel.clearMessages()
              onNavigateBack()
            },
            modifier = Modifier.fillMaxWidth(),
          )
        }
        return@Column
      }

      TournamentCard(
        modifier = Modifier.fillMaxWidth(),
        backgroundColor = NavyCard,
        borderColor = NavyCardBorder,
      ) {
        Text(text = "AVAILABLE FOR WITHDRAWAL", style = MaterialTheme.typography.labelSmall, color = Slate400)
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = "৳ ${"%.2f".format(availableBalance / 100.0)}",
          style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Black),
          color = Gold400,
        )
      }

      Spacer(modifier = Modifier.height(16.dp))

      TournamentCard(
        modifier = Modifier.fillMaxWidth(),
        backgroundColor = NavyCard,
        borderColor = NavyCardBorder,
      ) {
        Text(
          text = "Payout Method",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          color = Color.White,
        )
        Spacer(modifier = Modifier.height(10.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          listOf("BKASH" to "bKash", "NAGAD" to "Nagad", "ROCKET" to "Rocket").forEach { (key, label) ->
            val isSelected = selectedMethod == key
            Surface(
              onClick = { selectedMethod = key },
              color = if (isSelected) Gold500.copy(alpha = 0.2f) else Slate900,
              shape = RoundedCornerShape(10.dp),
              border = BorderStroke(1.5.dp, if (isSelected) Gold500 else Slate700),
              modifier = Modifier.weight(1f),
            ) {
              Box(modifier = Modifier.padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                Text(
                  text = label,
                  style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                  color = if (isSelected) Gold400 else Slate300,
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        val displayError = clientError ?: uiState.errorMessage
        if (displayError != null) {
          Surface(
            color = Rose900.copy(alpha = 0.4f),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
              .fillMaxWidth()
              .padding(bottom = 12.dp),
          ) {
            Text(
              text = displayError,
              color = Rose400,
              style = MaterialTheme.typography.bodySmall,
              modifier = Modifier.padding(10.dp),
            )
          }
        }

        TournamentTextField(
          value = amountInput,
          onValueChange = {
            amountInput = it.filter { char -> char.isDigit() }
            clientError = null
          },
          label = "Withdrawal Amount (BDT)",
          placeholder = "e.g. 100",
          helperText = "Min: ৳ 100 | Max: ৳ 10,000",
          leadingIcon = Icons.Default.Paid,
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          testTag = "withdraw_amount_input",
        )

        Spacer(modifier = Modifier.height(12.dp))

        TournamentTextField(
          value = recipientNumber,
          onValueChange = {
            if (it.length <= 11) {
              recipientNumber = it
              clientError = null
            }
          },
          label = "Recipient $selectedMethod Number",
          placeholder = "01XXXXXXXXX",
          leadingIcon = Icons.Default.Phone,
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
          testTag = "withdraw_recipient_input",
        )

        Spacer(modifier = Modifier.height(20.dp))

        TournamentButton(
          text = "REQUEST WITHDRAWAL",
          onClick = {
            val amountNum = amountInput.toLongOrNull() ?: 0L
            val amountMinor = amountNum * 100L
            if (amountNum < 100L) {
              clientError = "Minimum withdrawal amount is ৳ 100"
              return@TournamentButton
            }
            if (amountNum > 10000L) {
              clientError = "Maximum withdrawal amount is ৳ 10,000"
              return@TournamentButton
            }
            if (amountMinor > availableBalance) {
              clientError = "Insufficient available balance. You have ৳ ${"%.0f".format(availableBalance / 100.0)}"
              return@TournamentButton
            }
            if (recipientNumber.length < 11) {
              clientError = "Please enter a valid 11-digit recipient mobile number"
              return@TournamentButton
            }
            viewModel.submitWithdrawal(
              amountMinorUnits = amountMinor,
              method = selectedMethod,
              recipientNumber = recipientNumber,
            )
          },
          isLoading = uiState.isSubmitting,
          modifier = Modifier.fillMaxWidth(),
          testTag = "submit_withdrawal_button",
        )
      }
    }
  }
}
