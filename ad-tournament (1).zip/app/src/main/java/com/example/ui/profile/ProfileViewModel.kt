package com.example.ui.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.domain.model.UserEntity
import com.example.domain.repository.AuthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ProfileUiState(
  val isLoading: Boolean = false,
  val user: UserEntity? = null,
  val errorMessage: String? = null,
  val successMessage: String? = null,
)

class ProfileViewModel(
  private val authRepository: AuthRepository,
) : ViewModel() {

  private val _uiState = MutableStateFlow(ProfileUiState())
  val uiState: StateFlow<ProfileUiState> = _uiState.asStateFlow()

  val currentUser: StateFlow<UserEntity?> = authRepository.getCurrentUser() as StateFlow<UserEntity?>

  fun updateName(userId: String, newName: String) {
    viewModelScope.launch {
      _uiState.value = _uiState.value.copy(isLoading = true)
      authRepository.updateDisplayName(userId, newName)
      _uiState.value = _uiState.value.copy(isLoading = false, successMessage = "Profile updated successfully")
    }
  }

  fun signOut(onSignedOut: () -> Unit) {
    viewModelScope.launch {
      authRepository.signOut()
      onSignedOut()
    }
  }

  class Factory(private val authRepository: AuthRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
      return ProfileViewModel(authRepository) as T
    }
  }
}
