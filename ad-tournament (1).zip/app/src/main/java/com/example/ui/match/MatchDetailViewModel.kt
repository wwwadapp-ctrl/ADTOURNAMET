package com.example.ui.match

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.error.Resource
import com.example.domain.model.MatchEntity
import com.example.domain.model.MatchPlayerEntity
import com.example.domain.repository.MatchRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class MatchDetailUiState(
  val isLoading: Boolean = true,
  val match: MatchEntity? = null,
  val players: List<MatchPlayerEntity> = emptyList(),
  val isJoined: Boolean = false,
  val isJoining: Boolean = false,
  val joinSuccess: Boolean = false,
  val errorMessage: String? = null,
  val successMessage: String? = null,
)

class MatchDetailViewModel(
  private val matchRepository: MatchRepository,
  private val matchId: String,
  private val currentUserId: String,
) : ViewModel() {

  private val _uiState = MutableStateFlow(MatchDetailUiState())
  val uiState: StateFlow<MatchDetailUiState> = _uiState.asStateFlow()

  init {
    loadMatchDetails()
  }

  fun loadMatchDetails() {
    viewModelScope.launch {
      matchRepository.getMatchById(matchId).collect { res ->
        if (res is Resource.Success) {
          _uiState.value = _uiState.value.copy(match = res.data, isLoading = false)
        }
      }
    }
    viewModelScope.launch {
      matchRepository.getMatchPlayers(matchId).collect { res ->
        if (res is Resource.Success) {
          val players = res.data
          val joined = players.any { it.effectiveUid == currentUserId }
          _uiState.value = _uiState.value.copy(players = players, isJoined = joined)
        }
      }
    }
  }

  fun joinMatch() {
    viewModelScope.launch {
      _uiState.value = _uiState.value.copy(isJoining = true, errorMessage = null)
      when (val res = matchRepository.joinMatch(currentUserId, matchId)) {
        is Resource.Success -> {
          _uiState.value = _uiState.value.copy(
            isJoining = false,
            isJoined = true,
            joinSuccess = true,
            successMessage = "Successfully joined tournament battle!",
          )
          loadMatchDetails()
        }
        is Resource.Error -> {
          _uiState.value = _uiState.value.copy(
            isJoining = false,
            errorMessage = res.error.message,
          )
        }
        else -> Unit
      }
    }
  }

  class Factory(
    private val matchRepository: MatchRepository,
    private val matchId: String,
    private val currentUserId: String,
  ) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
      return MatchDetailViewModel(matchRepository, matchId, currentUserId) as T
    }
  }
}
