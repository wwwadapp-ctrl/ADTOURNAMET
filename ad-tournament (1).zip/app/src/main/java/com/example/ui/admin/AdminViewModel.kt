package com.example.ui.admin

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.error.Resource
import com.example.domain.model.*
import com.example.domain.repository.AdminRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class AdminUiState(
  val isLoading: Boolean = false,
  val pendingDeposits: List<DepositEntity> = emptyList(),
  val pendingWithdrawals: List<WithdrawalEntity> = emptyList(),
  val errorMessage: String? = null,
  val successMessage: String? = null,
)

class AdminViewModel(
  private val adminRepository: AdminRepository,
  private val adminUid: String,
) : ViewModel() {

  private val _uiState = MutableStateFlow(AdminUiState())
  val uiState: StateFlow<AdminUiState> = _uiState.asStateFlow()

  init {
    loadPendingItems()
  }

  fun loadPendingItems() {
    viewModelScope.launch {
      adminRepository.getPendingDeposits().collect { res ->
        if (res is Resource.Success) {
          _uiState.value = _uiState.value.copy(pendingDeposits = res.data)
        }
      }
    }
    viewModelScope.launch {
      adminRepository.getPendingWithdrawals().collect { res ->
        if (res is Resource.Success) {
          _uiState.value = _uiState.value.copy(pendingWithdrawals = res.data)
        }
      }
    }
  }

  fun approveDeposit(deposit: DepositEntity) {
    viewModelScope.launch {
      adminRepository.approveDeposit(adminUid, deposit.depositId, deposit)
      loadPendingItems()
    }
  }

  fun rejectDeposit(depositId: String, reason: String) {
    viewModelScope.launch {
      adminRepository.rejectDeposit(adminUid, depositId, reason)
      loadPendingItems()
    }
  }

  fun setMatchGameCode(matchId: String, code: String) {
    viewModelScope.launch {
      adminRepository.setMatchGameCode(adminUid, matchId, code)
    }
  }

  class Factory(
    private val adminRepository: AdminRepository,
    private val adminUid: String,
  ) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
      return AdminViewModel(adminRepository, adminUid) as T
    }
  }
}
