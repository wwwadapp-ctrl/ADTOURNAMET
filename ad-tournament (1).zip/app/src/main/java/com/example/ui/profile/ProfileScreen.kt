package com.example.ui.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.UserEntity
import com.example.ui.components.TournamentButton
import com.example.ui.components.TournamentButtonVariant
import com.example.ui.components.TournamentCard
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
  viewModel: ProfileViewModel,
  user: UserEntity?,
  onNavigateBack: () -> Unit,
  onSignedOut: () -> Unit,
) {
  val currentUser = user ?: viewModel.currentUser.collectAsState().value

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Text(
            text = "Player Profile",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = Color.White,
          )
        },
        navigationIcon = {
          IconButton(onClick = onNavigateBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = NavySurface),
      )
    },
    containerColor = DeepNavyBg,
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Box(
        modifier = Modifier
          .size(80.dp)
          .clip(CircleShape)
          .background(Gold500.copy(alpha = 0.2f)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Default.AccountCircle,
          contentDescription = null,
          tint = Gold400,
          modifier = Modifier.size(54.dp),
        )
      }

      Spacer(modifier = Modifier.height(12.dp))

      Text(
        text = currentUser?.effectiveName ?: "Player",
        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
        color = Color.White,
      )
      Text(
        text = currentUser?.phoneNumber ?: "",
        style = MaterialTheme.typography.bodyMedium,
        color = Slate400,
      )

      Spacer(modifier = Modifier.height(20.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        TournamentCard(
          modifier = Modifier.weight(1f),
          backgroundColor = NavyCard,
          borderColor = NavyCardBorder,
        ) {
          Text(text = "TOTAL MATCHES", style = MaterialTheme.typography.labelSmall, color = Slate400)
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "${currentUser?.totalMatches ?: 0}",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = Color.White,
          )
        }
        TournamentCard(
          modifier = Modifier.weight(1f),
          backgroundColor = NavyCard,
          borderColor = NavyCardBorder,
        ) {
          Text(text = "VICTORIES", style = MaterialTheme.typography.labelSmall, color = Slate400)
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "${currentUser?.wins ?: 0}",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = Emerald400,
          )
        }
      }

      Spacer(modifier = Modifier.height(28.dp))

      TournamentButton(
        text = "LOG OUT",
        onClick = { viewModel.signOut(onSignedOut) },
        variant = TournamentButtonVariant.OUTLINED,
        modifier = Modifier.fillMaxWidth(),
        testTag = "profile_logout_button",
      )
    }
  }
}
