package com.example.ui.admin

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.components.EmptyState
import com.example.ui.components.TournamentButton
import com.example.ui.components.TournamentButtonVariant
import com.example.ui.components.TournamentCard
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminScreen(
  viewModel: AdminViewModel,
  onNavigateBack: () -> Unit,
) {
  val uiState by viewModel.uiState.collectAsState()

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Text(
            text = "Super Admin Dashboard",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = Color.White,
          )
        },
        navigationIcon = {
          IconButton(onClick = onNavigateBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = NavySurface),
      )
    },
    containerColor = DeepNavyBg,
  ) { innerPadding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      item {
        Text(
          text = "Pending Deposits (${uiState.pendingDeposits.size})",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          color = Gold400,
        )
      }

      if (uiState.pendingDeposits.isEmpty()) {
        item {
          Text(text = "No pending deposits awaiting verification.", color = Slate400, style = MaterialTheme.typography.bodyMedium)
        }
      } else {
        items(uiState.pendingDeposits, key = { it.depositId }) { dep ->
          TournamentCard(
            modifier = Modifier.fillMaxWidth(),
            backgroundColor = NavyCard,
            borderColor = NavyCardBorder,
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Column {
                Text(text = "৳ ${"%.0f".format(dep.amount / 100.0)} via ${dep.method}", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = Color.White)
                Text(text = "Sender: ${dep.senderNumber}", style = MaterialTheme.typography.bodySmall, color = Slate400)
                Text(text = "TrxID: ${dep.trxId}", style = MaterialTheme.typography.bodySmall, color = Gold400)
              }
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              TournamentButton(
                text = "APPROVE",
                onClick = { viewModel.approveDeposit(dep) },
                modifier = Modifier.weight(1f),
              )
              TournamentButton(
                text = "REJECT",
                onClick = { viewModel.rejectDeposit(dep.depositId, "Invalid TrxID") },
                variant = TournamentButtonVariant.DANGER,
                modifier = Modifier.weight(1f),
              )
            }
          }
        }
      }
    }
  }
}
