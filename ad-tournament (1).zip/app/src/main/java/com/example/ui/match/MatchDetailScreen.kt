package com.example.ui.match

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.MatchStatus
import com.example.ui.components.MatchStatusBadge
import com.example.ui.components.TournamentButton
import com.example.ui.components.TournamentButtonVariant
import com.example.ui.components.TournamentCard
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MatchDetailScreen(
  viewModel: MatchDetailViewModel,
  onNavigateBack: () -> Unit,
  onViewRoomCode: (String) -> Unit,
  onSubmitProof: (String) -> Unit,
) {
  val uiState by viewModel.uiState.collectAsState()
  val match = uiState.match

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Text(
            text = match?.matchNumber ?: "Match Details",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = Color.White,
          )
        },
        navigationIcon = {
          IconButton(onClick = onNavigateBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = NavySurface),
      )
    },
    containerColor = DeepNavyBg,
  ) { innerPadding ->
    if (match == null) {
      Box(modifier = Modifier.fillMaxSize().padding(innerPadding), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(color = Gold500)
      }
      return@Scaffold
    }

    val isLudo = match.gameType.equals("LUDO", ignoreCase = true)
    val isFull = match.joinedPlayersCount >= match.maxPlayers || match.status.equals(MatchStatus.FULL.name, ignoreCase = true)
    val isRunning = match.status.equals(MatchStatus.RUNNING.name, ignoreCase = true)
    val isCompleted = match.status.equals(MatchStatus.COMPLETED.name, ignoreCase = true)

    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
    ) {
      TournamentCard(
        modifier = Modifier.fillMaxWidth(),
        backgroundColor = NavyCard,
        borderColor = Gold500.copy(alpha = 0.4f),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = if (isLudo) "LUDO 1v1 BATTLE" else "CARROM 1v1 BATTLE",
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
            color = if (isLudo) Indigo400 else Cyan400,
          )
          MatchStatusBadge(
            status = match.status,
            joinedPlayersCount = match.joinedPlayersCount,
            maxPlayers = match.maxPlayers,
            isJoined = uiState.isJoined,
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text(
          text = match.title,
          style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
          color = Color.White,
        )

        Spacer(modifier = Modifier.height(16.dp))

        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(Slate900, RoundedCornerShape(10.dp))
            .padding(14.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Column {
            Text(text = "ENTRY FEE", style = MaterialTheme.typography.labelSmall, color = Slate400)
            Text(
              text = "৳ ${"%.0f".format(match.entryFee)}",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = Color.White,
            )
          }
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = "PLAYERS", style = MaterialTheme.typography.labelSmall, color = Slate400)
            Text(
              text = "${match.joinedPlayersCount} / ${match.maxPlayers}",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = Cyan400,
            )
          }
          Column(horizontalAlignment = Alignment.End) {
            Text(text = "WINNER PRIZE", style = MaterialTheme.typography.labelSmall, color = Slate400)
            Text(
              text = "৳ ${"%.0f".format(match.prizePool)}",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
              color = Gold400,
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      if (uiState.errorMessage != null) {
        Surface(
          color = Rose900.copy(alpha = 0.4f),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp),
        ) {
          Text(
            text = uiState.errorMessage ?: "",
            color = Rose400,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(12.dp),
          )
        }
      }

      if (uiState.isJoined || match.gameCode.isNotBlank()) {
        TournamentCard(
          modifier = Modifier.fillMaxWidth(),
          backgroundColor = NavyCard,
          borderColor = Indigo600,
        ) {
          Text(
            text = "Game Room Code",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = Color.White,
          )
          Spacer(modifier = Modifier.height(8.dp))
          if (match.gameCode.isNotBlank()) {
            Surface(
              color = Indigo900.copy(alpha = 0.5f),
              shape = RoundedCornerShape(8.dp),
              border = BorderStroke(1.dp, Indigo600),
              modifier = Modifier.fillMaxWidth(),
            ) {
              Column(
                modifier = Modifier.padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
              ) {
                Text(text = "ROOM CODE", style = MaterialTheme.typography.labelSmall, color = Gold400)
                Text(
                  text = match.gameCode,
                  style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Black,
                    letterSpacing = 4.sp,
                  ),
                  color = Color.White,
                )
                Text(
                  text = "Open Ludo King / Carrom Pool and enter this code to join match room",
                  style = MaterialTheme.typography.bodySmall,
                  color = Slate400,
                  modifier = Modifier.padding(top = 6.dp),
                )
              }
            }
            Spacer(modifier = Modifier.height(14.dp))
            TournamentButton(
              text = "SUBMIT MATCH VICTORY PROOF",
              onClick = { onSubmitProof(match.matchId) },
              modifier = Modifier.fillMaxWidth(),
              testTag = "detail_submit_proof_btn",
            )
          } else {
            Text(
              text = "Super Admin will generate the room code 5-10 minutes before the scheduled match time. Please keep this screen open.",
              style = MaterialTheme.typography.bodyMedium,
              color = Slate300,
            )
          }
        }
        Spacer(modifier = Modifier.height(16.dp))
      }

      TournamentCard(
        modifier = Modifier.fillMaxWidth(),
        backgroundColor = NavyCard,
        borderColor = NavyCardBorder,
      ) {
        Text(
          text = "Registered Players (${uiState.players.size}/${match.maxPlayers})",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          color = Color.White,
        )
        Spacer(modifier = Modifier.height(10.dp))
        if (uiState.players.isEmpty()) {
          Text(
            text = "No players have joined yet. Be the first to join!",
            style = MaterialTheme.typography.bodyMedium,
            color = Slate400,
          )
        } else {
          uiState.players.forEach { p ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AccountCircle, contentDescription = null, tint = Gold400, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = p.username, style = MaterialTheme.typography.bodyMedium, color = Color.White)
              }
              Surface(
                color = Slate850,
                shape = RoundedCornerShape(6.dp),
              ) {
                Text(
                  text = p.slot,
                  style = MaterialTheme.typography.labelSmall,
                  color = Cyan400,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                )
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(24.dp))

      if (!uiState.isJoined && !isFull && !isRunning && !isCompleted) {
        TournamentButton(
          text = "JOIN MATCH (৳ ${"%.0f".format(match.entryFee)})",
          onClick = { viewModel.joinMatch() },
          isLoading = uiState.isJoining,
          modifier = Modifier.fillMaxWidth(),
          testTag = "detail_join_button",
        )
      }
    }
  }
}
