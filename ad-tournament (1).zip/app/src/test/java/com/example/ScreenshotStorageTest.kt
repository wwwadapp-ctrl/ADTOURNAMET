package com.example

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import androidx.test.core.app.ApplicationProvider
import com.example.core.error.AppError
import com.example.core.error.Resource
import com.example.core.util.ImageCompressor
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileOutputStream

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk = [33])
class ScreenshotStorageTest {

  private fun createSampleVictoryScreenshot(width: Int = 1920, height: Int = 1080): Bitmap {
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    canvas.drawColor(Color.DKGRAY)

    val paint = Paint().apply {
      color = Color.YELLOW
      textSize = 48f
      isAntiAlias = true
    }
    canvas.drawText("VICTORY! Room Code: 123456", 50f, 150f, paint)
    canvas.drawText("Winner: ProPlayer_99 (UID: user_winner_1)", 50f, 250f, paint)
    canvas.drawText("Match: #101 - Ludo King Solo", 50f, 350f, paint)
    return bitmap
  }

  @Test
  fun test1_imageCompression_downscalesAndCompressesPreservingAspect() {
    val originalWidth = 2000
    val originalHeight = 1000
    val bitmap = createSampleVictoryScreenshot(originalWidth, originalHeight)

    val maxDimension = 1280
    val result = ImageCompressor.compressBitmap(bitmap, maxDimension = maxDimension)

    assertTrue("Expected compression to succeed", result is Resource.Success)
    val success = (result as Resource.Success).data

    // Width was 2000, scaled to maxDimension 1280
    assertEquals(1280, success.width)
    // Height scaled down proportionally (1000 * 1280 / 2000 = 640)
    assertEquals(640, success.height)

    // Result should be well under the 800 KB limit
    assertTrue(success.sizeInBytes < ImageCompressor.MAX_PAYLOAD_SIZE_BYTES)
    assertTrue(success.sizeInBytes > 0)
  }

  @Test
  fun test2_base64Conversion_producesValidDataUriAndDecodableJpeg() {
    val bitmap = createSampleVictoryScreenshot(800, 600)
    val result = ImageCompressor.compressBitmap(bitmap)

    assertTrue(result is Resource.Success)
    val data = (result as Resource.Success).data

    // Base64 string is non-empty
    assertTrue(data.base64String.isNotBlank())

    // Data URI format check
    assertTrue(data.dataUri.startsWith("data:image/jpeg;base64,"))
    assertTrue(data.dataUri.endsWith(data.base64String))

    // Decode back to bytes
    val decodedBytes = ImageCompressor.decodeBase64(data.dataUri)
    assertTrue("Decoded bytes must not be empty", decodedBytes.isNotEmpty())

    // Check JPEG magic numbers: 0xFF, 0xD8 (SOI - Start of Image)
    assertEquals(0xFF.toByte(), decodedBytes[0])
    assertEquals(0xD8.toByte(), decodedBytes[1])
  }

  @Test
  fun test3_emptyAndInvalidImageHandling_failsGracefully() {
    // 1. Empty stream
    val emptyStream = ByteArrayInputStream(ByteArray(0))
    val emptyResult = ImageCompressor.compressFromStream(emptyStream)
    assertTrue("Empty stream should return Error", emptyResult is Resource.Error)
    val emptyErr = (emptyResult as Resource.Error).error
    assertTrue(emptyErr is AppError.InvalidInput)

    // 2. Corrupted bytes stream
    val corruptBytes = "NotAnImageRandomStringCorruptData".toByteArray()
    val corruptStream = ByteArrayInputStream(corruptBytes)
    val corruptResult = ImageCompressor.compressFromStream(corruptStream)
    assertTrue("Corrupted stream should return Error", corruptResult is Resource.Error)

    // 3. Blank / empty Uri
    val context = ApplicationProvider.getApplicationContext<android.content.Context>()
    val blankUriResult = ImageCompressor.compressScreenshot(context, Uri.EMPTY)
    assertTrue("Empty Uri should return Error", blankUriResult is Resource.Error)

    // 4. Non-existent file Uri
    val fakeUri = Uri.fromFile(File(context.cacheDir, "non_existent_screenshot_${System.currentTimeMillis()}.png"))
    val nonExistentResult = ImageCompressor.compressScreenshot(context, fakeUri)
    assertTrue("Non-existent Uri should return Error", nonExistentResult is Resource.Error)
  }

  @Test
  fun test4_payloadSizeGuard_enforcesMaxSizeBytesLimitGracefully() {
    val largeBitmap = createSampleVictoryScreenshot(1920, 1080)

    // Set an artificially tiny size limit of 1 KB (1024 bytes) that a full screenshot cannot meet
    val tinyLimit = 1024
    val result = ImageCompressor.compressBitmap(largeBitmap, maxSizeBytes = tinyLimit)

    assertTrue("Expected to fail gracefully when image cannot fit size limit", result is Resource.Error)
    val error = (result as Resource.Error).error
    assertTrue(error is AppError.InvalidInput)
    val errorMsg = error.message.orEmpty()
    assertTrue(
      "Error message should mention safe size limit: $errorMsg",
      errorMsg.contains("800 KB") || errorMsg.contains("সাইজ") || errorMsg.contains("সীমা")
    )
  }

  @Test
  fun test5_endToEndUriCompression_usingRealFile() {
    val context = ApplicationProvider.getApplicationContext<android.content.Context>()
    val tempFile = File(context.cacheDir, "victory_proof_test.jpg")
    val originalBitmap = createSampleVictoryScreenshot(1280, 720)

    FileOutputStream(tempFile).use { out ->
      originalBitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
    }

    val fileUri = Uri.fromFile(tempFile)
    val result = ImageCompressor.compressScreenshot(context, fileUri)

    assertTrue(result is Resource.Success)
    val compressionResult = (result as Resource.Success).data
    assertTrue(compressionResult.dataUri.startsWith("data:image/jpeg;base64,"))
    assertTrue(compressionResult.sizeInBytes < ImageCompressor.MAX_PAYLOAD_SIZE_BYTES)

    // Clean up
    tempFile.delete()
  }
}
