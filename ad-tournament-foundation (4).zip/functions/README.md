# AD Tournament — Firebase Cloud Functions

## Overview
This folder contains the authoritative trusted backend functions for **AD TOURNAMENT**, specifically the server-side `joinMatch` function.

Client devices **MUST NOT** directly mutate:
- `wallets/$uid/availableBalance`
- `wallets/$uid/pendingBalance`
- `transactions` or `userTransactions`
- `matches/$matchId/joinedPlayersCount` or `matches/$matchId/status`

Instead, clients call the `joinMatch` Firebase Callable Cloud Function (or HTTPS endpoint), which executes with the **Firebase Admin SDK** on trusted Google Cloud infrastructure.

---

## Deployment Instructions

### Prerequisites
1. Install Node.js (v18 or v20 LTS recommended).
2. Install the Firebase CLI:
   ```bash
   npm install -g firebase-tools
   ```
3. Authenticate with your Firebase project:
   ```bash
   firebase login
   ```
4. Verify your active project:
   ```bash
   firebase use <your-firebase-project-id>
   ```

### Step 1: Install Dependencies
```bash
cd functions
npm install
```

### Step 2: Test Locally via Firebase Emulator (Optional)
```bash
firebase emulators:start --only functions,database
```

### Step 3: Deploy to Firebase Production
```bash
firebase deploy --only functions:joinMatch
```
Or deploy all functions:
```bash
firebase deploy --only functions
```

---

## Security Verification
Once deployed:
1. Verify `joinMatch` is listed in your **Firebase Console > Build > Functions**.
2. Deploy Realtime Database rules from `database.rules.json`:
   ```bash
   firebase deploy --only database
   ```
3. Test with an authenticated user account to ensure that invalid or unauthorized writes directly to `/wallets` or `/transactions` are blocked by database rules, while `joinMatch` completes atomically via the Admin SDK.
