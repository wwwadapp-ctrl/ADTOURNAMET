package com.example.core.backend

import com.example.core.finance.FinancialEngine
import com.example.core.util.AppError
import com.example.core.util.Resource
import com.example.domain.model.JoinMatchResult
import com.example.domain.model.MatchEntity
import com.example.domain.model.MatchPlayerEntity
import com.example.domain.model.MatchStatus
import com.example.domain.model.TransactionEntity
import com.example.domain.model.UserEntity
import com.example.domain.model.WalletEntity
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Trusted server-side backend contract for match joining.
 * The Android client NEVER computes or writes financial mutations, wallet balances, or transactions directly.
 */
interface TrustedMatchJoinBackend {
  suspend fun joinMatch(
    userId: String,
    matchId: String,
    currentTime: Long = System.currentTimeMillis()
  ): Resource<JoinMatchResult>
}

/**
 * Authoritative backend implementation that strictly enforces all server-side validation rules,
 * commission tiers, atomic deductions, idempotency, and capacity controls.
 *
 * It is used for authoritative server simulation and testing, and mirrors the exact server-side
 * logic executed by the Firebase Cloud Function.
 */
class AuthoritativeMatchJoinBackend(
  private val matchLookup: suspend (String) -> MatchEntity?,
  private val userLookup: suspend (String) -> UserEntity?,
  private val walletLookup: suspend (String) -> WalletEntity?,
  private val playersLookup: suspend (String) -> List<MatchPlayerEntity>,
  private val transactionsLookup: suspend (String) -> List<TransactionEntity>,
  private val commitMutation: suspend (FinancialEngine.MatchJoinResult.Success) -> Unit,
) : TrustedMatchJoinBackend {

  private val mutex = Mutex()

  override suspend fun joinMatch(
    userId: String,
    matchId: String,
    currentTime: Long
  ): Resource<JoinMatchResult> = mutex.withLock {
    // 1. Authenticate user
    if (userId.isBlank()) {
      return Resource.Error(AppError.InvalidInput(reason = "Authentication required. User ID cannot be empty."))
    }

    // 2. Look up user and check account status
    val user = userLookup(userId) ?: UserEntity(uid = userId, userId = userId, role = "PLAYER", status = "ACTIVE")
    if (user.isAccountBlocked) {
      return Resource.Error(AppError.InvalidInput(reason = "Your account is blocked. Cannot join tournament."))
    }

    // 3. Match existence check
    val match = matchLookup(matchId)
      ?: return Resource.Error(AppError.InvalidInput(reason = "Match $matchId not found."))

    // 4. Verify match is joinable
    val isJoinable = match.status.equals(MatchStatus.AVAILABLE.name, ignoreCase = true) ||
        match.status.equals(MatchStatus.UPCOMING.name, ignoreCase = true)
    if (!isJoinable) {
      return Resource.Error(AppError.InvalidInput(reason = "Match is not available to join (current status: ${match.status})."))
    }

    // 5. Verify scheduled/cutoff time
    val scheduledTime = match.effectiveScheduledAt
    if (scheduledTime > 0L && currentTime >= scheduledTime) {
      return Resource.Error(AppError.InvalidInput(reason = "Match registration deadline has passed."))
    }

    // 6. Verify existing players & prevent race-condition double joins
    val existingPlayers = playersLookup(matchId)
    if (existingPlayers.any { it.effectiveUid == userId }) {
      return Resource.Error(AppError.InvalidInput(reason = "You have already joined this match."))
    }

    if (existingPlayers.size >= match.maxPlayers) {
      return Resource.Error(AppError.InvalidInput(reason = "Match is full. Maximum ${match.maxPlayers} players allowed."))
    }

    // 7. Verify wallet balance
    val currentWallet = walletLookup(userId)
      ?: return Resource.Error(AppError.ServerError("Wallet not found for user $userId."))

    val existingTxns = transactionsLookup(userId)

    // 8. Execute authoritative validation and mutation via FinancialEngine
    val mutation = FinancialEngine.processMatchJoin(
      match = match,
      user = user,
      currentWallet = currentWallet,
      existingPlayers = existingPlayers,
      existingTransactions = existingTxns,
      currentTime = currentTime,
    )

    return when (mutation) {
      is FinancialEngine.MatchJoinResult.Success -> {
        // Commit atomically
        commitMutation(mutation)
        Resource.Success(
          JoinMatchResult(
            match = mutation.updatedMatch,
            player = mutation.newPlayer,
            wallet = mutation.updatedWallet,
            transaction = mutation.transaction,
          )
        )
      }
      is FinancialEngine.MatchJoinResult.Failure -> {
        // Crucial: return actual failure, NEVER fall back to local fake success
        Resource.Error(AppError.InvalidInput(reason = mutation.reason))
      }
    }
  }
}
