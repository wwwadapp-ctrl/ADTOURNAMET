package com.example

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import com.example.core.error.Resource
import com.example.data.repository.FirebaseNotificationRepository
import com.example.data.repository.LocalDataStore
import com.example.domain.model.NotificationEntity
import com.example.ui.home.HomeScreen
import com.example.ui.home.HomeViewModel
import com.example.ui.notifications.NotificationsScreen
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.util.concurrent.CopyOnWriteArrayList

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk = [36])
class NotificationCenterTest {

  @Rule
  @JvmField
  val composeTestRule = createComposeRule()

  private val notificationRepository = FirebaseNotificationRepository()

  @Before
  fun setup() {
    LocalDataStore.localUserNotifications.clear()
  }

  @Test
  fun homeNotificationButton_triggersCallback() {
    var notificationClicked = false

    composeTestRule.setContent {
      HomeScreen(
        viewModel = HomeViewModel(
          matchRepository = com.example.data.repository.FirebaseMatchRepository(),
          currentUserId = "test_user_1",
        ),
        currentUser = null,
        wallet = null,
        onMatchClick = {},
        onWalletClick = {},
        onDepositClick = {},
        onNotificationClick = { notificationClicked = true },
        onProfileClick = {},
        onRulesClick = {},
        onSupportClick = {},
        onAdminClick = {},
      )
    }

    composeTestRule.onNodeWithTag("home_notification_button").assertIsDisplayed()
    composeTestRule.onNodeWithTag("home_notification_button").performClick()
    assertTrue(notificationClicked)
  }

  @Test
  fun notificationsScreen_showsEmptyState_whenNoNotifications() {
    composeTestRule.setContent {
      NotificationsScreen(
        userId = "user_with_no_notifs",
        onNavigateBack = {},
        notificationRepository = notificationRepository,
      )
    }

    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("notifications_screen").assertIsDisplayed()
    composeTestRule.onNodeWithTag("notifications_empty_state").assertIsDisplayed()
    composeTestRule.onNodeWithText("কোনো নতুন নোটিফিকেশন নেই").assertIsDisplayed()
  }

  @Test
  fun notificationsScreen_doesNotShowOtherUsersNotifications() {
    // Add notification for user_B
    LocalDataStore.localUserNotifications["user_B"] = CopyOnWriteArrayList(
      listOf(
        NotificationEntity(
          notificationId = "notif_user_b",
          userId = "user_B",
          title = "Secret Alert For User B",
          body = "This must not be visible to user A",
          createdAt = System.currentTimeMillis(),
        )
      )
    )

    // View notifications for user_A
    composeTestRule.setContent {
      NotificationsScreen(
        userId = "user_A",
        onNavigateBack = {},
        notificationRepository = notificationRepository,
      )
    }

    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("notifications_empty_state").assertIsDisplayed()
    composeTestRule.onNodeWithText("কোনো নতুন নোটিফিকেশন নেই").assertIsDisplayed()
  }

  @Test
  fun notificationsScreen_showsUserNotifications_andMarksAsReadOnClick() {
    val targetUser = "user_real_winner"
    val notifId = "notif_winner_1"
    LocalDataStore.localUserNotifications[targetUser] = CopyOnWriteArrayList(
      listOf(
        NotificationEntity(
          notificationId = notifId,
          userId = targetUser,
          title = "Prize Credited! 🏆",
          body = "Congratulations! You won ৳ 90.",
          isRead = false,
          createdAt = System.currentTimeMillis(),
        )
      )
    )

    composeTestRule.setContent {
      NotificationsScreen(
        userId = targetUser,
        onNavigateBack = {},
        notificationRepository = notificationRepository,
      )
    }

    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("notification_item_$notifId").assertIsDisplayed()
    composeTestRule.onNodeWithText("Prize Credited! 🏆").assertIsDisplayed()
    composeTestRule.onNodeWithText("NEW").assertIsDisplayed()

    // Click on the notification to mark it as read
    composeTestRule.onNodeWithTag("notification_item_$notifId").performClick()
    composeTestRule.waitForIdle()

    // Verify local storage isRead changed to true
    val updatedNotif = LocalDataStore.localUserNotifications[targetUser]?.firstOrNull { it.notificationId == notifId }
    assertTrue(updatedNotif?.isRead == true)
  }
}
