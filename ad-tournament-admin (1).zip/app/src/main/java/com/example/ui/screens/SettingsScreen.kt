package com.example.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.core.config.FirebaseAdminConfig
import com.example.navigation.AdminSection
import com.example.ui.components.SectionHeader
import com.example.ui.components.SectionShellHeroCard
import com.example.ui.components.SecurityLockNotice
import com.example.ui.components.StructuralQueueCard

@Composable
fun SettingsScreen(
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("settings_screen")
    ) {
        SectionHeader(
            title = "Settings",
            subtitle = "Firebase connection, region & admin parameters",
            icon = AdminSection.SETTINGS.icon
        )

        SectionShellHeroCard(
            section = AdminSection.SETTINGS,
            statusText = "SYSTEM CONFIGURATION"
        )

        Spacer(modifier = Modifier.height(16.dp))

        SecurityLockNotice(
            title = "Backend Parameters (Authoritative & Read-Only)",
            description = "The settings below reflect the authoritative Firebase architecture. Parameters are enforced at compile time and backed by strict Firebase security rules."
        )

        Spacer(modifier = Modifier.height(16.dp))

        StructuralQueueCard(
            title = "Firebase Infrastructure Target",
            badgeLabel = "AUTHENTICATED CONSTANTS",
            items = listOf(
                "Firebase Project Name" to FirebaseAdminConfig.FIREBASE_PROJECT_NAME,
                "Firebase Project ID" to FirebaseAdminConfig.FIREBASE_PROJECT_ID,
                "RTDB Region" to FirebaseAdminConfig.RTDB_REGION,
                "RTDB Endpoint" to "adturnamet-default-rtdb",
                "Application ID" to "com.aistudio.adtournament.admin"
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        StructuralQueueCard(
            title = "Super Admin Security Configuration",
            badgeLabel = "RULE ENFORCEMENT",
            items = listOf(
                "Role Structure" to "Single Super Admin Only",
                "Multiple Admin Roles" to "Strictly Prohibited",
                "Shared With User App" to "Authoritative Firebase Backend",
                "Client-Side Financial Mutations" to "Locked & Prohibited",
                "Admin App Separation" to "Independent Project Isolated"
            )
        )
    }
}
