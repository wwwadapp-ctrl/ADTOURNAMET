package com.example.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.core.auth.AdminSessionManager
import com.example.core.model.AdminAuthState
import com.example.navigation.AdminSection
import com.example.ui.auth.LoginScreen
import com.example.ui.auth.LoginViewModel
import com.example.ui.components.AdminDrawerContent
import com.example.ui.components.AdminTopBar
import com.example.ui.screens.AuditLogsScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.DepositsScreen
import com.example.ui.screens.MatchesScreen
import com.example.ui.screens.NotificationsScreen
import com.example.ui.screens.ResultsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.UsersScreen
import com.example.ui.screens.WithdrawalsScreen
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.NavyBorder
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyDeepest
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavySurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextOnGold
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch

@Composable
fun AdminMainScreen(
    sessionManager: AdminSessionManager = AdminSessionManager.getInstance()
) {
    val authState by sessionManager.authState.collectAsState()
    val coroutineScope = rememberCoroutineScope()
    val loginViewModel: LoginViewModel = remember(sessionManager) { LoginViewModel(sessionManager) }

    LaunchedEffect(sessionManager) {
        sessionManager.checkExistingSession()
    }

    when (authState) {
        is AdminAuthState.Authenticated -> {
            var currentSection by remember { mutableStateOf(AdminSection.DASHBOARD) }
            val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

            ModalNavigationDrawer(
                drawerState = drawerState,
                drawerContent = {
                    ModalDrawerSheet(
                        drawerContainerColor = NavyDark,
                        drawerShape = RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp)
                    ) {
                        AdminDrawerContent(
                            currentSection = currentSection,
                            onSectionSelected = { section ->
                                currentSection = section
                            },
                            onCloseDrawer = {
                                coroutineScope.launch { drawerState.close() }
                            },
                            onLogout = {
                                coroutineScope.launch { sessionManager.logout() }
                            }
                        )
                    }
                }
            ) {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = NavyDeepest,
                    topBar = {
                        AdminTopBar(
                            onMenuClick = {
                                coroutineScope.launch {
                                    if (drawerState.isClosed) drawerState.open() else drawerState.close()
                                }
                            },
                            onNotificationClick = {
                                currentSection = AdminSection.NOTIFICATIONS
                            },
                            onLogoutClick = {
                                coroutineScope.launch { sessionManager.logout() }
                            }
                        )
                    },
                    bottomBar = {
                        AdminBottomNavigationBar(
                            currentSection = currentSection,
                            onSectionSelected = { section ->
                                currentSection = section
                            },
                            onOpenMenu = {
                                coroutineScope.launch { drawerState.open() }
                            }
                        )
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        AnimatedContent(
                            targetState = currentSection,
                            transitionSpec = { fadeIn() togetherWith fadeOut() },
                            label = "admin_section_transition"
                        ) { targetSection ->
                            when (targetSection) {
                                AdminSection.DASHBOARD -> DashboardScreen(
                                    onNavigateToSection = { section -> currentSection = section }
                                )
                                AdminSection.MATCHES -> MatchesScreen()
                                AdminSection.RESULTS -> ResultsScreen()
                                AdminSection.DEPOSITS -> DepositsScreen()
                                AdminSection.WITHDRAWALS -> WithdrawalsScreen()
                                AdminSection.USERS -> UsersScreen()
                                AdminSection.NOTIFICATIONS -> NotificationsScreen()
                                AdminSection.AUDIT_LOGS -> AuditLogsScreen()
                                AdminSection.SETTINGS -> SettingsScreen()
                            }
                        }
                    }
                }
            }
        }
        is AdminAuthState.Loading -> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(NavyDeepest)
                    .testTag("admin_auth_loading"),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(
                        color = GoldPrimary,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Verifying Super Admin Authorization...",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = TextSecondary,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }
            }
        }
        is AdminAuthState.Unauthenticated, is AdminAuthState.AccessDenied -> {
            LoginScreen(
                viewModel = loginViewModel,
                onLoginSuccess = {
                    // Session state update will trigger navigation to Authenticated UI
                }
            )
        }
    }
}

@Composable
private fun AdminBottomNavigationBar(
    currentSection: AdminSection,
    onSectionSelected: (AdminSection) -> Unit,
    onOpenMenu: () -> Unit
) {
    val quickItems = listOf(
        AdminSection.DASHBOARD,
        AdminSection.MATCHES,
        AdminSection.RESULTS,
        AdminSection.DEPOSITS
    )

    NavigationBar(
        containerColor = NavyDark,
        tonalElevation = 8.dp,
        modifier = Modifier
            .navigationBarsPadding()
            .border(width = 1.dp, color = NavyBorder, shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
            .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
            .testTag("admin_bottom_bar")
    ) {
        quickItems.forEach { section ->
            val isSelected = currentSection == section
            NavigationBarItem(
                selected = isSelected,
                onClick = { onSectionSelected(section) },
                modifier = Modifier.testTag("bottom_nav_${section.route}"),
                icon = {
                    Icon(
                        imageVector = section.icon,
                        contentDescription = section.title,
                        tint = if (isSelected) TextOnGold else TextSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                },
                label = {
                    Text(
                        text = section.title,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) GoldPrimary else TextMuted
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = GoldPrimary,
                    selectedIconColor = TextOnGold,
                    unselectedIconColor = TextSecondary,
                    selectedTextColor = GoldPrimary,
                    unselectedTextColor = TextMuted
                )
            )
        }

        // 5th item: "All Hubs" to open the drawer
        NavigationBarItem(
            selected = false,
            onClick = onOpenMenu,
            icon = {
                Icon(
                    imageVector = Icons.Default.Menu,
                    contentDescription = "All Admin Sections",
                    tint = CyanSecondary,
                    modifier = Modifier.size(22.dp)
                )
            },
            label = {
                Text(
                    text = "Sections",
                    fontSize = 11.sp,
                    color = CyanSecondary
                )
            },
            colors = NavigationBarItemDefaults.colors(
                indicatorColor = NavySurfaceElevated,
                unselectedIconColor = CyanSecondary,
                unselectedTextColor = CyanSecondary
            )
        )
    }
}
