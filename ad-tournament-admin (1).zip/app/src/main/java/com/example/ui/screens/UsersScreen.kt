package com.example.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.navigation.AdminSection
import com.example.ui.components.SectionHeader
import com.example.ui.components.SectionShellHeroCard
import com.example.ui.components.SecurityLockNotice
import com.example.ui.components.StructuralQueueCard

@Composable
fun UsersScreen(
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("users_screen")
    ) {
        SectionHeader(
            title = "Users",
            subtitle = "Player roster, account status & ban enforcement",
            icon = AdminSection.USERS.icon
        )

        SectionShellHeroCard(
            section = AdminSection.USERS,
            statusText = "USER GOVERNANCE SHELL"
        )

        Spacer(modifier = Modifier.height(16.dp))

        SecurityLockNotice(
            title = "Single Super Admin Enforcement",
            description = "The AD TOURNAMENT architecture enforces strictly ONE Super Admin. Multiple admin roles are forbidden. All other accounts are regular tournament participants."
        )

        Spacer(modifier = Modifier.height(16.dp))

        StructuralQueueCard(
            title = "User Directory & Moderation Modules",
            items = listOf(
                "Participant Master Index" to "Awaiting Firebase RTDB Stream",
                "Account Security & Device Bindings" to "Integrity Verification",
                "Disciplinary Status & Anti-Cheat Bans" to "Super Admin Enforcement",
                "Private User Financial Isolation" to "Strictly Protected"
            )
        )
    }
}
