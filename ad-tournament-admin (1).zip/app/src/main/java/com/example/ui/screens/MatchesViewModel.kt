package com.example.ui.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.auth.AdminSessionManager
import com.example.core.model.AdminAuthState
import com.example.core.model.AdminMatchItem
import com.example.core.model.BulkMatchPreviewItem
import com.example.core.model.BulkMatchRequest
import com.example.core.model.CreateMatchRequest
import com.example.core.model.MatchPlayerDetails
import com.example.core.model.MatchStatus
import com.example.core.model.MatchSummary
import com.example.core.model.TournamentMath
import com.example.core.repository.FirebaseMatchesRepository
import com.example.core.repository.MatchesRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface MatchesUiState {
    data object Loading : MatchesUiState
    data class Success(
        val matches: List<AdminMatchItem>,
        val filteredMatches: List<AdminMatchItem>,
        val summary: MatchSummary
    ) : MatchesUiState
    data class Error(val message: String) : MatchesUiState
}

class MatchesViewModel(
    private val repository: MatchesRepository = FirebaseMatchesRepository(),
    private val sessionManager: AdminSessionManager = AdminSessionManager.getInstance()
) : ViewModel() {

    data class MatchFilters(
        val query: String = "",
        val game: String = "ALL",
        val status: MatchStatus? = null
    )

    private val _filters = MutableStateFlow(MatchFilters())

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedGameFilter = MutableStateFlow("ALL") // "ALL", "LUDO", "CARROM"
    val selectedGameFilter: StateFlow<String> = _selectedGameFilter.asStateFlow()

    private val _selectedStatusFilter = MutableStateFlow<MatchStatus?>(null) // null = ALL
    val selectedStatusFilter: StateFlow<MatchStatus?> = _selectedStatusFilter.asStateFlow()

    private val _rawMatches = MutableStateFlow<List<AdminMatchItem>>(emptyList())
    private val _isLoading = MutableStateFlow(true)
    private val _errorMessage = MutableStateFlow<String?>(null)

    val uiState: StateFlow<MatchesUiState> = combine(
        _rawMatches,
        _filters,
        _isLoading,
        _errorMessage
    ) { matches, filters, loading, error ->
        if (loading && matches.isEmpty() && error == null) {
            MatchesUiState.Loading
        } else if (error != null && matches.isEmpty()) {
            MatchesUiState.Error(error)
        } else {
            val filtered = matches.filter { item ->
                val matchesQuery = filters.query.isBlank() ||
                        item.matchNumber.contains(filters.query, ignoreCase = true) ||
                        item.title.contains(filters.query, ignoreCase = true) ||
                        item.gameCode.contains(filters.query, ignoreCase = true)

                val matchesGame = when (filters.game.uppercase()) {
                    "LUDO" -> item.gameType.equals("LUDO", ignoreCase = true)
                    "CARROM" -> item.gameType.equals("CARROM", ignoreCase = true)
                    else -> true
                }

                val matchesStatus = filters.status == null || item.status == filters.status

                matchesQuery && matchesGame && matchesStatus
            }

            val summary = MatchSummary(
                totalMatches = matches.size,
                availableMatches = matches.count { it.status == MatchStatus.AVAILABLE },
                runningMatches = matches.count { it.status == MatchStatus.RUNNING },
                resultPendingMatches = matches.count { it.status == MatchStatus.RESULT_SUBMITTED },
                completedMatches = matches.count { it.status == MatchStatus.COMPLETED }
            )

            MatchesUiState.Success(
                matches = matches,
                filteredMatches = filtered,
                summary = summary
            )
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = MatchesUiState.Loading
    )

    // Selected Match for Details and Player Inspection
    private val _selectedMatch = MutableStateFlow<AdminMatchItem?>(null)
    val selectedMatch: StateFlow<AdminMatchItem?> = _selectedMatch.asStateFlow()

    private val _selectedMatchPlayers = MutableStateFlow<List<MatchPlayerDetails>>(emptyList())
    val selectedMatchPlayers: StateFlow<List<MatchPlayerDetails>> = _selectedMatchPlayers.asStateFlow()

    // Action dialog state (Pause, Disable, Cancel)
    data class ActionDialogState(
        val match: AdminMatchItem,
        val targetStatus: MatchStatus
    )
    private val _actionDialogState = MutableStateFlow<ActionDialogState?>(null)
    val actionDialogState: StateFlow<ActionDialogState?> = _actionDialogState.asStateFlow()

    // Create Match Dialog
    private val _isCreateDialogOpen = MutableStateFlow(false)
    val isCreateDialogOpen: StateFlow<Boolean> = _isCreateDialogOpen.asStateFlow()

    // Bulk Create Dialog
    private val _isBulkDialogOpen = MutableStateFlow(false)
    val isBulkDialogOpen: StateFlow<Boolean> = _isBulkDialogOpen.asStateFlow()

    // Operation status / Feedback toast
    private val _operationFeedback = MutableStateFlow<String?>(null)
    val operationFeedback: StateFlow<String?> = _operationFeedback.asStateFlow()

    private val _isMutating = MutableStateFlow(false)
    val isMutating: StateFlow<Boolean> = _isMutating.asStateFlow()

    private var matchesObservationJob: Job? = null
    private var playersObservationJob: Job? = null

    init {
        observeMatches()
    }

    private fun observeMatches() {
        matchesObservationJob?.cancel()
        matchesObservationJob = viewModelScope.launch {
            _isLoading.value = true
            try {
                repository.observeMatches().collect { items ->
                    _rawMatches.value = items
                    _isLoading.value = false
                    _errorMessage.value = null
                }
            } catch (e: Exception) {
                _errorMessage.value = e.message ?: "Failed to observe tournament matches."
                _isLoading.value = false
            }
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
        _filters.value = _filters.value.copy(query = query)
    }

    fun setGameFilter(game: String) {
        _selectedGameFilter.value = game
        _filters.value = _filters.value.copy(game = game)
    }

    fun setStatusFilter(status: MatchStatus?) {
        _selectedStatusFilter.value = status
        _filters.value = _filters.value.copy(status = status)
    }

    fun clearFilters() {
        _searchQuery.value = ""
        _selectedGameFilter.value = "ALL"
        _selectedStatusFilter.value = null
        _filters.value = MatchFilters()
    }

    fun selectMatch(match: AdminMatchItem?) {
        _selectedMatch.value = match
        playersObservationJob?.cancel()
        if (match != null) {
            playersObservationJob = viewModelScope.launch {
                repository.observeMatchPlayers(match.matchId).collect { players ->
                    _selectedMatchPlayers.value = players
                }
            }
        } else {
            _selectedMatchPlayers.value = emptyList()
        }
    }

    fun openActionDialog(match: AdminMatchItem, targetStatus: MatchStatus) {
        _actionDialogState.value = ActionDialogState(match, targetStatus)
    }

    fun closeActionDialog() {
        _actionDialogState.value = null
    }

    fun openCreateDialog() {
        _isCreateDialogOpen.value = true
    }

    fun closeCreateDialog() {
        _isCreateDialogOpen.value = false
    }

    fun openBulkDialog() {
        _isBulkDialogOpen.value = true
    }

    fun closeBulkDialog() {
        _isBulkDialogOpen.value = false
    }

    fun clearFeedback() {
        _operationFeedback.value = null
    }

    fun addOrEditGameCode(matchId: String, gameCode: String) {
        val session = getSuperAdminSessionOrNotify() ?: return
        viewModelScope.launch {
            _isMutating.value = true
            val result = repository.setMatchGameCode(matchId, gameCode, session)
            _isMutating.value = false
            result.onSuccess {
                _operationFeedback.value = "Room code updated successfully."
                // Update selected match in place if open
                _selectedMatch.value = _selectedMatch.value?.copy(
                    gameCode = gameCode.trim(),
                    isCodeVisible = true,
                    status = MatchStatus.CODE_ADDED
                )
            }.onFailure { err ->
                _operationFeedback.value = "Failed to update code: ${err.message}"
            }
        }
    }

    fun confirmStatusChange(matchId: String, newStatus: MatchStatus, reason: String) {
        val session = getSuperAdminSessionOrNotify() ?: return
        viewModelScope.launch {
            _isMutating.value = true
            val result = repository.updateMatchStatus(matchId, newStatus, reason, session)
            _isMutating.value = false
            closeActionDialog()
            result.onSuccess {
                _operationFeedback.value = "Match status updated to ${newStatus.label}."
                if (_selectedMatch.value?.matchId == matchId) {
                    _selectedMatch.value = _selectedMatch.value?.copy(status = newStatus)
                }
            }.onFailure { err ->
                _operationFeedback.value = "Status update failed: ${err.message}"
            }
        }
    }

    fun createSingleMatch(request: CreateMatchRequest) {
        val session = getSuperAdminSessionOrNotify() ?: return
        viewModelScope.launch {
            _isMutating.value = true
            val result = repository.createSingleMatch(request, session)
            _isMutating.value = false
            result.onSuccess {
                _operationFeedback.value = "Match ${request.matchNumber} created successfully."
                closeCreateDialog()
            }.onFailure { err ->
                _operationFeedback.value = "Match creation failed: ${err.message}"
            }
        }
    }

    fun createBulkMatches(request: BulkMatchRequest) {
        val session = getSuperAdminSessionOrNotify() ?: return
        viewModelScope.launch {
            _isMutating.value = true
            val result = repository.createBulkMatches(request, session)
            _isMutating.value = false
            result.onSuccess { ids ->
                _operationFeedback.value = "Bulk created ${ids.size} matches successfully."
                closeBulkDialog()
            }.onFailure { err ->
                _operationFeedback.value = "Bulk creation failed: ${err.message}"
            }
        }
    }

    fun generateBulkPreview(request: BulkMatchRequest): List<BulkMatchPreviewItem> {
        return TournamentMath.generateBulkPreview(request)
    }

    private fun getSuperAdminSessionOrNotify(): com.example.core.model.SuperAdminSession? {
        val authState = sessionManager.authState.value
        if (authState is AdminAuthState.Authenticated && authState.session.isSuperAdminVerified) {
            return authState.session
        }
        _operationFeedback.value = "Unauthorized: Only verified Super Admin can perform match mutations."
        return null
    }
}
