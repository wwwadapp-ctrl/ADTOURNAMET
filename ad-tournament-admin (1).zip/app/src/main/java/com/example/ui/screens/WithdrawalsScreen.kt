package com.example.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.navigation.AdminSection
import com.example.ui.components.SectionHeader
import com.example.ui.components.SectionShellHeroCard
import com.example.ui.components.SecurityLockNotice
import com.example.ui.components.StructuralQueueCard

@Composable
fun WithdrawalsScreen(
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("withdrawals_screen")
    ) {
        SectionHeader(
            title = "Withdrawals",
            subtitle = "Payout requests & Super Admin disbursement queue",
            icon = AdminSection.WITHDRAWALS.icon
        )

        SectionShellHeroCard(
            section = AdminSection.WITHDRAWALS,
            statusText = "DISBURSEMENT AUDIT SHELL"
        )

        Spacer(modifier = Modifier.height(16.dp))

        SecurityLockNotice(
            title = "Disbursement Authorization Locked",
            description = "Protected Financial Gateway: All withdrawals require dual cryptographic verification and single Super Admin approval on the authoritative Firebase database. Mutations are locked in foundation mode."
        )

        Spacer(modifier = Modifier.height(16.dp))

        StructuralQueueCard(
            title = "Withdrawal Verification Workflow",
            items = listOf(
                "Player Payout Requests" to "Authoritative Queue",
                "KYC & Account Standing Check" to "Automatic Backend Filter",
                "Single Super Admin Approval" to "Cryptographic Stamp",
                "Disbursement Status Dispatch" to "Realtime Push"
            )
        )
    }
}
