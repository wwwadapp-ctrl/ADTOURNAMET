package com.example.ui.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.auth.AdminSessionManager
import com.example.core.model.AuthResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class LoginUiState(
    val identifier: String = "",
    val password: String = "",
    val isPasswordVisible: Boolean = false,
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val identifierError: String? = null,
    val passwordError: String? = null,
    val isAccessDenied: Boolean = false
)

class LoginViewModel(
    private val sessionManager: AdminSessionManager = AdminSessionManager.getInstance()
) : ViewModel() {

    private val _uiState = MutableStateFlow(LoginUiState())
    val uiState: StateFlow<LoginUiState> = _uiState.asStateFlow()

    fun onIdentifierChanged(identifier: String) {
        _uiState.update {
            it.copy(
                identifier = identifier,
                identifierError = null,
                errorMessage = null,
                isAccessDenied = false
            )
        }
    }

    fun onPasswordChanged(password: String) {
        _uiState.update {
            it.copy(
                password = password,
                passwordError = null,
                errorMessage = null,
                isAccessDenied = false
            )
        }
    }

    fun togglePasswordVisibility() {
        _uiState.update { it.copy(isPasswordVisible = !it.isPasswordVisible) }
    }

    fun login(onSuccess: () -> Unit = {}) {
        val current = _uiState.value
        val identifier = current.identifier.trim()
        val password = current.password

        var hasError = false
        var idError: String? = null
        var passError: String? = null

        if (identifier.isBlank()) {
            idError = "Please enter your admin mobile number or identifier."
            hasError = true
        } else if (!identifier.contains("@") && identifier.length < 8) {
            idError = "Please enter a valid mobile number (min 8 digits) or email."
            hasError = true
        }

        if (password.isBlank()) {
            passError = "Please enter your admin password."
            hasError = true
        } else if (password.length < 6) {
            passError = "Password must be at least 6 characters."
            hasError = true
        }

        if (hasError) {
            _uiState.update {
                it.copy(
                    identifierError = idError,
                    passwordError = passError,
                    errorMessage = null
                )
            }
            return
        }

        _uiState.update { it.copy(isLoading = true, errorMessage = null, isAccessDenied = false) }

        viewModelScope.launch {
            when (val result = sessionManager.login(identifier, password)) {
                is AuthResult.Success -> {
                    _uiState.update { it.copy(isLoading = false, errorMessage = null) }
                    onSuccess()
                }
                is AuthResult.AccessDenied -> {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            errorMessage = result.reason,
                            isAccessDenied = true
                        )
                    }
                }
                is AuthResult.Failure -> {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            errorMessage = result.message,
                            isAccessDenied = false
                        )
                    }
                }
            }
        }
    }

    fun clearError() {
        _uiState.update { it.copy(errorMessage = null, isAccessDenied = false) }
    }
}
