package com.example.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.navigation.AdminSection
import com.example.ui.components.SectionHeader
import com.example.ui.components.SectionShellHeroCard
import com.example.ui.components.SecurityLockNotice
import com.example.ui.components.StructuralQueueCard

@Composable
fun NotificationsScreen(
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("notifications_screen")
    ) {
        SectionHeader(
            title = "Notifications",
            subtitle = "Global announcements & in-game push bulletins",
            icon = AdminSection.NOTIFICATIONS.icon
        )

        SectionShellHeroCard(
            section = AdminSection.NOTIFICATIONS,
            statusText = "COMMUNICATIONS DISPATCH SHELL"
        )

        Spacer(modifier = Modifier.height(16.dp))

        SecurityLockNotice(
            title = "Notification Dispatch Locked",
            description = "Broadcasting tools and player bulletin dispatches are locked during the foundation stage. Messages will be published to the authoritative Firebase topic channels once connected."
        )

        Spacer(modifier = Modifier.height(16.dp))

        StructuralQueueCard(
            title = "Planned Announcement Channels",
            items = listOf(
                "Global In-App Banner Bulletins" to "Broadcast Channel",
                "Match Schedule & Room Push Alerts" to "Targeted Participant Feed",
                "Maintenance & System Notices" to "Platform Critical",
                "Dispute Resolution Direct Notices" to "Private User Channel"
            )
        )
    }
}
