package com.example.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.navigation.AdminSection
import com.example.ui.components.SectionHeader
import com.example.ui.components.SectionShellHeroCard
import com.example.ui.components.SecurityLockNotice
import com.example.ui.components.StructuralQueueCard

@Composable
fun ResultsScreen(
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("results_screen")
    ) {
        SectionHeader(
            title = "Results",
            subtitle = "Match scores, screenshot proof & verification",
            icon = AdminSection.RESULTS.icon
        )

        SectionShellHeroCard(
            section = AdminSection.RESULTS,
            statusText = "VERIFICATION PIPELINE READY"
        )

        Spacer(modifier = Modifier.height(16.dp))

        SecurityLockNotice(
            title = "Result Approval Locked",
            description = "Anti-tamper protocol: Result approvals and score reconciliations are reserved for the Super Admin once Firebase Realtime Database rules are bound. Client-side bypass is disabled."
        )

        Spacer(modifier = Modifier.height(16.dp))

        StructuralQueueCard(
            title = "Verification Verification Architecture",
            items = listOf(
                "Match Screenshot Ingestion" to "Awaiting Firebase Storage Link",
                "Player Score Declarations" to "Dual Verification Protocol",
                "Dispute Arbitration Tribunal" to "Super Admin Exclusive",
                "Authoritative Prize Credit" to "Backend-Enforced Mutation"
            )
        )
    }
}
