package com.example.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.navigation.AdminSection
import com.example.ui.components.SectionHeader
import com.example.ui.components.SectionShellHeroCard
import com.example.ui.components.SecurityLockNotice
import com.example.ui.components.StructuralQueueCard

@Composable
fun AuditLogsScreen(
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("audit_logs_screen")
    ) {
        SectionHeader(
            title = "Audit Logs",
            subtitle = "Immutable security logs & system events",
            icon = AdminSection.AUDIT_LOGS.icon
        )

        SectionShellHeroCard(
            section = AdminSection.AUDIT_LOGS,
            statusText = "IMMUTABLE AUDIT TRAIL SHELL"
        )

        Spacer(modifier = Modifier.height(16.dp))

        SecurityLockNotice(
            title = "Tamper-Proof Audit Requirement",
            description = "Audit log records are append-only. No admin or user can modify or delete historical system events, financial decisions, or administrative actions."
        )

        Spacer(modifier = Modifier.height(16.dp))

        StructuralQueueCard(
            title = "Audit Event Specifications",
            items = listOf(
                "Super Admin Authentication Events" to "Cryptographic Log",
                "Match Lifecycle State Transitions" to "Timestamped Chain",
                "Financial Ledger Reconciliation Actions" to "Dual-Signed Audit",
                "Security & Role Access Verifications" to "Strict Backend Record"
            )
        )
    }
}
