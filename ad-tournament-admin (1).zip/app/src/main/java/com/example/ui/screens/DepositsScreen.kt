package com.example.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.navigation.AdminSection
import com.example.ui.components.SectionHeader
import com.example.ui.components.SectionShellHeroCard
import com.example.ui.components.SecurityLockNotice
import com.example.ui.components.StructuralQueueCard

@Composable
fun DepositsScreen(
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("deposits_screen")
    ) {
        SectionHeader(
            title = "Deposits",
            subtitle = "Player deposit reconciliation & gateway ledger",
            icon = AdminSection.DEPOSITS.icon
        )

        SectionShellHeroCard(
            section = AdminSection.DEPOSITS,
            statusText = "FINANCIAL LEDGER SHELL"
        )

        Spacer(modifier = Modifier.height(16.dp))

        SecurityLockNotice(
            title = "Financial Operations Locked",
            description = "Zero client-side wallet manipulation. Demo financial data is prohibited. Deposit verification will execute strictly against authoritative Firebase backend events under Super Admin authorization."
        )

        Spacer(modifier = Modifier.height(16.dp))

        StructuralQueueCard(
            title = "Deposit Ingestion Pipeline",
            items = listOf(
                "Payment Gateway Webhook Feeds" to "Authoritative Backend",
                "Transaction Reference Reconciliation" to "Strict Super Admin Audit",
                "Player Wallet Credit Protocol" to "Server-Side Mutation Only",
                "Anti-Fraud Velocity Checking" to "Active Security Shield"
            )
        )
    }
}
