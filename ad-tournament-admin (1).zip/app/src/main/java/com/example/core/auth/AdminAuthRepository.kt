package com.example.core.auth

import android.content.Context
import com.example.core.config.FirebaseAdminConfig
import com.example.core.model.AdminAuthState
import com.example.core.model.AuthResult
import com.example.core.model.SuperAdminAuthStatus
import com.example.core.model.SuperAdminSession
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.tasks.await

/**
 * Interface contract for Super Admin authentication and authoritative verification.
 */
interface AdminAuthRepository {
    suspend fun signIn(identifier: String, password: String): AuthResult
    suspend fun signOut()
    fun getCurrentSession(): SuperAdminSession?
    suspend fun verifySuperAdminAuthorization(uid: String): SuperAdminAuthStatus
}

/**
 * Real Firebase Authentication implementation for AD TOURNAMENT Admin Panel.
 * Uses authoritative Firebase Auth and enforces /admins/{uid} verification from Firebase Realtime Database.
 */
class FirebaseAuthRepository(
    private val context: Context? = null
) : AdminAuthRepository {

    private val firebaseAuth: FirebaseAuth? by lazy {
        try {
            FirebaseAuth.getInstance()
        } catch (e: Exception) {
            null
        }
    }

    private val firebaseDatabase: FirebaseDatabase? by lazy {
        try {
            FirebaseDatabase.getInstance(FirebaseAdminConfig.RTDB_BASE_URL)
        } catch (e: Exception) {
            null
        }
    }

    override suspend fun signIn(identifier: String, password: String): AuthResult {
        val auth = firebaseAuth ?: return AuthResult.Failure(
            "Firebase is not initialized. Please verify google-services.json configuration for project '${FirebaseAdminConfig.FIREBASE_PROJECT_ID}'."
        )

        val email = normalizeIdentifierToEmail(identifier)

        return try {
            val authResult = auth.signInWithEmailAndPassword(email, password).await()
            val user = authResult.user ?: return AuthResult.Failure("Authentication failed: No user returned from Firebase.")

            // Verify Authoritative Super Admin privilege
            when (val authStatus = verifySuperAdminAuthorization(user.uid)) {
                is SuperAdminAuthStatus.Authorized -> {
                    AuthResult.Success(authStatus.session)
                }
                is SuperAdminAuthStatus.Unauthorized -> {
                    // Instantly revoke local auth to avoid holding unauthorized tokens
                    auth.signOut()
                    AuthResult.AccessDenied(authStatus.reason)
                }
                is SuperAdminAuthStatus.BackendPending -> {
                    auth.signOut()
                    AuthResult.AccessDenied(authStatus.message)
                }
            }
        } catch (e: FirebaseAuthInvalidUserException) {
            AuthResult.Failure("Admin account not found for '$identifier'.")
        } catch (e: FirebaseAuthInvalidCredentialsException) {
            AuthResult.Failure("Invalid credentials. Please verify your mobile number/identifier and password.")
        } catch (e: Exception) {
            AuthResult.Failure(e.localizedMessage ?: "Authentication error: ${e::class.simpleName}")
        }
    }

    override suspend fun signOut() {
        try {
            firebaseAuth?.signOut()
        } catch (_: Exception) {
            // Safe cleanup
        }
    }

    override fun getCurrentSession(): SuperAdminSession? {
        val user = firebaseAuth?.currentUser ?: return null
        return SuperAdminSession(
            uid = user.uid,
            identifier = user.email ?: user.phoneNumber ?: user.uid,
            isSuperAdminVerified = false // Needs explicit verification
        )
    }

    override suspend fun verifySuperAdminAuthorization(uid: String): SuperAdminAuthStatus {
        val auth = firebaseAuth ?: return SuperAdminAuthStatus.BackendPending(
            "Firebase Auth instance not initialized."
        )
        val db = firebaseDatabase ?: return SuperAdminAuthStatus.BackendPending(
            "Firebase Realtime Database instance not initialized."
        )
        val user = auth.currentUser ?: return SuperAdminAuthStatus.Unauthorized(
            "No active Firebase session."
        )

        if (user.uid != uid) {
            return SuperAdminAuthStatus.Unauthorized("Session UID mismatch.")
        }

        return try {
            val snapshot = db.getReference("admins").child(uid).get().await()

            if (!snapshot.exists()) {
                return SuperAdminAuthStatus.Unauthorized(
                    "Access Denied: Record /admins/$uid does not exist on project '${FirebaseAdminConfig.FIREBASE_PROJECT_ID}'."
                )
            }

            val isActive = snapshot.child("isActive").getValue(Boolean::class.java) == true
            val role = snapshot.child("role").getValue(String::class.java)

            if (!isActive) {
                return SuperAdminAuthStatus.Unauthorized(
                    "Access Denied: Admin account is inactive (isActive != true)."
                )
            }

            if (role != "SUPER_ADMIN") {
                return SuperAdminAuthStatus.Unauthorized(
                    "Access Denied: Admin account role is not SUPER_ADMIN (found: '${role ?: "none"}')."
                )
            }

            SuperAdminAuthStatus.Authorized(
                SuperAdminSession(
                    uid = user.uid,
                    identifier = user.email ?: user.phoneNumber ?: user.uid,
                    isSuperAdminVerified = true
                )
            )
        } catch (e: Exception) {
            SuperAdminAuthStatus.BackendPending(
                "Authoritative /admins/$uid verification pending: ${e.message ?: "Unable to read admin record."}"
            )
        }
    }

    private fun normalizeIdentifierToEmail(identifier: String): String {
        val trimmed = identifier.trim()
        return if (trimmed.contains("@")) {
            trimmed
        } else {
            // Standard mobile number identifier mapped to project domain
            val sanitized = trimmed.filter { it.isDigit() || it == '+' }
            "$sanitized@adturnamet.admin"
        }
    }
}
