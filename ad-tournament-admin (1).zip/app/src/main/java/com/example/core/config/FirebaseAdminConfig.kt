package com.example.core.config

/**
 * Authoritative Firebase backend configuration metadata for AD TOURNAMENT.
 * Shared with the authoritative backend and User App.
 */
object FirebaseAdminConfig {
    const val FIREBASE_PROJECT_NAME = "ADTURNAMENT"
    const val FIREBASE_PROJECT_ID = "adturnamet"
    const val RTDB_REGION = "asia-southeast1"
    const val RTDB_BASE_URL = "https://adturnamet-default-rtdb.asia-southeast1.firebasedatabase.app"
    
    // Established Realtime Database Nodes
    const val NODE_USERS = "users"
    const val NODE_MATCHES = "matches"
    const val NODE_DEPOSITS = "deposits"
    const val NODE_WITHDRAWALS = "withdrawals"
    const val NODE_RESULTS = "results"
    const val NODE_AUDIT_LOGS = "audit_logs"
    const val NODE_MATCH_PLAYERS = "matchPlayers"
    
    // Strict Single Super Admin Enforcement
    const val SUPER_ADMIN_ROLE_NAME = "Super Admin"
    const val IS_SINGLE_SUPER_ADMIN_ENFORCED = true
    
    // Security flags for the foundation stage
    const val CLIENT_MUTATIONS_LOCKED = true
    const val BACKEND_AUTHORITATIVE_ENFORCED = true
}
