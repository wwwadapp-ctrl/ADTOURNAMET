package com.example.core.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.GoldLight
import com.example.ui.theme.StatusInfo
import com.example.ui.theme.StatusLive
import com.example.ui.theme.StatusPending
import com.example.ui.theme.StatusRejected
import com.example.ui.theme.TextMuted
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Authoritative 10 Match Statuses from the User App domain + safe UNKNOWN fallback.
 */
enum class MatchStatus(val label: String, val badgeColor: Color) {
    AVAILABLE("Available", StatusLive),
    FULL("Full", StatusPending),
    CODE_ADDED("Code Added", CyanSecondary),
    RUNNING("Running", StatusRejected),
    RESULT_SUBMITTED("Result Submitted", GoldLight),
    COMPLETED("Completed", TextMuted),
    PAUSED("Paused", StatusPending),
    DISABLED("Disabled", StatusRejected),
    CANCELLED("Cancelled", StatusRejected),
    UPCOMING("Upcoming", StatusInfo),
    UNKNOWN("Unknown", TextMuted);

    companion object {
        fun fromString(status: String?): MatchStatus {
            if (status.isNullOrBlank()) return UNKNOWN
            return when (status.trim().uppercase()) {
                "AVAILABLE" -> AVAILABLE
                "FULL" -> FULL
                "CODE_ADDED", "CODEADDED" -> CODE_ADDED
                "RUNNING" -> RUNNING
                "RESULT_SUBMITTED", "RESULTSUBMITTED" -> RESULT_SUBMITTED
                "COMPLETED" -> COMPLETED
                "PAUSED" -> PAUSED
                "DISABLED" -> DISABLED
                "CANCELLED" -> CANCELLED
                "UPCOMING" -> UPCOMING
                else -> UNKNOWN
            }
        }
    }
}

/**
 * Pure calculation engine for tournament commissions and prize distributions.
 * All authoritative financial math is performed using Long minor units (৳1 = 100 minor units).
 */
object TournamentMath {
    const val MINOR_UNITS_PER_TAKA = 100L
    const val MAX_PLAYERS = 2

    fun takaToMinorUnits(taka: Long): Long = taka * MINOR_UNITS_PER_TAKA

    fun minorUnitsToTaka(minorUnits: Long): Long = minorUnits / MINOR_UNITS_PER_TAKA

    /**
     * Commission rules:
     * entryFee <= ৳100 (10,000 units) -> ৳10 (1,000 units)
     * entryFee > ৳100 and <= ৳200 (10,001..20,000 units) -> ৳20 (2,000 units)
     * entryFee > ৳200 (> 20,000 units) -> ৳40 (4,000 units)
     * CRITICAL: Exactly ৳200 MUST produce ৳20 commission.
     */
    fun calculateCommissionMinorUnits(entryFeeMinorUnits: Long): Long {
        require(entryFeeMinorUnits >= 0) { "Entry fee cannot be negative" }
        val threshold100 = 100L * MINOR_UNITS_PER_TAKA
        val threshold200 = 200L * MINOR_UNITS_PER_TAKA

        return when {
            entryFeeMinorUnits <= threshold100 -> 10L * MINOR_UNITS_PER_TAKA
            entryFeeMinorUnits <= threshold200 -> 20L * MINOR_UNITS_PER_TAKA
            else -> 40L * MINOR_UNITS_PER_TAKA
        }
    }

    /**
     * Prize = (entryFee * 2) - commission
     */
    fun calculatePrizeMinorUnits(entryFeeMinorUnits: Long): Long {
        require(entryFeeMinorUnits >= 0) { "Entry fee cannot be negative" }
        val commission = calculateCommissionMinorUnits(entryFeeMinorUnits)
        val totalPool = entryFeeMinorUnits * MAX_PLAYERS
        return maxOf(0L, totalPool - commission)
    }

    fun calculateCommissionTaka(entryFeeTaka: Long): Long {
        return minorUnitsToTaka(calculateCommissionMinorUnits(takaToMinorUnits(entryFeeTaka)))
    }

    fun calculatePrizeTaka(entryFeeTaka: Long): Long {
        return minorUnitsToTaka(calculatePrizeMinorUnits(takaToMinorUnits(entryFeeTaka)))
    }

    fun formatTaka(minorUnits: Long): String {
        return "৳${minorUnitsToTaka(minorUnits)}"
    }

    fun formatTakaAmount(taka: Long): String {
        return "৳$taka"
    }

    /**
     * Generates a preview list for bulk match creation.
     */
    fun generateBulkPreview(request: BulkMatchRequest): List<BulkMatchPreviewItem> {
        val startNumLong = request.startingNumber.trim().trimStart('#').toLongOrNull()
            ?: throw IllegalArgumentException("Starting number must be a valid numeric value.")
        
        val prefix = if (request.startingNumber.trim().startsWith("#")) "#" else ""
        val commissionTaka = calculateCommissionTaka(request.entryFeeTaka)
        val prizeTaka = calculatePrizeTaka(request.entryFeeTaka)

        return (0 until request.quantity).map { index ->
            val matchNum = "$prefix${startNumLong + index}"
            val scheduledTs = request.scheduledStartTimestamp + (index * request.intervalMinutes * 60 * 1000L)
            val timeFormatted = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(scheduledTs))
            val title = "${if (request.gameType.contains("CARROM", ignoreCase = true)) "Carrom" else "Ludo"} 1v1 $matchNum"

            BulkMatchPreviewItem(
                matchNumber = matchNum,
                title = title,
                gameType = if (request.gameType.contains("CARROM", ignoreCase = true)) "CARROM" else "LUDO",
                entryFeeTaka = request.entryFeeTaka,
                prizeTaka = prizeTaka,
                commissionTaka = commissionTaka,
                scheduledTimestamp = scheduledTs,
                formattedTime = timeFormatted
            )
        }
    }
}

/**
 * Domain entity for an Admin Match item matching the exact User App canonical schema.
 */
data class AdminMatchItem(
    val matchId: String,
    val matchNumber: String,
    val title: String,
    val gameType: String, // "LUDO" or "CARROM"
    val entryFee: Double,
    val prizePool: Double,
    val status: MatchStatus,
    val rawStatus: String,
    val gameCode: String,
    val isCodeVisible: Boolean,
    val scheduledTime: Long,
    val maxPlayers: Int = TournamentMath.MAX_PLAYERS,
    val joinedPlayersCount: Int,
    val winnerUserId: String = "",
    val createdByAdminId: String = "",
    val createdAt: Long = 0L,
    val entryFeeMinorUnits: Long = 0L,
    val prizeMinorUnits: Long = 0L,
    val scheduledAt: Long = 0L,
    val updatedAt: Long = 0L,
    val startedAt: Long? = null
) {
    val displayGameType: String get() = if (gameType.contains("carrom", ignoreCase = true)) "Carrom" else "Ludo"

    val entryFeeTaka: Long get() = if (entryFeeMinorUnits > 0) {
        TournamentMath.minorUnitsToTaka(entryFeeMinorUnits)
    } else {
        entryFee.toLong()
    }

    val prizeTaka: Long get() = if (prizeMinorUnits > 0) {
        TournamentMath.minorUnitsToTaka(prizeMinorUnits)
    } else {
        prizePool.toLong()
    }

    val commissionTaka: Long get() = TournamentMath.calculateCommissionTaka(entryFeeTaka)

    val formattedScheduledTime: String get() {
        val ts = if (scheduledAt > 0) scheduledAt else scheduledTime
        return if (ts > 0) {
            SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(ts))
        } else {
            "Scheduled"
        }
    }
}

/**
 * Player participation entity matching /matchPlayers/$matchId/$userId.
 */
data class MatchPlayerDetails(
    val matchPlayerId: String,
    val matchId: String,
    val userId: String,
    val username: String,
    val slot: String, // "PLAYER_1", "PLAYER_2"
    val joinedAt: Long,
    val isReady: Boolean,
    val uid: String,
    val entryFeeMinorUnits: Long,
    val status: String // "JOINED", "LOST", "WON"
) {
    val displaySlot: String get() = when (slot.uppercase()) {
        "PLAYER_1" -> "Player 1"
        "PLAYER_2" -> "Player 2"
        else -> slot
    }

    val formattedJoinedAt: String get() {
        return if (joinedAt > 0) {
            SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(joinedAt))
        } else {
            "Joined"
        }
    }
}

/**
 * Aggregated summary counts for the Matches screen.
 */
data class MatchSummary(
    val totalMatches: Int = 0,
    val availableMatches: Int = 0,
    val runningMatches: Int = 0,
    val resultPendingMatches: Int = 0,
    val completedMatches: Int = 0
)

/**
 * Request payload for creating a single match.
 */
data class CreateMatchRequest(
    val gameType: String, // "LUDO" or "CARROM"
    val matchNumber: String,
    val title: String,
    val entryFeeTaka: Long,
    val scheduledTimestamp: Long,
    val maxPlayers: Int = TournamentMath.MAX_PLAYERS
)

/**
 * Request payload for bulk creating matches.
 */
data class BulkMatchRequest(
    val quantity: Int,
    val gameType: String, // "LUDO" or "CARROM"
    val entryFeeTaka: Long,
    val startingNumber: String,
    val scheduledStartTimestamp: Long,
    val intervalMinutes: Int,
    val maxPlayers: Int = TournamentMath.MAX_PLAYERS
)

/**
 * Preview item for bulk match creation.
 */
data class BulkMatchPreviewItem(
    val matchNumber: String,
    val title: String,
    val gameType: String,
    val entryFeeTaka: Long,
    val prizeTaka: Long,
    val commissionTaka: Long,
    val scheduledTimestamp: Long,
    val formattedTime: String
)
