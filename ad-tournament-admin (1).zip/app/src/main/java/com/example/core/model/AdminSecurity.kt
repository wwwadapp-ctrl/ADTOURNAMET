package com.example.core.model

/**
 * Super Admin session model representing an authenticated and verified Super Admin.
 * In the AD TOURNAMENT architecture, there is strictly ONLY ONE Super Admin.
 * Multiple admin roles and client-only authorizations are strictly prohibited.
 */
data class SuperAdminSession(
    val uid: String,
    val identifier: String,
    val role: String = "Super Admin",
    val projectId: String = "adturnamet",
    val authenticatedAt: Long = System.currentTimeMillis(),
    val isSuperAdminVerified: Boolean = false
)

/**
 * Global authentication state for the Admin Panel.
 * The application MUST default to Unauthenticated until authoritative verification succeeds.
 */
sealed interface AdminAuthState {
    data object Unauthenticated : AdminAuthState
    data object Loading : AdminAuthState
    data class Authenticated(val session: SuperAdminSession) : AdminAuthState
    data class AccessDenied(val reason: String) : AdminAuthState
}

/**
 * Outcome of a sign-in or authorization attempt.
 */
sealed interface AuthResult {
    data class Success(val session: SuperAdminSession) : AuthResult
    data class AccessDenied(val reason: String) : AuthResult
    data class Failure(val message: String) : AuthResult
}

/**
 * Authoritative verification status against Firebase claims or protected records.
 */
sealed interface SuperAdminAuthStatus {
    data class Authorized(val session: SuperAdminSession) : SuperAdminAuthStatus
    data class Unauthorized(val reason: String) : SuperAdminAuthStatus
    data class BackendPending(val message: String) : SuperAdminAuthStatus
}

/**
 * Presentation context used across dashboard and top bar.
 */
data class SuperAdminContext(
    val adminId: String,
    val title: String = "Super Administrator",
    val authorityScope: String = "AD TOURNAMENT Global Authority",
    val projectId: String = "adturnamet",
    val targetRegion: String = "asia-southeast1",
    val isAuthorized: Boolean
) {
    companion object {
        fun fromSession(session: SuperAdminSession): SuperAdminContext {
            return SuperAdminContext(
                adminId = session.identifier,
                isAuthorized = session.isSuperAdminVerified
            )
        }
    }
}

