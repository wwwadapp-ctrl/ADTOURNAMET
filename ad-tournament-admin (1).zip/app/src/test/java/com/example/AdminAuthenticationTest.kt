package com.example

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTextInput
import com.example.core.auth.AdminAuthRepository
import com.example.core.auth.AdminSessionManager
import com.example.core.model.AdminAuthState
import com.example.core.model.AuthResult
import com.example.core.model.SuperAdminAuthStatus
import com.example.core.model.SuperAdminSession
import com.example.navigation.AdminSection
import com.example.ui.AdminMainScreen
import com.example.ui.auth.LoginScreen
import com.example.ui.auth.LoginViewModel
import com.example.ui.theme.ADAdminTheme
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * Test implementation of AdminAuthRepository to verify all auth states
 * without relying on live Firebase network or real production credentials.
 */
class TestAdminAuthRepository : AdminAuthRepository {
    var activeSession: SuperAdminSession? = null
    var shouldSucceedSuperAdmin: Boolean = false
    var shouldFailInvalidCredentials: Boolean = false
    var shouldFailUnauthorizedAccount: Boolean = false

    override suspend fun signIn(identifier: String, password: String): AuthResult {
        if (shouldFailInvalidCredentials) {
            return AuthResult.Failure("Invalid credentials. Please verify your mobile number/identifier and password.")
        }
        if (shouldFailUnauthorizedAccount) {
            return AuthResult.AccessDenied("Access Denied: Record /admins/test_uid does not exist or account is not an active SUPER_ADMIN.")
        }
        if (shouldSucceedSuperAdmin) {
            val session = SuperAdminSession(
                uid = "super_admin_test_uid",
                identifier = identifier,
                isSuperAdminVerified = true
            )
            activeSession = session
            return AuthResult.Success(session)
        }
        return AuthResult.Failure("Authentication failed.")
    }

    override suspend fun signOut() {
        activeSession = null
    }

    override fun getCurrentSession(): SuperAdminSession? = activeSession

    override suspend fun verifySuperAdminAuthorization(uid: String): SuperAdminAuthStatus {
        val session = activeSession ?: return SuperAdminAuthStatus.Unauthorized("No session")
        return if (session.isSuperAdminVerified) {
            SuperAdminAuthStatus.Authorized(session)
        } else {
            SuperAdminAuthStatus.Unauthorized("Account lacks Super Admin claim.")
        }
    }
}

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], qualifiers = "w480dp-h1000dp")
class AdminAuthenticationTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    private lateinit var testRepo: TestAdminAuthRepository
    private lateinit var sessionManager: AdminSessionManager

    @Before
    fun setup() {
        testRepo = TestAdminAuthRepository()
        sessionManager = AdminSessionManager(testRepo)
        AdminSessionManager.resetForTesting(sessionManager)
    }

    @Test
    fun `1 - verify login screen appears when unauthenticated`() {
        // App must open to Login screen when there is no authenticated session
        composeTestRule.setContent {
            ADAdminTheme {
                AdminMainScreen(sessionManager = sessionManager)
            }
        }

        composeTestRule.onNodeWithTag("login_screen").assertExists()
        composeTestRule.onNodeWithTag("identifier_input").assertExists()
        composeTestRule.onNodeWithTag("password_input").assertExists()
        composeTestRule.onNodeWithTag("login_button").assertExists()
    }

    @Test
    fun `2 - verify no automatic or demo login occurs`() {
        runBlocking {
            // Default session state must be Unauthenticated
            assertEquals(AdminAuthState.Unauthenticated, sessionManager.authState.value)
            assertNull(testRepo.getCurrentSession())
        }
    }

    @Test
    fun `3 - verify invalid credentials produce an error state`() {
        testRepo.shouldFailInvalidCredentials = true
        val viewModel = LoginViewModel(sessionManager)

        composeTestRule.setContent {
            ADAdminTheme {
                LoginScreen(viewModel = viewModel)
            }
        }

        // Enter invalid credentials
        composeTestRule.onNodeWithTag("identifier_input").performTextInput("9876543210")
        composeTestRule.onNodeWithTag("password_input").performTextInput("wrongpass")
        composeTestRule.onNodeWithTag("login_button").performClick()

        // Wait for coroutine and UI to update with error message
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("login_error_message").assertExists()
        assertTrue(sessionManager.authState.value is AdminAuthState.Unauthenticated)
    }

    @Test
    fun `4 - verify authorized Super Admin can reach Dashboard`() {
        runBlocking {
            testRepo.shouldSucceedSuperAdmin = true

            val result = sessionManager.login("+919876543210", "ValidPass123")
            assertTrue(result is AuthResult.Success)
            assertTrue(sessionManager.authState.value is AdminAuthState.Authenticated)
        }

        composeTestRule.setContent {
            ADAdminTheme {
                AdminMainScreen(sessionManager = sessionManager)
            }
        }

        // Dashboard and admin navigation must be visible
        composeTestRule.onNodeWithTag("dashboard_screen").assertExists()
        composeTestRule.onNodeWithTag("admin_menu_button").assertExists()
    }

    @Test
    fun `5 - verify unauthorized authenticated account cannot reach Dashboard`() {
        runBlocking {
            testRepo.shouldFailUnauthorizedAccount = true

            val result = sessionManager.login("player@adturnamet.com", "Password123")
            assertTrue(result is AuthResult.AccessDenied)
            assertTrue(sessionManager.authState.value is AdminAuthState.AccessDenied)
        }

        composeTestRule.setContent {
            ADAdminTheme {
                AdminMainScreen(sessionManager = sessionManager)
            }
        }

        // Dashboard must NOT be visible, Login screen remains
        composeTestRule.onNodeWithTag("login_screen").assertExists()
    }

    @Test
    fun `6 - verify logout returns to Login screen`() {
        runBlocking {
            testRepo.shouldSucceedSuperAdmin = true

            // First login
            sessionManager.login("+919876543210", "ValidPass123")
            assertTrue(sessionManager.authState.value is AdminAuthState.Authenticated)
        }

        composeTestRule.setContent {
            ADAdminTheme {
                AdminMainScreen(sessionManager = sessionManager)
            }
        }

        composeTestRule.onNodeWithTag("dashboard_screen").assertExists()

        // Click top bar logout button
        composeTestRule.onNodeWithTag("admin_top_logout_button").performClick()
        composeTestRule.waitForIdle()

        // Should return to login screen
        composeTestRule.onNodeWithTag("login_screen").assertExists()
        assertEquals(AdminAuthState.Unauthenticated, sessionManager.authState.value)
    }

    @Test
    fun `7 - verify existing Admin navigation remains intact for authorized Super Admin`() {
        runBlocking {
            testRepo.shouldSucceedSuperAdmin = true
            sessionManager.login("+919876543210", "ValidPass123")
        }

        composeTestRule.setContent {
            ADAdminTheme {
                AdminMainScreen(sessionManager = sessionManager)
            }
        }

        // Check that bottom navigation and menu can navigate through existing sections
        composeTestRule.onNodeWithTag("admin_bottom_bar").assertExists()
        composeTestRule.onNodeWithTag("bottom_nav_matches").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("matches_screen").assertExists()

        composeTestRule.onNodeWithTag("bottom_nav_results").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("results_screen").assertExists()

        composeTestRule.onNodeWithTag("bottom_nav_deposits").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("deposits_screen").assertExists()
    }
}
