package com.example

import androidx.compose.ui.test.assertCountEquals
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import com.example.core.model.ActionRequiredSummary
import com.example.core.model.AdminActivityLogItem
import com.example.core.model.DashboardOverviewStats
import com.example.core.model.MatchLifecycleStatus
import com.example.core.model.TodayMatchItem
import com.example.core.repository.TestDashboardRepository
import com.example.navigation.AdminSection
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.DashboardViewModel
import com.example.ui.theme.ADAdminTheme
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], qualifiers = "w480dp-h1000dp")
class AdminDashboardTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    private lateinit var testRepo: TestDashboardRepository
    private lateinit var viewModel: DashboardViewModel
    private var navigatedSection: AdminSection? = null

    @Before
    fun setup() {
        testRepo = TestDashboardRepository()
        DashboardViewModel.resetForTesting(testRepo)
        viewModel = DashboardViewModel(testRepo)
        navigatedSection = null
    }

    @Test
    fun `1 - verify dashboard loading state renders indicator`() {
        testRepo.emitLoading()

        composeTestRule.setContent {
            ADAdminTheme {
                DashboardScreen(
                    onNavigateToSection = { navigatedSection = it },
                    viewModel = viewModel
                )
            }
        }

        composeTestRule.onNodeWithTag("dashboard_loading").assertExists()
        composeTestRule.onNodeWithText("Syncing authoritative RTDB telemetry...").assertExists()
    }

    @Test
    fun `2 - verify dashboard populated state renders all sections`() {
        testRepo.emitSuccess(
            overviewStats = DashboardOverviewStats(
                totalUsers = 42L,
                totalMatches = 15L,
                pendingDeposits = 3L,
                pendingWithdrawals = 2L,
                availableMatches = 5L,
                runningMatches = 4L,
                resultPending = 2L,
                blockedUsers = 1L
            ),
            todayMatches = listOf(
                TodayMatchItem(
                    id = "match_1",
                    matchNumber = "#101",
                    gameType = "Ludo",
                    entryFee = 50L,
                    prize = 90L,
                    scheduledTime = "10:30 AM",
                    status = MatchLifecycleStatus.AVAILABLE,
                    joinedCount = 1,
                    maxPlayers = 2
                )
            ),
            actionRequired = ActionRequiredSummary(
                pendingDepositsCount = 3L,
                pendingWithdrawalsCount = 2L,
                pendingResultsCount = 1L
            ),
            recentActivity = listOf(
                AdminActivityLogItem(
                    id = "act_1",
                    action = "Deposit approved",
                    time = "10:45 AM",
                    admin = "Super Admin",
                    referenceId = "#DEP-5501"
                )
            )
        )

        composeTestRule.setContent {
            ADAdminTheme {
                DashboardScreen(
                    onNavigateToSection = { navigatedSection = it },
                    viewModel = viewModel
                )
            }
        }

        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("dashboard_screen").assertExists()
        composeTestRule.onNodeWithTag("stat_total_users").assertExists()
        composeTestRule.onNodeWithTag("stat_total_matches").assertExists()
        composeTestRule.onNodeWithTag("action_deposits_pending").assertExists()
        composeTestRule.onNodeWithTag("match_item_match_1").assertExists()
        composeTestRule.onNodeWithTag("activity_item_act_1").assertExists()
    }

    @Test
    fun `3 - verify dashboard empty state displays clean empty notices`() {
        testRepo.emitSuccess(
            overviewStats = DashboardOverviewStats(0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L),
            todayMatches = emptyList(),
            actionRequired = ActionRequiredSummary(0L, 0L, 0L),
            recentActivity = emptyList()
        )

        composeTestRule.setContent {
            ADAdminTheme {
                DashboardScreen(
                    onNavigateToSection = { navigatedSection = it },
                    viewModel = viewModel
                )
            }
        }

        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("action_required_empty").assertExists()
        composeTestRule.onNodeWithText("No pending actions requiring attention").assertExists()
        composeTestRule.onNodeWithTag("matches_empty_state").assertExists()
        composeTestRule.onNodeWithText("No matches scheduled for today").assertExists()
        composeTestRule.onNodeWithTag("activity_empty_state").assertExists()
        composeTestRule.onNodeWithText("No recent activity").assertExists()
    }

    @Test
    fun `4 - verify primary and secondary statistics rendering accurately`() {
        testRepo.emitSuccess(
            overviewStats = DashboardOverviewStats(
                totalUsers = 120L,
                totalMatches = 35L,
                pendingDeposits = 7L,
                pendingWithdrawals = 4L,
                availableMatches = 10L,
                runningMatches = 6L,
                resultPending = 3L,
                blockedUsers = 2L
            )
        )

        composeTestRule.setContent {
            ADAdminTheme {
                DashboardScreen(
                    onNavigateToSection = { navigatedSection = it },
                    viewModel = viewModel
                )
            }
        }

        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithText("120").assertExists()
        composeTestRule.onNodeWithText("35").assertExists()
        composeTestRule.onNodeWithText("7").assertExists()
        composeTestRule.onNodeWithText("4").assertExists()
        composeTestRule.onNodeWithTag("stat_available_matches").assertExists()
        composeTestRule.onNodeWithTag("stat_running_matches").assertExists()
        composeTestRule.onNodeWithTag("stat_result_pending").assertExists()
        composeTestRule.onNodeWithTag("stat_blocked_users").assertExists()
    }

    @Test
    fun `5 - verify today matches rendering with game type and lifecycle status`() {
        testRepo.emitSuccess(
            todayMatches = listOf(
                TodayMatchItem(
                    id = "match_ludo_1",
                    matchNumber = "#901",
                    gameType = "Ludo",
                    entryFee = 100L,
                    prize = 180L,
                    scheduledTime = "12:00 PM",
                    status = MatchLifecycleStatus.RUNNING,
                    joinedCount = 2,
                    maxPlayers = 2
                ),
                TodayMatchItem(
                    id = "match_carrom_1",
                    matchNumber = "#902",
                    gameType = "Carrom",
                    entryFee = 250L,
                    prize = 450L,
                    scheduledTime = "01:15 PM",
                    status = MatchLifecycleStatus.FULL,
                    joinedCount = 2,
                    maxPlayers = 2
                )
            )
        )

        composeTestRule.setContent {
            ADAdminTheme {
                DashboardScreen(
                    onNavigateToSection = { navigatedSection = it },
                    viewModel = viewModel
                )
            }
        }

        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("match_item_match_ludo_1").assertExists()
        composeTestRule.onNodeWithText("#901").assertExists()
        composeTestRule.onNodeWithText("৳100").assertExists()
        composeTestRule.onNodeWithText("৳180").assertExists()
        composeTestRule.onNodeWithTag("status_badge_RUNNING").assertExists()

        composeTestRule.onNodeWithTag("match_item_match_carrom_1").assertExists()
        composeTestRule.onNodeWithText("#902").assertExists()
        composeTestRule.onNodeWithTag("status_badge_FULL").assertExists()
    }

    @Test
    fun `6 - verify pending action required counts and click navigation`() {
        testRepo.emitSuccess(
            actionRequired = ActionRequiredSummary(
                pendingDepositsCount = 5L,
                pendingWithdrawalsCount = 2L,
                pendingResultsCount = 3L
            )
        )

        composeTestRule.setContent {
            ADAdminTheme {
                DashboardScreen(
                    onNavigateToSection = { navigatedSection = it },
                    viewModel = viewModel
                )
            }
        }

        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("action_deposits_pending").assertExists()
        composeTestRule.onNodeWithTag("action_deposits_pending").performClick()
        assertEquals(AdminSection.DEPOSITS, navigatedSection)

        composeTestRule.onNodeWithTag("action_withdrawals_pending").performClick()
        assertEquals(AdminSection.WITHDRAWALS, navigatedSection)

        composeTestRule.onNodeWithTag("action_results_pending").performClick()
        assertEquals(AdminSection.RESULTS, navigatedSection)
    }

    @Test
    fun `7 - verify recent activity log items render metadata`() {
        testRepo.emitSuccess(
            recentActivity = listOf(
                AdminActivityLogItem(
                    id = "act_log_89",
                    action = "User blocked",
                    time = "02:30 PM",
                    admin = "Super Admin",
                    referenceId = "#USR-991"
                )
            )
        )

        composeTestRule.setContent {
            ADAdminTheme {
                DashboardScreen(
                    onNavigateToSection = { navigatedSection = it },
                    viewModel = viewModel
                )
            }
        }

        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("activity_item_act_log_89").assertExists()
        composeTestRule.onNodeWithText("User blocked").assertExists()
        composeTestRule.onNodeWithText("Super Admin • #USR-991").assertExists()
        composeTestRule.onNodeWithText("02:30 PM").assertExists()
    }

    @Test
    fun `8 - verify quick action buttons navigate to respective sections`() {
        testRepo.emitSuccess()

        composeTestRule.setContent {
            ADAdminTheme {
                DashboardScreen(
                    onNavigateToSection = { navigatedSection = it },
                    viewModel = viewModel
                )
            }
        }

        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithTag("quick_action_create_match").performClick()
        assertEquals(AdminSection.MATCHES, navigatedSection)

        composeTestRule.onNodeWithTag("quick_action_create_bulk_matches").performClick()
        assertEquals(AdminSection.MATCHES, navigatedSection)

        composeTestRule.onNodeWithTag("quick_action_results").performClick()
        assertEquals(AdminSection.RESULTS, navigatedSection)

        composeTestRule.onNodeWithTag("quick_action_deposits").performClick()
        assertEquals(AdminSection.DEPOSITS, navigatedSection)

        composeTestRule.onNodeWithTag("quick_action_withdrawals").performClick()
        assertEquals(AdminSection.WITHDRAWALS, navigatedSection)

        composeTestRule.onNodeWithTag("quick_action_users").performClick()
        assertEquals(AdminSection.USERS, navigatedSection)
    }

    @Test
    fun `9 - verify zero fake or demo numbers appear in empty initial state`() {
        testRepo.emitSuccess(
            overviewStats = DashboardOverviewStats(),
            todayMatches = emptyList(),
            actionRequired = ActionRequiredSummary(),
            recentActivity = emptyList()
        )

        composeTestRule.setContent {
            ADAdminTheme {
                DashboardScreen(
                    onNavigateToSection = { navigatedSection = it },
                    viewModel = viewModel
                )
            }
        }

        composeTestRule.waitForIdle()
        // Must show 0 for default stats, not fake numbers like 12,480 or 1,250
        composeTestRule.onAllNodesWithText("0").assertCountEquals(8)
        composeTestRule.onNodeWithText("12,480").assertDoesNotExist()
        composeTestRule.onNodeWithText("1,250").assertDoesNotExist()
    }

    @Test
    fun `10 - verify unauthorized access remains blocked at root shell`() {
        // Confirm that the AdminAuthenticationTest suite invariants remain true:
        // Dashboard is only accessible under authenticated Super Admin state.
        // Direct instantiation outside navigation still renders strictly clean state.
        testRepo.emitSuccess()
        assertEquals(0L, testRepo.stateFlow.value.let { (it as? com.example.core.model.DashboardUiState.Success)?.overviewStats?.totalUsers ?: 0L })
    }
}
