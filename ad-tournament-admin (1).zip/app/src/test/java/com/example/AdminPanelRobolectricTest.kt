package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.assertIsDisplayed
import androidx.test.core.app.ApplicationProvider
import android.content.Context
import com.example.core.config.FirebaseAdminConfig
import com.example.navigation.AdminSection
import com.example.ui.AdminMainScreen
import com.example.ui.theme.ADAdminTheme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AdminPanelRobolectricTest {

  @get:Rule
  val composeTestRule = createComposeRule()

  @Test
  fun `verify firebase configuration matches backend specification`() {
    assertEquals("ADTURNAMENT", FirebaseAdminConfig.FIREBASE_PROJECT_NAME)
    assertEquals("adturnamet", FirebaseAdminConfig.FIREBASE_PROJECT_ID)
    assertEquals("asia-southeast1", FirebaseAdminConfig.RTDB_REGION)
    assertTrue("Single Super Admin must be enforced", FirebaseAdminConfig.IS_SINGLE_SUPER_ADMIN_ENFORCED)
    assertTrue("Client mutations must remain locked in foundation shell", FirebaseAdminConfig.CLIENT_MUTATIONS_LOCKED)
  }

  @Test
  fun `verify exact 9 admin sections exist`() {
    val expectedSections = listOf(
      "dashboard",
      "matches",
      "results",
      "deposits",
      "withdrawals",
      "users",
      "notifications",
      "audit_logs",
      "settings"
    )
    val actualRoutes = AdminSection.entries.map { it.route }
    assertEquals(expectedSections, actualRoutes)
    assertEquals(9, AdminSection.entries.size)
  }

  @Test
  fun `verify admin main screen renders login when unauthenticated`() {
    composeTestRule.setContent {
      ADAdminTheme {
        AdminMainScreen()
      }
    }

    composeTestRule.onNodeWithTag("login_screen").assertIsDisplayed()
  }
}
