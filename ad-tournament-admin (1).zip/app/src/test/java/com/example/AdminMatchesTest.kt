package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import com.example.core.auth.AdminAuthRepository
import com.example.core.auth.AdminSessionManager
import com.example.core.model.AdminMatchItem
import com.example.core.model.AuthResult
import com.example.core.model.BulkMatchRequest
import com.example.core.model.CreateMatchRequest
import com.example.core.model.MatchPlayerDetails
import com.example.core.model.MatchStatus
import com.example.core.model.SuperAdminAuthStatus
import com.example.core.model.SuperAdminSession
import com.example.core.model.TournamentMath
import com.example.core.repository.InMemoryMatchesRepository
import com.example.ui.screens.MatchesScreen
import com.example.ui.screens.MatchesUiState
import com.example.ui.screens.MatchesViewModel
import com.example.ui.theme.ADAdminTheme
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], qualifiers = "w480dp-h1000dp")
class AdminMatchesTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    private lateinit var testRepo: InMemoryMatchesRepository
    private lateinit var testSessionManager: AdminSessionManager
    private val authorizedAdminSession = SuperAdminSession(
        uid = "super_admin_test_uid",
        identifier = "01700000000",
        isSuperAdminVerified = true
    )

    @Before
    fun setUp() {
        testRepo = InMemoryMatchesRepository()

        val mockAuthRepo = object : AdminAuthRepository {
            override suspend fun signIn(identifier: String, password: String): AuthResult =
                AuthResult.Success(authorizedAdminSession)
            override fun getCurrentSession(): SuperAdminSession? = authorizedAdminSession
            override suspend fun verifySuperAdminAuthorization(uid: String): SuperAdminAuthStatus =
                SuperAdminAuthStatus.Authorized(authorizedAdminSession)
            override suspend fun signOut() {}
        }

        testSessionManager = AdminSessionManager(mockAuthRepo)
        runBlocking {
            testSessionManager.checkExistingSession()
        }
    }

    @After
    fun tearDown() {
        AdminSessionManager.resetForTesting(null)
    }

    // 1. commission ৳100 = ৳10
    @Test
    fun `1 - verify commission for 100 taka is exactly 10 taka`() {
        val commission = TournamentMath.calculateCommissionTaka(100L)
        assertEquals(10L, commission)
    }

    // 2. commission ৳200 = ৳20 (Locked rule: Exactly ৳200 MUST produce ৳20)
    @Test
    fun `2 - verify commission for exactly 200 taka is 20 taka`() {
        val commission = TournamentMath.calculateCommissionTaka(200L)
        assertEquals(20L, commission)
    }

    // 3. commission ৳201 = ৳40
    @Test
    fun `3 - verify commission for 201 taka is 40 taka`() {
        val commission = TournamentMath.calculateCommissionTaka(201L)
        assertEquals(40L, commission)
    }

    // 4. prize ৳100 = ৳190
    @Test
    fun `4 - verify prize for 100 taka entry is 190 taka`() {
        val prize = TournamentMath.calculatePrizeTaka(100L)
        assertEquals(190L, prize)
    }

    // 5. prize ৳200 = ৳380
    @Test
    fun `5 - verify prize for 200 taka entry is 380 taka`() {
        val prize = TournamentMath.calculatePrizeTaka(200L)
        assertEquals(380L, prize)
    }

    // 6. prize ৳300 = ৳560
    @Test
    fun `6 - verify prize for 300 taka entry is 560 taka`() {
        val prize = TournamentMath.calculatePrizeTaka(300L)
        assertEquals(560L, prize)
    }

    // 7. max players always 2
    @Test
    fun `7 - verify max players is strictly 2`() {
        assertEquals(2, TournamentMath.MAX_PLAYERS)
    }

    // 8. empty match number rejected
    @Test
    fun `8 - verify empty match number is rejected`() {
        runBlocking {
            val request = CreateMatchRequest(
                gameType = "LUDO",
                matchNumber = "   ",
                title = "Test Match",
                entryFeeTaka = 100L,
                scheduledTimestamp = System.currentTimeMillis() + 60000L
            )
            val result = testRepo.createSingleMatch(request, authorizedAdminSession)
            assertTrue(result.isFailure)
            assertTrue(result.exceptionOrNull()?.message?.contains("cannot be empty", ignoreCase = true) == true)
        }
    }

    // 9. empty game code rejected
    @Test
    fun `9 - verify empty game code is rejected`() {
        runBlocking {
            val result = testRepo.setMatchGameCode("match_1", "   ", authorizedAdminSession)
            assertTrue(result.isFailure)
            assertTrue(result.exceptionOrNull()?.message?.contains("cannot be empty", ignoreCase = true) == true)
        }
    }

    // 10. status parser supports all existing statuses
    @Test
    fun `10 - verify status parser supports all 10 canonical statuses`() {
        assertEquals(MatchStatus.AVAILABLE, MatchStatus.fromString("AVAILABLE"))
        assertEquals(MatchStatus.FULL, MatchStatus.fromString("FULL"))
        assertEquals(MatchStatus.CODE_ADDED, MatchStatus.fromString("CODE_ADDED"))
        assertEquals(MatchStatus.RUNNING, MatchStatus.fromString("RUNNING"))
        assertEquals(MatchStatus.RESULT_SUBMITTED, MatchStatus.fromString("RESULT_SUBMITTED"))
        assertEquals(MatchStatus.COMPLETED, MatchStatus.fromString("COMPLETED"))
        assertEquals(MatchStatus.PAUSED, MatchStatus.fromString("PAUSED"))
        assertEquals(MatchStatus.DISABLED, MatchStatus.fromString("DISABLED"))
        assertEquals(MatchStatus.CANCELLED, MatchStatus.fromString("CANCELLED"))
        assertEquals(MatchStatus.UPCOMING, MatchStatus.fromString("UPCOMING"))
    }

    // 11. unknown status does not silently become AVAILABLE
    @Test
    fun `11 - verify unknown status does not silently become AVAILABLE`() {
        val parsed = MatchStatus.fromString("SOME_UNKNOWN_STATUS_XYZ")
        assertNotEquals(MatchStatus.AVAILABLE, parsed)
        assertEquals(MatchStatus.UNKNOWN, parsed)

        val nullParsed = MatchStatus.fromString(null)
        assertNotEquals(MatchStatus.AVAILABLE, nullParsed)
        assertEquals(MatchStatus.UNKNOWN, nullParsed)
    }

    // 12. search filtering
    @Test
    fun `12 - verify search filtering across match number and title`() {
        runBlocking {
            val matches = listOf(
                createTestMatch("m1", "#101", "Ludo 1v1 #101", "LUDO", MatchStatus.AVAILABLE),
                createTestMatch("m2", "#102", "Carrom 1v1 #102", "CARROM", MatchStatus.RUNNING),
                createTestMatch("m3", "#103", "Ludo Special #103", "LUDO", MatchStatus.COMPLETED)
            )
            testRepo.emitMatches(matches)
            val vm = MatchesViewModel(testRepo, testSessionManager)

            vm.setSearchQuery("102")
            val state = vm.uiState.first { it is MatchesUiState.Success } as MatchesUiState.Success
            assertEquals(1, state.filteredMatches.size)
            assertEquals("#102", state.filteredMatches[0].matchNumber)
        }
    }

    // 13. Ludo filtering
    @Test
    fun `13 - verify game filtering for Ludo only`() {
        runBlocking {
            val matches = listOf(
                createTestMatch("m1", "#101", "Ludo 1v1", "LUDO", MatchStatus.AVAILABLE),
                createTestMatch("m2", "#102", "Carrom 1v1", "CARROM", MatchStatus.RUNNING),
                createTestMatch("m3", "#103", "Ludo 1v1 B", "LUDO", MatchStatus.FULL)
            )
            testRepo.emitMatches(matches)
            val vm = MatchesViewModel(testRepo, testSessionManager)

            vm.setGameFilter("LUDO")
            val state = vm.uiState.first { it is MatchesUiState.Success } as MatchesUiState.Success
            assertEquals(2, state.filteredMatches.size)
            assertTrue(state.filteredMatches.all { it.gameType == "LUDO" })
        }
    }

    // 14. Carrom filtering
    @Test
    fun `14 - verify game filtering for Carrom only`() {
        runBlocking {
            val matches = listOf(
                createTestMatch("m1", "#101", "Ludo 1v1", "LUDO", MatchStatus.AVAILABLE),
                createTestMatch("m2", "#102", "Carrom 1v1", "CARROM", MatchStatus.RUNNING),
                createTestMatch("m3", "#103", "Ludo 1v1 B", "LUDO", MatchStatus.FULL)
            )
            testRepo.emitMatches(matches)
            val vm = MatchesViewModel(testRepo, testSessionManager)

            vm.setGameFilter("CARROM")
            val state = vm.uiState.first { it is MatchesUiState.Success } as MatchesUiState.Success
            assertEquals(1, state.filteredMatches.size)
            assertEquals("CARROM", state.filteredMatches[0].gameType)
        }
    }

    // 15. status filtering
    @Test
    fun `15 - verify status filtering`() {
        runBlocking {
            val matches = listOf(
                createTestMatch("m1", "#101", "Ludo 1v1", "LUDO", MatchStatus.AVAILABLE),
                createTestMatch("m2", "#102", "Carrom 1v1", "CARROM", MatchStatus.RUNNING),
                createTestMatch("m3", "#103", "Carrom 1v1 B", "CARROM", MatchStatus.RUNNING),
                createTestMatch("m4", "#104", "Ludo 1v1 C", "LUDO", MatchStatus.COMPLETED)
            )
            testRepo.emitMatches(matches)
            val vm = MatchesViewModel(testRepo, testSessionManager)

            vm.setStatusFilter(MatchStatus.RUNNING)
            val state = vm.uiState.first { it is MatchesUiState.Success } as MatchesUiState.Success
            assertEquals(2, state.filteredMatches.size)
            assertTrue(state.filteredMatches.all { it.status == MatchStatus.RUNNING })
        }
    }

    // 16. summary counts
    @Test
    fun `16 - verify summary counts calculation`() {
        runBlocking {
            val matches = listOf(
                createTestMatch("m1", "#101", "A", "LUDO", MatchStatus.AVAILABLE),
                createTestMatch("m2", "#102", "B", "CARROM", MatchStatus.AVAILABLE),
                createTestMatch("m3", "#103", "C", "LUDO", MatchStatus.RUNNING),
                createTestMatch("m4", "#104", "D", "CARROM", MatchStatus.RESULT_SUBMITTED),
                createTestMatch("m5", "#105", "E", "LUDO", MatchStatus.COMPLETED)
            )
            testRepo.emitMatches(matches)
            val vm = MatchesViewModel(testRepo, testSessionManager)

            val state = vm.uiState.first { it is MatchesUiState.Success } as MatchesUiState.Success
            assertEquals(5, state.summary.totalMatches)
            assertEquals(2, state.summary.availableMatches)
            assertEquals(1, state.summary.runningMatches)
            assertEquals(1, state.summary.resultPendingMatches)
            assertEquals(1, state.summary.completedMatches)
        }
    }

    // 17. match player parsing
    @Test
    fun `17 - verify match player parsing`() {
        runBlocking {
            val player = MatchPlayerDetails(
                matchPlayerId = "mp_1",
                matchId = "m_1",
                userId = "usr_100",
                username = "PlayerAlpha",
                slot = "PLAYER_1",
                joinedAt = 1700000000000L,
                isReady = true,
                uid = "usr_100",
                entryFeeMinorUnits = 10000L,
                status = "JOINED"
            )
            assertEquals("Player 1", player.displaySlot)
            assertEquals("PlayerAlpha", player.username)
            assertEquals("usr_100", player.userId)
        }
    }

    // 18. money uses Long minor units
    @Test
    fun `18 - verify money strictly uses Long minor units`() {
        val takaAmount = 250L
        val minorUnits = TournamentMath.takaToMinorUnits(takaAmount)
        assertEquals(25000L, minorUnits)
        assertEquals(takaAmount, TournamentMath.minorUnitsToTaka(minorUnits))

        val commissionMinor = TournamentMath.calculateCommissionMinorUnits(minorUnits)
        assertEquals(4000L, commissionMinor) // 40 taka in minor units

        val prizeMinor = TournamentMath.calculatePrizeMinorUnits(minorUnits)
        assertEquals(46000L, prizeMinor) // (250 * 2) - 40 = 460 taka in minor units
    }

    // 19. cancel does NOT perform client wallet mutation
    @Test
    fun `19 - verify cancel updates match status and logs audit without mutating wallets`() {
        runBlocking {
            val initialMatch = createTestMatch("match_cancel_test", "#999", "Fixture 999", "LUDO", MatchStatus.RUNNING)
            testRepo.emitMatches(listOf(initialMatch))

            val result = testRepo.updateMatchStatus(
                matchId = "match_cancel_test",
                newStatus = MatchStatus.CANCELLED,
                reason = "Admin manual fixture cancellation",
                adminSession = authorizedAdminSession
            )

            assertTrue(result.isSuccess)
            val updated = testRepo.observeMatches().first().first { it.matchId == "match_cancel_test" }
            assertEquals(MatchStatus.CANCELLED, updated.status)

            // Verify audit log recorded
            val auditRecord = testRepo.auditLogRecords.lastOrNull()
            assertNotNull(auditRecord)
            assertEquals("MATCH_CANCELLED", auditRecord?.get("action"))
            assertEquals("match_cancel_test", auditRecord?.get("referenceId"))

            // Verify zero wallet keys in audit log or repo state
            assertFalse(auditRecord?.containsKey("wallet") == true)
            assertFalse(auditRecord?.containsKey("balance") == true)
        }
    }

    // 20. unauthorized mutation is rejected
    @Test
    fun `20 - verify unauthorized mutation is strictly rejected`() {
        runBlocking {
            val unverifiedSession = SuperAdminSession(
                uid = "unverified_user",
                identifier = "01800000000",
                isSuperAdminVerified = false
            )

            val result = testRepo.setMatchGameCode("match_1", "ROOM999", unverifiedSession)
            assertTrue(result.isFailure)
            assertTrue(result.exceptionOrNull() is SecurityException)
        }
    }

    // 21. bulk preview numbering
    @Test
    fun `21 - verify bulk preview generates sequential numbers accurately`() {
        val req = BulkMatchRequest(
            quantity = 4,
            gameType = "LUDO",
            entryFeeTaka = 100L,
            startingNumber = "#501",
            scheduledStartTimestamp = 1700000000000L,
            intervalMinutes = 20
        )
        val previews = TournamentMath.generateBulkPreview(req)
        assertEquals(4, previews.size)
        assertEquals("#501", previews[0].matchNumber)
        assertEquals("#502", previews[1].matchNumber)
        assertEquals("#503", previews[2].matchNumber)
        assertEquals("#504", previews[3].matchNumber)
    }

    // 22. bulk schedule interval calculation
    @Test
    fun `22 - verify bulk schedule calculates intervals accurately`() {
        val startTs = 1700000000000L
        val intervalMin = 30
        val req = BulkMatchRequest(
            quantity = 3,
            gameType = "CARROM",
            entryFeeTaka = 200L,
            startingNumber = "100",
            scheduledStartTimestamp = startTs,
            intervalMinutes = intervalMin
        )
        val previews = TournamentMath.generateBulkPreview(req)
        assertEquals(startTs, previews[0].scheduledTimestamp)
        assertEquals(startTs + (30 * 60 * 1000L), previews[1].scheduledTimestamp)
        assertEquals(startTs + (60 * 60 * 1000L), previews[2].scheduledTimestamp)
    }

    // UI Compose test: Compose screen renders real matches and handles interactions
    @Test
    fun `verify matches screen renders matches list and filter chips`() {
        runBlocking {
            val matches = listOf(
                createTestMatch("m_ui_1", "#777", "Ludo Championship", "LUDO", MatchStatus.AVAILABLE),
                createTestMatch("m_ui_2", "#778", "Carrom Master", "CARROM", MatchStatus.RUNNING)
            )
            testRepo.emitMatches(matches)
            val vm = MatchesViewModel(testRepo, testSessionManager)

            composeTestRule.setContent {
                ADAdminTheme {
                    MatchesScreen(viewModel = vm)
                }
            }

            composeTestRule.waitForIdle()
            composeTestRule.onNodeWithTag("matches_screen").assertExists()
            composeTestRule.onNodeWithTag("match_card_m_ui_1").assertExists()
            composeTestRule.onNodeWithText("#777").assertExists()
        }
    }

    private fun createTestMatch(
        id: String,
        number: String,
        title: String,
        game: String,
        status: MatchStatus
    ): AdminMatchItem {
        return AdminMatchItem(
            matchId = id,
            matchNumber = number,
            title = title,
            gameType = game,
            entryFee = 100.0,
            prizePool = 190.0,
            status = status,
            rawStatus = status.name,
            gameCode = "",
            isCodeVisible = false,
            scheduledTime = System.currentTimeMillis(),
            maxPlayers = 2,
            joinedPlayersCount = 1,
            entryFeeMinorUnits = 10000L,
            prizeMinorUnits = 19000L,
            scheduledAt = System.currentTimeMillis(),
            createdAt = System.currentTimeMillis()
        )
    }
}
