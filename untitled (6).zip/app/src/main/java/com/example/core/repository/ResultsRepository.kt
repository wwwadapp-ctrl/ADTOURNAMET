package com.example.core.repository

import com.example.core.config.FirebaseAdminConfig
import com.example.core.model.AdminResultItem
import com.example.core.model.ResultStatus
import com.example.core.model.SuperAdminSession
import com.example.core.model.TournamentMath
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.MutableData
import com.google.firebase.database.Transaction
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.tasks.await
import kotlin.coroutines.resume

data class ResultApprovalResult(
    val success: Boolean,
    val alreadySettled: Boolean = false,
    val errorMessage: String? = null
)

interface ResultsRepository {
    fun observeResults(): Flow<List<AdminResultItem>>
    suspend fun getResult(resultId: String): AdminResultItem?
    suspend fun approveResult(
        resultId: String,
        submittedMatchNumber: String,
        submittedRoomCode: String,
        adminSession: SuperAdminSession
    ): Result<Unit>
    suspend fun rejectResult(
        resultId: String,
        reason: String,
        adminSession: SuperAdminSession
    ): Result<Unit>
}

class FirebaseResultsRepository : ResultsRepository {
    private val database: FirebaseDatabase? = try {
        FirebaseDatabase.getInstance(FirebaseAdminConfig.RTDB_BASE_URL)
    } catch (e: Exception) {
        null
    }

    private fun verifySuperAdmin(adminSession: SuperAdminSession) {
        if (!adminSession.isSuperAdminVerified || adminSession.uid.isBlank()) {
            throw SecurityException("Unauthorized: Result settlement requires verified Super Admin authorization.")
        }
    }

    override fun observeResults(): Flow<List<AdminResultItem>> {
        val db = database ?: return flowOf(emptyList())
        return callbackFlow {
            val ref = db.getReference(FirebaseAdminConfig.NODE_RESULTS)
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val list = mutableListOf<AdminResultItem>()
                    for (child in snapshot.children) {
                        try {
                            val resultId = child.key ?: continue
                            val matchId = child.child("matchId").value?.toString()
                                ?: child.child("match_id").value?.toString() ?: ""
                            val matchNumber = child.child("matchNumber").value?.toString()
                                ?: child.child("match_number").value?.toString() ?: "#001"
                            val rawGame = child.child("gameType").value?.toString()
                                ?: child.child("game").value?.toString() ?: "LUDO"
                            val gameType = if (rawGame.contains("carrom", ignoreCase = true)) "CARROM" else "LUDO"
                            val userId = child.child("userId").value?.toString()
                                ?: child.child("uid").value?.toString() ?: ""
                            val userName = child.child("userName").value?.toString()
                                ?: child.child("name").value?.toString()
                                ?: child.child("username").value?.toString() ?: "Player"
                            val userPhone = child.child("userPhone").value?.toString()
                                ?: child.child("phone").value?.toString() ?: ""
                            val roomCode = child.child("roomCode").value?.toString()
                                ?: child.child("code").value?.toString()
                                ?: child.child("gameCode").value?.toString() ?: ""
                            val screenshotUrl = child.child("screenshotUrl").value?.toString()
                                ?: child.child("screenshot").value?.toString()
                                ?: child.child("imageUrl").value?.toString()
                                ?: child.child("proofUrl").value?.toString() ?: ""
                            val prizePoolDouble = (child.child("prizePool").value as? Number)?.toDouble()
                                ?: (child.child("prize").value as? Number)?.toDouble()
                                ?: (child.child("amount").value as? Number)?.toDouble() ?: 0.0
                            val prizeMinor = (child.child("prizeMinorUnits").value as? Number)?.toLong()
                                ?: (child.child("amountMinorUnits").value as? Number)?.toLong()
                                ?: TournamentMath.takaToMinorUnits(prizePoolDouble.toLong())
                            val prizeTaka = (child.child("prizeTaka").value as? Number)?.toLong()
                                ?: TournamentMath.minorUnitsToTaka(prizeMinor)

                            val rawStatus = child.child("status").value?.toString() ?: "PENDING"
                            val status = ResultStatus.fromString(rawStatus)
                            val createdAt = (child.child("createdAt").value as? Number)?.toLong()
                                ?: (child.child("timestamp").value as? Number)?.toLong() ?: System.currentTimeMillis()
                            val processedAt = (child.child("processedAt").value as? Number)?.toLong()
                            val processedBy = child.child("processedBy").value?.toString()
                            val rejectionReason = child.child("rejectionReason").value?.toString()
                                ?: child.child("reason").value?.toString()
                            val settlementTransactionId = child.child("settlementTransactionId").value?.toString()
                                ?: child.child("transactionId").value?.toString() ?: ""

                            list.add(
                                AdminResultItem(
                                    resultId = resultId,
                                    matchId = matchId,
                                    matchNumber = matchNumber,
                                    gameType = gameType,
                                    userId = userId,
                                    userName = userName,
                                    userPhone = userPhone,
                                    roomCode = roomCode,
                                    screenshotUrl = screenshotUrl,
                                    prizeMinorUnits = prizeMinor,
                                    prizeTaka = prizeTaka,
                                    status = status,
                                    rawStatus = rawStatus,
                                    createdAt = createdAt,
                                    processedAt = processedAt,
                                    processedBy = processedBy,
                                    rejectionReason = rejectionReason,
                                    settlementTransactionId = settlementTransactionId
                                )
                            )
                        } catch (_: Exception) {
                            // Skip malformed nodes gracefully
                        }
                    }
                    val sorted = list.sortedByDescending { it.createdAt }
                    trySend(sorted)
                }

                override fun onCancelled(error: DatabaseError) {
                    close(error.toException())
                }
            }
            ref.addValueEventListener(listener)
            awaitClose { ref.removeEventListener(listener) }
        }
    }

    override suspend fun getResult(resultId: String): AdminResultItem? {
        val db = database ?: return null
        return try {
            val child = db.getReference(FirebaseAdminConfig.NODE_RESULTS).child(resultId).get().await()
            if (!child.exists()) return null

            val matchId = child.child("matchId").value?.toString() ?: ""
            val matchNumber = child.child("matchNumber").value?.toString() ?: "#001"
            val rawGame = child.child("gameType").value?.toString() ?: "LUDO"
            val gameType = if (rawGame.contains("carrom", ignoreCase = true)) "CARROM" else "LUDO"
            val userId = child.child("userId").value?.toString() ?: ""
            val userName = child.child("userName").value?.toString() ?: "Player"
            val userPhone = child.child("userPhone").value?.toString() ?: ""
            val roomCode = child.child("roomCode").value?.toString() ?: ""
            val screenshotUrl = child.child("screenshotUrl").value?.toString() ?: ""
            val prizeMinor = (child.child("prizeMinorUnits").value as? Number)?.toLong()
                ?: TournamentMath.takaToMinorUnits((child.child("prizePool").value as? Number)?.toLong() ?: 0L)
            val prizeTaka = TournamentMath.minorUnitsToTaka(prizeMinor)
            val rawStatus = child.child("status").value?.toString() ?: "PENDING"
            val status = ResultStatus.fromString(rawStatus)
            val createdAt = (child.child("createdAt").value as? Number)?.toLong() ?: System.currentTimeMillis()

            AdminResultItem(
                resultId = resultId,
                matchId = matchId,
                matchNumber = matchNumber,
                gameType = gameType,
                userId = userId,
                userName = userName,
                userPhone = userPhone,
                roomCode = roomCode,
                screenshotUrl = screenshotUrl,
                prizeMinorUnits = prizeMinor,
                prizeTaka = prizeTaka,
                status = status,
                rawStatus = rawStatus,
                createdAt = createdAt
            )
        } catch (_: Exception) {
            null
        }
    }

    override suspend fun approveResult(
        resultId: String,
        submittedMatchNumber: String,
        submittedRoomCode: String,
        adminSession: SuperAdminSession
    ): Result<Unit> = runCatching {
        verifySuperAdmin(adminSession)
        val db = database ?: throw IllegalStateException("Firebase RTDB instance is unavailable.")

        val resultItem = getResult(resultId)
            ?: throw IllegalArgumentException("Result submission '$resultId' does not exist.")

        if (resultItem.status == ResultStatus.APPROVED) {
            throw IllegalStateException("Result '$resultId' has already been approved and settled.")
        }
        if (resultItem.status == ResultStatus.REJECTED) {
            throw IllegalStateException("Result '$resultId' was rejected and cannot be approved.")
        }

        val matchId = resultItem.matchId
        require(matchId.isNotBlank()) { "Result submission is not linked to any match ID." }

        // Fetch authoritative match details from /matches/{matchId}
        val matchSnapshot = db.getReference(FirebaseAdminConfig.NODE_MATCHES).child(matchId).get().await()
        if (!matchSnapshot.exists()) {
            throw IllegalArgumentException("Linked match ID '$matchId' does not exist in the system.")
        }

        val canonicalMatchNumber = matchSnapshot.child("matchNumber").value?.toString()
            ?: matchSnapshot.child("match_number").value?.toString() ?: resultItem.matchNumber
        val authoritativeGameCode = matchSnapshot.child("gameCode").value?.toString()
            ?: matchSnapshot.child("code").value?.toString()
            ?: matchSnapshot.child("game_code").value?.toString() ?: ""
        val authoritativePrizeMinor = (matchSnapshot.child("prizeMinorUnits").value as? Number)?.toLong()
            ?: TournamentMath.takaToMinorUnits((matchSnapshot.child("prizePool").value as? Number)?.toLong()
                ?: (matchSnapshot.child("prize").value as? Number)?.toLong()
                ?: resultItem.prizeTaka)

        // Strict verification rules as requested:
        // 1. Match Number correspondence check
        val cleanSubmittedMatchNum = submittedMatchNumber.trim().lowercase()
        val cleanCanonicalMatchNum = canonicalMatchNumber.trim().lowercase()
        require(cleanSubmittedMatchNum == cleanCanonicalMatchNum || resultItem.matchNumber.trim().lowercase() == cleanCanonicalMatchNum) {
            "Match verification mismatch: Submitted Match Number ($submittedMatchNumber) does not correspond to system Match Number ($canonicalMatchNumber)."
        }

        // 2. Room Code correspondence check (if room code exists in match)
        val cleanSubmittedRoomCode = submittedRoomCode.trim()
        val cleanAuthoritativeRoomCode = authoritativeGameCode.trim()
        if (cleanAuthoritativeRoomCode.isNotBlank()) {
            require(cleanSubmittedRoomCode.equals(cleanAuthoritativeRoomCode, ignoreCase = true) || cleanSubmittedRoomCode.equals(resultItem.roomCode.trim(), ignoreCase = true)) {
                "Room Code verification mismatch: Submitted Room Code ($submittedRoomCode) does not correspond to authoritative system Room Code."
            }
        }

        val userId = resultItem.userId
        require(userId.isNotBlank()) { "Winner User ID is missing from result submission." }

        val now = System.currentTimeMillis()
        val deterministicTrxId = "WIN_$resultId"
        val deterministicLogId = "AUDIT_WIN_$resultId"
        val prizeTaka = TournamentMath.minorUnitsToTaka(authoritativePrizeMinor)

        // Step 1: Authoritative atomic status lock on /results/{resultId}
        val resultRef = db.getReference(FirebaseAdminConfig.NODE_RESULTS).child(resultId)
        val lockResult = executeResultApprovalLockTransaction(
            resultRef = resultRef,
            adminSession = adminSession,
            settlementTrxId = deterministicTrxId,
            authoritativePrizeMinor = authoritativePrizeMinor,
            now = now
        )

        if (!lockResult.success) {
            if (lockResult.alreadySettled) {
                throw IllegalStateException("Result '$resultId' has already been approved or settled concurrently.")
            }
            throw IllegalStateException(lockResult.errorMessage ?: "Failed to lock result status for approval.")
        }

        // Step 2: Atomic wallet prize credit via runTransaction on /wallets/{userId}
        val walletRef = db.getReference(FirebaseAdminConfig.NODE_WALLETS).child(userId)
        val walletCreditResult = executeWalletPrizeCreditTransaction(
            walletRef = walletRef,
            resultId = resultId,
            prizeMinorUnits = authoritativePrizeMinor,
            now = now
        )

        if (!walletCreditResult.success) {
            throw IllegalStateException(walletCreditResult.errorMessage ?: "Wallet prize credit transaction failed.")
        }

        // Step 3: Write secondary mirrored nodes, match winner updates, ledger transaction, and audit logs
        val userResultsNodeKey = "userResults"
        val updates = mutableMapOf<String, Any?>(
            // User result mirror update
            "$userResultsNodeKey/$userId/$resultId/status" to ResultStatus.APPROVED.name,
            "$userResultsNodeKey/$userId/$resultId/processedAt" to now,
            "$userResultsNodeKey/$userId/$resultId/processedBy" to adminSession.identifier,
            "$userResultsNodeKey/$userId/$resultId/settlementTransactionId" to deterministicTrxId,
            "$userResultsNodeKey/$userId/$resultId/screenshotUrl" to null,

            // Root result screenshot cleanup
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/screenshotUrl" to null,

            // Update match winner & status in /matches/{matchId}
            "${FirebaseAdminConfig.NODE_MATCHES}/$matchId/winnerUserId" to userId,
            "${FirebaseAdminConfig.NODE_MATCHES}/$matchId/status" to "COMPLETED",
            "${FirebaseAdminConfig.NODE_MATCHES}/$matchId/updatedAt" to now,

            // Profile consistency update in /users/{userId}
            "${FirebaseAdminConfig.NODE_USERS}/$userId/balance" to walletCreditResult.newBalance,
            "${FirebaseAdminConfig.NODE_USERS}/$userId/winningBalance" to walletCreditResult.newWinningBalance,
            "${FirebaseAdminConfig.NODE_USERS}/$userId/updatedAt" to now,

            // Global ledger record in /transactions/{deterministicTrxId}
            "${FirebaseAdminConfig.NODE_TRANSACTIONS}/$deterministicTrxId" to mapOf(
                "transactionId" to deterministicTrxId,
                "resultId" to resultId,
                "matchId" to matchId,
                "userId" to userId,
                "amount" to prizeTaka,
                "amountMinorUnits" to authoritativePrizeMinor,
                "type" to "PRIZE_WIN",
                "direction" to "CREDIT",
                "status" to "COMPLETED",
                "timestamp" to now,
                "processedBy" to adminSession.identifier,
                "description" to "Prize winning payout of ৳$prizeTaka credited for match $canonicalMatchNumber"
            ),

            // User ledger mirror in /userTransactions/{userId}/{deterministicTrxId}
            "${FirebaseAdminConfig.NODE_USER_TRANSACTIONS}/$userId/$deterministicTrxId" to mapOf(
                "transactionId" to deterministicTrxId,
                "resultId" to resultId,
                "matchId" to matchId,
                "amount" to prizeTaka,
                "amountMinorUnits" to authoritativePrizeMinor,
                "type" to "PRIZE_WIN",
                "direction" to "CREDIT",
                "status" to "COMPLETED",
                "timestamp" to now,
                "description" to "Won match $canonicalMatchNumber — Prize credited: ৳$prizeTaka"
            ),

            // Immutable audit log entry in /auditLogs/{deterministicLogId}
            "${FirebaseAdminConfig.NODE_AUDIT_LOGS}/$deterministicLogId" to mapOf(
                "action" to "MATCH_RESULT_APPROVED",
                "admin" to adminSession.identifier,
                "referenceId" to resultId,
                "matchId" to matchId,
                "timestamp" to now,
                "reason" to "Super Admin approved result for match $canonicalMatchNumber. Credited prize of ৳$prizeTaka to winner $userId",
                "amount" to prizeTaka,
                "amountMinorUnits" to authoritativePrizeMinor,
                "userId" to userId,
                "transactionId" to deterministicTrxId
            )
        )

        db.reference.updateChildren(updates).await()
    }

    override suspend fun rejectResult(
        resultId: String,
        reason: String,
        adminSession: SuperAdminSession
    ): Result<Unit> = runCatching {
        verifySuperAdmin(adminSession)
        val trimmedReason = reason.trim()
        require(trimmedReason.isNotBlank()) { "Rejection reason is required." }

        val db = database ?: throw IllegalStateException("Firebase RTDB instance is unavailable.")
        val resultItem = getResult(resultId)
            ?: throw IllegalArgumentException("Result submission '$resultId' does not exist.")

        if (resultItem.status == ResultStatus.APPROVED) {
            throw IllegalStateException("Result '$resultId' is already approved and settled.")
        }
        if (resultItem.status == ResultStatus.REJECTED) {
            throw IllegalStateException("Result '$resultId' is already rejected.")
        }

        val now = System.currentTimeMillis()
        val userId = resultItem.userId
        val deterministicLogId = "AUDIT_REJ_RES_$resultId"
        val userResultsNodeKey = "userResults"

        val updates = mutableMapOf<String, Any?>(
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/status" to ResultStatus.REJECTED.name,
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/rejectionReason" to trimmedReason,
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/processedAt" to now,
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/processedBy" to adminSession.identifier,
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/updatedAt" to now,

            "${FirebaseAdminConfig.NODE_AUDIT_LOGS}/$deterministicLogId" to mapOf(
                "action" to "MATCH_RESULT_REJECTED",
                "admin" to adminSession.identifier,
                "referenceId" to resultId,
                "timestamp" to now,
                "reason" to "Super Admin rejected result submission: $trimmedReason"
            )
        )

        if (userId.isNotBlank()) {
            updates["$userResultsNodeKey/$userId/$resultId/status"] = ResultStatus.REJECTED.name
            updates["$userResultsNodeKey/$userId/$resultId/rejectionReason"] = trimmedReason
        }

        db.reference.updateChildren(updates).await()
    }

    private suspend fun executeResultApprovalLockTransaction(
        resultRef: DatabaseReference,
        adminSession: SuperAdminSession,
        settlementTrxId: String,
        authoritativePrizeMinor: Long,
        now: Long
    ): ResultApprovalResult = suspendCancellableCoroutine { continuation ->
        resultRef.runTransaction(object : Transaction.Handler {
            var failureMessage: String? = null
            var wasAlreadySettled = false

            override fun doTransaction(currentData: MutableData): Transaction.Result {
                if (currentData.value == null) {
                    failureMessage = "Result submission record does not exist on database."
                    return Transaction.abort()
                }

                val currentStatusStr = currentData.child("status").value?.toString()
                val currentStatus = ResultStatus.fromString(currentStatusStr)

                if (currentStatus == ResultStatus.APPROVED) {
                    wasAlreadySettled = true
                    failureMessage = "Result is already APPROVED and settled."
                    return Transaction.abort()
                }

                if (currentStatus == ResultStatus.REJECTED) {
                    wasAlreadySettled = true
                    failureMessage = "Result is ALREADY REJECTED."
                    return Transaction.abort()
                }

                currentData.child("status").value = ResultStatus.APPROVED.name
                currentData.child("processedAt").value = now
                currentData.child("processedBy").value = adminSession.identifier
                currentData.child("updatedAt").value = now
                currentData.child("settlementTransactionId").value = settlementTrxId
                currentData.child("settledPrizeMinorUnits").value = authoritativePrizeMinor

                return Transaction.success(currentData)
            }

            override fun onComplete(
                error: DatabaseError?,
                committed: Boolean,
                currentData: DataSnapshot?
            ) {
                if (committed && error == null) {
                    continuation.resume(ResultApprovalResult(success = true))
                } else {
                    continuation.resume(
                        ResultApprovalResult(
                            success = false,
                            alreadySettled = wasAlreadySettled,
                            errorMessage = error?.message ?: failureMessage ?: "Result approval lock transaction aborted."
                        )
                    )
                }
            }
        })
    }

    private suspend fun executeWalletPrizeCreditTransaction(
        walletRef: DatabaseReference,
        resultId: String,
        prizeMinorUnits: Long,
        now: Long
    ): WalletPrizeCreditResult = suspendCancellableCoroutine { continuation ->
        walletRef.runTransaction(object : Transaction.Handler {
            var failureMessage: String? = null
            var creditResult: WalletPrizeCreditResult? = null

            override fun doTransaction(currentData: MutableData): Transaction.Result {
                // Idempotency check: verify if this resultId was already credited to the wallet
                val creditedResultsNode = currentData.child("creditedResults")
                if (creditedResultsNode.hasChild(resultId)) {
                    creditResult = WalletPrizeCreditResult(
                        success = true,
                        alreadySettled = true,
                        newBalance = (currentData.child("balance").value as? Number)?.toLong() ?: 0L,
                        newWinningBalance = (currentData.child("winningBalance").value as? Number)?.toLong() ?: 0L
                    )
                    return Transaction.abort()
                }

                val currentBalance = (currentData.child("balance").value as? Number)?.toLong() ?: 0L
                val currentAvailable = (currentData.child("availableBalance").value as? Number)?.toLong() ?: currentBalance
                val currentWinning = (currentData.child("winningBalance").value as? Number)?.toLong() ?: 0L
                val currentPending = (currentData.child("pendingBalance").value as? Number)?.toLong() ?: 0L

                val newAvailable = currentAvailable + prizeMinorUnits
                val newWinning = currentWinning + prizeMinorUnits
                val newBalance = newAvailable + currentPending

                currentData.child("balance").value = newBalance
                currentData.child("availableBalance").value = newAvailable
                currentData.child("winningBalance").value = newWinning
                currentData.child("balanceDouble").value = newBalance / 100.0
                currentData.child("updatedAt").value = now

                // Mark resultId as settled inside wallet
                currentData.child("creditedResults").child(resultId).value = mapOf(
                    "resultId" to resultId,
                    "prizeMinorUnits" to prizeMinorUnits,
                    "creditedAt" to now
                )

                creditResult = WalletPrizeCreditResult(
                    success = true,
                    alreadySettled = false,
                    newBalance = newBalance,
                    newWinningBalance = newWinning
                )

                return Transaction.success(currentData)
            }

            override fun onComplete(
                error: DatabaseError?,
                committed: Boolean,
                currentData: DataSnapshot?
            ) {
                if (committed && error == null) {
                    continuation.resume(creditResult ?: WalletPrizeCreditResult(success = true))
                } else {
                    continuation.resume(
                        creditResult ?: WalletPrizeCreditResult(
                            success = false,
                            errorMessage = error?.message ?: failureMessage ?: "Wallet prize credit transaction failed."
                        )
                    )
                }
            }
        })
    }
}

data class WalletPrizeCreditResult(
    val success: Boolean,
    val alreadySettled: Boolean = false,
    val newBalance: Long = 0L,
    val newWinningBalance: Long = 0L,
    val errorMessage: String? = null
)
