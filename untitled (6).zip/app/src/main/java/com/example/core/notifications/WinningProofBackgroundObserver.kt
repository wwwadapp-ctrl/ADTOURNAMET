package com.example.core.notifications

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import com.example.core.repository.FirebaseResultsRepository
import com.example.core.repository.ResultsRepository
import kotlinx.coroutines.flow.collectLatest

@Composable
fun WinningProofBackgroundObserver(
    repository: ResultsRepository = FirebaseResultsRepository()
) {
    val context = LocalContext.current

    LaunchedEffect(Unit) {
        repository.observeResults().collectLatest { results ->
            val pendingProofs = results.filter { it.isPending }
            for (proof in pendingProofs) {
                WinningProofNotificationHelper.showWinningProofNotification(context, proof)
            }
        }
    }
}
