package com.example.ui.profile

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ClipboardManager
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.UserEntity
import com.example.ui.components.TournamentButton
import com.example.ui.components.TournamentButtonVariant
import com.example.ui.components.TournamentCard
import com.example.ui.components.TournamentTextField
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
  viewModel: ProfileViewModel,
  user: UserEntity?,
  onNavigateBack: () -> Unit,
  onSignedOut: () -> Unit,
  modifier: Modifier = Modifier,
  onHistoryClick: () -> Unit = {},
) {
  val userState by viewModel.currentUser.collectAsState(initial = user)
  val currentUser = user ?: userState
  val clipboardManager: ClipboardManager = LocalClipboardManager.current
  var showEditNameDialog by remember { mutableStateOf(false) }
  var bannerMessage by remember { mutableStateOf<String?>(null) }

  val joinDateFormatted = remember(currentUser?.joinDate, currentUser?.createdAt) {
    val date = if ((currentUser?.joinDate ?: 0L) > 0L) currentUser?.joinDate else currentUser?.createdAt
    if (date != null && date > 0L) {
      SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(Date(date))
    } else {
      "Recently Joined"
    }
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Text(
            text = "Player Profile",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = Color.White,
          )
        },
        navigationIcon = {
          IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("profile_back_button")) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = NavySurface),
      )
    },
    containerColor = DeepNavyBg,
    modifier = modifier.fillMaxSize(),
  ) { innerPadding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .padding(horizontal = 16.dp),
      contentPadding = PaddingValues(bottom = 28.dp, top = 8.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      // Feedback banner
      item {
        AnimatedVisibility(visible = bannerMessage != null) {
          Surface(
            color = Cyan500.copy(alpha = 0.15f),
            border = BorderStroke(1.dp, Cyan400),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Row(
              modifier = Modifier.padding(10.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Cyan400, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = bannerMessage ?: "",
                color = Color.White,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.weight(1f),
              )
              IconButton(onClick = { bannerMessage = null }, modifier = Modifier.size(24.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = Slate400, modifier = Modifier.size(16.dp))
              }
            }
          }
        }
      }

      // 1. PROFILE HEADER CARD
      item {
        TournamentCard(
          modifier = Modifier.fillMaxWidth(),
          backgroundColor = NavyCard,
          borderColor = NavyCardBorder,
        ) {
          Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
          ) {
            // Avatar
            Box(
              modifier = Modifier
                .size(80.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Indigo600, Purple600))),
              contentAlignment = Alignment.Center,
            ) {
              Icon(
                imageVector = Icons.Default.Person,
                contentDescription = "Avatar",
                tint = Gold400,
                modifier = Modifier.size(46.dp),
              )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Name + Edit icon
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.clickable { showEditNameDialog = true },
            ) {
              Text(
                text = currentUser?.effectiveName ?: "Player",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                color = Color.White,
              )
              Spacer(modifier = Modifier.width(6.dp))
              Icon(
                imageVector = Icons.Default.Edit,
                contentDescription = "Edit Name",
                tint = Gold400,
                modifier = Modifier.size(18.dp),
              )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // User ID (Tappable copy)
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier
                .clickable {
                  val id = currentUser?.userId ?: currentUser?.uid ?: "AD-USER"
                  clipboardManager.setText(AnnotatedString(id))
                  bannerMessage = "User ID $id copied to clipboard"
                }
                .testTag("copy_user_id_button"),
            ) {
              Text(
                text = "ID: ${currentUser?.userId ?: currentUser?.uid ?: "AD-USER"}",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                color = Cyan400,
              )
              Spacer(modifier = Modifier.width(4.dp))
              Icon(Icons.Default.ContentCopy, contentDescription = "Copy ID", tint = Cyan400, modifier = Modifier.size(14.dp))
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Mobile number (Non-editable badge)
            Surface(
              color = Slate900,
              shape = RoundedCornerShape(8.dp),
              border = BorderStroke(1.dp, CardBorder),
              modifier = Modifier.fillMaxWidth(),
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Default.Phone, contentDescription = null, tint = Slate400, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    text = currentUser?.effectiveMobile ?: "01XXXXXXXXX",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                    color = Color.White,
                  )
                }
                Surface(
                  color = Slate800,
                  shape = RoundedCornerShape(6.dp),
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                  ) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = Slate400, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                      text = "LOCKED",
                      style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                      color = Slate400,
                    )
                  }
                }
              }
            }

            Text(
              text = "Mobile number cannot be changed from the app for security & anti-fraud protection.",
              style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
              color = Slate500,
              modifier = Modifier.padding(top = 6.dp),
            )
          }
        }
      }

      // 2. CAREER STATISTICS GRID
      item {
        Column {
          Text(
            text = "CAREER STATISTICS",
            style = MaterialTheme.typography.titleSmall.copy(
              fontWeight = FontWeight.Bold,
              letterSpacing = 1.sp,
            ),
            color = Gold400,
          )
          Spacer(modifier = Modifier.height(10.dp))
          val totalMatches = currentUser?.totalMatches ?: 0
          val wins = currentUser?.wins ?: 0
          val losses = currentUser?.losses ?: 0
          val winRate = if (totalMatches > 0) ((wins.toDouble() / totalMatches) * 100).toInt() else 0
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            StatBox(title = "MATCHES", value = "$totalMatches", subtitle = "1v1 Battles", modifier = Modifier.weight(1f))
            StatBox(title = "WINS", value = "$wins", subtitle = "$winRate% Win Rate", color = Emerald500, modifier = Modifier.weight(1f))
            StatBox(title = "LOSSES", value = "$losses", subtitle = "Contests", color = Rose500, modifier = Modifier.weight(1f))
          }
          Spacer(modifier = Modifier.height(10.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            StatBox(
              title = "TOTAL WINNINGS",
              value = "৳ ${"%.0f".format(currentUser?.totalWinnings ?: 0.0)}",
              subtitle = "All-Time Rewards",
              color = Gold400,
              modifier = Modifier.weight(1f),
            )
            StatBox(
              title = "MEMBER SINCE",
              value = joinDateFormatted,
              subtitle = "Verified Player",
              color = Cyan400,
              modifier = Modifier.weight(1f),
            )
          }
        }
      }

      // 3. MATCH HISTORY SHORTCUT
      item {
        TournamentCard(
          modifier = Modifier
            .fillMaxWidth()
            .clickable { onHistoryClick() }
            .testTag("profile_history_card"),
          backgroundColor = NavyCard,
          borderColor = CardBorder,
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(38.dp)
                  .clip(CircleShape)
                  .background(Gold400.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center,
              ) {
                Icon(
                  imageVector = Icons.Default.History,
                  contentDescription = null,
                  tint = Gold400,
                  modifier = Modifier.size(22.dp),
                )
              }
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Text(
                  text = "Match History",
                  style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                  color = Color.White,
                )
                Text(
                  text = "Past battles, game outcomes, and rewards",
                  style = MaterialTheme.typography.bodySmall,
                  color = Slate400,
                )
              }
            }
            Icon(
              imageVector = Icons.Default.ChevronRight,
              contentDescription = "View History",
              tint = Slate400,
              modifier = Modifier.size(20.dp),
            )
          }
        }
      }

      // 4. FAIR PLAY & INTEGRITY POLICY
      item {
        TournamentCard(
          modifier = Modifier.fillMaxWidth(),
          backgroundColor = NavyCard,
          borderColor = CardBorder,
        ) {
          Text(
            text = "FAIR PLAY & INTEGRITY",
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
            color = Gold400,
          )
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "• Account Status: ${currentUser?.status ?: "ACTIVE"}\n• Single Account Policy: One verified mobile number per player\n• Zero Tolerance: Cheating, fake screenshots, or match abandonment results in permanent account suspension and wallet forfeiture.",
            style = MaterialTheme.typography.bodySmall,
            color = Slate400,
            lineHeight = 18.sp,
          )
        }
      }

      // 4. LOGOUT BUTTON
      item {
        TournamentButton(
          text = "SIGN OUT",
          onClick = { viewModel.signOut(onSignedOut) },
          variant = TournamentButtonVariant.DANGER,
          leadingIcon = {
            Icon(Icons.Default.Logout, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
          },
          modifier = Modifier.fillMaxWidth(),
          testTag = "profile_logout_button",
        )
      }
    }
  }

  // EDIT NAME DIALOG
  if (showEditNameDialog) {
    var newName by remember { mutableStateOf(currentUser?.effectiveName ?: "") }
    AlertDialog(
      onDismissRequest = { showEditNameDialog = false },
      title = { Text("Update Display Name", color = Color.White) },
      text = {
        Column {
          TournamentTextField(
            value = newName,
            onValueChange = { newName = it },
            label = "Player Name",
            placeholder = "Enter new display name",
            leadingIcon = Icons.Default.Person,
            testTag = "edit_name_input",
            modifier = Modifier.fillMaxWidth(),
          )
        }
      },
      confirmButton = {
        TournamentButton(
          text = "SAVE NAME",
          onClick = {
            if (newName.isNotBlank()) {
              val uid = currentUser?.userId ?: currentUser?.uid ?: ""
              viewModel.updateName(uid, newName)
              showEditNameDialog = false
              bannerMessage = "Display name updated successfully"
            }
          },
          testTag = "confirm_edit_name_button",
        )
      },
      dismissButton = {
        TextButton(onClick = { showEditNameDialog = false }) {
          Text("Cancel", color = Slate400)
        }
      },
      containerColor = NavyCard,
    )
  }
}

@Composable
private fun StatBox(
  title: String,
  value: String,
  subtitle: String,
  color: Color = Color.White,
  modifier: Modifier = Modifier,
) {
  Surface(
    color = NavyCard,
    shape = RoundedCornerShape(12.dp),
    border = BorderStroke(1.dp, CardBorder),
    modifier = modifier,
  ) {
    Column(
      modifier = Modifier.padding(12.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Text(
        text = title,
        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
        color = Slate400,
      )
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = value,
        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
        color = color,
      )
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = subtitle,
        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
        color = Slate500,
      )
    }
  }
}
