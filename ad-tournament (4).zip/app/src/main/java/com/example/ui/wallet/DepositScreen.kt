package com.example.ui.wallet

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.TournamentButton
import com.example.ui.components.TournamentCard
import com.example.ui.components.TournamentTextField
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DepositScreen(
  viewModel: WalletViewModel,
  onNavigateBack: () -> Unit,
) {
  val uiState by viewModel.uiState.collectAsState()

  var selectedMethod by remember { mutableStateOf("BKASH") }
  var amountInput by remember { mutableStateOf("100") }
  var senderNumber by remember { mutableStateOf("") }
  var trxId by remember { mutableStateOf("") }
  var clientError by remember { mutableStateOf<String?>(null) }

  LaunchedEffect(uiState.depositSubmitted) {
    if (uiState.depositSubmitted) {
      // Completed
    }
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Text(
            text = "Add Money (Deposit)",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = Color.White,
          )
        },
        navigationIcon = {
          IconButton(onClick = onNavigateBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = NavySurface),
      )
    },
    containerColor = DeepNavyBg,
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
    ) {
      if (uiState.depositSubmitted) {
        TournamentCard(
          modifier = Modifier.fillMaxWidth(),
          backgroundColor = Slate900,
          borderColor = Emerald500,
        ) {
          Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = null,
            tint = Emerald400,
            modifier = Modifier.size(48.dp),
          )
          Spacer(modifier = Modifier.height(12.dp))
          Text(
            text = "Deposit Request Submitted",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = Color.White,
          )
          Text(
            text = uiState.successMessage ?: "Your deposit has been submitted for admin verification. It will be credited within 10-15 minutes.",
            style = MaterialTheme.typography.bodyMedium,
            color = Slate300,
            modifier = Modifier.padding(top = 4.dp, bottom = 16.dp),
          )
          TournamentButton(
            text = "BACK TO WALLET",
            onClick = {
              viewModel.clearMessages()
              onNavigateBack()
            },
            modifier = Modifier.fillMaxWidth(),
          )
        }
        return@Column
      }

      TournamentCard(
        modifier = Modifier.fillMaxWidth(),
        backgroundColor = NavyCard,
        borderColor = NavyCardBorder,
      ) {
        Text(
          text = "1. Select Payment Method",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          color = Color.White,
        )
        Spacer(modifier = Modifier.height(10.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          listOf("BKASH" to "bKash", "NAGAD" to "Nagad").forEach { (key, label) ->
            val isSelected = selectedMethod == key
            Surface(
              onClick = { selectedMethod = key },
              color = if (isSelected) Gold500.copy(alpha = 0.2f) else Slate900,
              shape = RoundedCornerShape(10.dp),
              border = BorderStroke(1.5.dp, if (isSelected) Gold500 else Slate700),
              modifier = Modifier.weight(1f),
            ) {
              Box(
                modifier = Modifier.padding(vertical = 12.dp),
                contentAlignment = Alignment.Center,
              ) {
                Text(
                  text = label,
                  style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                  color = if (isSelected) Gold400 else Slate300,
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Surface(
          color = Slate850,
          shape = RoundedCornerShape(10.dp),
          border = BorderStroke(1.dp, CardBorder),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Text(
              text = "Send Money (Personal Number):",
              style = MaterialTheme.typography.labelSmall,
              color = Slate400,
            )
            Text(
              text = "01700-000000",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
              color = Gold400,
            )
            Text(
              text = "Send money to this official number, then enter the sender number and TrxID below.",
              style = MaterialTheme.typography.bodySmall,
              color = Slate400,
              modifier = Modifier.padding(top = 4.dp),
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      TournamentCard(
        modifier = Modifier.fillMaxWidth(),
        backgroundColor = NavyCard,
        borderColor = NavyCardBorder,
      ) {
        Text(
          text = "2. Deposit Details",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          color = Color.White,
        )
        Spacer(modifier = Modifier.height(14.dp))

        val displayError = clientError ?: uiState.errorMessage
        if (displayError != null) {
          Surface(
            color = Rose900.copy(alpha = 0.4f),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
              .fillMaxWidth()
              .padding(bottom = 12.dp),
          ) {
            Text(
              text = displayError,
              color = Rose400,
              style = MaterialTheme.typography.bodySmall,
              modifier = Modifier.padding(10.dp),
            )
          }
        }

        TournamentTextField(
          value = amountInput,
          onValueChange = {
            amountInput = it.filter { char -> char.isDigit() }
            clientError = null
          },
          label = "Deposit Amount (BDT)",
          placeholder = "e.g. 100",
          helperText = "Min: ৳ 50 | Max: ৳ 25,000",
          leadingIcon = Icons.Default.Paid,
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          testTag = "deposit_amount_input",
        )

        Spacer(modifier = Modifier.height(12.dp))

        TournamentTextField(
          value = senderNumber,
          onValueChange = {
            if (it.length <= 11) {
              senderNumber = it
              clientError = null
            }
          },
          label = "Sender Mobile Number",
          placeholder = "01XXXXXXXXX",
          leadingIcon = Icons.Default.Phone,
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
          testTag = "deposit_sender_input",
        )

        Spacer(modifier = Modifier.height(12.dp))

        TournamentTextField(
          value = trxId,
          onValueChange = {
            trxId = it.uppercase()
            clientError = null
          },
          label = "Transaction ID (TrxID)",
          placeholder = "e.g. 9J8K7L6M",
          leadingIcon = Icons.Default.Receipt,
          testTag = "deposit_trx_input",
        )

        Spacer(modifier = Modifier.height(20.dp))

        TournamentButton(
          text = "SUBMIT DEPOSIT",
          onClick = {
            val amountNum = amountInput.toLongOrNull() ?: 0L
            if (amountNum < 50L) {
              clientError = "Minimum deposit amount is ৳ 50"
              return@TournamentButton
            }
            if (amountNum > 25000L) {
              clientError = "Maximum deposit amount is ৳ 25,000"
              return@TournamentButton
            }
            if (senderNumber.length < 11) {
              clientError = "Please enter a valid 11-digit sender mobile number"
              return@TournamentButton
            }
            if (trxId.length < 6) {
              clientError = "Please enter a valid Transaction ID"
              return@TournamentButton
            }
            viewModel.submitDeposit(
              amountMinorUnits = amountNum * 100L,
              method = selectedMethod,
              senderNumber = senderNumber,
              trxId = trxId,
            )
          },
          isLoading = uiState.isSubmitting,
          modifier = Modifier.fillMaxWidth(),
          testTag = "submit_deposit_button",
        )
      }
    }
  }
}
