package com.example.ui.navigation

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.navArgument
import com.example.core.di.AppContainer
import com.example.ui.admin.AdminScreen
import com.example.ui.admin.AdminViewModel
import com.example.ui.auth.*
import com.example.ui.history.HistoryScreen
import com.example.ui.home.HomeScreen
import com.example.ui.home.HomeViewModel
import com.example.ui.match.MatchDetailScreen
import com.example.ui.match.MatchDetailViewModel
import com.example.ui.matches.MatchesScreen
import com.example.ui.notifications.NotificationsScreen
import com.example.ui.profile.ProfileScreen
import com.example.ui.profile.ProfileViewModel
import com.example.ui.rules.RulesScreen
import com.example.ui.splash.SplashScreen
import com.example.ui.support.SupportScreen
import com.example.ui.theme.*
import com.example.ui.wallet.*

object Destinations {
  const val SPLASH = "splash"
  const val LOGIN = "login"
  const val REGISTER = "register"
  const val FORGOT_PASSWORD = "forgot_password"
  const val OTP = "otp/{phone}"
  const val RESET_PASSWORD = "reset_password/{phone}/{otp}"

  const val HOME = "home"
  const val WALLET = "wallet"
  const val MATCHES = "matches"
  const val NOTIFICATIONS = "notifications"
  const val PROFILE = "profile"

  const val DEPOSIT = "deposit"
  const val WITHDRAW = "withdraw"
  const val TRANSACTIONS = "transactions"
  const val MATCH_DETAIL = "match_detail/{matchId}"
  const val HISTORY = "history"
  const val SUPPORT = "support"
  const val RULES = "rules"
  const val ADMIN = "admin"

  fun otp(phone: String) = "otp/$phone"
  fun resetPassword(phone: String, otp: String) = "reset_password/$phone/$otp"
  fun matchDetail(matchId: String) = "match_detail/$matchId"
}

data class BottomNavigationItem(
  val route: String,
  val label: String,
  val icon: ImageVector,
)

val PrimaryBottomNavItems = listOf(
  BottomNavigationItem(Destinations.HOME, "Home", Icons.Default.Home),
  BottomNavigationItem(Destinations.WALLET, "Wallet", Icons.Default.AccountBalanceWallet),
  BottomNavigationItem(Destinations.MATCHES, "Matches", Icons.Default.SportsEsports),
  BottomNavigationItem(Destinations.NOTIFICATIONS, "Alerts", Icons.Default.Notifications),
  BottomNavigationItem(Destinations.PROFILE, "Profile", Icons.Default.Person),
)

@Composable
fun AppNavigation(
  navController: NavHostController,
  container: AppContainer,
) {
  val startDestination = Destinations.SPLASH

  val authViewModel: AuthViewModel = viewModel(
    factory = AuthViewModel.Factory(container.authRepository)
  )

  val currentUser by authViewModel.currentUser.collectAsState()
  val activeUserId = currentUser?.userId ?: currentUser?.uid ?: "AD-USER-9481"

  val navBackStackEntry by navController.currentBackStackEntryAsState()
  val currentRoute = navBackStackEntry?.destination?.route

  val primaryRoutes = remember {
    setOf(
      Destinations.HOME,
      Destinations.WALLET,
      Destinations.MATCHES,
      Destinations.NOTIFICATIONS,
      Destinations.PROFILE,
    )
  }
  val isBottomNavVisible = currentRoute in primaryRoutes

  Scaffold(
    containerColor = DeepNavyBg,
    bottomBar = {
      if (isBottomNavVisible) {
        Surface(
          color = NavySurface,
          border = BorderStroke(1.dp, NavyCardBorder),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("main_bottom_navigation"),
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .navigationBarsPadding()
              .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            PrimaryBottomNavItems.forEach { item ->
              val isSelected = currentRoute == item.route
              Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier
                  .weight(1f)
                  .clickable {
                    if (currentRoute != item.route) {
                      navController.navigate(item.route) {
                        popUpTo(Destinations.HOME) {
                          saveState = true
                        }
                        launchSingleTop = true
                        restoreState = true
                      }
                    }
                  }
                  .padding(vertical = 4.dp)
                  .testTag("nav_item_${item.route}"),
              ) {
                Icon(
                  imageVector = item.icon,
                  contentDescription = item.label,
                  tint = if (isSelected) Gold400 else Slate400,
                  modifier = Modifier.size(24.dp),
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = item.label,
                  style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                    fontSize = 11.sp,
                  ),
                  color = if (isSelected) Gold400 else Slate400,
                )
              }
            }
          }
        }
      }
    },
  ) { innerPadding ->
    NavHost(
      navController = navController,
      startDestination = startDestination,
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding),
    ) {
      // 0. BRANDED SPLASH SCREEN
      composable(Destinations.SPLASH) {
        SplashScreen(
          onSplashFinished = {
            val targetDestination = if (container.authRepository.isUserSignedIn()) {
              Destinations.HOME
            } else {
              Destinations.LOGIN
            }
            navController.navigate(targetDestination) {
              popUpTo(Destinations.SPLASH) { inclusive = true }
            }
          },
        )
      }

      // 1. AUTHENTICATION: LOGIN
      composable(Destinations.LOGIN) {
        LoginScreen(
          viewModel = authViewModel,
          onLoginSuccess = {
            navController.navigate(Destinations.HOME) {
              popUpTo(Destinations.LOGIN) { inclusive = true }
            }
          },
          onNavigateToRegister = { navController.navigate(Destinations.REGISTER) },
          onNavigateToForgotPassword = { navController.navigate(Destinations.FORGOT_PASSWORD) },
        )
      }

      // 2. AUTHENTICATION: REGISTER
      composable(Destinations.REGISTER) {
        RegisterScreen(
          viewModel = authViewModel,
          onRegisterSuccess = {
            navController.navigate(Destinations.HOME) {
              popUpTo(Destinations.REGISTER) { inclusive = true }
            }
          },
          onNavigateToLogin = { navController.popBackStack() },
        )
      }

      // 3. AUTHENTICATION: FORGOT PASSWORD
      composable(Destinations.FORGOT_PASSWORD) {
        ForgotPasswordScreen(
          viewModel = authViewModel,
          onNavigateToOtp = { phone -> navController.navigate(Destinations.otp(phone)) },
          onNavigateBack = { navController.popBackStack() },
        )
      }

      // 4. AUTHENTICATION: OTP VERIFICATION
      composable(
        route = Destinations.OTP,
        arguments = listOf(navArgument("phone") { type = NavType.StringType }),
      ) { backStackEntry ->
        val phone = backStackEntry.arguments?.getString("phone") ?: ""
        OtpScreen(
          phoneNumber = phone,
          viewModel = authViewModel,
          onOtpVerified = { verifiedPhone, otp ->
            navController.navigate(Destinations.resetPassword(verifiedPhone, otp))
          },
          onNavigateBack = { navController.popBackStack() },
        )
      }

      // 5. AUTHENTICATION: RESET PASSWORD
      composable(
        route = Destinations.RESET_PASSWORD,
        arguments = listOf(
          navArgument("phone") { type = NavType.StringType },
          navArgument("otp") { type = NavType.StringType },
        ),
      ) { backStackEntry ->
        val phone = backStackEntry.arguments?.getString("phone") ?: ""
        val otp = backStackEntry.arguments?.getString("otp") ?: ""
        ResetPasswordScreen(
          phoneNumber = phone,
          otp = otp,
          viewModel = authViewModel,
          onResetSuccess = {
            navController.navigate(Destinations.LOGIN) {
              popUpTo(Destinations.LOGIN) { inclusive = true }
            }
          },
          onNavigateBack = { navController.popBackStack() },
        )
      }

      // 6. MAIN HUB: HOME SCREEN
      composable(Destinations.HOME) {
        val homeViewModel: HomeViewModel = viewModel(
          factory = HomeViewModel.Factory(container.matchRepository, activeUserId)
        )
        val walletViewModel: WalletViewModel = viewModel(
          factory = WalletViewModel.Factory(container.walletRepository, activeUserId)
        )
        val walletUiState by walletViewModel.uiState.collectAsState()

        HomeScreen(
          viewModel = homeViewModel,
          currentUser = currentUser,
          wallet = walletUiState.wallet,
          onMatchClick = { matchId -> navController.navigate(Destinations.matchDetail(matchId)) },
          onWalletClick = {
            navController.navigate(Destinations.WALLET) {
              popUpTo(Destinations.HOME) { saveState = true }
              launchSingleTop = true
              restoreState = true
            }
          },
          onDepositClick = { navController.navigate(Destinations.DEPOSIT) },
          onNotificationClick = { navController.navigate(Destinations.NOTIFICATIONS) },
          onProfileClick = {
            navController.navigate(Destinations.PROFILE) {
              popUpTo(Destinations.HOME) { saveState = true }
              launchSingleTop = true
              restoreState = true
            }
          },
          onRulesClick = { navController.navigate(Destinations.RULES) },
          onSupportClick = { navController.navigate(Destinations.SUPPORT) },
          onAdminClick = { navController.navigate(Destinations.ADMIN) },
          onHistoryClick = { navController.navigate(Destinations.HISTORY) },
        )
      }

      // 7. PRIMARY TAB: WALLET SCREEN
      composable(Destinations.WALLET) {
        val walletViewModel: WalletViewModel = viewModel(
          factory = WalletViewModel.Factory(container.walletRepository, activeUserId)
        )
        WalletScreen(
          viewModel = walletViewModel,
          onNavigateBack = { navController.popBackStack() },
          onNavigateToDeposit = { navController.navigate(Destinations.DEPOSIT) },
          onNavigateToWithdraw = { navController.navigate(Destinations.WITHDRAW) },
          onNavigateToTransactions = { navController.navigate(Destinations.TRANSACTIONS) },
        )
      }

      // 8. PRIMARY TAB: MATCHES SCREEN
      composable(Destinations.MATCHES) {
        MatchesScreen(
          userId = activeUserId,
          onNavigateToMatchDetails = { matchId -> navController.navigate(Destinations.matchDetail(matchId)) },
          onHistoryClick = { navController.navigate(Destinations.HISTORY) },
          matchRepository = container.matchRepository,
        )
      }

      // 9. PRIMARY TAB: NOTIFICATIONS SCREEN
      composable(Destinations.NOTIFICATIONS) {
        NotificationsScreen(
          userId = activeUserId,
          onNavigateBack = { navController.popBackStack() },
          notificationRepository = container.notificationRepository,
        )
      }

      // 10. PRIMARY TAB: PROFILE SCREEN
      composable(Destinations.PROFILE) {
        val profileViewModel: ProfileViewModel = viewModel(
          factory = ProfileViewModel.Factory(container.authRepository)
        )
        ProfileScreen(
          viewModel = profileViewModel,
          user = currentUser,
          onNavigateBack = { navController.popBackStack() },
          onHistoryClick = { navController.navigate(Destinations.HISTORY) },
          onSignedOut = {
            navController.navigate(Destinations.LOGIN) {
              popUpTo(0) { inclusive = true }
            }
          },
        )
      }

      // 11. MATCH DETAIL SCREEN
      composable(
        route = Destinations.MATCH_DETAIL,
        arguments = listOf(navArgument("matchId") { type = NavType.StringType }),
      ) { backStackEntry ->
        val matchId = backStackEntry.arguments?.getString("matchId") ?: ""
        val isAdmin = currentUser?.role == "SUPER_ADMIN" || currentUser?.role == "ADMIN"
        val detailViewModel: MatchDetailViewModel = viewModel(
          factory = MatchDetailViewModel.Factory(
            matchRepository = container.matchRepository,
            resultRepository = container.resultRepository,
            matchId = matchId,
            currentUserId = activeUserId,
            isAdmin = isAdmin,
          )
        )
        MatchDetailScreen(
          viewModel = detailViewModel,
          onNavigateBack = { navController.popBackStack() },
          onViewRoomCode = { /* Handled in-screen */ },
          onSubmitProof = { /* Handled in-screen */ },
        )
      }

      // 12. WALLET: DEPOSIT SCREEN
      composable(Destinations.DEPOSIT) {
        val walletViewModel: WalletViewModel = viewModel(
          factory = WalletViewModel.Factory(container.walletRepository, activeUserId)
        )
        DepositScreen(
          viewModel = walletViewModel,
          onNavigateBack = { navController.popBackStack() },
        )
      }

      // 13. WALLET: WITHDRAW SCREEN
      composable(Destinations.WITHDRAW) {
        val walletViewModel: WalletViewModel = viewModel(
          factory = WalletViewModel.Factory(container.walletRepository, activeUserId)
        )
        WithdrawScreen(
          viewModel = walletViewModel,
          onNavigateBack = { navController.popBackStack() },
        )
      }

      // 14. WALLET: TRANSACTIONS SCREEN
      composable(Destinations.TRANSACTIONS) {
        val walletViewModel: WalletViewModel = viewModel(
          factory = WalletViewModel.Factory(container.walletRepository, activeUserId)
        )
        TransactionsScreen(
          viewModel = walletViewModel,
          onNavigateBack = { navController.popBackStack() },
        )
      }

      // 15. MATCH HISTORY SCREEN
      composable(Destinations.HISTORY) {
        HistoryScreen(
          userId = activeUserId,
          matchRepository = container.matchRepository,
          onNavigateBack = { navController.popBackStack() },
          onMatchClick = { matchId -> navController.navigate(Destinations.matchDetail(matchId)) },
        )
      }

      // 16. SUPPORT SCREEN
      composable(Destinations.SUPPORT) {
        SupportScreen(
          onNavigateBack = { navController.popBackStack() },
        )
      }

      // 17. RULES SCREEN
      composable(Destinations.RULES) {
        RulesScreen(
          onNavigateBack = { navController.popBackStack() },
        )
      }

      // 18. SUPER ADMIN DASHBOARD
      composable(Destinations.ADMIN) {
        val adminViewModel: AdminViewModel = viewModel(
          factory = AdminViewModel.Factory(container.adminRepository, activeUserId)
        )
        AdminScreen(
          viewModel = adminViewModel,
          onNavigateBack = { navController.popBackStack() },
        )
      }
    }
  }
}
