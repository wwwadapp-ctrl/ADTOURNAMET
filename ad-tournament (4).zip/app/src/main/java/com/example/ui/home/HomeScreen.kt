package com.example.ui.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.GameType
import com.example.domain.model.UserEntity
import com.example.domain.model.WalletEntity
import com.example.ui.components.*
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
  viewModel: HomeViewModel,
  currentUser: UserEntity?,
  wallet: WalletEntity?,
  onMatchClick: (String) -> Unit,
  onWalletClick: () -> Unit,
  onDepositClick: () -> Unit,
  onNotificationClick: () -> Unit,
  onProfileClick: () -> Unit,
  onRulesClick: () -> Unit,
  onSupportClick: () -> Unit,
  onAdminClick: () -> Unit,
  onHistoryClick: () -> Unit = {},
  modifier: Modifier = Modifier,
) {
  val uiState by viewModel.uiState.collectAsState()
  val isAdmin = currentUser?.role?.equals("ADMIN", ignoreCase = true) == true ||
      currentUser?.role?.equals("SUPER_ADMIN", ignoreCase = true) == true
  val availableBalance = wallet?.availableAmount ?: (currentUser?.walletBalance ?: 0.0)
  val winningBalance = wallet?.totalWinningsAmount ?: 0.0

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Indigo600, Purple600))),
              contentAlignment = Alignment.Center,
            ) {
              Icon(
                imageVector = Icons.Default.SportsEsports,
                contentDescription = "AD Tournament",
                tint = Gold400,
                modifier = Modifier.size(22.dp),
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "AD TOURNAMENT",
                style = MaterialTheme.typography.titleMedium.copy(
                  fontWeight = FontWeight.Black,
                  letterSpacing = 1.sp,
                ),
                color = Color.White,
              )
              Text(
                text = "1v1 Esports Battles",
                style = MaterialTheme.typography.labelSmall,
                color = Gold400,
              )
            }
          }
        },
        actions = {
          // Wallet quick pill
          Surface(
            color = Slate850,
            shape = RoundedCornerShape(20.dp),
            border = BorderStroke(1.dp, CardBorder),
            modifier = Modifier
              .clickable { onWalletClick() }
              .testTag("home_header_wallet_pill"),
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(
                imageVector = Icons.Default.AccountBalanceWallet,
                contentDescription = null,
                tint = Gold400,
                modifier = Modifier.size(16.dp),
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "৳ ${"%.0f".format(availableBalance)}",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = Color.White,
              )
            }
          }

          Spacer(modifier = Modifier.width(6.dp))

          // Notifications button
          IconButton(
            onClick = onNotificationClick,
            modifier = Modifier.testTag("home_notification_button"),
          ) {
            BadgedBox(
              badge = {
                Badge(containerColor = Rose600) {
                  Text("2", color = Color.White, fontSize = 10.sp)
                }
              }
            ) {
              Icon(
                imageVector = Icons.Default.Notifications,
                contentDescription = "Notifications",
                tint = Slate300,
                modifier = Modifier.size(24.dp),
              )
            }
          }

          // Admin button if admin
          if (isAdmin) {
            IconButton(
              onClick = onAdminClick,
              modifier = Modifier.testTag("home_admin_button"),
            ) {
              Icon(
                imageVector = Icons.Default.AdminPanelSettings,
                contentDescription = "Admin Panel",
                tint = Cyan400,
                modifier = Modifier.size(24.dp),
              )
            }
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = NavySurface,
        ),
      )
    },
    containerColor = DeepNavyBg,
    modifier = modifier.fillMaxSize(),
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding),
    ) {
      // 1. Quick Wallet Card with Playable Balance and + DEPOSIT button
      QuickWalletBanner(
        availableBalance = availableBalance,
        winningBalance = winningBalance,
        onDepositClick = onDepositClick,
      )

      // 2. Quick Utility Links (Rules & Support)
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Surface(
          color = Slate900,
          shape = RoundedCornerShape(10.dp),
          border = BorderStroke(1.dp, CardBorder),
          modifier = Modifier
            .weight(1f)
            .clickable { onRulesClick() }
            .testTag("home_quick_rules"),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
          ) {
            Icon(Icons.Default.Gavel, contentDescription = null, tint = Gold400, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Rules", style = MaterialTheme.typography.labelMedium, color = Color.White)
          }
        }

        Surface(
          color = Slate900,
          shape = RoundedCornerShape(10.dp),
          border = BorderStroke(1.dp, CardBorder),
          modifier = Modifier
            .weight(1f)
            .clickable { onHistoryClick() }
            .testTag("home_quick_history"),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
          ) {
            Icon(Icons.Default.History, contentDescription = null, tint = Amber400, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("History", style = MaterialTheme.typography.labelMedium, color = Color.White)
          }
        }

        Surface(
          color = Slate900,
          shape = RoundedCornerShape(10.dp),
          border = BorderStroke(1.dp, CardBorder),
          modifier = Modifier
            .weight(1f)
            .clickable { onSupportClick() }
            .testTag("home_quick_support"),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
          ) {
            Icon(Icons.Default.HeadsetMic, contentDescription = null, tint = Cyan400, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Support", style = MaterialTheme.typography.labelMedium, color = Color.White)
          }
        }
      }

      // 3. Game Filter Chips (All, Ludo, Carrom)
      GameFilterSelector(
        selectedFilter = uiState.selectedGameFilter,
        onFilterSelect = { viewModel.setGameFilter(it) },
      )

      // 4. Section Tabs (Available, My Joined, Upcoming, History)
      MatchSectionTabs(
        selectedTab = uiState.selectedTab,
        onTabSelect = { viewModel.setTab(it) },
      )

      // 5. Match List Feed
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(horizontal = 16.dp),
      ) {
        when {
          uiState.isLoading -> {
            LoadingState(message = "Loading ${uiState.selectedTab.label.lowercase()} matches...")
          }
          uiState.errorMessage != null -> {
            ErrorState(
              message = uiState.errorMessage ?: "Failed to load matches",
              onRetry = { viewModel.refresh() },
            )
          }
          uiState.filteredMatches.isEmpty() -> {
            val (emptyTitle, emptyDesc) = when (uiState.selectedTab) {
              MatchFilterTab.AVAILABLE -> Pair(
                "No Available Matches",
                "All current contests are either in progress or filled. New 1v1 matches are posted frequently by Super Admin."
              )
              MatchFilterTab.MY_JOINED -> Pair(
                "No Joined Matches",
                "You haven't joined any active tournaments yet. Browse the Available tab to enter a 1v1 match!"
              )
              MatchFilterTab.UPCOMING -> Pair(
                "No Upcoming Tournaments",
                "Upcoming scheduled matches will appear here. Check back soon for new tournaments."
              )
              MatchFilterTab.HISTORY -> Pair(
                "No Match History",
                "Your completed matches and tournament results will appear here."
              )
            }
            EmptyState(
              title = emptyTitle,
              description = emptyDesc,
              actionButtonText = if (uiState.selectedTab != MatchFilterTab.AVAILABLE) "Browse Available Matches" else null,
              onActionClick = if (uiState.selectedTab != MatchFilterTab.AVAILABLE) {
                { viewModel.setTab(MatchFilterTab.AVAILABLE) }
              } else null,
            )
          }
          else -> {
            LazyColumn(
              modifier = Modifier.fillMaxSize(),
              verticalArrangement = Arrangement.spacedBy(12.dp),
              contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp),
            ) {
              items(uiState.filteredMatches, key = { it.matchId }) { match ->
                MatchCard(
                  match = match,
                  isJoined = uiState.joinedMatchIds.contains(match.matchId) || match.isCodeVisible,
                  onCardClick = { onMatchClick(match.matchId) },
                  onJoinClick = { onMatchClick(match.matchId) },
                  onViewCodeClick = { onMatchClick(match.matchId) },
                  onSubmitProofClick = { onMatchClick(match.matchId) },
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun QuickWalletBanner(
  availableBalance: Double,
  winningBalance: Double,
  onDepositClick: () -> Unit,
) {
  Box(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 6.dp)
      .clip(RoundedCornerShape(16.dp))
      .background(
        Brush.horizontalGradient(
          listOf(Color(0xFF1E1B4B), Color(0xFF0F172A))
        )
      )
      .testTag("home_wallet_quick_card"),
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Column {
        Text(
          text = "PLAYABLE BALANCE",
          style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.sp),
          color = Slate400,
        )
        Row(
          verticalAlignment = Alignment.Bottom,
          modifier = Modifier.padding(top = 4.dp),
        ) {
          Text(
            text = "৳ ${"%.2f".format(availableBalance)}",
            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black),
            color = Gold400,
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = "Winnings: ৳ ${"%.0f".format(winningBalance)}",
            style = MaterialTheme.typography.bodySmall,
            color = Emerald500,
          )
        }
      }
      TournamentButton(
        text = "+ DEPOSIT",
        onClick = onDepositClick,
        modifier = Modifier.height(38.dp),
        testTag = "home_deposit_quick_button",
      )
    }
  }
}

@Composable
private fun GameFilterSelector(
  selectedFilter: GameType?,
  onFilterSelect: (GameType?) -> Unit,
) {
  LazyRow(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 6.dp),
    horizontalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    val filters = listOf(
      null to "All Contests",
      GameType.LUDO to "Ludo 1v1",
      GameType.CARROM to "Carrom 1v1",
    )
    items(filters) { (type, label) ->
      val isSelected = selectedFilter == type
      Surface(
        shape = RoundedCornerShape(20.dp),
        color = if (isSelected) Gold500 else Slate900,
        border = BorderStroke(1.dp, if (isSelected) Gold400 else Slate800),
        modifier = Modifier
          .clickable { onFilterSelect(type) }
          .testTag("filter_chip_${type?.name ?: "ALL"}"),
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          if (type == GameType.LUDO) {
            Icon(
              imageVector = Icons.Default.Casino,
              contentDescription = null,
              tint = if (isSelected) Slate950 else Gold400,
              modifier = Modifier.size(16.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
          } else if (type == GameType.CARROM) {
            Icon(
              imageVector = Icons.Default.Album,
              contentDescription = null,
              tint = if (isSelected) Slate950 else Cyan400,
              modifier = Modifier.size(16.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
          }
          Text(
            text = label,
            style = MaterialTheme.typography.labelMedium.copy(
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
            ),
            color = if (isSelected) Slate950 else Color.White,
          )
        }
      }
    }
  }
}

@Composable
private fun MatchSectionTabs(
  selectedTab: MatchFilterTab,
  onTabSelect: (MatchFilterTab) -> Unit,
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 6.dp),
    horizontalArrangement = Arrangement.spacedBy(6.dp),
  ) {
    MatchFilterTab.values().forEach { tab ->
      val isSelected = selectedTab == tab
      Surface(
        shape = RoundedCornerShape(10.dp),
        color = if (isSelected) NavySurface else Color.Transparent,
        border = BorderStroke(1.dp, if (isSelected) Indigo600 else Color.Transparent),
        modifier = Modifier
          .weight(1f)
          .clickable { onTabSelect(tab) }
          .testTag("tab_${tab.name.lowercase()}"),
      ) {
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier.padding(vertical = 9.dp),
        ) {
          Text(
            text = tab.label,
            style = MaterialTheme.typography.labelMedium.copy(
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
            ),
            color = if (isSelected) Cyan400 else Slate400,
          )
        }
      }
    }
  }
}
