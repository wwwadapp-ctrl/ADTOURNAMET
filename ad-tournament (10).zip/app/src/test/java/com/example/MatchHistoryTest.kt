package com.example

import com.example.data.repository.LocalDataStore
import com.example.domain.model.GameType
import com.example.domain.model.MatchEntity
import com.example.domain.model.MatchPlayerEntity
import com.example.domain.model.MatchStatus
import com.example.ui.history.completedAt
import com.example.ui.history.player1UserId
import com.example.ui.history.player2UserId
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.concurrent.CopyOnWriteArrayList

class MatchHistoryTest {

  private val currentUserId = "user_123"
  private val opponentUserId = "user_456"
  private val thirdUserId = "user_789"

  @Test
  fun userParticipationFiltering_includesOnlyMatchesWithCurrentUser() {
    LocalDataStore.localMatchPlayers["m1"] = CopyOnWriteArrayList(
      listOf(
        MatchPlayerEntity(matchId = "m1", userId = currentUserId),
        MatchPlayerEntity(matchId = "m1", userId = opponentUserId),
      )
    )
    LocalDataStore.localMatchPlayers["m2"] = CopyOnWriteArrayList(
      listOf(
        MatchPlayerEntity(matchId = "m2", userId = opponentUserId),
        MatchPlayerEntity(matchId = "m2", userId = currentUserId),
      )
    )
    LocalDataStore.localMatchPlayers["m3"] = CopyOnWriteArrayList(
      listOf(
        MatchPlayerEntity(matchId = "m3", userId = opponentUserId),
        MatchPlayerEntity(matchId = "m3", userId = thirdUserId),
      )
    )

    val match1 = MatchEntity(
      matchId = "m1",
      status = MatchStatus.COMPLETED.name,
      winnerUserId = currentUserId,
    )
    val match2 = MatchEntity(
      matchId = "m2",
      status = MatchStatus.COMPLETED.name,
      winnerUserId = opponentUserId,
    )
    val match3 = MatchEntity(
      matchId = "m3",
      status = MatchStatus.COMPLETED.name,
      winnerUserId = opponentUserId,
    )

    val allMatches = listOf(match1, match2, match3)
    val userMatches = allMatches.filter { match ->
      (match.player1UserId == currentUserId ||
       match.player2UserId == currentUserId ||
       match.winnerUserId == currentUserId ||
       LocalDataStore.localMatchPlayers[match.matchId]?.any { it.effectiveUid == currentUserId } == true) &&
        (match.status == MatchStatus.COMPLETED.name ||
         match.status == MatchStatus.CANCELLED.name ||
         match.winnerUserId.isNotBlank())
    }

    assertEquals(2, userMatches.size)
    assertTrue(userMatches.contains(match1))
    assertTrue(userMatches.contains(match2))
    assertTrue(!userMatches.contains(match3))
  }

  @Test
  fun historicalFiltering_excludesOpenAndActiveMatches() {
    LocalDataStore.localMatchPlayers["m1"] = CopyOnWriteArrayList(
      listOf(MatchPlayerEntity(matchId = "m1", userId = currentUserId))
    )
    LocalDataStore.localMatchPlayers["m2"] = CopyOnWriteArrayList(
      listOf(MatchPlayerEntity(matchId = "m2", userId = currentUserId))
    )
    LocalDataStore.localMatchPlayers["m3"] = CopyOnWriteArrayList(
      listOf(MatchPlayerEntity(matchId = "m3", userId = currentUserId))
    )
    LocalDataStore.localMatchPlayers["m4"] = CopyOnWriteArrayList(
      listOf(MatchPlayerEntity(matchId = "m4", userId = currentUserId))
    )

    val completedMatch = MatchEntity(
      matchId = "m1",
      status = MatchStatus.COMPLETED.name,
      winnerUserId = currentUserId,
    )
    val cancelledMatch = MatchEntity(
      matchId = "m2",
      status = MatchStatus.CANCELLED.name,
    )
    val openMatch = MatchEntity(
      matchId = "m3",
      status = MatchStatus.AVAILABLE.name,
    )
    val liveMatch = MatchEntity(
      matchId = "m4",
      status = MatchStatus.RUNNING.name,
    )

    val matches = listOf(completedMatch, cancelledMatch, openMatch, liveMatch)
    val historical = matches.filter { match ->
      (match.player1UserId == currentUserId ||
       match.player2UserId == currentUserId ||
       match.winnerUserId == currentUserId ||
       LocalDataStore.localMatchPlayers[match.matchId]?.any { it.effectiveUid == currentUserId } == true) &&
        (match.status == MatchStatus.COMPLETED.name ||
         match.status == MatchStatus.CANCELLED.name ||
         match.winnerUserId.isNotBlank())
    }

    assertEquals(2, historical.size)
    assertTrue(historical.contains(completedMatch))
    assertTrue(historical.contains(cancelledMatch))
  }

  @Test
  fun gameFiltering_filtersCorrectly() {
    val ludoMatch = MatchEntity(
      matchId = "m1",
      status = MatchStatus.COMPLETED.name,
      gameType = GameType.LUDO.name,
      winnerUserId = currentUserId,
    )
    val carromMatch = MatchEntity(
      matchId = "m2",
      status = MatchStatus.COMPLETED.name,
      gameType = GameType.CARROM.name,
      winnerUserId = currentUserId,
    )

    val list = listOf(ludoMatch, carromMatch)

    val allFiltered = list
    val ludoFiltered = list.filter { it.gameType.equals("LUDO", ignoreCase = true) }
    val carromFiltered = list.filter { it.gameType.equals("CARROM", ignoreCase = true) }

    assertEquals(2, allFiltered.size)
    assertEquals(1, ludoFiltered.size)
    assertEquals("m1", ludoFiltered.first().matchId)
    assertEquals(1, carromFiltered.size)
    assertEquals("m2", carromFiltered.first().matchId)
  }

  @Test
  fun resultClassification_victoryDefeatRefunded() {
    val victoryMatch = MatchEntity(
      matchId = "m1",
      status = MatchStatus.COMPLETED.name,
      winnerUserId = currentUserId,
    )
    val defeatMatch = MatchEntity(
      matchId = "m2",
      status = MatchStatus.COMPLETED.name,
      winnerUserId = opponentUserId,
    )
    val refundedMatch = MatchEntity(
      matchId = "m3",
      status = MatchStatus.CANCELLED.name,
      winnerUserId = "",
    )

    fun classify(match: MatchEntity, userId: String): String {
      return when {
        match.status == MatchStatus.CANCELLED.name -> "REFUNDED"
        match.winnerUserId.isNotBlank() && match.winnerUserId == userId -> "VICTORY"
        match.winnerUserId.isNotBlank() && match.winnerUserId != userId -> "DEFEAT"
        else -> "RESULT PENDING"
      }
    }

    assertEquals("VICTORY", classify(victoryMatch, currentUserId))
    assertEquals("DEFEAT", classify(defeatMatch, currentUserId))
    assertEquals("REFUNDED", classify(refundedMatch, currentUserId))
  }

  @Test
  fun winRateCalculation_zeroAndNonZero() {
    val totalPlayedZero = 0
    val wonZero = 0
    val winRateZero = if (totalPlayedZero > 0) (wonZero * 100) / totalPlayedZero else 0
    assertEquals(0, winRateZero)

    val totalPlayed = 4
    val won = 3
    val winRate = (won * 100) / totalPlayed
    assertEquals(75, winRate)
  }

  @Test
  fun currencyFormatting_minorUnitsToBDT() {
    val feeMinor5000 = 5000L
    val feeMinor10000 = 10000L

    val display50 = "৳${feeMinor5000 / 100}"
    val display100 = "৳${feeMinor10000 / 100}"

    assertEquals("৳50", display50)
    assertEquals("৳100", display100)
  }
}
