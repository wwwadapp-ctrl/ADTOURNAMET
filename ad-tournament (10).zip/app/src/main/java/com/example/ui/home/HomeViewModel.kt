package com.example.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.error.Resource
import com.example.domain.model.GameType
import com.example.domain.model.MatchEntity
import com.example.domain.repository.MatchRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class MatchFilterTab(val label: String) {
  AVAILABLE("Available"),
  MY_JOINED("My Joined"),
  UPCOMING("Upcoming"),
  HISTORY("History"),
}

data class HomeUiState(
  val isLoading: Boolean = true,
  val selectedTab: MatchFilterTab = MatchFilterTab.AVAILABLE,
  val selectedGameFilter: GameType? = null,
  val matchesList: List<MatchEntity> = emptyList(),
  val filteredMatches: List<MatchEntity> = emptyList(),
  val errorMessage: String? = null,
  val joinedMatchIds: Set<String> = emptySet(),
)

class HomeViewModel(
  private val matchRepository: MatchRepository,
  private val currentUserId: String,
) : ViewModel() {

  private val _uiState = MutableStateFlow(HomeUiState())
  val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

  private var fetchJob: Job? = null

  init {
    loadMatchesForCurrentTab()
    observeJoinedMatches()
  }

  private fun observeJoinedMatches() {
    viewModelScope.launch {
      matchRepository.getMyJoinedMatches(currentUserId).collect { res ->
        if (res is Resource.Success) {
          _uiState.value = _uiState.value.copy(
            joinedMatchIds = res.data.map { it.matchId }.toSet()
          )
        }
      }
    }
  }

  fun setTab(tab: MatchFilterTab) {
    if (_uiState.value.selectedTab == tab) return
    _uiState.value = _uiState.value.copy(selectedTab = tab)
    loadMatchesForCurrentTab()
  }

  fun setGameFilter(gameType: GameType?) {
    _uiState.value = _uiState.value.copy(
      selectedGameFilter = gameType,
      filteredMatches = filterMatches(_uiState.value.matchesList, gameType),
    )
  }

  fun refresh() {
    loadMatchesForCurrentTab()
  }

  fun loadMatchesForCurrentTab() {
    fetchJob?.cancel()
    fetchJob = viewModelScope.launch {
      _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
      val flow = when (_uiState.value.selectedTab) {
        MatchFilterTab.AVAILABLE -> matchRepository.getAvailableMatches(30)
        MatchFilterTab.MY_JOINED -> matchRepository.getMyJoinedMatches(currentUserId)
        MatchFilterTab.UPCOMING -> matchRepository.getUpcomingMatches(30)
        MatchFilterTab.HISTORY -> matchRepository.getMatchHistory(currentUserId, 30)
      }
      flow.collect { resource ->
        when (resource) {
          is Resource.Loading -> {
            _uiState.value = _uiState.value.copy(isLoading = true)
          }
          is Resource.Success -> {
            val matches = resource.data
            _uiState.value = _uiState.value.copy(
              isLoading = false,
              matchesList = matches,
              filteredMatches = filterMatches(matches, _uiState.value.selectedGameFilter),
              errorMessage = null,
            )
          }
          is Resource.Error -> {
            _uiState.value = _uiState.value.copy(
              isLoading = false,
              errorMessage = resource.error.userMessage,
            )
          }
          is Resource.Idle -> Unit
        }
      }
    }
  }

  private fun filterMatches(matches: List<MatchEntity>, filter: GameType?): List<MatchEntity> {
    if (filter == null) return matches
    return matches.filter { it.gameType.equals(filter.name, ignoreCase = true) }
  }

  class Factory(
    private val matchRepository: MatchRepository,
    private val currentUserId: String,
  ) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
      return HomeViewModel(matchRepository, currentUserId) as T
    }
  }
}
