package com.example.ui.history

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.domain.model.MatchEntity
import com.example.domain.model.MatchStatus
import com.example.core.i18n.LocalAppStrings
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val MatchEntity.player1UserId: String
  get() = (com.example.data.repository.LocalDataStore.localMatchPlayers[matchId]?.getOrNull(0)?.effectiveUid)
    ?: (if (winnerUserId.isNotBlank()) winnerUserId else "")

val MatchEntity.player2UserId: String
  get() = (com.example.data.repository.LocalDataStore.localMatchPlayers[matchId]?.getOrNull(1)?.effectiveUid) ?: ""

val MatchEntity.completedAt: Long
  get() = if (scheduledAt > 0L) scheduledAt else scheduledTime

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(
  matches: List<MatchEntity> = emptyList(),
  currentUserId: String = "",
  onMatchClick: (String) -> Unit = {},
  onBackClick: () -> Unit = {},
  onNotificationClick: () -> Unit = {},
  onProfileClick: () -> Unit = {},
  modifier: Modifier = Modifier,
) {
  val strings = LocalAppStrings.current
  // 1. User participation filtering & historical completion filter
  val userHistoricalMatches = remember(matches, currentUserId) {
    if (currentUserId.isBlank()) {
      emptyList()
    } else {
      matches.filter { match ->
        (match.player1UserId == currentUserId ||
         match.player2UserId == currentUserId ||
         match.winnerUserId == currentUserId ||
         com.example.data.repository.LocalDataStore.localMatchPlayers[match.matchId]?.any { it.effectiveUid == currentUserId } == true) &&
          (match.status == MatchStatus.COMPLETED.name ||
           match.status == MatchStatus.CANCELLED.name ||
           match.winnerUserId.isNotBlank())
      }
    }
  }

  // 2. Filter selection (ALL, LUDO, CARROM)
  var selectedFilter by remember { mutableStateOf("ALL") }

  val filteredMatches = remember(userHistoricalMatches, selectedFilter) {
    when (selectedFilter) {
      "LUDO" -> userHistoricalMatches.filter { it.gameType.equals("LUDO", ignoreCase = true) }
      "CARROM" -> userHistoricalMatches.filter { it.gameType.equals("CARROM", ignoreCase = true) }
      else -> userHistoricalMatches
    }
  }

  // 3. Summary statistics from current user's historical matches
  val totalPlayed = userHistoricalMatches.size
  val wonCount = userHistoricalMatches.count { it.winnerUserId.isNotBlank() && it.winnerUserId == currentUserId }
  val winRate = if (totalPlayed > 0) (wonCount * 100) / totalPlayed else 0

  Scaffold(
    topBar = {
      // BRANDED AD TOURNAMENT HEADER
      TopAppBar(
        title = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = Slate900,
              border = BorderStroke(1.dp, Gold400.copy(alpha = 0.7f)),
              modifier = Modifier.size(36.dp),
            ) {
              Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center,
              ) {
                Image(
                  painter = painterResource(id = R.drawable.ic_launcher_foreground),
                  contentDescription = "AD TOURNAMENT",
                  modifier = Modifier.size(32.dp),
                )
              }
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "AD TOURNAMENT",
                style = MaterialTheme.typography.titleMedium.copy(
                  fontWeight = FontWeight.Black,
                  letterSpacing = 1.sp,
                  fontSize = 14.sp,
                ),
                color = Color.White,
              )
              Text(
                text = "1v1 ESPORTS BATTLES",
                style = MaterialTheme.typography.labelSmall.copy(
                  fontWeight = FontWeight.Bold,
                  letterSpacing = 0.5.sp,
                  fontSize = 10.sp,
                ),
                color = Gold400,
              )
            }
          }
        },
        navigationIcon = {
          IconButton(
            onClick = onBackClick,
            modifier = Modifier.testTag("history_back_button"),
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "Back",
              tint = Color.White,
            )
          }
        },
        actions = {
          IconButton(
            onClick = onNotificationClick,
            modifier = Modifier.testTag("history_notification_button"),
          ) {
            Icon(
              imageVector = Icons.Default.Notifications,
              contentDescription = "Notifications",
              tint = Slate300,
              modifier = Modifier.size(24.dp),
            )
          }
          IconButton(
            onClick = onProfileClick,
            modifier = Modifier.testTag("history_profile_button"),
          ) {
            Icon(
              imageVector = Icons.Default.Person,
              contentDescription = "Profile",
              tint = Gold400,
              modifier = Modifier.size(26.dp),
            )
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = NavySurface),
        modifier = Modifier.testTag("history_header"),
      )
    },
    containerColor = DeepNavyBg,
    modifier = modifier.testTag("history_screen"),
  ) { innerPadding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .testTag("history_match_list"),
      contentPadding = PaddingValues(bottom = 32.dp),
    ) {
      // 1. PAGE TITLE & SUBTITLE
      item {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        ) {
          Text(
            text = strings.matchHistoryTitle,
            style = MaterialTheme.typography.titleLarge.copy(
              fontWeight = FontWeight.Black,
              letterSpacing = 0.8.sp,
            ),
            color = Color.White,
          )
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = strings.matchHistorySubtitle,
            style = MaterialTheme.typography.bodySmall,
            color = Slate400,
          )
        }
      }

      // 2. SUMMARY CARD
      item {
        HistorySummaryCard(
          totalPlayed = totalPlayed,
          wonCount = wonCount,
          winRate = winRate,
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .testTag("history_summary"),
        )
      }

      // 3. GAME FILTER PILLS
      item {
        HistoryFilterRow(
          selectedFilter = selectedFilter,
          onFilterSelected = { selectedFilter = it },
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        )
      }

      // 4. MATCH LIST OR EMPTY STATE
      if (userHistoricalMatches.isEmpty()) {
        item {
          HistoryEmptyState(
            title = strings.noMatchHistoryTitle,
            subtitle = strings.noMatchHistorySubtext,
            modifier = Modifier
              .fillMaxWidth()
              .padding(32.dp)
              .testTag("history_empty_state"),
          )
        }
      } else if (filteredMatches.isEmpty()) {
        item {
          HistoryEmptyState(
            title = strings.noFilteredMatchesTitle,
            subtitle = strings.noFilteredMatchesSubtext,
            modifier = Modifier
              .fillMaxWidth()
              .padding(32.dp)
              .testTag("history_empty_state"),
          )
        }
      } else {
        items(
          items = filteredMatches,
          key = { it.matchId },
        ) { match ->
          HistoryMatchCard(
            match = match,
            currentUserId = currentUserId,
            onClick = { onMatchClick(match.matchId) },
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 16.dp, vertical = 6.dp)
              .testTag("history_match_card"),
          )
        }
      }
    }
  }
}

// -----------------------------------------------------------------------------
// SUMMARY STAT CARD
// -----------------------------------------------------------------------------

@Composable
private fun HistorySummaryCard(
  totalPlayed: Int,
  wonCount: Int,
  winRate: Int,
  modifier: Modifier = Modifier,
) {
  val strings = LocalAppStrings.current
  Surface(
    shape = RoundedCornerShape(14.dp),
    color = NavySurface,
    border = BorderStroke(1.dp, Gold400.copy(alpha = 0.25f)),
    modifier = modifier,
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 16.dp, horizontal = 8.dp),
      horizontalArrangement = Arrangement.SpaceEvenly,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      SummaryStatColumn(
        label = strings.totalPlayed,
        value = totalPlayed.toString(),
        valueColor = Color.White,
      )
      VerticalDivider(
        modifier = Modifier.height(36.dp),
        color = CardBorder,
      )
      SummaryStatColumn(
        label = strings.totalWon,
        value = wonCount.toString(),
        valueColor = Emerald400,
      )
      VerticalDivider(
        modifier = Modifier.height(36.dp),
        color = CardBorder,
      )
      SummaryStatColumn(
        label = strings.winRateLabel,
        value = "$winRate%",
        valueColor = Gold400,
      )
    }
  }
}

@Composable
private fun SummaryStatColumn(
  label: String,
  value: String,
  valueColor: Color,
  modifier: Modifier = Modifier,
) {
  Column(
    modifier = modifier,
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.labelSmall.copy(
        fontWeight = FontWeight.Bold,
        letterSpacing = 0.5.sp,
        fontSize = 10.sp,
      ),
      color = Slate400,
    )
    Spacer(modifier = Modifier.height(4.dp))
    Text(
      text = value,
      style = MaterialTheme.typography.titleLarge.copy(
        fontWeight = FontWeight.Black,
      ),
      color = valueColor,
    )
  }
}

// -----------------------------------------------------------------------------
// FILTER PILLS ROW
// -----------------------------------------------------------------------------

@Composable
private fun HistoryFilterRow(
  selectedFilter: String,
  onFilterSelected: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  val strings = LocalAppStrings.current
  val filters = listOf(
    Triple("ALL", strings.filterAll, "history_filter_all"),
    Triple("LUDO", strings.filterLudo, "history_filter_ludo"),
    Triple("CARROM", strings.filterCarrom, "history_filter_carrom"),
  )

  Row(
    modifier = modifier,
    horizontalArrangement = Arrangement.spacedBy(8.dp),
    verticalAlignment = Alignment.CenterVertically,
  ) {
    filters.forEach { (key, label, tag) ->
      val isSelected = selectedFilter == key
      Surface(
        shape = RoundedCornerShape(20.dp),
        color = if (isSelected) Gold500.copy(alpha = 0.2f) else Slate900,
        border = BorderStroke(
          1.dp,
          if (isSelected) Gold400 else CardBorder,
        ),
        modifier = Modifier
          .clickable { onFilterSelected(key) }
          .testTag(tag),
      ) {
        Text(
          text = label,
          style = MaterialTheme.typography.labelMedium.copy(
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            letterSpacing = 0.5.sp,
          ),
          color = if (isSelected) Gold400 else Slate300,
          modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
        )
      }
    }
  }
}

// -----------------------------------------------------------------------------
// MATCH HISTORY CARD
// -----------------------------------------------------------------------------

@Composable
private fun HistoryMatchCard(
  match: MatchEntity,
  currentUserId: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val strings = LocalAppStrings.current
  val isCancelled = match.status == MatchStatus.CANCELLED.name
  val isWinner = match.winnerUserId.isNotBlank() && match.winnerUserId == currentUserId
  val isDefeat = match.winnerUserId.isNotBlank() && match.winnerUserId != currentUserId

  val (resultText, resultColor, resultBg) = when {
    isCancelled -> Triple(strings.badgeRefunded, Slate300, Slate800)
    isWinner -> Triple(strings.badgeVictory, Emerald400, Emerald600.copy(alpha = 0.2f))
    isDefeat -> Triple(strings.badgeDefeat, Rose400, Rose600.copy(alpha = 0.2f))
    else -> Triple(strings.badgePending, Gold400, Gold500.copy(alpha = 0.2f))
  }

  // Timestamp selection
  val rawTimestamp = when {
    match.completedAt > 0L -> match.completedAt
    match.scheduledAt > 0L -> match.scheduledAt
    match.createdAt > 0L -> match.createdAt
    else -> 0L
  }
  val formattedDate = remember(rawTimestamp) {
    if (rawTimestamp > 0L) {
      SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(rawTimestamp))
    } else {
      "Completed"
    }
  }

  val displayTitle = match.title.ifBlank {
    "${match.gameType} 1v1 Battle"
  }
  val matchIdShort = if (match.matchId.isNotBlank()) "#${match.matchId.takeLast(6).uppercase()}" else ""

  Surface(
    shape = RoundedCornerShape(12.dp),
    color = NavySurface,
    border = BorderStroke(
      1.dp,
      when {
        isWinner -> Gold400.copy(alpha = 0.35f)
        isCancelled -> CardBorder
        else -> NavyCardBorder
      },
    ),
    modifier = modifier.clickable(onClick = onClick),
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
    ) {
      // Upper row: Icon + Title/Info + Result Badge
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(
          modifier = Modifier.weight(1f),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Box(
            modifier = Modifier
              .size(40.dp)
              .clip(CircleShape)
              .background(
                when {
                  isWinner -> Gold400.copy(alpha = 0.15f)
                  isCancelled -> Slate800
                  isDefeat -> Rose600.copy(alpha = 0.12f)
                  else -> Slate800
                }
              ),
            contentAlignment = Alignment.Center,
          ) {
            Icon(
              imageVector = when {
                isWinner -> Icons.Default.EmojiEvents
                isCancelled -> Icons.Default.Refresh
                isDefeat -> Icons.Default.Close
                else -> Icons.Default.HourglassEmpty
              },
              contentDescription = resultText,
              tint = resultColor,
              modifier = Modifier.size(22.dp),
            )
          }
          Spacer(modifier = Modifier.width(10.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = displayTitle,
              style = MaterialTheme.typography.titleSmall.copy(
                fontWeight = FontWeight.Bold,
              ),
              color = Color.White,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
              text = buildString {
                append(formattedDate)
                if (matchIdShort.isNotBlank()) {
                  append(" • ")
                  append(matchIdShort)
                }
              },
              style = MaterialTheme.typography.labelSmall,
              color = Slate400,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }
        }

        Spacer(modifier = Modifier.width(8.dp))

        // Result Chip
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = resultBg,
          border = BorderStroke(1.dp, resultColor.copy(alpha = 0.6f)),
        ) {
          Text(
            text = resultText,
            style = MaterialTheme.typography.labelSmall.copy(
              fontWeight = FontWeight.Bold,
              letterSpacing = 0.5.sp,
            ),
            color = resultColor,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Lower row: Match Details Strip
      Surface(
        shape = RoundedCornerShape(8.dp),
        color = Slate900,
        modifier = Modifier.fillMaxWidth(),
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          // Game
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = "${strings.labelGame} ",
              style = MaterialTheme.typography.labelSmall,
              color = Slate400,
            )
            Text(
              text = if (match.gameType.equals("LUDO", ignoreCase = true)) strings.filterLudo
                     else if (match.gameType.equals("CARROM", ignoreCase = true)) strings.filterCarrom
                     else match.gameType,
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
              color = Cyan400,
            )
          }

          // Entry Fee
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = "${strings.labelEntry} ",
              style = MaterialTheme.typography.labelSmall,
              color = Slate400,
            )
            Text(
              text = "৳${match.effectiveEntryFeeMinorUnits / 100}",
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
              color = Color.White,
            )
          }

          // Prize or Refund Amount
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = if (isCancelled) "${strings.labelRefund} " else "${strings.labelPrize} ",
              style = MaterialTheme.typography.labelSmall,
              color = Slate400,
            )
            Text(
              text = if (isCancelled) "৳${match.effectiveEntryFeeMinorUnits / 100}" else "৳${match.effectivePrizeMinorUnits / 100}",
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
              color = if (isCancelled) Slate200 else Gold400,
            )
          }
        }
      }
    }
  }
}

// -----------------------------------------------------------------------------
// EMPTY STATE
// -----------------------------------------------------------------------------

@Composable
private fun HistoryEmptyState(
  title: String,
  subtitle: String,
  modifier: Modifier = Modifier,
) {
  Box(
    modifier = modifier,
    contentAlignment = Alignment.Center,
  ) {
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
    ) {
      Surface(
        shape = CircleShape,
        color = Slate900,
        border = BorderStroke(1.dp, CardBorder),
        modifier = Modifier.size(72.dp),
      ) {
        Box(
          modifier = Modifier.fillMaxSize(),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            imageVector = Icons.Default.History,
            contentDescription = null,
            tint = Slate400,
            modifier = Modifier.size(36.dp),
          )
        }
      }
      Spacer(modifier = Modifier.height(16.dp))
      Text(
        text = title,
        style = MaterialTheme.typography.titleMedium.copy(
          fontWeight = FontWeight.Bold,
          letterSpacing = 0.5.sp,
        ),
        color = Color.White,
      )
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = subtitle,
        style = MaterialTheme.typography.bodyMedium,
        color = Slate400,
      )
    }
  }
}
