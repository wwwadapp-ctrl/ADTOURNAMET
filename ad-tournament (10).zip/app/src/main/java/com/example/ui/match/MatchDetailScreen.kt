package com.example.ui.match

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.MatchStatus
import com.example.ui.components.MatchStatusBadge
import com.example.ui.components.TournamentButton
import com.example.ui.components.TournamentButtonVariant
import com.example.ui.components.TournamentCard
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MatchDetailScreen(
  viewModel: MatchDetailViewModel,
  onNavigateBack: () -> Unit,
  onViewRoomCode: (String) -> Unit = {},
  onSubmitProof: (String) -> Unit = {},
) {
  val uiState by viewModel.uiState.collectAsState()
  val match = uiState.match

  var showProofDialog by remember { mutableStateOf(false) }
  var screenshotUrlInput by remember { mutableStateOf("") }
  var proofNotesInput by remember { mutableStateOf("") }
  var proofError by remember { mutableStateOf<String?>(null) }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Text(
            text = match?.matchNumber ?: "Match Details",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = Color.White,
          )
        },
        navigationIcon = {
          IconButton(onClick = onNavigateBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = NavySurface),
      )
    },
    containerColor = DeepNavyBg,
  ) { innerPadding ->
    if (match == null) {
      Box(modifier = Modifier.fillMaxSize().padding(innerPadding), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(color = Gold500)
      }
      return@Scaffold
    }

    val isLudo = match.gameType.equals("LUDO", ignoreCase = true)
    val isFull = match.joinedPlayersCount >= match.maxPlayers || match.status.equals(MatchStatus.FULL.name, ignoreCase = true)
    val isRunning = match.status.equals(MatchStatus.RUNNING.name, ignoreCase = true)
    val isCompleted = match.status.equals(MatchStatus.COMPLETED.name, ignoreCase = true)

    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
    ) {
      TournamentCard(
        modifier = Modifier.fillMaxWidth(),
        backgroundColor = NavyCard,
        borderColor = Gold500.copy(alpha = 0.4f),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = if (isLudo) "LUDO 1v1 BATTLE" else "CARROM 1v1 BATTLE",
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
            color = if (isLudo) Indigo400 else Cyan400,
          )
          MatchStatusBadge(
            status = match.status,
            joinedPlayersCount = match.joinedPlayersCount,
            maxPlayers = match.maxPlayers,
            isJoined = uiState.isJoined,
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text(
          text = match.title,
          style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
          color = Color.White,
        )

        Spacer(modifier = Modifier.height(16.dp))

        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(Slate900, RoundedCornerShape(10.dp))
            .padding(14.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Column {
            Text(text = "ENTRY FEE", style = MaterialTheme.typography.labelSmall, color = Slate400)
            Text(
              text = "৳ ${"%.0f".format(match.entryFee)}",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = Color.White,
            )
          }
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = "PLAYERS", style = MaterialTheme.typography.labelSmall, color = Slate400)
            Text(
              text = "${match.joinedPlayersCount} / ${match.maxPlayers}",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = Cyan400,
            )
          }
          Column(horizontalAlignment = Alignment.End) {
            Text(text = "WINNER PRIZE", style = MaterialTheme.typography.labelSmall, color = Slate400)
            Text(
              text = "৳ ${"%.0f".format(match.prizePool)}",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
              color = Gold400,
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      if (uiState.successMessage != null) {
        Surface(
          color = Emerald900.copy(alpha = 0.5f),
          shape = RoundedCornerShape(8.dp),
          border = BorderStroke(1.dp, Emerald500),
          modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp),
        ) {
          Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            Icon(
              imageVector = Icons.Default.CheckCircle,
              contentDescription = null,
              tint = Emerald400,
              modifier = Modifier.size(20.dp),
            )
            Text(
              text = uiState.successMessage ?: "",
              color = Emerald400,
              style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
            )
          }
        }
      }

      if (uiState.errorMessage != null) {
        Surface(
          color = Rose900.copy(alpha = 0.4f),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp),
        ) {
          Text(
            text = uiState.errorMessage ?: "",
            color = Rose400,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(12.dp),
          )
        }
      }

      // Game Room Code section with strict privacy
      TournamentCard(
        modifier = Modifier.fillMaxWidth(),
        backgroundColor = NavyCard,
        borderColor = if (uiState.isJoined || uiState.isAdmin) Indigo600 else NavyCardBorder,
      ) {
        Text(
          text = "Game Room Code",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          color = Color.White,
        )
        Spacer(modifier = Modifier.height(8.dp))
        if (uiState.isJoined || uiState.isAdmin) {
          if (match.gameCode.isNotBlank()) {
            Surface(
              color = Indigo900.copy(alpha = 0.5f),
              shape = RoundedCornerShape(8.dp),
              border = BorderStroke(1.dp, Indigo600),
              modifier = Modifier.fillMaxWidth(),
            ) {
              Column(
                modifier = Modifier.padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
              ) {
                Text(text = "ROOM CODE", style = MaterialTheme.typography.labelSmall, color = Gold400)
                Text(
                  text = match.gameCode,
                  style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Black,
                    letterSpacing = 4.sp,
                  ),
                  color = Color.White,
                )
                Text(
                  text = "Open Ludo King / Carrom Pool and enter this code to join match room",
                  style = MaterialTheme.typography.bodySmall,
                  color = Slate400,
                  modifier = Modifier.padding(top = 6.dp),
                )
              }
            }
          } else {
            Text(
              text = "Super Admin will generate the room code 5-10 minutes before the scheduled match time. Please keep this screen open.",
              style = MaterialTheme.typography.bodyMedium,
              color = Slate300,
            )
          }
        } else {
          Surface(
            color = Slate850,
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Row(
              modifier = Modifier.padding(12.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(Icons.Default.Lock, contentDescription = null, tint = Amber400)
              Spacer(modifier = Modifier.width(10.dp))
              Text(
                text = "Game room code is confidential and accessible only to registered match participants.",
                style = MaterialTheme.typography.bodySmall,
                color = Slate400,
              )
            }
          }
        }
      }
      Spacer(modifier = Modifier.height(16.dp))

      // Result Submission Status or Action
      if (uiState.submittedResult != null) {
        val result = uiState.submittedResult!!
        TournamentCard(
          modifier = Modifier.fillMaxWidth(),
          backgroundColor = NavyCard,
          borderColor = when (result.status) {
            "APPROVED" -> Emerald500
            "REJECTED" -> Rose500
            else -> Gold400
          },
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(
              text = "Victory Submission",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = Color.White,
            )
            Surface(
              color = when (result.status) {
                "APPROVED" -> Emerald900.copy(alpha = 0.5f)
                "REJECTED" -> Rose900.copy(alpha = 0.5f)
                else -> Amber900.copy(alpha = 0.5f)
              },
              shape = RoundedCornerShape(6.dp),
              border = BorderStroke(
                1.dp,
                when (result.status) {
                  "APPROVED" -> Emerald500
                  "REJECTED" -> Rose500
                  else -> Gold400
                },
              ),
            ) {
              Text(
                text = when (result.status) {
                  "APPROVED" -> "APPROVED 🏆"
                  "REJECTED" -> "REJECTED"
                  else -> "UNDER REVIEW"
                },
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = when (result.status) {
                  "APPROVED" -> Emerald400
                  "REJECTED" -> Rose400
                  else -> Gold400
                },
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              )
            }
          }
          Spacer(modifier = Modifier.height(8.dp))
          if (result.proofScreenshotUrl.isNotBlank()) {
            Text(
              text = "Proof: ${result.proofScreenshotUrl}",
              style = MaterialTheme.typography.bodySmall,
              color = Slate300,
            )
          }
          if (result.reviewNotes.isNotBlank()) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "Notes: ${result.reviewNotes}",
              style = MaterialTheme.typography.bodySmall,
              color = if (result.status == "REJECTED") Rose400 else Slate400,
            )
          }
        }
        Spacer(modifier = Modifier.height(16.dp))
      } else if (uiState.isJoined) {
        val currentPlayer = uiState.players.find { it.effectiveUid == viewModel.currentUserId }
        val isWinnerDeclared = match.winnerUserId.isNotBlank()
        val isDeclaredWinner = isWinnerDeclared && match.winnerUserId == viewModel.currentUserId
        val isDeclaredLoser = isWinnerDeclared && match.winnerUserId != viewModel.currentUserId
        val isPlayerLost = currentPlayer?.status?.equals("LOST", ignoreCase = true) == true
        val isMatchCompleted = match.status == MatchStatus.COMPLETED.name
        val isLoser = isDeclaredLoser || isPlayerLost || (isMatchCompleted && !isDeclaredWinner)

        val isEligibleStatus = match.status in setOf(
          MatchStatus.RUNNING.name,
          MatchStatus.CODE_ADDED.name,
          MatchStatus.FULL.name,
          MatchStatus.COMPLETED.name,
        )

        val canSubmitProof = !isLoser && (isDeclaredWinner || (!isWinnerDeclared && isEligibleStatus))

        if (canSubmitProof) {
          TournamentButton(
            text = "SUBMIT MATCH VICTORY PROOF",
            onClick = { showProofDialog = true },
            modifier = Modifier.fillMaxWidth(),
            testTag = "detail_submit_proof_btn",
          )
          Spacer(modifier = Modifier.height(16.dp))
        } else if (isLoser) {
          TournamentCard(
            modifier = Modifier.fillMaxWidth(),
            backgroundColor = NavyCard,
            borderColor = CardBorder,
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              Icon(Icons.Default.Info, contentDescription = null, tint = Slate400, modifier = Modifier.size(20.dp))
              Text(
                text = if (isMatchCompleted) "Match completed. Victory proof can only be submitted by the winner." else "Losers cannot submit victory proof.",
                style = MaterialTheme.typography.bodySmall,
                color = Slate300,
              )
            }
          }
          Spacer(modifier = Modifier.height(16.dp))
        }
      }

      TournamentCard(
        modifier = Modifier.fillMaxWidth(),
        backgroundColor = NavyCard,
        borderColor = NavyCardBorder,
      ) {
        Text(
          text = "Registered Players (${uiState.players.size}/${match.maxPlayers})",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          color = Color.White,
        )
        Spacer(modifier = Modifier.height(10.dp))
        if (uiState.players.isEmpty()) {
          Text(
            text = "No players have joined yet. Be the first to join!",
            style = MaterialTheme.typography.bodyMedium,
            color = Slate400,
          )
        } else {
          uiState.players.forEach { p ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AccountCircle, contentDescription = null, tint = Gold400, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = p.username, style = MaterialTheme.typography.bodyMedium, color = Color.White)
              }
              Surface(
                color = Slate850,
                shape = RoundedCornerShape(6.dp),
              ) {
                Text(
                  text = p.slot,
                  style = MaterialTheme.typography.labelSmall,
                  color = Cyan400,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                )
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(24.dp))

      if (!uiState.isJoined && !isFull && !isRunning && !isCompleted) {
        TournamentButton(
          text = "JOIN MATCH (৳ ${"%.0f".format(match.entryFee)})",
          onClick = { viewModel.joinMatch() },
          isLoading = uiState.isJoining,
          modifier = Modifier.fillMaxWidth(),
          testTag = "detail_join_button",
        )
      }
    }
  }

  if (showProofDialog) {
    AlertDialog(
      onDismissRequest = { showProofDialog = false },
      containerColor = NavyCard,
      title = {
        Text(
          text = "Submit Victory Proof",
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
          color = Color.White,
        )
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Text(
            text = "Submit screenshot proof of victory. Warning: Only actual winners should submit. Fake claims result in instant account ban.",
            style = MaterialTheme.typography.bodySmall,
            color = Slate300,
          )

          OutlinedTextField(
            value = screenshotUrlInput,
            onValueChange = {
              screenshotUrlInput = it
              proofError = null
            },
            label = { Text("Screenshot URL / Image link") },
            placeholder = { Text("https://...") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
              focusedTextColor = Color.White,
              unfocusedTextColor = Color.White,
              focusedBorderColor = Gold400,
              unfocusedBorderColor = NavyCardBorder,
              focusedLabelColor = Gold400,
              unfocusedLabelColor = Slate400,
            ),
          )

          OutlinedTextField(
            value = proofNotesInput,
            onValueChange = { proofNotesInput = it },
            label = { Text("Notes / Winner Remarks (Optional)") },
            placeholder = { Text("e.g., Ludo King 1st place") },
            maxLines = 3,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
              focusedTextColor = Color.White,
              unfocusedTextColor = Color.White,
              focusedBorderColor = Gold400,
              unfocusedBorderColor = NavyCardBorder,
              focusedLabelColor = Gold400,
              unfocusedLabelColor = Slate400,
            ),
          )

          if (proofError != null) {
            Text(
              text = proofError!!,
              style = MaterialTheme.typography.bodySmall,
              color = Rose400,
            )
          }
        }
      },
      confirmButton = {
        TournamentButton(
          text = "SUBMIT PROOF",
          onClick = {
            if (screenshotUrlInput.trim().isEmpty()) {
              proofError = "Please enter a valid screenshot URL or proof reference."
            } else {
              viewModel.submitVictoryProof(screenshotUrlInput.trim(), proofNotesInput.trim())
              showProofDialog = false
            }
          },
          isLoading = uiState.isSubmittingResult,
          testTag = "dialog_confirm_proof_btn",
        )
      },
      dismissButton = {
        TextButton(onClick = { showProofDialog = false }) {
          Text("Cancel", color = Slate400)
        }
      },
    )
  }
}
