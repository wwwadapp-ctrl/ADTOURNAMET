package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.*

enum class TournamentButtonVariant {
  PRIMARY,
  SECONDARY,
  OUTLINED,
  DANGER
}

@Composable
fun TournamentButton(
  text: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  variant: TournamentButtonVariant = TournamentButtonVariant.PRIMARY,
  enabled: Boolean = true,
  isLoading: Boolean = false,
  leadingIcon: @Composable (() -> Unit)? = null,
  testTag: String = "tournament_button",
) {
  val shape = RoundedCornerShape(12.dp)
  val isButtonEnabled = enabled && !isLoading

  when (variant) {
    TournamentButtonVariant.PRIMARY -> {
      Button(
        onClick = onClick,
        modifier = modifier
          .defaultMinSize(minHeight = 48.dp)
          .testTag(testTag),
        enabled = isButtonEnabled,
        shape = shape,
        colors = ButtonDefaults.buttonColors(
          containerColor = Gold500,
          contentColor = Slate950,
          disabledContainerColor = Slate800,
          disabledContentColor = Slate600,
        ),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
      ) {
        ButtonContent(text = text, isLoading = isLoading, contentColor = Slate950, leadingIcon = leadingIcon)
      }
    }
    TournamentButtonVariant.SECONDARY -> {
      Button(
        onClick = onClick,
        modifier = modifier
          .defaultMinSize(minHeight = 48.dp)
          .testTag(testTag),
        enabled = isButtonEnabled,
        shape = shape,
        colors = ButtonDefaults.buttonColors(
          containerColor = Slate800,
          contentColor = Gold400,
          disabledContainerColor = Slate850,
          disabledContentColor = Slate600,
        ),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
      ) {
        ButtonContent(text = text, isLoading = isLoading, contentColor = Gold400, leadingIcon = leadingIcon)
      }
    }
    TournamentButtonVariant.OUTLINED -> {
      OutlinedButton(
        onClick = onClick,
        modifier = modifier
          .defaultMinSize(minHeight = 48.dp)
          .testTag(testTag),
        enabled = isButtonEnabled,
        shape = shape,
        border = BorderStroke(1.5.dp, if (isButtonEnabled) Gold500 else Slate700),
        colors = ButtonDefaults.outlinedButtonColors(
          contentColor = Gold500,
          disabledContentColor = Slate600,
        ),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
      ) {
        ButtonContent(text = text, isLoading = isLoading, contentColor = Gold500, leadingIcon = leadingIcon)
      }
    }
    TournamentButtonVariant.DANGER -> {
      Button(
        onClick = onClick,
        modifier = modifier
          .defaultMinSize(minHeight = 48.dp)
          .testTag(testTag),
        enabled = isButtonEnabled,
        shape = shape,
        colors = ButtonDefaults.buttonColors(
          containerColor = Rose600,
          contentColor = Color.White,
          disabledContainerColor = Slate800,
          disabledContentColor = Slate600,
        ),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
      ) {
        ButtonContent(text = text, isLoading = isLoading, contentColor = Color.White, leadingIcon = leadingIcon)
      }
    }
  }
}

@Composable
private fun ButtonContent(
  text: String,
  isLoading: Boolean,
  contentColor: Color,
  leadingIcon: @Composable (() -> Unit)? = null,
) {
  Row(
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.Center,
  ) {
    if (isLoading) {
      CircularProgressIndicator(
        modifier = Modifier.size(20.dp),
        strokeWidth = 2.5.dp,
        color = contentColor,
      )
      Spacer(modifier = Modifier.width(10.dp))
    } else if (leadingIcon != null) {
      leadingIcon()
      Spacer(modifier = Modifier.width(8.dp))
    }
    Text(
      text = text,
      style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
    )
  }
}
