package com.example.ui.notifications

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.error.Resource
import com.example.domain.model.NotificationEntity
import com.example.domain.repository.NotificationRepository
import com.example.ui.components.TournamentCard
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun NotificationsScreen(
  userId: String,
  onNavigateBack: () -> Unit,
  notificationRepository: NotificationRepository,
  modifier: Modifier = Modifier,
) {
  val notificationsResource by notificationRepository.getNotifications(userId, 50).collectAsState(initial = null)
  val notifications = (notificationsResource as? Resource.Success)?.data ?: emptyList()

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(DeepNavyBg)
      .testTag("notifications_screen"),
  ) {
    // Header
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 14.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      IconButton(
        onClick = onNavigateBack,
        modifier = Modifier.testTag("notifications_back_button"),
      ) {
        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
      }
      Spacer(modifier = Modifier.width(4.dp))
      Text(
        text = "NOTIFICATIONS",
        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black, letterSpacing = 1.sp),
        color = Color.White,
      )
    }

    if (notifications.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(32.dp),
        contentAlignment = Alignment.Center,
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Icon(Icons.Default.NotificationsNone, contentDescription = null, tint = Slate600, modifier = Modifier.size(50.dp))
          Spacer(modifier = Modifier.height(12.dp))
          Text("No notifications yet", color = Slate400, style = MaterialTheme.typography.bodyMedium)
        }
      }
    } else {
      LazyColumn(
        modifier = Modifier
          .fillMaxSize()
          .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 24.dp),
      ) {
        items(notifications, key = { it.notificationId }) { notif ->
          NotificationCard(notif = notif)
        }
      }
    }
  }
}

@Composable
private fun NotificationCard(notif: NotificationEntity) {
  val formattedDate = remember(notif.createdAt) {
    if (notif.createdAt > 0L) {
      SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(notif.createdAt))
    } else {
      "Recent"
    }
  }

  TournamentCard(
    modifier = Modifier.fillMaxWidth(),
    backgroundColor = if (!notif.isRead) NavySurface else NavyCard,
    borderColor = if (!notif.isRead) Indigo600 else CardBorder,
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.Top,
    ) {
      Box(
        modifier = Modifier
          .size(36.dp)
          .clip(CircleShape)
          .background(if (!notif.isRead) Gold500.copy(alpha = 0.2f) else Slate800),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = if (!notif.isRead) Icons.Default.NotificationsActive else Icons.Default.Notifications,
          contentDescription = null,
          tint = if (!notif.isRead) Gold400 else Slate400,
          modifier = Modifier.size(18.dp),
        )
      }
      Spacer(modifier = Modifier.width(12.dp))
      Column(modifier = Modifier.weight(1f)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = notif.title,
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
            color = Color.White,
          )
          if (!notif.isRead) {
            Surface(
              color = Indigo600,
              shape = RoundedCornerShape(4.dp),
            ) {
              Text(
                text = "NEW",
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.Black),
                color = Color.White,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
              )
            }
          }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = notif.body,
          style = MaterialTheme.typography.bodySmall,
          color = Slate300,
          lineHeight = 17.sp,
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = formattedDate,
          style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
          color = Slate500,
        )
      }
    }
  }
}
