package com.example.core.repository

import com.example.core.config.FirebaseAdminConfig
import com.example.core.model.AdminResultItem
import com.example.core.model.NotificationTargetType
import com.example.core.model.ResultStatus
import com.example.core.model.SuperAdminSession
import com.example.core.model.TournamentMath
import com.example.core.model.UserWalletData
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.MutableData
import com.google.firebase.database.Transaction
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.tasks.await
import kotlin.coroutines.resume

data class ResultApprovalResult(
    val success: Boolean,
    val alreadySettled: Boolean = false,
    val errorMessage: String? = null
)

object ResultPrizeResolver {
    /**
     * Resolves authoritative prize in minor units from match data with fallbacks.
     * 1. Prefers authoritative minor-unit field: prizeMinorUnits
     * 2. Safely falls back to authoritative prize field present in match model (prizePool / prize)
     * 3. Falls back to entry fee under existing TournamentMath
     * 4. Falls back to result record prize if available
     */
    fun resolvePrizeMinorUnits(
        matchPrizeMinorUnits: Long? = null,
        matchPrizePoolTaka: Double? = null,
        matchEntryFeeMinorUnits: Long? = null,
        matchEntryFeeTaka: Double? = null,
        resultPrizeMinorUnits: Long? = null,
        resultPrizePoolTaka: Double? = null
    ): Long {
        if (matchPrizeMinorUnits != null && matchPrizeMinorUnits > 0L) {
            return matchPrizeMinorUnits
        }

        if (matchPrizePoolTaka != null && matchPrizePoolTaka > 0.0) {
            return matchPrizePoolTaka.toLong()
        }

        if (matchEntryFeeMinorUnits != null && matchEntryFeeMinorUnits > 0L) {
            val calculated = TournamentMath.calculatePrizeMinorUnits(matchEntryFeeMinorUnits)
            if (calculated > 0L) return calculated
        }

        if (matchEntryFeeTaka != null && matchEntryFeeTaka > 0.0) {
            val entryFeeMinor = matchEntryFeeTaka.toLong()
            val calculated = TournamentMath.calculatePrizeMinorUnits(entryFeeMinor)
            if (calculated > 0L) return calculated
        }

        if (resultPrizeMinorUnits != null && resultPrizeMinorUnits > 0L) {
            return resultPrizeMinorUnits
        }

        if (resultPrizePoolTaka != null && resultPrizePoolTaka > 0.0) {
            return resultPrizePoolTaka.toLong()
        }

        return 0L
    }

    fun resolveFromSnapshots(
        matchSnapshot: DataSnapshot?,
        resultSnapshot: DataSnapshot? = null
    ): Long {
        val matchPrizeMinor = (matchSnapshot?.child("prizeMinorUnits")?.value as? Number)?.toLong()
            ?: matchSnapshot?.child("prizeMinorUnits")?.value?.toString()?.toLongOrNull()
            ?: (matchSnapshot?.child("prize_minor_units")?.value as? Number)?.toLong()
            ?: matchSnapshot?.child("prize_minor_units")?.value?.toString()?.toLongOrNull()
        val matchPrizePool = (matchSnapshot?.child("prizePool")?.value as? Number)?.toDouble()
            ?: matchSnapshot?.child("prizePool")?.value?.toString()?.toDoubleOrNull()
            ?: (matchSnapshot?.child("prize_pool")?.value as? Number)?.toDouble()
            ?: matchSnapshot?.child("prize_pool")?.value?.toString()?.toDoubleOrNull()
            ?: (matchSnapshot?.child("prize")?.value as? Number)?.toDouble()
            ?: matchSnapshot?.child("prize")?.value?.toString()?.toDoubleOrNull()
            ?: (matchSnapshot?.child("winningPrize")?.value as? Number)?.toDouble()
            ?: matchSnapshot?.child("winningPrize")?.value?.toString()?.toDoubleOrNull()
            ?: (matchSnapshot?.child("amount")?.value as? Number)?.toDouble()
            ?: matchSnapshot?.child("amount")?.value?.toString()?.toDoubleOrNull()
        val matchEntryFeeMinor = (matchSnapshot?.child("entryFeeMinorUnits")?.value as? Number)?.toLong()
            ?: matchSnapshot?.child("entryFeeMinorUnits")?.value?.toString()?.toLongOrNull()
            ?: (matchSnapshot?.child("entry_fee_minor_units")?.value as? Number)?.toLong()
            ?: matchSnapshot?.child("entry_fee_minor_units")?.value?.toString()?.toLongOrNull()
        val matchEntryFee = (matchSnapshot?.child("entryFee")?.value as? Number)?.toDouble()
            ?: matchSnapshot?.child("entryFee")?.value?.toString()?.toDoubleOrNull()
            ?: (matchSnapshot?.child("entry_fee")?.value as? Number)?.toDouble()
            ?: matchSnapshot?.child("entry_fee")?.value?.toString()?.toDoubleOrNull()

        val resultPrizeMinor = (resultSnapshot?.child("prizeMinorUnits")?.value as? Number)?.toLong()
            ?: resultSnapshot?.child("prizeMinorUnits")?.value?.toString()?.toLongOrNull()
            ?: (resultSnapshot?.child("amountMinorUnits")?.value as? Number)?.toLong()
            ?: resultSnapshot?.child("amountMinorUnits")?.value?.toString()?.toLongOrNull()
        val resultPrizeTaka = (resultSnapshot?.child("prizePool")?.value as? Number)?.toDouble()
            ?: resultSnapshot?.child("prizePool")?.value?.toString()?.toDoubleOrNull()
            ?: (resultSnapshot?.child("prize")?.value as? Number)?.toDouble()
            ?: resultSnapshot?.child("prize")?.value?.toString()?.toDoubleOrNull()
            ?: (resultSnapshot?.child("amount")?.value as? Number)?.toDouble()
            ?: resultSnapshot?.child("amount")?.value?.toString()?.toDoubleOrNull()
            ?: (resultSnapshot?.child("prizeTaka")?.value as? Number)?.toDouble()
            ?: resultSnapshot?.child("prizeTaka")?.value?.toString()?.toDoubleOrNull()

        return resolvePrizeMinorUnits(
            matchPrizeMinorUnits = matchPrizeMinor,
            matchPrizePoolTaka = matchPrizePool,
            matchEntryFeeMinorUnits = matchEntryFeeMinor,
            matchEntryFeeTaka = matchEntryFee,
            resultPrizeMinorUnits = resultPrizeMinor,
            resultPrizePoolTaka = resultPrizeTaka
        )
    }
}

interface ResultsRepository {
    fun observeResults(): Flow<List<AdminResultItem>>
    suspend fun getResult(resultId: String): AdminResultItem?
    suspend fun approveResult(
        resultId: String,
        submittedMatchNumber: String,
        submittedRoomCode: String,
        adminSession: SuperAdminSession
    ): Result<Unit>
    suspend fun rejectResult(
        resultId: String,
        reason: String,
        adminSession: SuperAdminSession
    ): Result<Unit>
}

class FirebaseResultsRepository(
    initialResults: List<AdminResultItem>? = null,
    initialWallets: Map<String, UserWalletData>? = null,
    initialMatches: Map<String, com.example.core.model.AdminMatchItem>? = null,
    initialMatchPlayers: Map<String, List<com.example.core.model.MatchPlayerDetails>>? = null
) : ResultsRepository {
    companion object {
        val defaultSeedResults = listOf(
            AdminResultItem(
                resultId = "res_seed_001",
                matchId = "mtc_seed_001",
                matchNumber = "#101",
                gameType = "LUDO",
                userId = "usr_tanvir_9812",
                userName = "Tanvir Hasan",
                userPhone = "01712984561",
                roomCode = "7829104",
                proofScreenshotUrl = "data:image/jpeg;base64,/9j/4AAQSkZJRg==",
                screenshotUrl = "data:image/jpeg;base64,/9j/4AAQSkZJRg==",
                prizeMinorUnits = TournamentMath.takaToMinorUnits(750),
                prizeTaka = 750.0,
                status = ResultStatus.PENDING,
                rawStatus = "PENDING",
                createdAt = System.currentTimeMillis() - 1800000L
            ),
            AdminResultItem(
                resultId = "res_seed_002",
                matchId = "mtc_seed_002",
                matchNumber = "#102",
                gameType = "CARROM",
                userId = "usr_shakib_4412",
                userName = "Shakib Rahman",
                userPhone = "01823490123",
                roomCode = "5512903",
                proofScreenshotUrl = "data:image/jpeg;base64,/9j/4AAQSkZJRg==",
                screenshotUrl = "data:image/jpeg;base64,/9j/4AAQSkZJRg==",
                prizeMinorUnits = TournamentMath.takaToMinorUnits(1200),
                prizeTaka = 1200.0,
                status = ResultStatus.APPROVED,
                rawStatus = "APPROVED",
                createdAt = System.currentTimeMillis() - 7200000L,
                processedAt = System.currentTimeMillis() - 3600000L
            )
        )

        val defaultSeedWallets = mapOf(
            "usr_tanvir_9812" to UserWalletData(
                userId = "usr_tanvir_9812",
                balance = TournamentMath.takaToMinorUnits(1200),
                availableBalance = TournamentMath.takaToMinorUnits(700),
                depositBalance = TournamentMath.takaToMinorUnits(500),
                winningBalance = TournamentMath.takaToMinorUnits(700),
                pendingBalance = TournamentMath.takaToMinorUnits(500),
                totalDeposited = TournamentMath.takaToMinorUnits(2000),
                totalWithdrawn = 0L,
                balanceDouble = 1200.0,
                lockedBalanceDouble = 500.0,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    private val database: FirebaseDatabase? = try {
        FirebaseDatabase.getInstance(FirebaseAdminConfig.RTDB_BASE_URL)
    } catch (e: Exception) {
        null
    }

    private val _matchesMap = (initialMatches ?: emptyMap()).toMutableMap()
    private val _resultsMap = (initialResults ?: defaultSeedResults).map { res ->
        if (res.prizeMinorUnits <= 0L && res.matchId.isNotBlank() && _matchesMap.containsKey(res.matchId)) {
            val match = _matchesMap[res.matchId]!!
            val resolvedMinor = ResultPrizeResolver.resolvePrizeMinorUnits(
                matchPrizeMinorUnits = match.prizeMinorUnits,
                matchPrizePoolTaka = match.prizePool,
                matchEntryFeeMinorUnits = match.entryFeeMinorUnits,
                matchEntryFeeTaka = match.entryFee,
                resultPrizeMinorUnits = res.prizeMinorUnits,
                resultPrizePoolTaka = res.prizeTaka.toDouble()
            )
            res.copy(
                prizeMinorUnits = resolvedMinor,
                prizeTaka = TournamentMath.minorUnitsToTakaDouble(resolvedMinor)
            )
        } else {
            res
        }
    }.associateBy { it.resultId }.toMutableMap()
    private val _walletsMap = (initialWallets ?: defaultSeedWallets).toMutableMap()
    private val _matchPlayersMap = (initialMatchPlayers ?: emptyMap()).toMutableMap()
    private val _creditedResultIds = mutableSetOf<String>()
    private val _localResultsState = MutableStateFlow(_resultsMap.values.toList())

    fun getUserWallet(userId: String): UserWalletData? {
        return _walletsMap[userId]
    }

    fun setUserWallet(userId: String, wallet: UserWalletData) {
        _walletsMap[userId] = wallet
    }

    fun setMatch(match: com.example.core.model.AdminMatchItem) {
        _matchesMap[match.matchId] = match
    }

    fun setMatchPlayers(matchId: String, players: List<com.example.core.model.MatchPlayerDetails>) {
        _matchPlayersMap[matchId] = players
    }

    fun getMatchPlayers(matchId: String): List<com.example.core.model.MatchPlayerDetails> {
        return _matchPlayersMap[matchId] ?: emptyList()
    }

    fun addResult(item: AdminResultItem) {
        val resolvedMinor = if (item.prizeMinorUnits <= 0L && item.matchId.isNotBlank() && _matchesMap.containsKey(item.matchId)) {
            val match = _matchesMap[item.matchId]!!
            ResultPrizeResolver.resolvePrizeMinorUnits(
                matchPrizeMinorUnits = match.prizeMinorUnits,
                matchPrizePoolTaka = match.prizePool,
                matchEntryFeeMinorUnits = match.entryFeeMinorUnits,
                matchEntryFeeTaka = match.entryFee,
                resultPrizeMinorUnits = item.prizeMinorUnits,
                resultPrizePoolTaka = item.prizeTaka.toDouble()
            )
        } else {
            item.prizeMinorUnits
        }
        val resolvedItem = item.copy(
            prizeMinorUnits = resolvedMinor,
            prizeTaka = TournamentMath.minorUnitsToTakaDouble(resolvedMinor)
        )
        _resultsMap[item.resultId] = resolvedItem
        _localResultsState.value = _resultsMap.values.toList()
    }

    private fun verifySuperAdmin(adminSession: SuperAdminSession) {
        if (!adminSession.isSuperAdminVerified || adminSession.uid.isBlank()) {
            throw SecurityException("Unauthorized: Result settlement requires verified Super Admin authorization.")
        }
    }

    override fun observeResults(): Flow<List<AdminResultItem>> {
        val db = database ?: return _localResultsState.asStateFlow()

        val resultsFlow = callbackFlow {
            val ref = db.getReference(FirebaseAdminConfig.NODE_RESULTS)
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    trySend(snapshot)
                }
                override fun onCancelled(error: DatabaseError) {
                    close(error.toException())
                }
            }
            ref.addValueEventListener(listener)
            awaitClose { ref.removeEventListener(listener) }
        }

        val matchesFlow = callbackFlow {
            val ref = db.getReference(FirebaseAdminConfig.NODE_MATCHES)
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    trySend(snapshot)
                }
                override fun onCancelled(error: DatabaseError) {
                    trySend(null)
                }
            }
            ref.addValueEventListener(listener)
            awaitClose { ref.removeEventListener(listener) }
        }

        return combine(resultsFlow, matchesFlow) { resultsSnap, matchesSnap ->
            val list = mutableListOf<AdminResultItem>()
            for (matchGroup in resultsSnap.children) {
                // Ensure this is a match node (has result objects as children)
                if (!matchGroup.hasChildren()) continue
                
                val matchIdFromKey = matchGroup.key ?: continue
                val matchSnap = if (matchesSnap != null && matchesSnap.hasChild(matchIdFromKey)) {
                    matchesSnap.child(matchIdFromKey)
                } else null

                for (child in matchGroup.children) {
                    // Ensure this is a result object (has fields), not a primitive leaf
                    if (!child.hasChildren()) continue

                    try {
                        val userIdFromKey = child.key ?: continue
                        val resultId = "$matchIdFromKey/$userIdFromKey"

                        val matchId = child.child("matchId").value?.toString()
                            ?: child.child("match_id").value?.toString()
                            ?: matchIdFromKey

                        val matchNumber = child.child("matchNumber").value?.toString()
                            ?: child.child("match_number").value?.toString()
                            ?: matchSnap?.child("matchNumber")?.value?.toString()
                            ?: matchSnap?.child("match_number")?.value?.toString() ?: "#001"
                        
                        val rawGame = child.child("gameType").value?.toString()
                            ?: child.child("game").value?.toString()
                            ?: matchSnap?.child("gameType")?.value?.toString()
                            ?: matchSnap?.child("game")?.value?.toString() ?: "LUDO"
                        val gameType = if (rawGame.contains("carrom", ignoreCase = true)) "CARROM" else "LUDO"

                        val userId = child.child("claimedWinnerUserId").value?.toString()
                            ?: child.child("submittedByUserId").value?.toString()
                            ?: child.child("userId").value?.toString()
                            ?: child.child("winnerUserId").value?.toString()
                            ?: child.child("uid").value?.toString()
                            ?: child.child("submitterId").value?.toString()
                            ?: child.child("playerUid").value?.toString()
                            ?: userIdFromKey

                        val winnerUserId = child.child("claimedWinnerUserId").value?.toString()
                            ?: child.child("submittedByUserId").value?.toString()
                            ?: child.child("winnerUserId").value?.toString()
                            ?: userId

                        var userName = child.child("userName").value?.toString()
                            ?: child.child("name").value?.toString()
                            ?: child.child("username").value?.toString()
                            ?: child.child("displayName").value?.toString()
                            ?: child.child("fullName").value?.toString() ?: ""
                        
                        if (userName.isBlank() || userName.equals("Player", ignoreCase = true)) {
                            userName = userId.ifBlank { "Player" }
                        }

                        val userPhone = child.child("userPhone").value?.toString()
                            ?: child.child("phone").value?.toString()
                            ?: child.child("mobile").value?.toString()
                            ?: child.child("contact").value?.toString() ?: ""

                        val reviewNotes = child.child("reviewNotes").value?.toString() ?: ""
                        var roomCode = child.child("roomCode").value?.toString()
                            ?: child.child("code").value?.toString()
                            ?: child.child("gameCode").value?.toString()

                        if (roomCode.isNullOrBlank() && reviewNotes.isNotBlank()) {
                            val regex = Regex("""রুমকোড:\s*([0-9]+)""", RegexOption.IGNORE_CASE)
                            val match = regex.find(reviewNotes)
                            roomCode = match?.groupValues?.get(1)
                        }

                        val authoritativeGameCode = matchSnap?.child("gameCode")?.value?.toString()
                            ?: matchSnap?.child("code")?.value?.toString() ?: ""
                        
                        val proofScreenshotUrl = child.child("proofScreenshotUrl").value?.toString()
                            ?: child.child("screenshotUrl").value?.toString()
                            ?: child.child("screenshot").value?.toString()
                            ?: child.child("imageUrl").value?.toString()
                            ?: child.child("proofUrl").value?.toString() ?: ""
                        val screenshotUrl = proofScreenshotUrl

                        val prizeMinor = ResultPrizeResolver.resolveFromSnapshots(matchSnap, child)
                        val prizeTaka = TournamentMath.minorUnitsToTakaDouble(prizeMinor)

                        val rawStatus = child.child("status").value?.toString() ?: "PENDING"
                        val status = ResultStatus.fromString(rawStatus)
                        val createdAt = (child.child("createdAt").value as? Number)?.toLong()
                            ?: (child.child("timestamp").value as? Number)?.toLong() ?: System.currentTimeMillis()
                        val processedAt = (child.child("processedAt").value as? Number)?.toLong()
                        val processedBy = child.child("processedBy").value?.toString()
                        val rejectionReason = child.child("rejectionReason").value?.toString()
                            ?: child.child("reason").value?.toString()
                        val settlementTransactionId = child.child("settlementTransactionId").value?.toString()
                            ?: child.child("transactionId").value?.toString() ?: ""

                        list.add(
                            AdminResultItem(
                                resultId = resultId,
                                matchId = matchId,
                                matchNumber = matchNumber,
                                gameType = gameType,
                                userId = userId,
                                winnerUserId = winnerUserId,
                                userName = userName,
                                userPhone = userPhone,
                                roomCode = (roomCode ?: "").ifBlank { authoritativeGameCode }.ifBlank { "N/A" },
                                reviewNotes = reviewNotes,
                                proofScreenshotUrl = proofScreenshotUrl,
                                screenshotUrl = proofScreenshotUrl,
                                prizeMinorUnits = prizeMinor,
                                prizeTaka = prizeTaka,
                                status = status,
                                rawStatus = rawStatus,
                                createdAt = createdAt,
                                processedAt = processedAt,
                                processedBy = processedBy,
                                rejectionReason = rejectionReason,
                                settlementTransactionId = settlementTransactionId
                            )
                        )
                    } catch (e: Exception) {
                        // Skip malformed nodes gracefully
                    }
                }
            }
            list.sortedByDescending { it.createdAt }
        }
    }

    override suspend fun getResult(resultId: String): AdminResultItem? {
        val db = database
        if (db == null) {
            val item = _resultsMap[resultId] ?: return null
            if (item.prizeMinorUnits <= 0L && item.matchId.isNotBlank() && _matchesMap.containsKey(item.matchId)) {
                val match = _matchesMap[item.matchId]!!
                val resolvedMinor = ResultPrizeResolver.resolvePrizeMinorUnits(
                    matchPrizeMinorUnits = match.prizeMinorUnits,
                    matchPrizePoolTaka = match.prizePool,
                    matchEntryFeeMinorUnits = match.entryFeeMinorUnits,
                    matchEntryFeeTaka = match.entryFee,
                    resultPrizeMinorUnits = item.prizeMinorUnits,
                    resultPrizePoolTaka = item.prizeTaka.toDouble()
                )
                val updated = item.copy(
                    prizeMinorUnits = resolvedMinor,
                    prizeTaka = TournamentMath.minorUnitsToTakaDouble(resolvedMinor)
                )
                _resultsMap[resultId] = updated
                return updated
            }
            return item
        }
        return try {
            val ref = db.getReference(FirebaseAdminConfig.NODE_RESULTS).child(resultId)
            val child = ref.get().await()
            if (child.exists()) {
                resolveResultData(db, resultId, child)
            } else {
                // If resultId is not matchId/userId but just userId, we might need a search, 
                // but usually the app passes the full resultId.
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    private suspend fun resolveResultData(
        db: FirebaseDatabase,
        resultId: String,
        child: DataSnapshot
    ): AdminResultItem {
        val parts = resultId.split("/")
        val matchIdFromPath = if (parts.size > 1) parts[0] else ""
        val userIdFromPath = if (parts.size > 1) parts[1] else resultId

        val matchId = child.child("matchId").value?.toString()
            ?: child.child("match_id").value?.toString()
            ?: matchIdFromPath

        val matchNumber = child.child("matchNumber").value?.toString()
            ?: child.child("match_number").value?.toString() ?: "#001"
        val rawGame = child.child("gameType").value?.toString()
            ?: child.child("game").value?.toString() ?: "LUDO"
        val gameType = if (rawGame.contains("carrom", ignoreCase = true)) "CARROM" else "LUDO"
        
        var userId = child.child("claimedWinnerUserId").value?.toString()
            ?: child.child("submittedByUserId").value?.toString()
            ?: child.child("userId").value?.toString()
            ?: child.child("winnerUserId").value?.toString()
            ?: child.child("uid").value?.toString()
            ?: child.child("submitterId").value?.toString()
            ?: child.child("playerUid").value?.toString()
            ?: userIdFromPath

        val winnerUserId = child.child("claimedWinnerUserId").value?.toString()
            ?: child.child("submittedByUserId").value?.toString()
            ?: child.child("winnerUserId").value?.toString()
            ?: userId

        var userName = child.child("userName").value?.toString()
            ?: child.child("name").value?.toString()
            ?: child.child("username").value?.toString()
            ?: child.child("displayName").value?.toString()
            ?: child.child("fullName").value?.toString() ?: ""
        
        if (userName.isBlank() || userName.equals("Player", ignoreCase = true)) {
            userName = userId.ifBlank { "Player" }
        }

        var userPhone = child.child("userPhone").value?.toString()
            ?: child.child("phone").value?.toString()
            ?: child.child("mobile").value?.toString()
            ?: child.child("contact").value?.toString() ?: ""

        val reviewNotes = child.child("reviewNotes").value?.toString() ?: ""
        var roomCode = child.child("roomCode").value?.toString()
            ?: child.child("code").value?.toString()
            ?: child.child("gameCode").value?.toString()

        if (roomCode.isNullOrBlank() && reviewNotes.isNotBlank()) {
            val regex = Regex("""রুমকোড:\s*([0-9]+)""", RegexOption.IGNORE_CASE)
            val match = regex.find(reviewNotes)
            roomCode = match?.groupValues?.get(1)
        }

        if (roomCode.isNullOrBlank()) {
            roomCode = ""
        }

        val proofScreenshotUrl = child.child("proofScreenshotUrl").value?.toString()
            ?: child.child("screenshotUrl").value?.toString()
            ?: child.child("screenshot").value?.toString()
            ?: child.child("imageUrl").value?.toString()
            ?: child.child("proofUrl").value?.toString() ?: ""
        val screenshotUrl = proofScreenshotUrl

        var matchSnap: DataSnapshot? = null
        if (matchId.isNotBlank()) {
            try {
                val snap = db.getReference(FirebaseAdminConfig.NODE_MATCHES).child(matchId).get().await()
                if (snap.exists()) {
                    matchSnap = snap
                    if (userId.isBlank()) {
                        userId = matchSnap.child("winnerUserId").value?.toString()
                            ?: matchSnap.child("winnerId").value?.toString()
                            ?: matchSnap.child("userId").value?.toString() ?: ""
                    }
                }
            } catch (e: Exception) {}
        }

        val authoritativeGameCode = matchSnap?.child("gameCode")?.value?.toString()
            ?: matchSnap?.child("code")?.value?.toString() ?: ""

        val prizeMinor = ResultPrizeResolver.resolveFromSnapshots(matchSnap, child)

        // Deep resolution from /matchPlayers if userId is still missing
        if (userId.isBlank() && matchId.isNotBlank()) {
            try {
                val playersSnap = db.getReference(FirebaseAdminConfig.NODE_MATCH_PLAYERS).child(matchId).get().await()
                    if (playersSnap.exists()) {
                        var firstPlayerId = ""
                        var firstPlayerName = ""
                        var firstPlayerPhone = ""
                        for (playerChild in playersSnap.children) {
                            val pId = playerChild.key ?: continue
                            val pUserId = playerChild.child("userId").value?.toString()
                                ?: playerChild.child("uid").value?.toString() ?: pId
                            val pName = playerChild.child("username").value?.toString()
                                ?: playerChild.child("name").value?.toString() ?: ""
                            val pPhone = playerChild.child("phone").value?.toString()
                                ?: playerChild.child("mobile").value?.toString() ?: ""
                            val isWinnerFlag = playerChild.child("isWinner").getValue(Boolean::class.java)
                                ?: playerChild.child("winner").getValue(Boolean::class.java)
                                ?: (playerChild.child("status").value?.toString().equals("WON", ignoreCase = true))

                            if (firstPlayerId.isBlank()) {
                                firstPlayerId = pUserId
                                firstPlayerName = pName
                                firstPlayerPhone = pPhone
                            }
                            if (isWinnerFlag) {
                                userId = pUserId
                                if (userName.isBlank() || userName.equals("Player", ignoreCase = true)) {
                                    if (pName.isNotBlank()) userName = pName
                                }
                                if (userPhone.isBlank() && pPhone.isNotBlank()) {
                                    userPhone = pPhone
                                }
                                break
                            }
                        }
                        if (userId.isBlank() && firstPlayerId.isNotBlank()) {
                            userId = firstPlayerId
                            if (userName.isBlank() || userName.equals("Player", ignoreCase = true)) {
                                if (firstPlayerName.isNotBlank()) userName = firstPlayerName
                            }
                            if (userPhone.isBlank() && firstPlayerPhone.isNotBlank()) {
                                userPhone = firstPlayerPhone
                            }
                        }
                    }
            } catch (e: Exception) {}
        }

        if (userId.isNotBlank() && (userName.isBlank() || userName.equals("Player", ignoreCase = true))) {
            try {
                val userSnap = db.getReference(FirebaseAdminConfig.NODE_USERS).child(userId).get().await()
                if (userSnap.exists()) {
                    val uName = userSnap.child("name").value?.toString()
                        ?: userSnap.child("username").value?.toString()
                        ?: userSnap.child("fullName").value?.toString() ?: ""
                    val uPhone = userSnap.child("phone").value?.toString()
                        ?: userSnap.child("mobile").value?.toString() ?: ""
                    if (uName.isNotBlank()) userName = uName
                    if (userPhone.isBlank() && uPhone.isNotBlank()) userPhone = uPhone
                }
            } catch (e: Exception) {}
        }

        if (userName.isBlank() || userName.equals("Player", ignoreCase = true)) {
            userName = userId.ifBlank { "Player" }
        }

        val prizeTaka = TournamentMath.minorUnitsToTakaDouble(prizeMinor)
        val rawStatus = child.child("status").value?.toString() ?: "PENDING"
        val status = ResultStatus.fromString(rawStatus)
        val createdAt = (child.child("createdAt").value as? Number)?.toLong()
            ?: (child.child("timestamp").value as? Number)?.toLong() ?: System.currentTimeMillis()
        val processedAt = (child.child("processedAt").value as? Number)?.toLong()
        val processedBy = child.child("processedBy").value?.toString()
        val rejectionReason = child.child("rejectionReason").value?.toString()
            ?: child.child("reason").value?.toString()
        val settlementTransactionId = child.child("settlementTransactionId").value?.toString()
            ?: child.child("transactionId").value?.toString() ?: ""

        return AdminResultItem(
            resultId = resultId,
            matchId = matchId,
            matchNumber = matchNumber,
            gameType = gameType,
            userId = userId,
            winnerUserId = winnerUserId,
            userName = userName,
            userPhone = userPhone,
            roomCode = (roomCode ?: "").ifBlank { authoritativeGameCode }.ifBlank { "N/A" },
            proofScreenshotUrl = proofScreenshotUrl,
            screenshotUrl = proofScreenshotUrl,
            prizeMinorUnits = prizeMinor,
            prizeTaka = prizeTaka,
            status = status,
            rawStatus = rawStatus,
            createdAt = createdAt,
            processedAt = processedAt,
            processedBy = processedBy,
            rejectionReason = rejectionReason,
            settlementTransactionId = settlementTransactionId,
            reviewNotes = reviewNotes
        )
    }

    override suspend fun approveResult(
        resultId: String,
        submittedMatchNumber: String,
        submittedRoomCode: String,
        adminSession: SuperAdminSession
    ): Result<Unit> = runCatching {
        verifySuperAdmin(adminSession)
        val db = database

        if (db == null) {
            // In-memory offline/test execution path
            val resultItem = getResult(resultId)
                ?: throw IllegalArgumentException("Result submission '$resultId' does not exist.")

            if (resultItem.status == ResultStatus.APPROVED) {
                throw IllegalStateException("Result '$resultId' has already been approved and settled.")
            }
            if (resultItem.status == ResultStatus.REJECTED) {
                throw IllegalStateException("Result '$resultId' was rejected and cannot be approved.")
            }

            val matchId = resultItem.matchId
            val userId = resultItem.userId
            require(userId.isNotBlank()) { "Winner User ID is missing from result submission." }

            // GUARD: If /matches/{matchId}/status is already "COMPLETED", abort immediately to prevent duplicate payouts
            val match = if (matchId.isNotBlank()) _matchesMap[matchId] else null
            if (match != null) {
                if (match.status == com.example.core.model.MatchStatus.COMPLETED || match.rawStatus.equals("COMPLETED", ignoreCase = true) || match.winnerUserId.isNotBlank()) {
                    throw IllegalStateException("Match '$matchId' is already COMPLETED. Payout has already been settled.")
                }
            }

            if (_creditedResultIds.contains(resultId) || (matchId.isNotBlank() && _creditedResultIds.contains("MATCH_$matchId"))) {
                throw IllegalStateException("Result '$resultId' or Match '$matchId' has already been approved or settled concurrently.")
            }

            val prizeMinor = if (resultItem.prizeMinorUnits > 0L) {
                resultItem.prizeMinorUnits
            } else if (matchId.isNotBlank() && _matchesMap.containsKey(matchId)) {
                val m = _matchesMap[matchId]!!
                ResultPrizeResolver.resolvePrizeMinorUnits(
                    matchPrizeMinorUnits = m.prizeMinorUnits,
                    matchPrizePoolTaka = m.prizePool,
                    matchEntryFeeMinorUnits = m.entryFeeMinorUnits,
                    matchEntryFeeTaka = m.entryFee,
                    resultPrizeMinorUnits = resultItem.prizeMinorUnits,
                    resultPrizePoolTaka = resultItem.prizeTaka.toDouble()
                )
            } else {
                resultItem.prizeMinorUnits
            }
            require(prizeMinor > 0L) { "Cannot approve result: Prize amount is ৳0." }
            val now = System.currentTimeMillis()
            val sanitizedResultId = resultId.replace('/', '_')
            val deterministicTrxId = "WIN_${sanitizedResultId}"
            val prizeTaka = TournamentMath.minorUnitsToTakaDouble(prizeMinor)

            // WALLET PAYOUT: Credit the winning prize (in minor units / paisa) ONLY to the approved winner's wallet
            val currentWallet = _walletsMap[userId] ?: UserWalletData(userId = userId)
            val updatedWallet = currentWallet.copy(
                balance = currentWallet.balance + prizeMinor,
                availableBalance = currentWallet.availableBalance + prizeMinor,
                winningBalance = currentWallet.winningBalance + prizeMinor,
                balanceDouble = (currentWallet.balance + prizeMinor) / 100.0,
                updatedAt = now
            )
            _walletsMap[userId] = updatedWallet
            _creditedResultIds.add(resultId)
            if (matchId.isNotBlank()) {
                _creditedResultIds.add("MATCH_$matchId")
            }

            // Set /matches/{matchId}/status to "COMPLETED" and winnerUserId
            if (match != null) {
                _matchesMap[matchId] = match.copy(
                    status = com.example.core.model.MatchStatus.COMPLETED,
                    rawStatus = "COMPLETED",
                    winnerUserId = userId
                )
            }

            // Set approved result item
            val approvedItem = resultItem.copy(
                status = ResultStatus.APPROVED,
                rawStatus = ResultStatus.APPROVED.name,
                prizeMinorUnits = prizeMinor,
                prizeTaka = prizeTaka,
                proofScreenshotUrl = "",
                screenshotUrl = "",
                processedAt = now,
                processedBy = adminSession.identifier,
                settlementTransactionId = deterministicTrxId,
                reviewNotes = "Approved by Super Admin"
            )
            _resultsMap[resultId] = approvedItem

            // Automatic Loser Handling (1v1 Match):
            // 1. Identify opponents in _matchPlayersMap and update winner/loser status
            if (matchId.isNotBlank() && _matchPlayersMap.containsKey(matchId)) {
                val updatedPlayers = _matchPlayersMap[matchId]?.map { p ->
                    if (p.userId == userId || p.uid == userId) {
                        p.copy(status = "WON")
                    } else {
                        p.copy(status = "LOST")
                    }
                }
                if (updatedPlayers != null) {
                    _matchPlayersMap[matchId] = updatedPlayers
                }
            }

            // 2. Identify opponent results in _resultsMap and mark them LOST
            if (matchId.isNotBlank()) {
                for ((otherId, otherResult) in _resultsMap) {
                    if (otherResult.matchId == matchId && otherResult.userId != userId && otherId != resultId) {
                        _resultsMap[otherId] = otherResult.copy(
                            status = ResultStatus.LOST,
                            rawStatus = ResultStatus.LOST.name,
                            proofScreenshotUrl = "",
                            screenshotUrl = "",
                            processedAt = now,
                            processedBy = adminSession.identifier,
                            reviewNotes = "Opponent was approved as the match winner."
                        )
                    }
                }
            }
            _localResultsState.value = _resultsMap.values.toList()

            sendResultNotification(
                userId = userId,
                title = "Match Winning Prize Credited! / ম্যাচ বিজয়ী পুরস্কার যোগ হয়েছে",
                message = "Congratulations! You won match ${resultItem.matchNumber}. Prize of ৳$prizeTaka has been credited to your wallet balance.",
                adminSession = adminSession
            )

            return@runCatching
        }

        // Production Firebase Realtime Database path
        val resultItem = getResult(resultId)
            ?: throw IllegalArgumentException("Result submission '$resultId' does not exist.")

        if (resultItem.status == ResultStatus.APPROVED) {
            throw IllegalStateException("Result '$resultId' has already been approved and settled.")
        }
        if (resultItem.status == ResultStatus.REJECTED) {
            throw IllegalStateException("Result '$resultId' was rejected and cannot be approved.")
        }

        val matchId = resultItem.matchId
        require(matchId.isNotBlank()) { "Result submission is not linked to any match ID." }
        val userId = resultItem.userId
        require(userId.isNotBlank()) { "Winner User ID is missing from result submission." }

        // Fetch authoritative match details from /matches/{matchId}
        val matchRef = db.getReference(FirebaseAdminConfig.NODE_MATCHES).child(matchId)
        val matchSnapshot = matchRef.get().await()
        if (!matchSnapshot.exists()) {
            throw IllegalArgumentException("Linked match ID '$matchId' does not exist in the system.")
        }

        // GUARD: If /matches/{matchId}/status is already "COMPLETED", abort immediately to prevent duplicate payouts
        val currentMatchStatus = matchSnapshot.child("status").value?.toString() ?: ""
        val currentWinnerUserId = matchSnapshot.child("winnerUserId").value?.toString() ?: ""
        if (currentMatchStatus.equals("COMPLETED", ignoreCase = true) || currentWinnerUserId.isNotBlank()) {
            throw IllegalStateException("Match '$matchId' is already COMPLETED. Payout has already been settled.")
        }

        val canonicalMatchNumber = matchSnapshot.child("matchNumber").value?.toString()
            ?: matchSnapshot.child("match_number").value?.toString() ?: resultItem.matchNumber
        val authoritativeGameCode = matchSnapshot.child("gameCode").value?.toString()
            ?: matchSnapshot.child("code").value?.toString()
            ?: matchSnapshot.child("game_code").value?.toString() ?: ""
        val authoritativePrizeMinor = ResultPrizeResolver.resolveFromSnapshots(matchSnapshot).let { resolved ->
            if (resolved > 0L) resolved else resultItem.prizeMinorUnits
        }

        // Strict correspondence check
        val cleanSubmittedMatchNum = submittedMatchNumber.trim().lowercase()
        val cleanCanonicalMatchNum = canonicalMatchNumber.trim().lowercase()
        require(cleanSubmittedMatchNum == cleanCanonicalMatchNum || resultItem.matchNumber.trim().lowercase() == cleanCanonicalMatchNum) {
            "Match verification mismatch: Submitted Match Number ($submittedMatchNumber) does not correspond to system Match Number ($canonicalMatchNumber)."
        }

        val cleanSubmittedRoomCode = submittedRoomCode.trim()
        val cleanAuthoritativeRoomCode = authoritativeGameCode.trim()
        if (cleanAuthoritativeRoomCode.isNotBlank()) {
            require(cleanSubmittedRoomCode.equals(cleanAuthoritativeRoomCode, ignoreCase = true) || cleanSubmittedRoomCode.equals(resultItem.roomCode.trim(), ignoreCase = true)) {
                "Room Code verification mismatch: Submitted Room Code ($submittedRoomCode) does not correspond to authoritative system Room Code."
            }
        }

        val now = System.currentTimeMillis()
        val sanitizedResultId = resultId.replace('/', '_')
        val deterministicTrxId = "WIN_${matchId}_${userId}"
        val deterministicLogId = "AUDIT_WIN_${matchId}_${userId}"
        val prizeTaka = TournamentMath.minorUnitsToTakaDouble(authoritativePrizeMinor)

        // Step 1: Prevent Double Payouts - Atomic match status lock to COMPLETED on /matches/{matchId}
        val matchLockResult = executeMatchCompletionLockTransaction(
            matchRef = matchRef,
            winnerUserId = userId,
            now = now
        )

        if (!matchLockResult.success) {
            if (matchLockResult.alreadyCompleted) {
                throw IllegalStateException("Match '$matchId' is already COMPLETED or settled concurrently.")
            }
            throw IllegalStateException(matchLockResult.errorMessage ?: "Failed to lock match status for completion.")
        }

        // Step 2: Authoritative atomic status lock on /results/{resultId}
        val resultRef = db.getReference(FirebaseAdminConfig.NODE_RESULTS).child(resultId)
        val lockResult = executeResultApprovalLockTransaction(
            resultRef = resultRef,
            adminSession = adminSession,
            settlementTrxId = deterministicTrxId,
            authoritativePrizeMinor = authoritativePrizeMinor,
            now = now
        )

        if (!lockResult.success) {
            if (lockResult.alreadySettled) {
                throw IllegalStateException("Result '$resultId' has already been approved or settled concurrently.")
            }
            throw IllegalStateException(lockResult.errorMessage ?: "Failed to lock result status for approval.")
        }

        // Step 3: WALLET PAYOUT - Atomic wallet prize credit via runTransaction on /wallets/{userId}
        // STRICT AUDIT: Credit the winning prize (in minor units / paisa) ONLY to the approved winner's wallet
        val walletRef = db.getReference(FirebaseAdminConfig.NODE_WALLETS).child(userId)
        val walletCreditResult = executeWalletPrizeCreditTransaction(
            walletRef = walletRef,
            resultId = resultId,
            matchId = matchId,
            prizeMinorUnits = authoritativePrizeMinor,
            now = now
        )

        if (!walletCreditResult.success) {
            throw IllegalStateException(walletCreditResult.errorMessage ?: "Wallet prize credit transaction failed.")
        }

        // Step 4: Automatic Loser Handling (1v1 Match)
        // Identify opponents in /matchPlayers/{matchId} and /results/{matchId}
        val matchPlayersRef = db.getReference(FirebaseAdminConfig.NODE_MATCH_PLAYERS).child(matchId)
        val playersSnapshot = try { matchPlayersRef.get().await() } catch (e: Exception) { null }
        val opponentUserIds = mutableSetOf<String>()

        if (playersSnapshot != null && playersSnapshot.exists()) {
            for (playerChild in playersSnapshot.children) {
                val pKey = playerChild.key ?: continue
                val pUserId = playerChild.child("userId").value?.toString()
                    ?: playerChild.child("uid").value?.toString() ?: pKey
                if (pUserId.isNotBlank() && pUserId != userId) {
                    opponentUserIds.add(pUserId)
                }
            }
        }

        try {
            val matchResultsSnap = db.getReference(FirebaseAdminConfig.NODE_RESULTS).child(matchId).get().await()
            if (matchResultsSnap.exists()) {
                for (child in matchResultsSnap.children) {
                    val oppUserId = child.key ?: continue
                    if (oppUserId.isNotBlank() && oppUserId != userId) {
                        opponentUserIds.add(oppUserId)
                    }
                }
            }
        } catch (e: Exception) {}

        // Step 5: Write secondary mirrored nodes, loser statuses, ledger transaction, audit logs, and nullify proof screenshots
        val userResultsNodeKey = "userResults"
        val updates = mutableMapOf<String, Any?>(
            // User result mirror update for winner
            "$userResultsNodeKey/$userId/$resultId/status" to ResultStatus.APPROVED.name,
            "$userResultsNodeKey/$userId/$resultId/processedAt" to now,
            "$userResultsNodeKey/$userId/$resultId/processedBy" to adminSession.identifier,
            "$userResultsNodeKey/$userId/$resultId/settlementTransactionId" to deterministicTrxId,
            "$userResultsNodeKey/$userId/$resultId/proofScreenshotUrl" to null,
            "$userResultsNodeKey/$userId/$resultId/screenshotUrl" to null,
            "$userResultsNodeKey/$userId/$resultId/proofLocked" to true,
            "$userResultsNodeKey/$userId/$resultId/canResubmit" to false,

            // Root result screenshot removal and proof locking for winner
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/status" to ResultStatus.APPROVED.name,
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/proofLocked" to true,
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/canResubmit" to false,
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/proofScreenshotUrl" to null,
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/screenshotUrl" to null,

            // Update match winner & status in /matches/{matchId}
            "${FirebaseAdminConfig.NODE_MATCHES}/$matchId/winnerUserId" to userId,
            "${FirebaseAdminConfig.NODE_MATCHES}/$matchId/status" to "COMPLETED",
            "${FirebaseAdminConfig.NODE_MATCHES}/$matchId/updatedAt" to now,

            // Update winner status in /matchPlayers/{matchId}/{userId}
            "${FirebaseAdminConfig.NODE_MATCH_PLAYERS}/$matchId/$userId/status" to "WON",
            "${FirebaseAdminConfig.NODE_MATCH_PLAYERS}/$matchId/$userId/isWinner" to true,
            "${FirebaseAdminConfig.NODE_MATCH_PLAYERS}/$matchId/$userId/winner" to true,
            "${FirebaseAdminConfig.NODE_MATCH_PLAYERS}/$matchId/$userId/updatedAt" to now,

            // Profile consistency update in /users/{userId}
            "${FirebaseAdminConfig.NODE_USERS}/$userId/balance" to walletCreditResult.newBalance,
            "${FirebaseAdminConfig.NODE_USERS}/$userId/winningBalance" to walletCreditResult.newWinningBalance,
            "${FirebaseAdminConfig.NODE_USERS}/$userId/updatedAt" to now,

            // Global ledger record in /transactions/{deterministicTrxId}
            "${FirebaseAdminConfig.NODE_TRANSACTIONS}/$deterministicTrxId" to mapOf(
                "transactionId" to deterministicTrxId,
                "resultId" to resultId,
                "matchId" to matchId,
                "userId" to userId,
                "amount" to authoritativePrizeMinor,
                "amountMinorUnits" to authoritativePrizeMinor,
                "type" to "PRIZE_WIN",
                "direction" to "CREDIT",
                "status" to "COMPLETED",
                "timestamp" to now,
                "processedBy" to adminSession.identifier,
                "description" to "Prize winning payout of ৳$prizeTaka credited for match $canonicalMatchNumber"
            ),

            // User ledger mirror in /userTransactions/{userId}/{deterministicTrxId}
            "${FirebaseAdminConfig.NODE_USER_TRANSACTIONS}/$userId/$deterministicTrxId" to mapOf(
                "transactionId" to deterministicTrxId,
                "resultId" to resultId,
                "matchId" to matchId,
                "amount" to authoritativePrizeMinor,
                "amountMinorUnits" to authoritativePrizeMinor,
                "type" to "PRIZE_WIN",
                "direction" to "CREDIT",
                "status" to "COMPLETED",
                "timestamp" to now,
                "description" to "Won match $canonicalMatchNumber — Prize credited: ৳$prizeTaka"
            ),

            // Immutable audit log entry in /auditLogs/{deterministicLogId}
            "${FirebaseAdminConfig.NODE_AUDIT_LOGS}/$deterministicLogId" to mapOf(
                "action" to "MATCH_RESULT_APPROVED",
                "admin" to adminSession.identifier,
                "referenceId" to resultId,
                "matchId" to matchId,
                "timestamp" to now,
                "reason" to "Super Admin approved result for match $canonicalMatchNumber. Credited prize of ৳$prizeTaka to winner $userId",
                "amount" to authoritativePrizeMinor,
                "amountMinorUnits" to authoritativePrizeMinor,
                "userId" to userId,
                "transactionId" to deterministicTrxId
            )
        )

        // Ensure /results/{matchId}/{userId} and /userResults/{userId}/{matchId} are also set if resultId differs
        if (resultId != "$matchId/$userId") {
            updates["${FirebaseAdminConfig.NODE_RESULTS}/$matchId/$userId/status"] = ResultStatus.APPROVED.name
            updates["${FirebaseAdminConfig.NODE_RESULTS}/$matchId/$userId/reviewNotes"] = "Approved by Super Admin"
            updates["${FirebaseAdminConfig.NODE_RESULTS}/$matchId/$userId/proofLocked"] = true
            updates["${FirebaseAdminConfig.NODE_RESULTS}/$matchId/$userId/canResubmit"] = false
            updates["${FirebaseAdminConfig.NODE_RESULTS}/$matchId/$userId/proofScreenshotUrl"] = null
            updates["${FirebaseAdminConfig.NODE_RESULTS}/$matchId/$userId/screenshotUrl"] = null
            updates["${FirebaseAdminConfig.NODE_RESULTS}/$matchId/$userId/processedAt"] = now
            updates["${FirebaseAdminConfig.NODE_RESULTS}/$matchId/$userId/processedBy"] = adminSession.identifier
            updates["${FirebaseAdminConfig.NODE_RESULTS}/$matchId/$userId/settlementTransactionId"] = deterministicTrxId

            updates["$userResultsNodeKey/$userId/$matchId/status"] = ResultStatus.APPROVED.name
            updates["$userResultsNodeKey/$userId/$matchId/proofLocked"] = true
            updates["$userResultsNodeKey/$userId/$matchId/canResubmit"] = false
            updates["$userResultsNodeKey/$userId/$matchId/proofScreenshotUrl"] = null
            updates["$userResultsNodeKey/$userId/$matchId/screenshotUrl"] = null
            updates["$userResultsNodeKey/$userId/$matchId/processedAt"] = now
            updates["$userResultsNodeKey/$userId/$matchId/processedBy"] = adminSession.identifier
        }

        // Automatic Loser Handling updates:
        for (oppId in opponentUserIds) {
            // Update opponent status in /matchPlayers/{matchId}/{oppId}
            updates["${FirebaseAdminConfig.NODE_MATCH_PLAYERS}/$matchId/$oppId/status"] = "LOST"
            updates["${FirebaseAdminConfig.NODE_MATCH_PLAYERS}/$matchId/$oppId/isWinner"] = false
            updates["${FirebaseAdminConfig.NODE_MATCH_PLAYERS}/$matchId/$oppId/winner"] = false
            updates["${FirebaseAdminConfig.NODE_MATCH_PLAYERS}/$matchId/$oppId/proofLocked"] = true
            updates["${FirebaseAdminConfig.NODE_MATCH_PLAYERS}/$matchId/$oppId/canResubmit"] = false
            updates["${FirebaseAdminConfig.NODE_MATCH_PLAYERS}/$matchId/$oppId/updatedAt"] = now

            // Update user match record in /userMatches/{oppId}/{matchId}
            updates["userMatches/$oppId/$matchId/status"] = "LOST"
            updates["userMatches/$oppId/$matchId/isWinner"] = false
            updates["userMatches/$oppId/$matchId/updatedAt"] = now

            // If opponent also submitted proof at /results/{matchId}/{oppId}, set result status to LOST
            updates["${FirebaseAdminConfig.NODE_RESULTS}/$matchId/$oppId/status"] = ResultStatus.LOST.name
            updates["${FirebaseAdminConfig.NODE_RESULTS}/$matchId/$oppId/rawStatus"] = ResultStatus.LOST.name
            updates["${FirebaseAdminConfig.NODE_RESULTS}/$matchId/$oppId/reviewNotes"] = "Opponent was approved as the match winner."
            updates["${FirebaseAdminConfig.NODE_RESULTS}/$matchId/$oppId/proofScreenshotUrl"] = null
            updates["${FirebaseAdminConfig.NODE_RESULTS}/$matchId/$oppId/screenshotUrl"] = null
            updates["${FirebaseAdminConfig.NODE_RESULTS}/$matchId/$oppId/proofLocked"] = true
            updates["${FirebaseAdminConfig.NODE_RESULTS}/$matchId/$oppId/canResubmit"] = false
            updates["${FirebaseAdminConfig.NODE_RESULTS}/$matchId/$oppId/processedAt"] = now
            updates["${FirebaseAdminConfig.NODE_RESULTS}/$matchId/$oppId/processedBy"] = adminSession.identifier
            updates["${FirebaseAdminConfig.NODE_RESULTS}/$matchId/$oppId/updatedAt"] = now

            // Mirror to userResults
            updates["$userResultsNodeKey/$oppId/$matchId/status"] = ResultStatus.LOST.name
            updates["$userResultsNodeKey/$oppId/$matchId/reviewNotes"] = "Opponent was approved as the match winner."
            updates["$userResultsNodeKey/$oppId/$matchId/proofScreenshotUrl"] = null
            updates["$userResultsNodeKey/$oppId/$matchId/screenshotUrl"] = null
            updates["$userResultsNodeKey/$oppId/$matchId/proofLocked"] = true
            updates["$userResultsNodeKey/$oppId/$matchId/canResubmit"] = false
            updates["$userResultsNodeKey/$oppId/$matchId/processedAt"] = now
            updates["$userResultsNodeKey/$oppId/$matchId/processedBy"] = adminSession.identifier
        }

        db.reference.updateChildren(updates).await()

        // Step 6: Idempotent screenshot cleanup after primary financial & status settlement (never rolls back approval)
        try {
            db.getReference(FirebaseAdminConfig.NODE_RESULTS).child(resultId).child("proofScreenshotUrl").removeValue().await()
            db.getReference(FirebaseAdminConfig.NODE_RESULTS).child(resultId).child("screenshotUrl").removeValue().await()
            if (userId.isNotBlank()) {
                db.getReference(userResultsNodeKey).child(userId).child(resultId).child("proofScreenshotUrl").removeValue().await()
                db.getReference(userResultsNodeKey).child(userId).child(resultId).child("screenshotUrl").removeValue().await()
            }
            if (resultId != "$matchId/$userId") {
                db.getReference(FirebaseAdminConfig.NODE_RESULTS).child(matchId).child(userId).child("proofScreenshotUrl").removeValue().await()
                db.getReference(FirebaseAdminConfig.NODE_RESULTS).child(matchId).child(userId).child("screenshotUrl").removeValue().await()
            }
            for (oppId in opponentUserIds) {
                db.getReference(FirebaseAdminConfig.NODE_RESULTS).child(matchId).child(oppId).child("proofScreenshotUrl").removeValue().await()
                db.getReference(FirebaseAdminConfig.NODE_RESULTS).child(matchId).child(oppId).child("screenshotUrl").removeValue().await()
                db.getReference(userResultsNodeKey).child(oppId).child(matchId).child("proofScreenshotUrl").removeValue().await()
                db.getReference(userResultsNodeKey).child(oppId).child(matchId).child("screenshotUrl").removeValue().await()
            }
        } catch (e: Exception) {
            // Screenshot cleanup failure must never fail the successful financial settlement
        }

        // Step 7: Send notifications
        sendResultNotification(
            userId = userId,
            title = "Match Winning Prize Credited! / ম্যাচ বিজয়ী পুরস্কার যোগ হয়েছে",
            message = "Congratulations! You won match $canonicalMatchNumber. Prize of ৳$prizeTaka has been credited to your wallet balance.",
            adminSession = adminSession
        )

        for (oppId in opponentUserIds) {
            sendResultNotification(
                userId = oppId,
                title = "Match Concluded / ম্যাচ সমাপ্ত হয়েছে",
                message = "Match $canonicalMatchNumber has concluded. Winner: ${resultItem.userName.ifBlank { "Opponent" }}.",
                adminSession = adminSession
            )
        }
    }

    override suspend fun rejectResult(
        resultId: String,
        reason: String,
        adminSession: SuperAdminSession
    ): Result<Unit> = runCatching {
        verifySuperAdmin(adminSession)
        val trimmedReason = reason.trim()
        require(trimmedReason.isNotBlank()) { "Rejection reason is required." }

        val db = database

        if (db == null) {
            // In-memory offline/test execution path
            val resultItem = getResult(resultId)
                ?: throw IllegalArgumentException("Result submission '$resultId' does not exist.")

            if (resultItem.status == ResultStatus.APPROVED) {
                throw IllegalStateException("Result '$resultId' is already approved and settled.")
            }
            if (resultItem.status == ResultStatus.REJECTED) {
                throw IllegalStateException("Result '$resultId' is already rejected.")
            }

            val now = System.currentTimeMillis()
            val userId = resultItem.userId
            val matchId = resultItem.matchId

            val rejectedItem = resultItem.copy(
                status = ResultStatus.REJECTED,
                rawStatus = ResultStatus.REJECTED.name,
                proofScreenshotUrl = "",
                screenshotUrl = "",
                rejectionReason = trimmedReason,
                reviewNotes = trimmedReason,
                processedAt = now,
                processedBy = adminSession.identifier
            )
            _resultsMap[resultId] = rejectedItem
            _localResultsState.value = _resultsMap.values.toList()

            // Update in-memory match players if present
            if (matchId.isNotBlank() && _matchPlayersMap.containsKey(matchId)) {
                val updatedPlayers = _matchPlayersMap[matchId]?.map { p ->
                    if (p.userId == userId || p.uid == userId) {
                        p.copy(status = "REJECTED")
                    } else {
                        p
                    }
                }
                if (updatedPlayers != null) {
                    _matchPlayersMap[matchId] = updatedPlayers
                }
            }

            // STRICT AUDIT: DO NOT credit any prize or touch the user's wallet (_walletsMap)

            if (userId.isNotBlank()) {
                sendResultNotification(
                    userId = userId,
                    title = "Result Submission Rejected / রেজাল্ট বাতিল করা হয়েছে",
                    message = "Your result submission for match ${resultItem.matchNumber} was rejected. Reason: $trimmedReason",
                    adminSession = adminSession
                )
            }

            return@runCatching
        }

        // Production Firebase Realtime Database path
        val resultItem = getResult(resultId)
            ?: throw IllegalArgumentException("Result submission '$resultId' does not exist.")

        if (resultItem.status == ResultStatus.APPROVED) {
            throw IllegalStateException("Result '$resultId' is already approved and settled.")
        }
        if (resultItem.status == ResultStatus.REJECTED) {
            throw IllegalStateException("Result '$resultId' is already rejected.")
        }

        val now = System.currentTimeMillis()
        val userId = resultItem.userId
        val matchId = resultItem.matchId
        val sanitizedResultId = resultId.replace('/', '_')
        val deterministicLogId = "AUDIT_REJ_RES_${sanitizedResultId}"
        val userResultsNodeKey = "userResults"

        val updates = mutableMapOf<String, Any?>(
            // Primary node update on /results
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/status" to ResultStatus.REJECTED.name,
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/rawStatus" to ResultStatus.REJECTED.name,
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/rejectionReason" to trimmedReason,
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/reviewNotes" to trimmedReason,
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/proofLocked" to true,
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/canResubmit" to false,
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/proofScreenshotUrl" to null,
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/screenshotUrl" to null,
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/processedAt" to now,
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/processedBy" to adminSession.identifier,
            "${FirebaseAdminConfig.NODE_RESULTS}/$resultId/updatedAt" to now,

            "${FirebaseAdminConfig.NODE_AUDIT_LOGS}/$deterministicLogId" to mapOf(
                "action" to "MATCH_RESULT_REJECTED",
                "admin" to adminSession.identifier,
                "referenceId" to resultId,
                "matchId" to matchId,
                "userId" to userId,
                "timestamp" to now,
                "reason" to "Super Admin rejected result submission for user $userId (Match: $matchId). Reason: $trimmedReason"
            )
        )

        // If resultId is not in matchId/userId format, also sync /results/{matchId}/{userId}
        if (matchId.isNotBlank() && userId.isNotBlank() && resultId != "$matchId/$userId") {
            updates["${FirebaseAdminConfig.NODE_RESULTS}/$matchId/$userId/status"] = ResultStatus.REJECTED.name
            updates["${FirebaseAdminConfig.NODE_RESULTS}/$matchId/$userId/rawStatus"] = ResultStatus.REJECTED.name
            updates["${FirebaseAdminConfig.NODE_RESULTS}/$matchId/$userId/rejectionReason"] = trimmedReason
            updates["${FirebaseAdminConfig.NODE_RESULTS}/$matchId/$userId/reviewNotes"] = trimmedReason
            updates["${FirebaseAdminConfig.NODE_RESULTS}/$matchId/$userId/proofLocked"] = true
            updates["${FirebaseAdminConfig.NODE_RESULTS}/$matchId/$userId/canResubmit"] = false
            updates["${FirebaseAdminConfig.NODE_RESULTS}/$matchId/$userId/proofScreenshotUrl"] = null
            updates["${FirebaseAdminConfig.NODE_RESULTS}/$matchId/$userId/screenshotUrl"] = null
            updates["${FirebaseAdminConfig.NODE_RESULTS}/$matchId/$userId/processedAt"] = now
            updates["${FirebaseAdminConfig.NODE_RESULTS}/$matchId/$userId/processedBy"] = adminSession.identifier
            updates["${FirebaseAdminConfig.NODE_RESULTS}/$matchId/$userId/updatedAt"] = now
        }

        // Lock proof submission on /matchPlayers/{matchId}/{userId}
        if (matchId.isNotBlank() && userId.isNotBlank()) {
            updates["${FirebaseAdminConfig.NODE_MATCH_PLAYERS}/$matchId/$userId/proofLocked"] = true
            updates["${FirebaseAdminConfig.NODE_MATCH_PLAYERS}/$matchId/$userId/canResubmit"] = false
            updates["${FirebaseAdminConfig.NODE_MATCH_PLAYERS}/$matchId/$userId/updatedAt"] = now
        }

        // User results mirrors
        if (userId.isNotBlank()) {
            updates["$userResultsNodeKey/$userId/$resultId/status"] = ResultStatus.REJECTED.name
            updates["$userResultsNodeKey/$userId/$resultId/rejectionReason"] = trimmedReason
            updates["$userResultsNodeKey/$userId/$resultId/reviewNotes"] = trimmedReason
            updates["$userResultsNodeKey/$userId/$resultId/proofLocked"] = true
            updates["$userResultsNodeKey/$userId/$resultId/canResubmit"] = false
            updates["$userResultsNodeKey/$userId/$resultId/proofScreenshotUrl"] = null
            updates["$userResultsNodeKey/$userId/$resultId/screenshotUrl"] = null
            updates["$userResultsNodeKey/$userId/$resultId/processedAt"] = now
            updates["$userResultsNodeKey/$userId/$resultId/processedBy"] = adminSession.identifier

            if (matchId.isNotBlank() && resultId != matchId) {
                updates["$userResultsNodeKey/$userId/$matchId/status"] = ResultStatus.REJECTED.name
                updates["$userResultsNodeKey/$userId/$matchId/rejectionReason"] = trimmedReason
                updates["$userResultsNodeKey/$userId/$matchId/reviewNotes"] = trimmedReason
                updates["$userResultsNodeKey/$userId/$matchId/proofLocked"] = true
                updates["$userResultsNodeKey/$userId/$matchId/canResubmit"] = false
                updates["$userResultsNodeKey/$userId/$matchId/proofScreenshotUrl"] = null
                updates["$userResultsNodeKey/$userId/$matchId/screenshotUrl"] = null
                updates["$userResultsNodeKey/$userId/$matchId/processedAt"] = now
                updates["$userResultsNodeKey/$userId/$matchId/processedBy"] = adminSession.identifier
            }
        }

        // STRICT AUDIT: DO NOT credit any prize or touch the user's wallet (/wallets/{userId})
        db.reference.updateChildren(updates).await()

        // Clean up screenshots
        try {
            db.getReference(FirebaseAdminConfig.NODE_RESULTS).child(resultId).child("proofScreenshotUrl").removeValue().await()
            db.getReference(FirebaseAdminConfig.NODE_RESULTS).child(resultId).child("screenshotUrl").removeValue().await()
            if (matchId.isNotBlank() && userId.isNotBlank() && resultId != "$matchId/$userId") {
                db.getReference(FirebaseAdminConfig.NODE_RESULTS).child(matchId).child(userId).child("proofScreenshotUrl").removeValue().await()
                db.getReference(FirebaseAdminConfig.NODE_RESULTS).child(matchId).child(userId).child("screenshotUrl").removeValue().await()
            }
            if (userId.isNotBlank()) {
                db.getReference(userResultsNodeKey).child(userId).child(resultId).child("proofScreenshotUrl").removeValue().await()
                db.getReference(userResultsNodeKey).child(userId).child(resultId).child("screenshotUrl").removeValue().await()
            }
        } catch (e: Exception) {
            // Ignore non-critical cleanup errors
        }

        // Send notification
        if (userId.isNotBlank()) {
            sendResultNotification(
                userId = userId,
                title = "Result Submission Rejected / রেজাল্ট বাতিল করা হয়েছে",
                message = "Your result submission for match ${resultItem.matchNumber} was rejected. Reason: $trimmedReason",
                adminSession = adminSession
            )
        }
    }

    private suspend fun sendResultNotification(
        userId: String,
        title: String,
        message: String,
        adminSession: SuperAdminSession
    ) {
        try {
            val notifRepo = FirebaseNotificationsRepository()
            notifRepo.sendNotification(
                title = title,
                message = message,
                targetType = NotificationTargetType.SPECIFIC_USER,
                targetId = userId,
                adminSession = adminSession
            )
        } catch (e: Exception) {
            // Non-critical notification failure must never block financial operations
        }
    }

    private suspend fun executeMatchCompletionLockTransaction(
        matchRef: DatabaseReference,
        winnerUserId: String,
        now: Long
    ): MatchCompletionLockResult = suspendCancellableCoroutine { continuation ->
        matchRef.runTransaction(object : Transaction.Handler {
            var failureMessage: String? = null
            var wasAlreadyCompleted = false

            override fun doTransaction(currentData: MutableData): Transaction.Result {
                if (currentData.value == null) {
                    failureMessage = "Match record does not exist on database."
                    return Transaction.abort()
                }

                val currentStatus = currentData.child("status").value?.toString() ?: ""
                val currentWinner = currentData.child("winnerUserId").value?.toString() ?: ""

                if (currentStatus.equals("COMPLETED", ignoreCase = true) || currentWinner.isNotBlank()) {
                    wasAlreadyCompleted = true
                    failureMessage = "Match is already COMPLETED or winner is already settled."
                    return Transaction.abort()
                }

                currentData.child("status").value = "COMPLETED"
                currentData.child("winnerUserId").value = winnerUserId
                currentData.child("updatedAt").value = now

                return Transaction.success(currentData)
            }

            override fun onComplete(
                error: DatabaseError?,
                committed: Boolean,
                currentData: DataSnapshot?
            ) {
                if (committed && error == null) {
                    continuation.resume(MatchCompletionLockResult(success = true))
                } else {
                    continuation.resume(
                        MatchCompletionLockResult(
                            success = false,
                            alreadyCompleted = wasAlreadyCompleted,
                            errorMessage = error?.message ?: failureMessage ?: "Match completion lock transaction aborted."
                        )
                    )
                }
            }
        })
    }

    private suspend fun executeResultApprovalLockTransaction(
        resultRef: DatabaseReference,
        adminSession: SuperAdminSession,
        settlementTrxId: String,
        authoritativePrizeMinor: Long,
        now: Long
    ): ResultApprovalResult = suspendCancellableCoroutine { continuation ->
        resultRef.runTransaction(object : Transaction.Handler {
            var failureMessage: String? = null
            var wasAlreadySettled = false

            override fun doTransaction(currentData: MutableData): Transaction.Result {
                if (currentData.value == null) {
                    failureMessage = "Result submission record does not exist on database."
                    return Transaction.abort()
                }

                val currentStatusStr = currentData.child("status").value?.toString()
                val currentStatus = ResultStatus.fromString(currentStatusStr)

                if (currentStatus == ResultStatus.APPROVED) {
                    wasAlreadySettled = true
                    failureMessage = "Result is already APPROVED and settled."
                    return Transaction.abort()
                }

                if (currentStatus == ResultStatus.REJECTED) {
                    wasAlreadySettled = true
                    failureMessage = "Result is ALREADY REJECTED."
                    return Transaction.abort()
                }

                currentData.child("status").value = ResultStatus.APPROVED.name
                currentData.child("reviewNotes").value = "Approved by Super Admin"
                currentData.child("proofLocked").value = true
                currentData.child("canResubmit").value = false
                currentData.child("processedAt").value = now
                currentData.child("processedBy").value = adminSession.identifier
                currentData.child("updatedAt").value = now
                currentData.child("settlementTransactionId").value = settlementTrxId
                currentData.child("settledPrizeMinorUnits").value = authoritativePrizeMinor

                return Transaction.success(currentData)
            }

            override fun onComplete(
                error: DatabaseError?,
                committed: Boolean,
                currentData: DataSnapshot?
            ) {
                if (committed && error == null) {
                    continuation.resume(ResultApprovalResult(success = true))
                } else {
                    continuation.resume(
                        ResultApprovalResult(
                            success = false,
                            alreadySettled = wasAlreadySettled,
                            errorMessage = error?.message ?: failureMessage ?: "Result approval lock transaction aborted."
                        )
                    )
                }
            }
        })
    }

    private suspend fun executeWalletPrizeCreditTransaction(
        walletRef: DatabaseReference,
        resultId: String,
        matchId: String,
        prizeMinorUnits: Long,
        now: Long
    ): WalletPrizeCreditResult = suspendCancellableCoroutine { continuation ->
        walletRef.runTransaction(object : Transaction.Handler {
            var failureMessage: String? = null
            var creditResult: WalletPrizeCreditResult? = null

            override fun doTransaction(currentData: MutableData): Transaction.Result {
                // Idempotency check: verify if this resultId or matchId was already credited to the wallet
                val creditedResultsNode = currentData.child("creditedResults")
                val matchKey = if (matchId.isNotBlank()) "MATCH_$matchId" else ""
                if (creditedResultsNode.hasChild(resultId) || (matchKey.isNotBlank() && creditedResultsNode.hasChild(matchKey))) {
                    creditResult = WalletPrizeCreditResult(
                        success = true,
                        alreadySettled = true,
                        newBalance = (currentData.child("balance").value as? Number)?.toLong() ?: 0L,
                        newWinningBalance = (currentData.child("winningBalance").value as? Number)?.toLong() ?: 0L
                    )
                    return Transaction.abort()
                }

                val currentBalance = (currentData.child("balance").value as? Number)?.toLong() ?: 0L
                val currentAvailable = (currentData.child("availableBalance").value as? Number)?.toLong() ?: currentBalance
                val currentWinning = (currentData.child("winningBalance").value as? Number)?.toLong() ?: 0L
                val currentPending = (currentData.child("pendingBalance").value as? Number)?.toLong() ?: 0L

                val newAvailable = currentAvailable + prizeMinorUnits
                val newWinning = currentWinning + prizeMinorUnits
                val newBalance = newAvailable + currentPending

                currentData.child("balance").value = newBalance
                currentData.child("availableBalance").value = newAvailable
                currentData.child("winningBalance").value = newWinning
                currentData.child("balanceDouble").value = newBalance / 100.0
                currentData.child("updatedAt").value = now

                // Mark resultId and matchKey as settled inside wallet
                currentData.child("creditedResults").child(resultId).value = mapOf(
                    "resultId" to resultId,
                    "matchId" to matchId,
                    "prizeMinorUnits" to prizeMinorUnits,
                    "creditedAt" to now
                )
                if (matchKey.isNotBlank()) {
                    currentData.child("creditedResults").child(matchKey).value = mapOf(
                        "resultId" to resultId,
                        "matchId" to matchId,
                        "prizeMinorUnits" to prizeMinorUnits,
                        "creditedAt" to now
                    )
                }

                creditResult = WalletPrizeCreditResult(
                    success = true,
                    alreadySettled = false,
                    newBalance = newBalance,
                    newWinningBalance = newWinning
                )

                return Transaction.success(currentData)
            }

            override fun onComplete(
                error: DatabaseError?,
                committed: Boolean,
                currentData: DataSnapshot?
            ) {
                if (committed && error == null) {
                    continuation.resume(creditResult ?: WalletPrizeCreditResult(success = true))
                } else {
                    continuation.resume(
                        creditResult ?: WalletPrizeCreditResult(
                            success = false,
                            errorMessage = error?.message ?: failureMessage ?: "Wallet prize credit transaction failed."
                        )
                    )
                }
            }
        })
    }
}

data class MatchCompletionLockResult(
    val success: Boolean,
    val alreadyCompleted: Boolean = false,
    val errorMessage: String? = null
)

data class WalletPrizeCreditResult(
    val success: Boolean,
    val alreadySettled: Boolean = false,
    val newBalance: Long = 0L,
    val newWinningBalance: Long = 0L,
    val errorMessage: String? = null
)
