package com.example

import com.example.core.model.AdminDepositItem
import com.example.core.model.AdminMatchItem
import com.example.core.model.CreateMatchRequest
import com.example.core.model.DepositStatus
import com.example.core.model.MatchStatus
import com.example.core.model.PaymentNumberItem
import com.example.core.model.SuperAdminSession
import com.example.core.model.TournamentMath
import com.example.core.repository.FirebaseDepositsRepository
import com.example.core.repository.FirebaseSettingsRepository
import com.example.core.repository.FirebaseUsersRepository
import com.example.core.repository.InMemoryMatchesRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testDeleteMatchPermanently() = runBlocking {
    val repo = InMemoryMatchesRepository()
    val superAdminSession = SuperAdminSession(
      uid = "GuIxwtI4hLQIoKOOt3V2XKnFhiB2",
      identifier = "superadmin@example.com",
      isSuperAdminVerified = true
    )

    // Create a match
    val createResult = repo.createSingleMatch(
      CreateMatchRequest(
        gameType = "LUDO",
        matchNumber = "TEST-999",
        title = "Test Elimination Fixture",
        entryFeeTaka = 50,
        scheduledTimestamp = System.currentTimeMillis() + 3600000L
      ),
      superAdminSession
    )
    assertTrue("Match creation should succeed", createResult.isSuccess)
    val matchId = createResult.getOrThrow()

    // Verify it is present in flow
    val matchesBefore = repo.observeMatches().first()
    assertTrue(matchesBefore.any { it.matchId == matchId })

    // Permanently delete match
    val deleteResult = repo.deleteMatchPermanently(matchId, superAdminSession)
    assertTrue("Delete match should succeed", deleteResult.isSuccess)

    // Verify it has been permanently removed
    val matchesAfter = repo.observeMatches().first()
    assertFalse("Deleted match should no longer be present", matchesAfter.any { it.matchId == matchId })
  }

  @Test
  fun testRoomCodeInjectionAndStatusUpdate() = runBlocking {
    val repo = InMemoryMatchesRepository()
    val superAdminSession = SuperAdminSession(
      uid = "GuIxwtI4hLQIoKOOt3V2XKnFhiB2",
      identifier = "superadmin@example.com",
      isSuperAdminVerified = true
    )

    // Create match
    val createResult = repo.createSingleMatch(
      CreateMatchRequest(
        gameType = "LUDO",
        matchNumber = "TEST-100",
        title = "Room Code Test Match",
        entryFeeTaka = 50,
        scheduledTimestamp = System.currentTimeMillis() + 3600000L
      ),
      superAdminSession
    )
    assertTrue(createResult.isSuccess)
    val matchId = createResult.getOrThrow()

    // Transition to FULL status (simulating 2 players joined)
    val statusResult = repo.updateMatchStatus(matchId, MatchStatus.FULL, "2/2 joined", superAdminSession)
    assertTrue(statusResult.isSuccess)

    val matchFull = repo.observeMatches().first().first { it.matchId == matchId }
    assertTrue("FULL match with blank code should flag needsRoomCode", matchFull.needsRoomCode)

    // Admin injects game room code
    val codeResult = repo.setMatchGameCode(matchId, "982341", superAdminSession)
    assertTrue("Room code injection should succeed", codeResult.isSuccess)

    val matchWithCode = repo.observeMatches().first().first { it.matchId == matchId }
    assertEquals("982341", matchWithCode.gameCode)
    assertEquals(MatchStatus.CODE_ADDED, matchWithCode.status)
    assertFalse("Match with room code should no longer need room code", matchWithCode.needsRoomCode)
  }

  @Test
  fun testPaymentNumberManagement() = runBlocking {
    val settingsRepo = FirebaseSettingsRepository()
    val superAdminSession = SuperAdminSession(
      uid = "GuIxwtI4hLQIoKOOt3V2XKnFhiB2",
      identifier = "01700000000",
      isSuperAdminVerified = true
    )

    // Verify initial payment numbers exist
    val initialNumbers = settingsRepo.observePaymentNumbers().first()
    assertTrue("Should contain seeded payment numbers", initialNumbers.isNotEmpty())

    // Add a new Nagad Merchant payment number
    val newNumber = PaymentNumberItem(
      id = "test_nagad_merchant_01",
      method = "Nagad",
      number = "01855667788",
      type = "Merchant",
      isActive = true,
      instructions = "Merchant payment with tournament TrxID"
    )
    val saveResult = settingsRepo.savePaymentNumber(newNumber, superAdminSession)
    assertTrue("Saving payment number should succeed", saveResult.isSuccess)

    val numbersAfterAdd = settingsRepo.observePaymentNumbers().first()
    val addedItem = numbersAfterAdd.firstOrNull { it.id == "test_nagad_merchant_01" }
    assertNotNull("Added payment number should be present in flow", addedItem)
    assertEquals("01855667788", addedItem?.number)
    assertEquals("Merchant", addedItem?.type)
    assertTrue(addedItem?.isActive == true)

    // Toggle active status to inactive
    val toggleResult = settingsRepo.togglePaymentNumberActive("test_nagad_merchant_01", false, superAdminSession)
    assertTrue("Toggling payment number active should succeed", toggleResult.isSuccess)

    val numbersAfterToggle = settingsRepo.observePaymentNumbers().first()
    val toggledItem = numbersAfterToggle.firstOrNull { it.id == "test_nagad_merchant_01" }
    assertFalse("Payment number should now be inactive", toggledItem?.isActive ?: true)

    // Delete the payment number
    val deleteResult = settingsRepo.removePaymentNumber(
      id = "test_nagad_merchant_01",
      method = "Nagad",
      number = "01855667788",
      adminSession = superAdminSession
    )
    assertTrue("Deleting payment number should succeed", deleteResult.isSuccess)

    val numbersAfterDelete = settingsRepo.observePaymentNumbers().first()
    assertNull("Deleted payment number should no longer exist", numbersAfterDelete.firstOrNull { it.id == "test_nagad_merchant_01" })
  }

  @Test
  fun testUsersDirectoryAndBanUnban() = runBlocking {
    val usersRepo = FirebaseUsersRepository()
    val superAdminSession = SuperAdminSession(
      uid = "GuIxwtI4hLQIoKOOt3V2XKnFhiB2",
      identifier = "01700000000",
      isSuperAdminVerified = true
    )

    // Observe users list
    val users = usersRepo.observeUsers().first()
    assertTrue("Users list should not be empty", users.isNotEmpty())

    val targetUser = users.first { it.isActive }
    val targetUid = targetUser.uid

    // Ban the user
    val banReason = "Suspicious multi-accounting detected"
    val banResult = usersRepo.toggleUserBan(
      uid = targetUid,
      shouldBan = true,
      reason = banReason,
      adminSession = superAdminSession
    )
    assertTrue("Banning user should succeed", banResult.isSuccess)

    val usersAfterBan = usersRepo.observeUsers().first()
    val bannedUser = usersAfterBan.first { it.uid == targetUid }
    assertTrue("User should be flagged as banned", bannedUser.isBanned)
    assertEquals("BANNED", bannedUser.status)
    assertEquals(banReason, bannedUser.banReason)

    // Unban the user
    val unbanResult = usersRepo.toggleUserBan(
      uid = targetUid,
      shouldBan = false,
      reason = "Admin review cleared player",
      adminSession = superAdminSession
    )
    assertTrue("Unbanning user should succeed", unbanResult.isSuccess)

    val usersAfterUnban = usersRepo.observeUsers().first()
    val restoredUser = usersAfterUnban.first { it.uid == targetUid }
    assertFalse("User should no longer be banned", restoredUser.isBanned)
    assertEquals("ACTIVE", restoredUser.status)
    assertTrue(restoredUser.isActive)
  }

  @Test
  fun testDepositApprovalBalanceCalculation() = runBlocking {
    val depositsRepo = FirebaseDepositsRepository()
    val superAdminSession = SuperAdminSession(
      uid = "GuIxwtI4hLQIoKOOt3V2XKnFhiB2",
      identifier = "01700000000",
      isSuperAdminVerified = true
    )

    // Observe initial deposits
    val deposits = depositsRepo.observeDeposits().first()
    val pendingDeposit = deposits.first { it.status == DepositStatus.PENDING && it.userId == "usr_tanvir_9812" }
    val initialWallet = depositsRepo.getWallet(pendingDeposit.userId)
    assertNotNull("Target user wallet should exist", initialWallet)

    val initialBalance = initialWallet!!.balance
    val initialAvailable = initialWallet.availableBalance
    val initialDepositBalance = initialWallet.depositBalance
    val initialTotalDeposited = initialWallet.totalDeposited
    val depositAmount = pendingDeposit.amountTaka

    // Approve the pending deposit
    val approveResult = depositsRepo.approveDeposit(pendingDeposit.id, superAdminSession)
    assertTrue("Deposit approval should succeed", approveResult.isSuccess)

    // Verify deposit status updated to APPROVED
    val updatedDeposits = depositsRepo.observeDeposits().first()
    val approvedItem = updatedDeposits.first { it.id == pendingDeposit.id }
    assertEquals(DepositStatus.APPROVED, approvedItem.status)
    assertTrue(approvedItem.isApproved)
    assertNotNull("Processed timestamp must be set", approvedItem.processedAt)
    assertEquals(superAdminSession.identifier, approvedItem.processedBy)

    // Verify wallet balances incremented directly by exact deposit amount
    val updatedWallet = depositsRepo.getWallet(pendingDeposit.userId)
    assertNotNull(updatedWallet)
    assertEquals(initialBalance + depositAmount, updatedWallet!!.balance)
    assertEquals(initialAvailable + depositAmount, updatedWallet.availableBalance)
    assertEquals(initialDepositBalance + depositAmount, updatedWallet.depositBalance)
    assertEquals(initialTotalDeposited + depositAmount, updatedWallet.totalDeposited)

    // Verify minor units calculation consistency via TournamentMath
    val expectedMinorUnits = TournamentMath.takaToMinorUnits(depositAmount)
    assertEquals(expectedMinorUnits, pendingDeposit.amountMinorUnits)

    // Verify cannot re-approve an already approved deposit
    val secondApproveResult = depositsRepo.approveDeposit(pendingDeposit.id, superAdminSession)
    assertFalse("Re-approving an already approved deposit must fail", secondApproveResult.isSuccess)
  }

  @Test
  fun testDepositRejectionFlow() = runBlocking {
    val depositsRepo = FirebaseDepositsRepository()
    val superAdminSession = SuperAdminSession(
      uid = "GuIxwtI4hLQIoKOOt3V2XKnFhiB2",
      identifier = "01700000000",
      isSuperAdminVerified = true
    )

    val deposits = depositsRepo.observeDeposits().first()
    val pendingDeposit = deposits.first { it.status == DepositStatus.PENDING && it.userId == "usr_shakib_4412" }
    val initialWallet = depositsRepo.getWallet(pendingDeposit.userId)
    assertNotNull(initialWallet)
    val balanceBefore = initialWallet!!.balance

    // Reject with a reason
    val rejectionReason = "TrxID 4M2K91823B not found in Nagad merchant ledger"
    val rejectResult = depositsRepo.rejectDeposit(pendingDeposit.id, rejectionReason, superAdminSession)
    assertTrue("Deposit rejection should succeed", rejectResult.isSuccess)

    // Verify deposit status is REJECTED with reason recorded
    val updatedDeposits = depositsRepo.observeDeposits().first()
    val rejectedItem = updatedDeposits.first { it.id == pendingDeposit.id }
    assertEquals(DepositStatus.REJECTED, rejectedItem.status)
    assertTrue(rejectedItem.isRejected)
    assertEquals(rejectionReason, rejectedItem.rejectionReason)

    // Verify wallet balance was NOT altered
    val walletAfter = depositsRepo.getWallet(pendingDeposit.userId)
    assertEquals("Wallet balance must remain unchanged on rejection", balanceBefore, walletAfter!!.balance)
  }

  @Test
  fun testTutorialAndBannerSettings() = runBlocking {
    val settingsRepo = FirebaseSettingsRepository()
    val superAdminSession = SuperAdminSession(
      uid = "GuIxwtI4hLQIoKOOt3V2XKnFhiB2",
      identifier = "01700000000",
      isSuperAdminVerified = true
    )

    val joinUrl = "https://youtube.com/watch?v=join123"
    val depositUrl = "https://youtube.com/watch?v=deposit456"
    val submitUrl = "https://youtube.com/watch?v=submit789"
    val rulesUrl = "https://youtube.com/watch?v=rules000"
    val bannerUrl = "https://cdn.example.com/banner_3d_promo.png"

    // Save tutorial video and custom banner settings
    val saveResult = settingsRepo.saveTutorialAndBannerSettings(
      howToJoinVideoUrl = joinUrl,
      howToDepositVideoUrl = depositUrl,
      howToSubmitResultVideoUrl = submitUrl,
      tournamentRulesVideoUrl = rulesUrl,
      customBannerImageUrl = bannerUrl,
      adminSession = superAdminSession
    )
    assertTrue("Saving tutorial & banner settings must succeed", saveResult.isSuccess)

    // Verify /appSettings reflects saved URLs
    val settingsAfterSave = settingsRepo.observeAppSettings().first()
    assertEquals(joinUrl, settingsAfterSave.howToJoinVideoUrl)
    assertEquals(depositUrl, settingsAfterSave.howToDepositVideoUrl)
    assertEquals(submitUrl, settingsAfterSave.howToSubmitResultVideoUrl)
    assertEquals(rulesUrl, settingsAfterSave.tournamentRulesVideoUrl)
    assertEquals(bannerUrl, settingsAfterSave.customBannerImageUrl)

    // Test unauthorized access prevention
    val unverifiedSession = SuperAdminSession(
      uid = "unverified_user",
      identifier = "intruder",
      isSuperAdminVerified = false
    )
    val unauthorizedResult = settingsRepo.saveTutorialAndBannerSettings(
      howToJoinVideoUrl = "https://malicious.com",
      howToDepositVideoUrl = "",
      howToSubmitResultVideoUrl = "",
      tournamentRulesVideoUrl = "",
      customBannerImageUrl = "",
      adminSession = unverifiedSession
    )
    assertFalse("Unverified session must be blocked", unauthorizedResult.isSuccess)

    // Clear / Reset settings
    val resetResult = settingsRepo.saveTutorialAndBannerSettings(
      howToJoinVideoUrl = "",
      howToDepositVideoUrl = "",
      howToSubmitResultVideoUrl = "",
      tournamentRulesVideoUrl = "",
      customBannerImageUrl = "",
      adminSession = superAdminSession
    )
    assertTrue("Clearing settings should succeed", resetResult.isSuccess)

    val settingsAfterReset = settingsRepo.observeAppSettings().first()
    assertEquals("", settingsAfterReset.howToJoinVideoUrl)
    assertEquals("", settingsAfterReset.howToDepositVideoUrl)
    assertEquals("", settingsAfterReset.howToSubmitResultVideoUrl)
    assertEquals("", settingsAfterReset.tournamentRulesVideoUrl)
    assertEquals("", settingsAfterReset.customBannerImageUrl)
  }
}
