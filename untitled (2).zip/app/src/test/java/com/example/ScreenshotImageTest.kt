package com.example

import com.example.core.model.AdminResultItem
import com.example.core.model.ResultStatus
import com.example.core.util.ScreenshotImageUtils
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ScreenshotImageTest {

    // Valid 1x1 transparent PNG data URI
    private val validPngDataUri = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=="

    @Test
    fun testValidBase64DataUriDecodesToBitmap() {
        val bitmap = ScreenshotImageUtils.decodeBase64ToBitmap(validPngDataUri)
        assertNotNull("Bitmap must decode successfully from valid Base64 data URI", bitmap)
        assertEquals(1, bitmap!!.width)
        assertEquals(1, bitmap.height)
    }

    @Test
    fun testResultModelBindsProofScreenshotUrlCorrectly() {
        val result = AdminResultItem(
            resultId = "res_test_99",
            matchId = "match_test_99",
            matchNumber = "#42",
            userName = "TestPlayer",
            proofScreenshotUrl = validPngDataUri,
            status = ResultStatus.PENDING
        )

        assertEquals(validPngDataUri, result.proofScreenshotUrl)
        assertEquals(validPngDataUri, result.effectiveScreenshotUrl)
        assertTrue(result.hasScreenshot)
        assertTrue(result.isPending)
    }

    @Test
    fun testMissingScreenshotHandledSafely() {
        val emptyItem = AdminResultItem(resultId = "res_test_empty")
        assertFalse(emptyItem.hasScreenshot)
        assertEquals("", emptyItem.effectiveScreenshotUrl)

        assertNull(ScreenshotImageUtils.decodeBase64ToBitmap(""))
        assertNull(ScreenshotImageUtils.decodeBase64ToBitmap("   "))
        assertNull(ScreenshotImageUtils.decodeBase64ToBitmap(null))
    }

    @Test
    fun testInvalidScreenshotHandledSafely() {
        val malformedDataUri = "data:image/jpeg;base64,this_is_not_valid_base64_image_data_!!!"
        val bitmap = ScreenshotImageUtils.decodeBase64ToBitmap(malformedDataUri)
        assertNull("Corrupt Base64 data must return null bitmap without crashing", bitmap)

        val nonImageDataUri = "data:image/png;base64,SGVsbG8gV29ybGQ=" // "Hello World" in base64 (not a valid image)
        val textBitmap = ScreenshotImageUtils.decodeBase64ToBitmap(nonImageDataUri)
        assertNull("Non-image base64 payload must return null bitmap without crashing", textBitmap)
    }
}
