package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.core.model.AdminMatchItem
import com.example.core.model.BulkMatchPreviewItem
import com.example.core.model.BulkMatchRequest
import com.example.core.model.CreateMatchRequest
import com.example.core.model.MatchPlayerDetails
import com.example.core.model.MatchStatus
import com.example.core.model.MatchSummary
import com.example.core.model.TournamentMath
import com.example.navigation.AdminSection
import com.example.ui.components.SectionHeader
import com.example.ui.theme.CyanLight
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.NavyBorder
import com.example.ui.theme.NavyDeepest
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavySurfaceElevated
import com.example.ui.theme.NavySurfaceHighlight
import com.example.ui.theme.StatusLive
import com.example.ui.theme.StatusPending
import com.example.ui.theme.StatusRejected
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextOnGold
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun MatchesScreen(
    modifier: Modifier = Modifier,
    viewModel: MatchesViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedGameFilter by viewModel.selectedGameFilter.collectAsState()
    val selectedStatusFilter by viewModel.selectedStatusFilter.collectAsState()
    val isActionRequiredFilterActive by viewModel.isActionRequiredFilterActive.collectAsState()
    val selectedMatch by viewModel.selectedMatch.collectAsState()
    val selectedMatchPlayers by viewModel.selectedMatchPlayers.collectAsState()
    val actionDialogState by viewModel.actionDialogState.collectAsState()
    val roomCodeDialogMatch by viewModel.roomCodeDialogMatch.collectAsState()
    val isCreateDialogOpen by viewModel.isCreateDialogOpen.collectAsState()
    val isBulkDialogOpen by viewModel.isBulkDialogOpen.collectAsState()
    val deleteConfirmMatch by viewModel.deleteConfirmMatch.collectAsState()
    val operationFeedback by viewModel.operationFeedback.collectAsState()
    val isMutating by viewModel.isMutating.collectAsState()

    val context = LocalContext.current
    LaunchedEffect(operationFeedback) {
        operationFeedback?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            viewModel.clearFeedback()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(NavyDeepest)
            .testTag("matches_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            // Header
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SectionHeader(
                    title = "Matches",
                    subtitle = "1v1 Tournament Coordination & Management",
                    icon = AdminSection.MATCHES.icon
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action Bar: Create Single & Bulk Match
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { viewModel.openCreateDialog() },
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("create_match_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = TextOnGold),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Create Match", fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = { viewModel.openBulkDialog() },
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("bulk_matches_button"),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CyanSecondary),
                    border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(CyanSecondary)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Layers, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Bulk Matches", fontWeight = FontWeight.SemiBold)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            when (val state = uiState) {
                is MatchesUiState.Loading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = GoldPrimary)
                    }
                }
                is MatchesUiState.Error -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = StatusRejected, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(state.message, color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
                is MatchesUiState.Success -> {
                    MatchesContent(
                        summary = state.summary,
                        filteredMatches = state.filteredMatches,
                        totalMatchesCount = state.matches.size,
                        searchQuery = searchQuery,
                        selectedGameFilter = selectedGameFilter,
                        selectedStatusFilter = selectedStatusFilter,
                        isActionRequiredFilterActive = isActionRequiredFilterActive,
                        onSearchChange = { viewModel.setSearchQuery(it) },
                        onGameFilterChange = { viewModel.setGameFilter(it) },
                        onStatusFilterChange = { viewModel.setStatusFilter(it) },
                        onToggleActionRequiredFilter = { viewModel.toggleActionRequiredFilter() },
                        onClearFilters = { viewModel.clearFilters() },
                        onSelectMatch = { viewModel.selectMatch(it) },
                        onActionClick = { match, targetStatus -> viewModel.openActionDialog(match, targetStatus) },
                        onEnterRoomCode = { match -> viewModel.openRoomCodeDialog(match) },
                        onDeleteClick = { match -> viewModel.requestDeleteMatch(match) }
                    )
                }
            }
        }

        // Mutation loading overlay
        if (isMutating) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.5f)),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = NavySurfaceElevated),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(GoldPrimary))
                ) {
                    Row(
                        modifier = Modifier.padding(20.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CircularProgressIndicator(color = GoldPrimary, modifier = Modifier.size(24.dp))
                        Text("Processing match operation...", color = TextPrimary, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }

        // Modals / Dialogs
        roomCodeDialogMatch?.let { match ->
            RoomCodeInjectionDialog(
                match = match,
                onDismiss = { viewModel.closeRoomCodeDialog() },
                onSubmit = { code -> viewModel.addOrEditGameCode(match.matchId, code) }
            )
        }

        selectedMatch?.let { match ->
            MatchDetailsDialog(
                match = match,
                players = selectedMatchPlayers,
                onDismiss = { viewModel.selectMatch(null) },
                onSaveGameCode = { code -> viewModel.addOrEditGameCode(match.matchId, code) },
                onOpenRoomCodeDialog = { viewModel.openRoomCodeDialog(match) },
                onActionTrigger = { status -> viewModel.openActionDialog(match, status) },
                onDeleteTrigger = { viewModel.requestDeleteMatch(match) }
            )
        }

        deleteConfirmMatch?.let { match ->
            DeleteMatchConfirmDialog(
                match = match,
                onDismiss = { viewModel.dismissDeleteDialog() },
                onConfirm = { viewModel.deleteMatchPermanently(match.matchId) }
            )
        }

        actionDialogState?.let { state ->
            MatchActionConfirmDialog(
                match = state.match,
                targetStatus = state.targetStatus,
                onDismiss = { viewModel.closeActionDialog() },
                onConfirm = { reason -> viewModel.confirmStatusChange(state.match.matchId, state.targetStatus, reason) }
            )
        }

        if (isCreateDialogOpen) {
            CreateMatchDialog(
                onDismiss = { viewModel.closeCreateDialog() },
                onCreate = { req -> viewModel.createSingleMatch(req) }
            )
        }

        if (isBulkDialogOpen) {
            BulkMatchDialog(
                onDismiss = { viewModel.closeBulkDialog() },
                onGeneratePreview = { req -> viewModel.generateBulkPreview(req) },
                onCreateBulk = { req -> viewModel.createBulkMatches(req) }
            )
        }
    }
}

@Composable
private fun MatchesContent(
    summary: MatchSummary,
    filteredMatches: List<AdminMatchItem>,
    totalMatchesCount: Int,
    searchQuery: String,
    selectedGameFilter: String,
    selectedStatusFilter: MatchStatus?,
    isActionRequiredFilterActive: Boolean,
    onSearchChange: (String) -> Unit,
    onGameFilterChange: (String) -> Unit,
    onStatusFilterChange: (MatchStatus?) -> Unit,
    onToggleActionRequiredFilter: () -> Unit,
    onClearFilters: () -> Unit,
    onSelectMatch: (AdminMatchItem) -> Unit,
    onActionClick: (AdminMatchItem, MatchStatus) -> Unit,
    onEnterRoomCode: (AdminMatchItem) -> Unit,
    onDeleteClick: (AdminMatchItem) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Summary Cards Row
        item {
            MatchSummaryRow(
                summary = summary,
                isActionRequiredActive = isActionRequiredFilterActive,
                onToggleActionRequired = onToggleActionRequiredFilter
            )
        }

        // Search Bar & Filter Controls
        item {
            MatchFilterControls(
                searchQuery = searchQuery,
                selectedGame = selectedGameFilter,
                selectedStatus = selectedStatusFilter,
                isActionRequiredActive = isActionRequiredFilterActive,
                actionRequiredCount = summary.actionRequiredMatches,
                onSearchChange = onSearchChange,
                onGameChange = onGameFilterChange,
                onStatusChange = onStatusFilterChange,
                onToggleActionRequired = onToggleActionRequiredFilter,
                onClear = onClearFilters
            )
        }

        // Matches Feed or Empty State
        if (filteredMatches.isEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp),
                    colors = CardDefaults.cardColors(containerColor = NavySurfaceElevated),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NavyBorder))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            Icons.Default.SportsEsports,
                            contentDescription = null,
                            tint = TextMuted,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (totalMatchesCount == 0) "No Matches in Database" else "No Matching Fixtures Found",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (totalMatchesCount == 0) "Create your first Ludo or Carrom match using the button above." else "Try adjusting your search query or filter tabs.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextMuted,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }
        } else {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isActionRequiredFilterActive) "Full Matches Needing Code (${filteredMatches.size})" else "Matches (${filteredMatches.size})",
                        style = MaterialTheme.typography.labelLarge,
                        color = if (isActionRequiredFilterActive) GoldLight else TextSecondary,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            items(filteredMatches, key = { it.matchId }) { match ->
                MatchCard(
                    match = match,
                    onClick = { onSelectMatch(match) },
                    onAction = { status -> onActionClick(match, status) },
                    onDelete = { onDeleteClick(match) },
                    onEnterRoomCode = { onEnterRoomCode(match) }
                )
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun MatchSummaryRow(
    summary: MatchSummary,
    isActionRequiredActive: Boolean,
    onToggleActionRequired: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        SummaryPill(label = "Total", value = summary.totalMatches.toString(), color = TextPrimary)
        if (summary.actionRequiredMatches > 0) {
            SummaryPill(
                label = "Action Required",
                value = "${summary.actionRequiredMatches} Full",
                color = GoldLight,
                onClick = onToggleActionRequired
            )
        }
        SummaryPill(label = "Available", value = summary.availableMatches.toString(), color = StatusLive)
        SummaryPill(label = "Running", value = summary.runningMatches.toString(), color = StatusRejected)
        SummaryPill(label = "Result Pending", value = summary.resultPendingMatches.toString(), color = GoldLight)
        SummaryPill(label = "Completed", value = summary.completedMatches.toString(), color = TextMuted)
    }
}

@Composable
private fun SummaryPill(
    label: String,
    value: String,
    color: Color,
    onClick: (() -> Unit)? = null
) {
    Card(
        modifier = if (onClick != null) Modifier.clickable { onClick() } else Modifier,
        colors = CardDefaults.cardColors(containerColor = NavySurface),
        shape = RoundedCornerShape(8.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(if (onClick != null) color.copy(alpha = 0.5f) else NavyBorder))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = TextMuted)
            Text(value, style = MaterialTheme.typography.labelLarge, color = color, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun MatchFilterControls(
    searchQuery: String,
    selectedGame: String,
    selectedStatus: MatchStatus?,
    isActionRequiredActive: Boolean,
    actionRequiredCount: Int,
    onSearchChange: (String) -> Unit,
    onGameChange: (String) -> Unit,
    onStatusChange: (MatchStatus?) -> Unit,
    onToggleActionRequired: () -> Unit,
    onClear: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = NavySurface),
        shape = RoundedCornerShape(12.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NavyBorder))
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            // Search Input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("search_matches_input"),
                placeholder = { Text("Search by #number, title or room code...", color = TextMuted, style = MaterialTheme.typography.bodySmall) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextMuted) },
                trailingIcon = {
                    if (searchQuery.isNotBlank()) {
                        IconButton(onClick = { onSearchChange("") }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear search", tint = TextMuted)
                        }
                    }
                },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GoldPrimary,
                    unfocusedBorderColor = NavyBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    cursorColor = GoldPrimary
                ),
                shape = RoundedCornerShape(8.dp)
            )

            // Dedicated Filter Tab: Action Required / Full Matches
            Surface(
                onClick = onToggleActionRequired,
                shape = RoundedCornerShape(10.dp),
                color = if (isActionRequiredActive) GoldPrimary.copy(alpha = 0.2f) else NavySurfaceElevated,
                border = BorderStroke(1.dp, if (isActionRequiredActive) GoldPrimary else NavyBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("filter_tab_action_required")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(if (isActionRequiredActive) GoldPrimary.copy(alpha = 0.3f) else NavySurfaceHighlight),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.VpnKey,
                                contentDescription = null,
                                tint = if (isActionRequiredActive) GoldLight else CyanSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "Action Required / Full Matches",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (isActionRequiredActive) GoldLight else TextPrimary
                                )
                            )
                            Text(
                                text = "Fixtures needing Game Room Code injection",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = TextSecondary
                                )
                            )
                        }
                    }

                    if (actionRequiredCount > 0) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = GoldPrimary
                        ) {
                            Text(
                                text = "$actionRequiredCount NEED CODE",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    color = TextOnGold,
                                    fontSize = 10.sp
                                )
                            )
                        }
                    } else {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isActionRequiredActive) GoldPrimary.copy(alpha = 0.3f) else NavyBorder
                        ) {
                            Text(
                                text = if (isActionRequiredActive) "ACTIVE" else "FILTER",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (isActionRequiredActive) GoldLight else TextMuted
                                )
                            )
                        }
                    }
                }
            }

            // Game Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Game:", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                listOf("ALL" to "All Games", "LUDO" to "Ludo", "CARROM" to "Carrom").forEach { (key, label) ->
                    val isSelected = selectedGame.equals(key, ignoreCase = true)
                    FilterChip(
                        selected = isSelected,
                        onClick = { onGameChange(key) },
                        label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                        modifier = Modifier.testTag("filter_game_${key.lowercase()}"),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = GoldDark,
                            selectedLabelColor = GoldLight,
                            containerColor = NavySurfaceElevated,
                            labelColor = TextSecondary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = if (isSelected) GoldPrimary else NavyBorder
                        )
                    )
                }
            }

            // Status Filter Scroll
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Status:", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                val allStatuses = listOf(null) + MatchStatus.entries.filter { it != MatchStatus.UNKNOWN }
                allStatuses.forEach { status ->
                    val isSelected = selectedStatus == status
                    val label = status?.label ?: "All"
                    FilterChip(
                        selected = isSelected,
                        onClick = { onStatusChange(status) },
                        label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = if (status != null) status.badgeColor.copy(alpha = 0.2f) else NavySurfaceHighlight,
                            selectedLabelColor = status?.badgeColor ?: TextPrimary,
                            containerColor = NavySurfaceElevated,
                            labelColor = TextMuted
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = if (isSelected) (status?.badgeColor ?: GoldPrimary) else NavyBorder
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun MatchCard(
    match: AdminMatchItem,
    onClick: () -> Unit,
    onAction: (MatchStatus) -> Unit,
    onDelete: () -> Unit,
    onEnterRoomCode: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("match_card_${match.matchId}")
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = NavySurfaceElevated),
        shape = RoundedCornerShape(12.dp),
        border = if (match.needsRoomCode) {
            BorderStroke(1.5.dp, GoldPrimary)
        } else {
            CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NavyBorder))
        }
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Top Row: Number, Game Type Badge & Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = match.matchNumber,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = GoldLight
                    )
                    Surface(
                        color = if (match.displayGameType == "Carrom") CyanSecondary.copy(alpha = 0.15f) else GoldPrimary.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = match.displayGameType,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                            style = MaterialTheme.typography.labelSmall,
                            color = if (match.displayGameType == "Carrom") CyanSecondary else GoldPrimary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (match.needsRoomCode) {
                        Surface(
                            color = GoldPrimary.copy(alpha = 0.25f),
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, GoldPrimary)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.VpnKey,
                                    contentDescription = "Needs Room Code",
                                    tint = GoldLight,
                                    modifier = Modifier.size(12.dp)
                                )
                                Text(
                                    text = "NEEDS ROOM CODE",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.ExtraBold,
                                        color = GoldLight,
                                        fontSize = 10.sp
                                    )
                                )
                            }
                        }
                    }

                    Surface(
                        color = match.status.badgeColor.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = match.status.label,
                            modifier = Modifier
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                                .testTag("status_badge_${match.status.name}"),
                            style = MaterialTheme.typography.labelSmall,
                            color = match.status.badgeColor,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Title
            Text(
                text = match.title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                color = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Financial & Player Telemetry Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Entry Fee", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Text("৳${match.entryFeeTaka}", style = MaterialTheme.typography.bodyMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
                }
                Column {
                    Text("Prize Pool", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Text("৳${match.prizeTaka}", style = MaterialTheme.typography.bodyMedium, color = GoldLight, fontWeight = FontWeight.Bold)
                }
                Column {
                    Text("Players", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(Icons.Default.Group, contentDescription = null, tint = TextMuted, modifier = Modifier.size(14.dp))
                        Text(
                            text = "${match.joinedPlayersCount}/${match.maxPlayers}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (match.joinedPlayersCount >= match.maxPlayers) StatusPending else TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("Scheduled", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(Icons.Default.Schedule, contentDescription = null, tint = TextMuted, modifier = Modifier.size(12.dp))
                        Text(match.formattedScheduledTime, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    }
                }
            }

            // Room Code Bar if code is present
            if (match.gameCode.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    color = NavySurface,
                    shape = RoundedCornerShape(6.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NavyBorder))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.Gamepad, contentDescription = null, tint = CyanSecondary, modifier = Modifier.size(14.dp))
                            Text("Room Code:", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            Text(match.gameCode, style = MaterialTheme.typography.labelSmall, color = CyanSecondary, fontWeight = FontWeight.Bold)
                        }

                        val clipboard = LocalClipboardManager.current
                        val context = LocalContext.current
                        IconButton(
                            onClick = {
                                clipboard.setText(AnnotatedString(match.gameCode))
                                Toast.makeText(context, "Room code copied", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy room code", tint = TextMuted, modifier = Modifier.size(14.dp))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Bottom Action Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Tap for details & players",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextMuted
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (match.status == MatchStatus.FULL || match.status == MatchStatus.AVAILABLE || match.needsRoomCode) {
                        Button(
                            onClick = onEnterRoomCode,
                            modifier = Modifier
                                .height(32.dp)
                                .testTag("enter_room_code_btn_${match.matchId}"),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (match.needsRoomCode) GoldPrimary else CyanSecondary.copy(alpha = 0.2f),
                                contentColor = if (match.needsRoomCode) TextOnGold else CyanLight
                            ),
                            border = if (match.needsRoomCode) null else BorderStroke(1.dp, CyanSecondary.copy(alpha = 0.5f))
                        ) {
                            Icon(
                                imageVector = Icons.Default.VpnKey,
                                contentDescription = "Room Code",
                                tint = if (match.needsRoomCode) TextOnGold else CyanLight,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (match.gameCode.isBlank()) "Enter Room Code" else "Edit Code",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    if (match.status != MatchStatus.PAUSED && match.status != MatchStatus.COMPLETED && match.status != MatchStatus.CANCELLED) {
                        OutlinedButton(
                            onClick = { onAction(MatchStatus.PAUSED) },
                            modifier = Modifier.height(32.dp),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusPending),
                            border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(StatusPending))
                        ) {
                            Text("Pause", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    if (match.status != MatchStatus.CANCELLED && match.status != MatchStatus.COMPLETED) {
                        Button(
                            onClick = { onAction(MatchStatus.CANCELLED) },
                            modifier = Modifier
                                .height(32.dp)
                                .testTag("cancel_match_btn_${match.matchId}"),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = StatusRejected.copy(alpha = 0.2f),
                                contentColor = StatusRejected
                            ),
                            border = androidx.compose.foundation.BorderStroke(1.dp, StatusRejected.copy(alpha = 0.5f))
                        ) {
                            Icon(
                                Icons.Default.Cancel,
                                contentDescription = "Cancel Match",
                                tint = StatusRejected,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Cancel Match", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        }
                    } else if (match.status == MatchStatus.CANCELLED) {
                        Surface(
                            color = StatusRejected.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "CANCELLED",
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall,
                                color = StatusRejected,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Direct Delete Match action
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("delete_match_btn_${match.matchId}")
                    ) {
                        Icon(
                            Icons.Default.Delete,
                            contentDescription = "Delete Match",
                            tint = StatusRejected,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MatchDetailsDialog(
    match: AdminMatchItem,
    players: List<MatchPlayerDetails>,
    onDismiss: () -> Unit,
    onSaveGameCode: (String) -> Unit,
    onOpenRoomCodeDialog: () -> Unit = {},
    onActionTrigger: (MatchStatus) -> Unit,
    onDeleteTrigger: () -> Unit
) {
    var editCodeText by remember(match.gameCode) { mutableStateOf(match.gameCode) }
    var isEditingCode by remember { mutableStateOf(false) }
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .testTag("match_details_dialog"),
            shape = RoundedCornerShape(16.dp),
            color = NavySurfaceElevated,
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NavyBorder))
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Title & Match Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(match.matchNumber, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = GoldLight)
                        Text(match.title, style = MaterialTheme.typography.bodySmall, color = TextMuted)
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Clear, contentDescription = "Close", tint = TextMuted)
                    }
                }

                // Action Required Warning Banner when full & missing room code
                if (match.needsRoomCode) {
                    Surface(
                        color = GoldPrimary.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.5.dp, GoldPrimary)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(GoldPrimary.copy(alpha = 0.3f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.VpnKey,
                                    contentDescription = null,
                                    tint = GoldLight,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "ACTION REQUIRED: ROOM CODE NEEDED",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.ExtraBold,
                                        color = GoldLight
                                    )
                                )
                                Text(
                                    text = "Match is FULL (${match.joinedPlayersCount}/${match.maxPlayers} joined). Please input Game Room Code immediately.",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = TextPrimary
                                    )
                                )
                            }
                            Button(
                                onClick = onOpenRoomCodeDialog,
                                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = TextOnGold),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text("Input Code", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                HorizontalDivider(color = NavyBorder)

                // Financial Breakdown Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = NavySurface),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Financial Breakdown", style = MaterialTheme.typography.labelMedium, color = GoldLight, fontWeight = FontWeight.Bold)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Entry Fee (Per Player):", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                            Text("৳${match.entryFeeTaka}", style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontWeight = FontWeight.Bold)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Total Pool (2x):", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                            Text("৳${match.entryFeeTaka * 2}", style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontWeight = FontWeight.Bold)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("System Commission:", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                            Text("৳${match.commissionTaka}", style = MaterialTheme.typography.bodySmall, color = CyanSecondary, fontWeight = FontWeight.Bold)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Net Prize Pool:", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                            Text("৳${match.prizeTaka}", style = MaterialTheme.typography.bodySmall, color = GoldLight, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Room / Game Code Management Section
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = NavySurface),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Game Room Code", style = MaterialTheme.typography.labelMedium, color = CyanSecondary, fontWeight = FontWeight.Bold)
                            if (match.gameCode.isNotBlank()) {
                                IconButton(
                                    onClick = {
                                        clipboard.setText(AnnotatedString(match.gameCode))
                                        Toast.makeText(context, "Room code copied", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy Code", tint = CyanSecondary, modifier = Modifier.size(16.dp))
                                }
                            }
                        }

                        if (!isEditingCode) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (match.gameCode.isBlank()) "No room code set" else match.gameCode,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (match.gameCode.isBlank()) TextMuted else TextPrimary,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Button(
                                    onClick = { isEditingCode = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = NavySurfaceHighlight, contentColor = GoldPrimary),
                                    modifier = Modifier.height(32.dp),
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp)
                                ) {
                                    Text(if (match.gameCode.isBlank()) "Add Code" else "Edit Code", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        } else {
                            OutlinedTextField(
                                value = editCodeText,
                                onValueChange = { editCodeText = it },
                                modifier = Modifier.fillMaxWidth(),
                                placeholder = { Text("Enter room code...", color = TextMuted) },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CyanSecondary,
                                    unfocusedBorderColor = NavyBorder,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary
                                )
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TextButton(onClick = {
                                    editCodeText = match.gameCode
                                    isEditingCode = false
                                }) {
                                    Text("Cancel", color = TextMuted)
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = {
                                        if (editCodeText.trim().isNotBlank()) {
                                            onSaveGameCode(editCodeText.trim())
                                            isEditingCode = false
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = CyanSecondary, contentColor = NavyDeepest),
                                    modifier = Modifier.height(36.dp)
                                ) {
                                    Text("Save Code", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                // Participant Roster
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = NavySurface),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Joined Players (${players.size}/${match.maxPlayers})",
                            style = MaterialTheme.typography.labelMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )

                        if (players.isEmpty()) {
                            Text(
                                "No players have checked into this fixture yet.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextMuted
                            )
                        } else {
                            players.forEach { player ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(NavySurfaceElevated, RoundedCornerShape(6.dp))
                                        .padding(8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(player.username, style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontWeight = FontWeight.Bold)
                                        Text("${player.displaySlot} • ID: ${player.userId.take(8)}", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                    }
                                    Surface(
                                        color = if (player.status == "WON") StatusLive.copy(alpha = 0.2f) else NavySurface,
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = player.status,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = if (player.status == "WON") StatusLive else TextSecondary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Quick Admin State Actions
                Text("Match Administration", style = MaterialTheme.typography.labelMedium, color = TextMuted)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (match.status != MatchStatus.PAUSED && match.status != MatchStatus.COMPLETED && match.status != MatchStatus.CANCELLED) {
                        Button(
                            onClick = { onActionTrigger(MatchStatus.PAUSED) },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = StatusPending, contentColor = NavyDeepest),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Pause Match", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (match.status != MatchStatus.DISABLED && match.status != MatchStatus.COMPLETED && match.status != MatchStatus.CANCELLED) {
                        Button(
                            onClick = { onActionTrigger(MatchStatus.DISABLED) },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = NavySurfaceHighlight, contentColor = TextSecondary),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Disable", style = MaterialTheme.typography.labelSmall)
                        }
                    }

                    if (match.status != MatchStatus.CANCELLED && match.status != MatchStatus.COMPLETED) {
                        Button(
                            onClick = { onActionTrigger(MatchStatus.CANCELLED) },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = StatusRejected, contentColor = Color.White),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Cancel", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Permanent Deletion
                Button(
                    onClick = onDeleteTrigger,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(38.dp)
                        .testTag("delete_match_details_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = StatusRejected.copy(alpha = 0.18f),
                        contentColor = StatusRejected
                    ),
                    border = androidx.compose.foundation.BorderStroke(1.dp, StatusRejected.copy(alpha = 0.6f)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = null,
                        tint = StatusRejected,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        "Permanently Delete Match",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun DeleteMatchConfirmDialog(
    match: AdminMatchItem,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    Icons.Default.Warning,
                    contentDescription = null,
                    tint = StatusRejected,
                    modifier = Modifier.size(24.dp)
                )
                Text(
                    "Delete Match Permanently",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Are you sure you want to permanently delete this match? This cannot be undone.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
                Surface(
                    color = NavySurface,
                    shape = RoundedCornerShape(8.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NavyBorder))
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "Fixture #${match.matchNumber}: ${match.title}",
                            style = MaterialTheme.typography.bodySmall,
                            color = GoldLight,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Game: ${match.displayGameType} • Entry Fee: ৳${match.entryFeeTaka}",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted
                        )
                    }
                }
                Card(
                    colors = CardDefaults.cardColors(containerColor = StatusRejected.copy(alpha = 0.12f)),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(StatusRejected))
                ) {
                    Text(
                        text = "This will completely remove the match node from /matches/${match.matchId} in Firebase and record an immutable Super Admin audit log.",
                        modifier = Modifier.padding(10.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = StatusRejected
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(
                    containerColor = StatusRejected,
                    contentColor = Color.White
                ),
                modifier = Modifier.testTag("confirm_delete_match_button")
            ) {
                Text("Delete Permanently", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_delete_match_button")
            ) {
                Text("Cancel", color = TextMuted)
            }
        },
        containerColor = NavySurfaceElevated
    )
}

@Composable
private fun MatchActionConfirmDialog(
    match: AdminMatchItem,
    targetStatus: MatchStatus,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var reasonText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Confirm Match ${targetStatus.label}", color = TextPrimary, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Are you sure you want to transition match ${match.matchNumber} (${match.title}) to ${targetStatus.label.uppercase()}?",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
                if (targetStatus == MatchStatus.CANCELLED) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = StatusRejected.copy(alpha = 0.12f)),
                        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(StatusRejected))
                    ) {
                        Text(
                            text = "SECURITY NOTICE: Client-side wallet balance refund is disabled. Status will be CANCELLED and an audit log recorded. Wallet refunds require backend/Cloud Function processing.",
                            modifier = Modifier.padding(10.dp),
                            style = MaterialTheme.typography.labelSmall,
                            color = StatusRejected
                        )
                    }
                }
                OutlinedTextField(
                    value = reasonText,
                    onValueChange = { reasonText = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Reason for audit log (optional)", color = TextMuted) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = NavyBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(reasonText) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = when (targetStatus) {
                        MatchStatus.CANCELLED -> StatusRejected
                        MatchStatus.PAUSED -> StatusPending
                        else -> GoldPrimary
                    },
                    contentColor = if (targetStatus == MatchStatus.CANCELLED) Color.White else NavyDeepest
                )
            ) {
                Text("Confirm", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Dismiss", color = TextMuted)
            }
        },
        containerColor = NavySurfaceElevated
    )
}

@Composable
private fun CreateMatchDialog(
    onDismiss: () -> Unit,
    onCreate: (CreateMatchRequest) -> Unit
) {
    var selectedGame by remember { mutableStateOf("LUDO") }
    var matchNumberText by remember { mutableStateOf("#101") }
    var titleText by remember { mutableStateOf("") }
    var entryFeeText by remember { mutableStateOf("100") }
    var scheduleOffsetMinutes by remember { mutableStateOf("30") }

    val entryFeeLong = entryFeeText.toLongOrNull() ?: 0L
    val calculatedCommission = TournamentMath.calculateCommissionTaka(entryFeeLong)
    val calculatedPrize = TournamentMath.calculatePrizeTaka(entryFeeLong)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .testTag("create_match_dialog"),
            shape = RoundedCornerShape(16.dp),
            color = NavySurfaceElevated,
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NavyBorder))
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Create Tournament Match", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = GoldLight)
                Text("1v1 single fixture setup with real-time financial calculation.", style = MaterialTheme.typography.bodySmall, color = TextMuted)

                HorizontalDivider(color = NavyBorder)

                // Game Type Selector
                Text("Select Game", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    listOf("LUDO" to "Ludo", "CARROM" to "Carrom").forEach { (type, label) ->
                        val isSelected = selectedGame == type
                        Button(
                            onClick = { selectedGame = type },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSelected) GoldPrimary else NavySurface,
                                contentColor = if (isSelected) TextOnGold else TextSecondary
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(label, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
                        }
                    }
                }

                // Match Number Input
                OutlinedTextField(
                    value = matchNumberText,
                    onValueChange = { matchNumberText = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Match Number (e.g. #101)", color = TextMuted) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = NavyBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                // Custom Title (Optional)
                OutlinedTextField(
                    value = titleText,
                    onValueChange = { titleText = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Custom Title (Optional)", color = TextMuted) },
                    placeholder = { Text("${if (selectedGame == "LUDO") "Ludo" else "Carrom"} 1v1 $matchNumberText", color = TextMuted) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = NavyBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                // Entry Fee Input in Taka
                OutlinedTextField(
                    value = entryFeeText,
                    onValueChange = { entryFeeText = it.filter { char -> char.isDigit() } },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Entry Fee (৳ BDT)", color = TextMuted) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = NavyBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                // Live Calculation Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = NavySurface),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Max Players:", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                            Text("2 (Strict 1v1)", style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontWeight = FontWeight.Bold)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Total Entry Pool (2x):", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                            Text("৳${entryFeeLong * 2}", style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontWeight = FontWeight.Bold)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Commission Deduction:", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                            Text("৳$calculatedCommission", style = MaterialTheme.typography.bodySmall, color = CyanSecondary, fontWeight = FontWeight.Bold)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Calculated Winner Prize:", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                            Text("৳$calculatedPrize", style = MaterialTheme.typography.bodySmall, color = GoldLight, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Schedule Offset
                OutlinedTextField(
                    value = scheduleOffsetMinutes,
                    onValueChange = { scheduleOffsetMinutes = it.filter { char -> char.isDigit() } },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Starts in (Minutes from now)", color = TextMuted) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = NavyBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = TextMuted)
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Button(
                        onClick = {
                            val cleanNumber = matchNumberText.trim()
                            if (cleanNumber.isNotBlank() && entryFeeLong >= 0) {
                                val offsetMinutes = scheduleOffsetMinutes.toLongOrNull() ?: 30L
                                val scheduledTime = System.currentTimeMillis() + (offsetMinutes * 60 * 1000L)
                                val finalTitle = titleText.trim().ifEmpty {
                                    "${if (selectedGame == "LUDO") "Ludo" else "Carrom"} 1v1 $cleanNumber"
                                }
                                onCreate(
                                    CreateMatchRequest(
                                        gameType = selectedGame,
                                        matchNumber = cleanNumber,
                                        title = finalTitle,
                                        entryFeeTaka = entryFeeLong,
                                        scheduledTimestamp = scheduledTime,
                                        maxPlayers = TournamentMath.MAX_PLAYERS
                                    )
                                )
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = TextOnGold),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Create Match", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun BulkMatchDialog(
    onDismiss: () -> Unit,
    onGeneratePreview: (BulkMatchRequest) -> List<BulkMatchPreviewItem>,
    onCreateBulk: (BulkMatchRequest) -> Unit
) {
    var quantityText by remember { mutableStateOf("5") }
    var selectedGame by remember { mutableStateOf("LUDO") }
    var entryFeeText by remember { mutableStateOf("100") }
    var startingNumberText by remember { mutableStateOf("201") }
    var intervalMinutesText by remember { mutableStateOf("30") }
    var previewList by remember { mutableStateOf<List<BulkMatchPreviewItem>?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val quantityInt = quantityText.toIntOrNull() ?: 0
    val entryFeeLong = entryFeeText.toLongOrNull() ?: 0L
    val intervalInt = intervalMinutesText.toIntOrNull() ?: 30

    fun buildRequest(): BulkMatchRequest? {
        if (quantityInt !in 1..50) {
            errorMessage = "Quantity must be between 1 and 50."
            return null
        }
        if (startingNumberText.trim().isBlank()) {
            errorMessage = "Starting match number is required."
            return null
        }
        errorMessage = null
        return BulkMatchRequest(
            quantity = quantityInt,
            gameType = selectedGame,
            entryFeeTaka = entryFeeLong,
            startingNumber = startingNumberText.trim(),
            scheduledStartTimestamp = System.currentTimeMillis() + (30 * 60 * 1000L),
            intervalMinutes = intervalInt,
            maxPlayers = TournamentMath.MAX_PLAYERS
        )
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .testTag("bulk_matches_dialog"),
            shape = RoundedCornerShape(16.dp),
            color = NavySurfaceElevated,
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NavyBorder))
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Bulk Match Generator", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = CyanSecondary)
                Text("Generate sequential tournament fixtures with automated intervals.", style = MaterialTheme.typography.bodySmall, color = TextMuted)

                HorizontalDivider(color = NavyBorder)

                // Game Type
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    listOf("LUDO" to "Ludo", "CARROM" to "Carrom").forEach { (type, label) ->
                        val isSelected = selectedGame == type
                        Button(
                            onClick = { selectedGame = type; previewList = null },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSelected) CyanSecondary else NavySurface,
                                contentColor = if (isSelected) NavyDeepest else TextSecondary
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(label, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
                        }
                    }
                }

                // Quantity & Starting Number
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = quantityText,
                        onValueChange = { quantityText = it.filter { c -> c.isDigit() }; previewList = null },
                        modifier = Modifier.weight(1f),
                        label = { Text("Quantity (1-50)", color = TextMuted) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanSecondary,
                            unfocusedBorderColor = NavyBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )
                    OutlinedTextField(
                        value = startingNumberText,
                        onValueChange = { startingNumberText = it; previewList = null },
                        modifier = Modifier.weight(1f),
                        label = { Text("Start Number", color = TextMuted) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanSecondary,
                            unfocusedBorderColor = NavyBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )
                }

                // Entry Fee & Interval
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = entryFeeText,
                        onValueChange = { entryFeeText = it.filter { c -> c.isDigit() }; previewList = null },
                        modifier = Modifier.weight(1f),
                        label = { Text("Entry Fee (৳ BDT)", color = TextMuted) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanSecondary,
                            unfocusedBorderColor = NavyBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )
                    OutlinedTextField(
                        value = intervalMinutesText,
                        onValueChange = { intervalMinutesText = it.filter { c -> c.isDigit() }; previewList = null },
                        modifier = Modifier.weight(1f),
                        label = { Text("Interval (Min)", color = TextMuted) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanSecondary,
                            unfocusedBorderColor = NavyBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )
                }

                // Error notice if validation fails
                errorMessage?.let {
                    Text(it, color = StatusRejected, style = MaterialTheme.typography.bodySmall)
                }

                // Preview Button
                OutlinedButton(
                    onClick = {
                        val req = buildRequest()
                        if (req != null) {
                            try {
                                previewList = onGeneratePreview(req)
                            } catch (e: Exception) {
                                errorMessage = e.message
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CyanSecondary),
                    border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(CyanSecondary)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.FilterList, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Preview Generated Batch")
                }

                // Preview Box
                previewList?.let { items ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = NavySurface),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                "Previewing ${items.size} Sequential Fixtures:",
                                style = MaterialTheme.typography.labelMedium,
                                color = GoldLight,
                                fontWeight = FontWeight.Bold
                            )
                            items.take(4).forEach { item ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(item.matchNumber, style = MaterialTheme.typography.labelSmall, color = TextPrimary, fontWeight = FontWeight.Bold)
                                    Text(item.formattedTime, style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                    Text("Prize: ৳${item.prizeTaka}", style = MaterialTheme.typography.labelSmall, color = GoldLight)
                                }
                            }
                            if (items.size > 4) {
                                Text(
                                    "+ ${items.size - 4} more scheduled fixtures...",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextMuted
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = TextMuted)
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Button(
                        onClick = {
                            val req = buildRequest()
                            if (req != null) {
                                onCreateBulk(req)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyanSecondary, contentColor = NavyDeepest),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Generate All Matches", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun RoomCodeInjectionDialog(
    match: AdminMatchItem,
    onDismiss: () -> Unit,
    onSubmit: (String) -> Unit
) {
    var codeInput by remember(match.gameCode) { mutableStateOf(match.gameCode) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(GoldPrimary.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.VpnKey,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Column {
                    Text(
                        text = "Input Game Room Code",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "Match ${match.matchNumber} • ${match.displayGameType}",
                        style = MaterialTheme.typography.bodySmall,
                        color = GoldLight
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Match details recap card
                Card(
                    colors = CardDefaults.cardColors(containerColor = NavySurfaceHighlight),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = match.title,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f, fill = false)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                color = if (match.needsRoomCode) GoldPrimary.copy(alpha = 0.25f) else StatusLive.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(4.dp),
                                border = if (match.needsRoomCode) BorderStroke(1.dp, GoldPrimary) else null
                            ) {
                                Text(
                                    text = if (match.needsRoomCode) "2/2 FULL - CODE NEEDED" else "${match.joinedPlayersCount}/${match.maxPlayers} JOINED",
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (match.needsRoomCode) GoldLight else StatusLive,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        Text(
                            text = "Create the private game room inside ${if (match.displayGameType == "Carrom") "Carrom King / Disc Pool" else "Ludo King"} and paste the generated room code below. This will instantly push the room code to both players and update match status to CODE_ADDED.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }

                // Input field
                OutlinedTextField(
                    value = codeInput,
                    onValueChange = {
                        codeInput = it
                        if (errorMessage != null) errorMessage = null
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("room_code_input"),
                    label = { Text("Game Room Code *") },
                    placeholder = { Text("e.g. 04829104") },
                    leadingIcon = {
                        Icon(Icons.Default.VpnKey, contentDescription = null, tint = GoldPrimary)
                    },
                    trailingIcon = {
                        IconButton(
                            onClick = {
                                val clipText = clipboard.getText()?.text
                                if (!clipText.isNullOrBlank()) {
                                    codeInput = clipText.trim()
                                    errorMessage = null
                                    Toast.makeText(context, "Pasted from clipboard", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "Clipboard is empty", Toast.LENGTH_SHORT).show()
                                }
                            }
                        ) {
                            Icon(Icons.Default.ContentPaste, contentDescription = "Paste from clipboard", tint = CyanSecondary)
                        }
                    },
                    isError = errorMessage != null,
                    supportingText = errorMessage?.let { { Text(it, color = StatusRejected) } },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = NavyBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = GoldPrimary
                    ),
                    shape = RoundedCornerShape(8.dp)
                )

                Text(
                    text = "Live RTDB Path: /matches/${match.matchId}/gameCode",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextMuted,
                    fontSize = 11.sp
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val clean = codeInput.trim()
                    if (clean.isBlank()) {
                        errorMessage = "Please enter a valid, non-blank room code."
                    } else {
                        onSubmit(clean)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = TextOnGold),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("submit_room_code_button")
            ) {
                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Inject & Notify Players", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("cancel_room_code_button")
            ) {
                Text("Cancel", color = TextSecondary)
            }
        },
        containerColor = NavySurfaceElevated,
        shape = RoundedCornerShape(16.dp)
    )
}
