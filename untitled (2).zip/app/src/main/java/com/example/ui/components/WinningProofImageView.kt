package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BrokenImage
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.rememberAsyncImagePainter
import com.example.core.util.ScreenshotImageUtils

/**
 * Renders a winning proof screenshot safely, supporting:
 * 1. Base64 Data URIs (e.g., data:image/jpeg;base64,...)
 * 2. Raw Base64 image payloads
 * 3. Standard HTTP/HTTPS image URLs
 *
 * If the screenshot is missing, empty, or cannot be decoded, it safely renders
 * a "Screenshot unavailable" state without crashing and never displays raw Base64 text.
 */
@Composable
fun WinningProofImageView(
    screenshotDataOrUrl: String,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Fit,
    contentDescription: String = "Winning Screenshot Proof",
    onClick: (() -> Unit)? = null
) {
    if (screenshotDataOrUrl.isBlank()) {
        ScreenshotUnavailablePlaceholder(modifier = modifier)
        return
    }

    val trimmed = screenshotDataOrUrl.trim()
    val isHttpUrl = trimmed.startsWith("http://", ignoreCase = true) || trimmed.startsWith("https://", ignoreCase = true)

    if (isHttpUrl) {
        val painter = rememberAsyncImagePainter(model = trimmed)
        Box(
            modifier = modifier
                .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painter,
                contentDescription = contentDescription,
                modifier = Modifier.fillMaxSize(),
                contentScale = contentScale
            )
        }
    } else {
        // Base64 Data URI or raw Base64 string
        val bitmap = remember(trimmed) {
            ScreenshotImageUtils.decodeBase64ToBitmap(trimmed)
        }

        if (bitmap != null) {
            Box(
                modifier = modifier
                    .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = contentDescription,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = contentScale
                )
            }
        } else {
            ScreenshotUnavailablePlaceholder(modifier = modifier)
        }
    }
}

/**
 * Zoomable full-screen image viewer supporting pinch-to-zoom and pan.
 */
@Composable
fun ZoomableWinningProofImageView(
    screenshotDataOrUrl: String,
    modifier: Modifier = Modifier,
    contentDescription: String = "Full Size Winning Screenshot Proof"
) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    val transformState = rememberTransformableState { zoomChange, offsetChange, _ ->
        scale = (scale * zoomChange).coerceIn(1f, 5f)
        if (scale > 1f) {
            offset += offsetChange
        } else {
            offset = Offset.Zero
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .transformable(state = transformState),
        contentAlignment = Alignment.Center
    ) {
        WinningProofImageView(
            screenshotDataOrUrl = screenshotDataOrUrl,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    translationX = offset.x
                    translationY = offset.y
                },
            contentScale = ContentScale.Fit,
            contentDescription = contentDescription
        )
    }
}

/**
 * Safe, graceful fallback state shown when screenshot is missing or corrupted.
 */
@Composable
fun ScreenshotUnavailablePlaceholder(
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 140.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.BrokenImage,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.outline,
                    modifier = Modifier.size(36.dp)
                )
                Text(
                    text = "Screenshot unavailable",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
