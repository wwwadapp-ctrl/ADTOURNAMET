package com.example.core.model

/**
 * Payment Provider types supported for dynamic deposit and withdrawal operations.
 */
enum class PaymentProvider(val displayName: String, val brandTag: String) {
    BKASH("bKash", "BKASH"),
    NAGAD("Nagad", "NAGAD"),
    ROCKET("Rocket", "ROCKET");

    companion object {
        fun fromString(value: String?): PaymentProvider {
            val normalized = value?.trim()?.uppercase() ?: return BKASH
            return when {
                normalized.contains("NAGAD") -> NAGAD
                normalized.contains("ROCKET") -> ROCKET
                else -> BKASH
            }
        }
    }
}

/**
 * Account type for payment processing (Personal, Agent, or Merchant).
 */
enum class PaymentAccountType(val displayName: String) {
    PERSONAL("Personal"),
    AGENT("Agent"),
    MERCHANT("Merchant");

    companion object {
        fun fromString(value: String?): PaymentAccountType {
            val normalized = value?.trim()?.uppercase() ?: return PERSONAL
            return when {
                normalized.contains("AGENT") -> AGENT
                normalized.contains("MERCHANT") -> MERCHANT
                else -> PERSONAL
            }
        }
    }
}

/**
 * Represents a payment method/number entry managed by Super Admin and broadcast under /appSettings.
 */
data class PaymentNumberItem(
    val id: String = "",
    val method: String = "bKash",
    val number: String = "",
    val type: String = "Personal", // Personal, Agent, Merchant
    val isActive: Boolean = true,
    val instructions: String = "",
    val updatedAt: Long = 0L,
    val updatedBy: String = ""
) {
    val provider: PaymentProvider
        get() = PaymentProvider.fromString(method)

    val accountType: PaymentAccountType
        get() = PaymentAccountType.fromString(type)
}

/**
 * Aggregate model for tournament application settings broadcast via /appSettings.
 */
data class AppSettingsData(
    val bkashNumber: String = "",
    val bkashType: String = "Personal",
    val nagadNumber: String = "",
    val nagadType: String = "Personal",
    val paymentNumbers: List<PaymentNumberItem> = emptyList(),
    val isDepositActive: Boolean = true,
    val isWithdrawActive: Boolean = true,
    val minDepositTaka: Long = 50L,
    val minWithdrawTaka: Long = 100L,
    val noticeBanner: String = "",
    val howToJoinVideoUrl: String = "",
    val howToDepositVideoUrl: String = "",
    val howToSubmitResultVideoUrl: String = "",
    val tournamentRulesVideoUrl: String = "",
    val customBannerImageUrl: String = "",
    val updatedAt: Long = 0L
)

/**
 * Typealias alias for AppSettingsData aligning with architectural naming standards.
 */
typealias AppSettingsEntity = AppSettingsData
