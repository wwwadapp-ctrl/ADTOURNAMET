package com.example.domain.model

import com.google.firebase.database.IgnoreExtraProperties

enum class AccountStatus {
  ACTIVE,
  BLOCKED
}

@IgnoreExtraProperties
data class UserEntity(
  val uid: String = "",
  val name: String = "",
  val mobileNumber: String = "",
  val joinDate: Long = 0L,
  val status: String = AccountStatus.ACTIVE.name,
  val profilePhotoUrl: String? = null,
  val userId: String = uid,
  val fullName: String = name,
  val profilePhoto: String = profilePhotoUrl ?: "",
  val accountStatus: String = status,
  val totalMatches: Int = 0,
  val wins: Int = 0,
  val losses: Int = 0,
  val role: String = "PLAYER",
  val lastActiveAt: Long = 0L,
  val savedBkashNumber: String = "",
  val savedNagadNumber: String = "",
  val displayName: String = name.ifEmpty { fullName },
  val phoneNumber: String = mobileNumber,
  val avatarUrl: String = profilePhotoUrl ?: profilePhoto,
  val isBlocked: Boolean = status.equals(AccountStatus.BLOCKED.name, ignoreCase = true) ||
      accountStatus.equals(AccountStatus.BLOCKED.name, ignoreCase = true),
  val createdAt: Long = joinDate,
  // Raw fields from Firebase (might store Paisa but typed as Double)
  val walletBalance: Double = 0.0,
  val totalWinnings: Double = 0.0,
) {
  val effectiveName: String get() = name.ifEmpty { fullName.ifEmpty { displayName.ifEmpty { "Player" } } }
  val effectiveMobile: String get() = mobileNumber.ifEmpty { phoneNumber }
  val effectivePhoto: String get() = profilePhotoUrl ?: profilePhoto.ifEmpty { avatarUrl }
  val isAccountBlocked: Boolean get() = isBlocked ||
      status.equals(AccountStatus.BLOCKED.name, ignoreCase = true) ||
      accountStatus.equals(AccountStatus.BLOCKED.name, ignoreCase = true)

  // Derived properties that always return Taka (dividing by 100 if stored as Paisa)
  val walletBalanceAmount: Double get() = if (walletBalance >= 100.0) walletBalance / 100.0 else walletBalance
  val totalWinningsAmount: Double get() = if (totalWinnings >= 100.0) totalWinnings / 100.0 else totalWinnings
  
  // Public accessors for UI to use
  fun getDisplayWalletBalance(): Double = walletBalanceAmount
  fun getDisplayTotalWinnings(): Double = totalWinningsAmount
}

@IgnoreExtraProperties
data class WalletEntity(
  val uid: String = "",
  val availableBalance: Long = 0L,
  val pendingBalance: Long = 0L,
  val totalDeposited: Long = 0L,
  val totalWithdrawn: Long = 0L,
  val totalWinnings: Long = 0L,
  val updatedAt: Long = 0L,
  val walletId: String = uid,
  val userId: String = uid,
  // Internal fields to capture Firebase Double fields if they exist
  val balance: Double = 0.0,
  val winningBalance: Double = 0.0,
  val lockedBalance: Double = 0.0,
  val bonusBalance: Double = 0.0,
) {
  val availableAmount: Double get() = availableBalance / 100.0
  val pendingAmount: Double get() = pendingBalance / 100.0
  val totalDepositedAmount: Double get() = totalDeposited / 100.0
  val totalWithdrawnAmount: Double get() = totalWithdrawn / 100.0
  
  // Correctly derived balance and winningBalance
  val balanceAmount: Double get() = if (availableBalance > 0L) availableBalance / 100.0 else if (balance >= 100.0) balance / 100.0 else balance
  val winningsAmount: Double get() = if (totalWinnings > 0L) totalWinnings / 100.0 else if (winningBalance >= 100.0) winningBalance / 100.0 else winningBalance
  
  val effectiveTotalWinnings: Double get() = winningsAmount
  val totalWinningsAmount: Double get() = winningsAmount
}

enum class TransactionType {
  DEPOSIT,
  WITHDRAW,
  WITHDRAW_HOLD,
  WITHDRAW_RELEASE,
  MATCH_ENTRY,
  MATCH_JOIN,
  MATCH_REFUND,
  MATCH_PRIZE,
  ADMIN_CREDIT,
  ADMIN_DEBIT,
  COMMISSION,
  WITHDRAWAL,
  MATCH_ENTRY_FEE,
  MATCH_PRIZE_CREDIT,
  REFUND,
  ADMIN_ADJUSTMENT
}

enum class TransactionStatus {
  PENDING,
  COMPLETED,
  FAILED,
  CANCELLED
}

@IgnoreExtraProperties
data class TransactionEntity(
  val transactionId: String = "",
  val uid: String = "",
  val amount: Long = 0L,
  val type: String = TransactionType.DEPOSIT.name,
  val status: String = TransactionStatus.PENDING.name,
  val beforeBalance: Long = 0L,
  val afterBalance: Long = 0L,
  val source: String = "APP",
  val referenceId: String = "",
  val description: String = "",
  val createdAt: Long = 0L,
  val processedAt: Long = 0L,
  val walletId: String = uid,
  val userId: String = uid,
) {
  val amountInCurrency: Double get() = amount / 100.0
  val beforeBalanceInCurrency: Double get() = beforeBalance / 100.0
  val afterBalanceInCurrency: Double get() = afterBalance / 100.0
}

enum class GameType {
  LUDO,
  CARROM
}

enum class MatchStatus {
  AVAILABLE,
  FULL,
  CODE_ADDED,
  RUNNING,
  RESULT_SUBMITTED,
  COMPLETED,
  PAUSED,
  DISABLED,
  CANCELLED,
  UPCOMING
}

@IgnoreExtraProperties
data class MatchEntity(
  val matchId: String = "",
  val matchNumber: String = "",
  val title: String = "",
  val gameType: String = GameType.LUDO.name,
  val entryFee: Double = 0.0,
  val prizePool: Double = 0.0,
  val status: String = MatchStatus.AVAILABLE.name,
  val gameCode: String = "",
  val isCodeVisible: Boolean = false,
  val scheduledTime: Long = 0L,
  val maxPlayers: Int = 2,
  val joinedPlayersCount: Int = 0,
  val winnerUserId: String = "",
  val createdByAdminId: String = "",
  val createdAt: Long = 0L,
  val entryFeeMinorUnits: Long = 0L,
  val prizeMinorUnits: Long = 0L,
  val scheduledAt: Long = 0L,
  val updatedAt: Long = 0L,
  val startedAt: Long? = null,
  val cancelReason: String? = null,
) {
  val effectiveEntryFeeMinorUnits: Long
    get() = maxOf(entryFeeMinorUnits, (entryFee * 100).toLong())
  val effectivePrizeMinorUnits: Long
    get() = maxOf(prizeMinorUnits, (prizePool * 100).toLong())
  val effectiveScheduledAt: Long
    get() = if (scheduledAt > 0L) scheduledAt else scheduledTime
  val effectiveUpdatedAt: Long
    get() = if (updatedAt > 0L) updatedAt else createdAt
  val displayEntryFee: Double
    get() = if (entryFee > 0.0) entryFee else effectiveEntryFeeMinorUnits / 100.0
  val displayPrizePool: Double
    get() = if (prizePool > 0.0) prizePool else effectivePrizeMinorUnits / 100.0
}

enum class PlayerSlot {
  PLAYER_1,
  PLAYER_2
}

@IgnoreExtraProperties
data class MatchPlayerEntity(
  val matchPlayerId: String = "",
  val matchId: String = "",
  val userId: String = "",
  val username: String = "",
  val slot: String = PlayerSlot.PLAYER_1.name,
  val joinedAt: Long = 0L,
  val isReady: Boolean = false,
  val uid: String = userId,
  val entryFeeMinorUnits: Long = 0L,
  val status: String = "JOINED",
) {
  val effectiveUid: String get() = uid.ifEmpty { userId }
}

@IgnoreExtraProperties
data class UserMatchHistoryEntity(
  val matchId: String = "",
  val userId: String = "",
  val uid: String = userId,
  val joinedAt: Long = 0L,
  val status: String = "JOINED", // JOINED, RESULT_SUBMITTED, COMPLETED, REJECTED, CANCELLED
  val isWinner: Boolean? = null,
  val updatedAt: Long = 0L,
  val gameType: String = GameType.LUDO.name,
  val matchNumber: String = "",
  val title: String = "",
  val entryFeeMinorUnits: Long = 0L,
  val prizeMinorUnits: Long = 0L,
  val opponentName: String = "",
  val opponentUserId: String = "",
) {
  val effectiveUid: String get() = uid.ifEmpty { userId }
}

enum class ResultStatus {
  PENDING_REVIEW,
  APPROVED,
  REJECTED
}

@IgnoreExtraProperties
data class ResultEntity(
  val resultId: String = "",
  val matchId: String = "",
  val submittedByUserId: String = "",
  val userId: String = submittedByUserId,
  val claimedWinnerUserId: String = "",
  val proofScreenshotUrl: String = "",
  val status: String = ResultStatus.PENDING_REVIEW.name,
  val reviewNotes: String = "",
  val reviewedByAdminId: String = "",
  val submittedAt: Long = 0L,
  val reviewedAt: Long = 0L,
  val matchNumber: String = "",
  val gameType: String = "",
  val createdAt: Long = submittedAt,
)

enum class DepositStatus {
  SUBMITTED,
  PENDING,
  APPROVED,
  REJECTED,
  VERIFYING
}

@IgnoreExtraProperties
data class DepositEntity(
  val depositId: String = "",
  val uid: String = "",
  val amount: Long = 0L,
  val method: String = "BKASH",
  val senderNumber: String = "",
  val trxId: String = "",
  val screenshotUrl: String = "",
  val status: String = DepositStatus.SUBMITTED.name,
  val createdAt: Long = 0L,
  val processedAt: Long = 0L,
  val rejectionReason: String = "",
  val adminUid: String = "",
  val userId: String = uid,
  val paymentMethod: String = method,
  val transactionReference: String = trxId,
  val screenshotProofUrl: String = screenshotUrl,
  val approvedAt: Long = processedAt,
) {
  val amountInCurrency: Double get() = amount / 100.0
}

enum class WithdrawalStatus {
  REQUESTED,
  PENDING,
  APPROVED,
  REJECTED,
  PROCESSING,
  COMPLETED
}

@IgnoreExtraProperties
data class WithdrawalEntity(
  val withdrawalId: String = "",
  val uid: String = "",
  val amount: Long = 0L,
  val method: String = "BKASH",
  val recipientNumber: String = "",
  val status: String = WithdrawalStatus.REQUESTED.name,
  val createdAt: Long = 0L,
  val processedAt: Long = 0L,
  val rejectionReason: String = "",
  val adminUid: String = "",
  val userId: String = uid,
  val paymentMethod: String = method,
  val paymentDetails: String = recipientNumber,
  val requestedAt: Long = createdAt,
) {
  val amountInCurrency: Double get() = amount / 100.0
}

@IgnoreExtraProperties
data class NotificationEntity(
  val notificationId: String = "",
  val userId: String = "",
  val title: String = "",
  val body: String = "",
  val targetScreen: String = "",
  val isRead: Boolean = false,
  val createdAt: Long = 0L,
)

@IgnoreExtraProperties
data class AdminUserEntity(
  val adminId: String = "",
  val userId: String = "",
  val email: String = "",
  val role: String = "MODERATOR",
  val permissions: List<String> = emptyList(),
  val isActive: Boolean = true,
  val createdAt: Long = 0L,
)

@IgnoreExtraProperties
data class AuditLogEntity(
  val logId: String = "",
  val action: String = "",
  val adminUid: String = "",
  val targetUid: String = "",
  val beforeState: String = "",
  val afterState: String = "",
  val timestamp: Long = 0L,
  val ipAddress: String = "",
  val performedByUserId: String = adminUid,
  val targetEntityId: String = targetUid,
  val targetEntityType: String = "",
  val details: String = "$beforeState -> $afterState",
)

@IgnoreExtraProperties
data class FinanceSettingsEntity(
  val minDeposit: Long = 5000L,
  val maxDeposit: Long = 2500000L,
  val minWithdraw: Long = 20000L,
  val maxWithdraw: Long = 1000000L,
  val depositFeePercent: Double = 0.0,
  val withdrawFeePercent: Double = 0.0,
  val commissionRate: Double = 10.0,
  val bkashNumber: String = "01700000000",
  val nagadNumber: String = "01800000000",
  val depositInstructions: String = "Send Money (Personal) to the official bKash/Nagad number, then submit your transaction ID and proof.",
) {
  val minDepositAmount: Double get() = minDeposit / 100.0
  val maxDepositAmount: Double get() = maxDeposit / 100.0
  val minWithdrawAmount: Double get() = minWithdraw / 100.0
  val maxWithdrawAmount: Double get() = maxWithdraw / 100.0
}

@IgnoreExtraProperties
data class AppSettingsEntity(
  val minDepositAmount: Double = 50.0,
  val minWithdrawalAmount: Double = 200.0,
  val platformCommissionPercent: Double = 10.0,
  val maintenanceMode: Boolean = false,
  val supportWhatsappNumber: String = "",
  val supportTelegramUrl: String = "",
  val appVersionCode: Int = 1,
  val finance: FinanceSettingsEntity = FinanceSettingsEntity(),
  val bkashNumber: String = "01700000000",
  val nagadNumber: String = "01800000000",
  val depositInstructions: String = "",
  val withdrawalInstructions: String = "",
  val howToJoinVideoUrl: String = "",
  val howToDepositVideoUrl: String = "",
  val howToSubmitResultVideoUrl: String = "",
  val tournamentRulesVideoUrl: String = "",
  val customBannerImageUrl: String = "",
  val depositBannerImageUrl: String = "",
  val matchJoinBannerImageUrl: String = "",
  val resultSubmitBannerImageUrl: String = "",
  val rulesBannerImageUrl: String = "",
  val announcementMessage: String = "",
  val announcementActive: Boolean = false,
) {
  val effectiveBkashNumber: String
    get() = bkashNumber.ifBlank { finance.bkashNumber }.ifBlank { "01700000000" }

  val effectiveNagadNumber: String
    get() = nagadNumber.ifBlank { finance.nagadNumber }.ifBlank { "01800000000" }
}

